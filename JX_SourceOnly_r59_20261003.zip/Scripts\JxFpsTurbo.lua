
local FT = { version = "1.0" }
_G.JxFpsTurbo = FT

local Log = (type(JX) == "table" and JX.Log) or function(s) print("[JxFpsTurbo] " .. tostring(s)) end
local function Say(s) print("[JxFpsTurbo] " .. tostring(s)) end

FT.enabled      = true          
FT.targetFPS    = 60            
FT.floorSP      = 60            
FT.samples      = {}            
FT.maxSamples   = 16
FT.curSP        = nil           
FT.baseSP       = nil           
FT.worldAge     = 0             
FT.paused       = false         
FT.tickCount    = 0
FT.lastStep     = 0             

local WORLDS = { 500, 8 }       
                                
local function nowWall()
    local t = nil
    pcall(function()
        local w = FindFirstOf("World")
        if w and w:IsValid() then
            local ok, v = pcall(function() return w:GetRealTimeSeconds() end)
            if ok and type(v) == "number" and v > 0 then t = v end
            if not t then
                
                local ok2, v2 = pcall(function() return w.RealTimeSeconds end)
                if ok2 and type(v2) == "number" and v2 > 0 then t = v2 end
            end
        end
    end)
    if t then return t end
    return os.time()            
end

local function exec(cmd)
    
    pcall(function()
        if type(JXQueue) == "function" then JXQueue({ cmd }); return end
        if type(ExecuteConsoleCommand) == "function" then ExecuteConsoleCommand(cmd); return end
        local PC = UEHelpers.GetPlayerController()
        if PC and PC:IsValid() then PC:ExecuteConsoleCommandInGame(cmd) end
    end)
end

local function readCVarNum(name)
    local v = nil
    pcall(function()
        local k = StaticFindObject("/Script/Engine.Default__KismetSystemLibrary")
        if k and k:IsValid() then
            local ok, r = pcall(function() return k:GetConsoleVariableFloatValue(name) end)
            if ok and type(r) == "number" then v = r end
        end
    end)
    return v
end

local function writeSP(pct)
    pct = math.floor(pct + 0.5)
    if pct < FT.floorSP then pct = FT.floorSP end
    if FT.baseSP and pct > FT.baseSP then pct = FT.baseSP end
    if FT.curSP == pct then return end
    exec("r.ScreenPercentage " .. pct)
    FT.curSP = pct
    Log(string.format("SP -> %d (target %d fps, floor %d)", pct, FT.targetFPS, FT.floorSP))
end

local lastReal = nil
local function measureFrameDt()
    local dt = nil
    pcall(function()
        local w = FindFirstOf("World")
        if w and w:IsValid() then
            local ok, v = pcall(function() return w:GetDeltaSeconds() end)
            if ok and type(v) == "number" and v > 0 and v < 10 then dt = v end
            if not dt then
                
                local ok2, v2 = pcall(function() return w.DeltaSeconds end)
                if ok2 and type(v2) == "number" and v2 > 0 and v2 < 10 then dt = v2 end
            end
            if not dt then
                local ok3, rt = pcall(function() return w:GetRealTimeSeconds() end)
                if ok3 and type(rt) == "number" and rt > 0 then
                    if lastReal then dt = math.abs(rt - lastReal) end
                    lastReal = rt
                end
            end
        end
    end)
    return dt
end

local function pushSample(sec)
    if sec <= 0 or sec > 10 then return end          
    FT.samples[#FT.samples + 1] = sec
    if #FT.samples > FT.maxSamples then table.remove(FT.samples, 1) end
end

local function avgFrameTime()
    local n, sum = #FT.samples, 0
    if n < 4 then return nil end                     
    for _, s in ipairs(FT.samples) do sum = sum + s end
    return sum / n
end

local function adapt()
    if not FT.enabled or FT.paused then return end
    if type(JXBusy) == "function" and JXBusy() then return end
    if FT.worldAge < 30 then return end              
    local aft = avgFrameTime()
    if not aft then return end
    local t = nowWall()
    if FT.lastStep > t then FT.lastStep = t end   
    if t - FT.lastStep < 4 then return end           
    local targetSec = 1 / math.max(FT.targetFPS, 10)
    local cur = FT.curSP or FT.baseSP or 100
    if aft > targetSec * 1.25 then
        
        writeSP(cur - 10)
        FT.lastStep = t
    elseif aft < targetSec * 0.75 and cur < (FT.baseSP or 100) then
        
        writeSP(cur + 10)
        FT.lastStep = t
    end
end

local function gcTune()
    
    pcall(function()
        if collectgarbage("isrunning") then
            collectgarbage("setpause", 200)
            collectgarbage("setstepmul", 300)
        end
    end)
end
local function gcStep()
    pcall(function() collectgarbage("step", 24) end)
end

local function tick(deltaMs)
    FT.tickCount = FT.tickCount + 1
    FT.worldAge = FT.worldAge + (deltaMs or 500) / 1000
    
    local dt = measureFrameDt()
    if dt then pushSample(dt) end
    if FT.enabled then
        
        gcStep()
        if type(ExecuteInGameThread) == "function" then
            ExecuteInGameThread(function() pcall(adapt) end)
        else
            pcall(adapt)
        end
    end
end

local function reportLine()
    local aft = avgFrameTime()
    local fps = aft and string.format("%.1f", 1 / aft) or "n/a"
    local sp = readCVarNum("r.ScreenPercentage") or FT.curSP or -1
    return string.format(
        "avg %s fps | SP=%.0f%% | mode=%s | target=%d | floor=%d | samples=%d | uptime=%.0fs",
        fps, sp,
        FT.paused and "manual" or (FT.enabled and "turbo" or "off"),
        FT.targetFPS, FT.floorSP, #FT.samples, FT.worldAge)
end

local function writeFile(line)
    pcall(function()
        local base = _G.JXSidecarDir or ""
        local f = io.open(base .. "jx_fps.txt", "w")
        if f then
            f:write("JxFpsTurbo v" .. FT.version .. " @ " .. os.date("%Y-%m-%d %H:%M:%S") .. "\n")
            f:write(line .. "\n")
            f:close()
        end
    end)
end

if type(JXRegCmd) == "function" then
    JXRegCmd("jfps", function(FullCommand, Parameters, Ar)
        local sub = (Parameters and Parameters[1] or ""):lower()
        if sub == "turbo" or sub == "on" then
            FT.enabled, FT.paused = true, false
            gcTune()
            Say("turbo ON (adaptive SP + GC slicing)")
        elseif sub == "off" then
            FT.enabled = false
            if FT.baseSP then writeSP(FT.baseSP) end
            pcall(function() collectgarbage("setpause", 100); collectgarbage("setstepmul", 200) end)
            Say("turbo OFF, SP restored to " .. tostring(FT.baseSP) .. ", GC defaults")
        elseif sub == "sp" then
            local v = tonumber(Parameters and Parameters[2] or "") or 100
            FT.paused = true
            writeSP(v)
            Say(string.format("SP manual %.0f%% (adaptation paused until 'jfps turbo')", v))
        elseif sub == "target" then
            local v = tonumber(Parameters and Parameters[2] or "") or 60
            FT.targetFPS = math.max(math.min(v, 240), 20)
            Say("target fps = " .. FT.targetFPS)
        elseif sub == "floor" then
            local v = tonumber(Parameters and Parameters[2] or "") or 60
            FT.floorSP = math.max(math.min(v, 100), 30)
            Say("SP floor = " .. FT.floorSP)
        elseif sub == "cap" then
            
            local v = (Parameters and Parameters[2] or ""):lower()
            if v == "off" or v == "0" then
                exec("t.MaxFPS 0")
                FT.capFPS = nil
                _G.JxFrameStats_CapFPS = nil   
                Say("frame cap removed (t.MaxFPS 0)")
            else
                local n = tonumber(v) or 0
                if n >= 20 and n <= 240 then
                    exec("t.MaxFPS " .. math.floor(n))
                    FT.capFPS = math.floor(n)
                    _G.JxFrameStats_CapFPS = FT.capFPS   
                    Say("frame cap = " .. math.floor(n) .. " fps (t.MaxFPS; laptop/heat friendly)")
                else
                    Say("usage: jfps cap <30..240> | off")
                end
            end
        else
            local line = reportLine()
            Say(line)
            writeFile(line)
        end
        return true
    end)
end

do
    
    local sp = readCVarNum("r.ScreenPercentage")
    FT.baseSP = (sp and sp > 10) and math.floor(sp) or 100
    FT.curSP = FT.baseSP
    if FT.enabled then gcTune() end
    
    pcall(function()
        if type(LoopAsync) == "function" then
            LoopAsync(WORLDS[1], function() tick(WORLDS[1]) end)
        else
            
            gcTune()
        end
    end)
    Log(string.format("ready v%s (base SP=%d, target=%dfps, floor=%d, mode=%s)",
        FT.version, FT.baseSP, FT.targetFPS, FT.floorSP,
        FT.enabled and "turbo" or "off"))
end

return FT
