-- JxNewUI.lua v5.11 - r51 native-state input, no NewUI UMG delegates
--
-- r51 (2026-10-02): r50 still registered UMG delegates and passed a Win32
-- key integer to PlayerController:IsInputKeyDown(FKey). Keep the existing
-- handlers/gates, but drive them from native button state + an LMB keybind.
-- Sliders retain value/release behavior via GetValue/HasMouseCapture.
-- Reset all per-shell input state, log failures, and bound scheduler work.
-- The old GC/error timestamps are correlation, not a proven root cause.
-- No pak/DLL changes, no FText GetText, no geometry or widget creation.
--
-- v5.9 (2026-10-02 r49): WHY THE FIVE TABS NEVER CLICKED. Cross-session
-- evidence: TabBtn_15..19 have NEVER echoed "NU| CLICK" in any session, and
-- neither have the Lua echoes of TabBtn_0..11 - the working originals are
-- BP-bound (native BndEvt), so only the Lua delegate layer is dead. r37/r38
-- proved the cure on the previous generation: force bEnableClickEvents /
-- bEnableMouseOverEvents on pipeline-authored buttons - that fix was LOST in
-- later refactors and the v46 pipeline likely authored the new buttons
-- without them. Restored in rail + pills + hideseek loops with before/after
-- logging, plus a GetCachedGeometry probe (0-sized button theory: renders
-- its text child while eating no hits) so the next log settles it.
--
-- v5.8 (2026-10-02 r44): THE REAL CULPRIT WAS 3 BYTES IN THE PAK. Forensics
-- on the 04:00 session: zero "NU| CLICK" echoes all session + a heal-created
-- shell at 04:00:49 -> clicks fell through to the ONLY handlers alive, the
-- BP-baked ones. Bytecode census (EX_IntConst+EndFunctionParms, opcodes from
-- Engine source): the three pills TabNavBtn_0/1/2 carry baked
-- SetActiveWidgetIndex calls with constants 12/13/14 - the OLD generation's
-- slots - so PLUS opened 娱乐, PRO opened AI, 娱乐 opened AMS. TabBtn_12/13/14
-- DO NOT EXIST in this generation (absent from the pak name table + tree).
--   [A] PAK REPLACED (user mandate, delete-then-replace): the three constants
--       patched 12->18 (PLUS), 13->19 (PRO), 14->12 (ENT) directly in
--       WBP_JinxingRoot.uexp bytecode; repacked 44 entries Oodle/Kraken as
--       JinxingLoader_P.pak F5531FBD; round-trip verified. BP now opens the
--       RIGHT page with zero Lua dependence.
--   [B] Tab whitelist gate (user spec): AI/Pro/Plus are whitelist-only - PRO
--       tier may open Plus, PLUS tier may NOT open Pro/AI, level 0 and
--       blacklist get nothing. Implemented on top of Core_WL's JXWL.Allow
--       (host pass + Steam64 double-layer + levels 1-3 PLUS / 3.5+ PRO).
--       Denied clicks revert to the last allowed page + a message.
--   [C] Recreation-proof wiring: shell instance address is tracked; a new
--       instance resets the wiring ledger and heals re-wire immediately
--       (400ms/1.2s) instead of waiting for the 2-6s rescan window.
--   [D] TabNavBtn_2 (娱乐) now Lua-wired too; TabBtn_12/13/14 railMap
--       entries removed (buttons do not exist - dead code out).
--
-- v5.7 (2026-10-02 r43): TAB NAMES VS CONTENT. User evidence: the 娱乐 rail
-- button opened AMS, PLUS opened 娱乐, PRO opened the AI page. Root causes:
-- the 854D2A38 pak reordered the switcher (12=Ent 13=Ai 14=Save/AMS 15=Net
-- 16=Keys 17=Help 18=Plus 19=Pro 20=HideSeek) while the Core BP graph still
-- bakes TabBtn_12/13/14 -> SetActiveWidgetIndex(12/13/14) from the OLD
-- layout; AND the 23 Plus/Pro sliders were never wired because this file
-- built "JxPLUSSlider_"/"JxPROSlider_" (grp:upper()) while the pak widgets
-- are JxPlusSlider_*/JxProSlider_* (title case). Fixes:
--   [A] railMap realign: TabBtn_12/13/14 name-resolve to PlusPageV48/
--       ProPageV48/EntPageV184; every wire records M.pgIdx[page]=index and
--       click telemetry prints "(realigned from BP N)" when the baked index
--       differs - page-order drift is now self-evident on every boot.
--   [B] slider prefix fix: Jx<Grp>Slider_/Jx<Grp>Val_ (title case) - the
--       10 Plus + 13 Pro sliders finally wire, "wire slider <feat>" x23.
--   [C] ActorPageV43 fill DELETED (it vandalised the page header + search
--       labels); FillPageTexts is whitelist-gated to the plain text pages
--       and skips TextBlocks under Buttons. AMS identity fill added on
--       SavePageV46 - AMS and Actor are and always were separate pages.
--   [D] HideSeekPageV49 (slot 20, no rail button) rescued via Ctrl+G; the
--       "NU| align map" audit line dumps the full rail->index map on boot.
--
-- v5.6 (2026-10-02 r42): THE UNCLICKABLE ADDED TABS. User-verified partition:
-- the BP-bound original tabs work (native BndEvt), the editor-added ones
-- (AI/网络/快捷/帮助) render but eat zero clicks - two v5.5 sessions showed
-- "NU| CLICK" echoes for NOTHING while cur=true and input was granted. That
-- leaves per-widget state as the eater: baked non-hittable visibility or a
-- disabled button. Fixes:
--   [A] wire-time hit-test repair: every rail/nav button's GetVisibility +
--       bIsEnabled are read and LOGGED; non-Visible visibility is forced to
--       Visible(0) and disabled forced to enabled - with before/after in the
--       wire line so the log shows exactly what was wrong.
--   [B] Ctrl+I/N/K/H jump straight to the AI/网络/快捷/帮助 pages (opens the
--       panel first) - the delivery channel that has never failed in this
--       project (Ctrl+O/P/T, Ctrl+arrows, B all proven).
--   [C] color persistence: the pak graph re-tints its own widgets, so the
--       palette is re-asserted every ~10 s ("tint" sweeps, log-quieted),
--       not only on B presses.
--   [D] truth fills: the network page now shows REAL status (whitelist sync
--       count, config source, catalog size) instead of baked placeholder
--       text; the actor page states spawning needs a game level (main menu
--       spawns do nothing by design - that was the "生成用不了" half).
--
-- v5.5 (2026-10-02 r41): THE INVISIBLE CLICK EATER. The 03:02 session (r40)
-- was the heal working perfectly - "heal: shell recreated (try=1)", the
-- stale menu core correctly dropped on map change, auto-shown shell belted,
-- "input true -> ok (poll-heal)", then a whole minute of "hb shell=true
-- vis=vis applied=true invp=1" in the main menu. And STILL zero clicks: the
-- click echo ("NU| CLICK TabBtn_x ...") has existed since r37 and the log
-- had NONE - mouse events never reached a single wired button while the
-- cursor flag was on. The remaining switches that can eat UMG clicks:
--   [A] InputApply(true) now forces PC.bEnableClickEvents,
--       PC.bEnableMouseOverEvents and GameViewportClient.bIgnoreInput=false
--       on EVERY grant (a cursor with click events off draws but deafens).
--   [B] poll re-fight: read bShowMouseCursor back EVERY tick; if the game's
--       menu code stole it, drop inputOwned so the full grant re-applies
--       ("NU| input reassert (cursor was stolen)"). Every ~30 s the full
--       grant is re-applied even when the readback looks fine.
--   [C] hb now reports cur=<true/false> so a silent input-mode steal is
--       visible in the log instead of guessed.
--
-- v5.4 (2026-10-02 r40): THE MAP-CHANGE SHELL DEATH. The 02:37 live session
-- proved v5.3's menu chain end to end (B open/close x4, cursor grants
-- "input true -> ok", verdict RAIL, hb invp=1) - then the Lobby map load at
-- 02:39:15 left "hb core=true shell=false invp=0" for the rest of the
-- session. The widget INSTANCE died with the old world, but the Core REF
-- survived as a stale pointer to a dead world, so the old respawn-only
-- branch (which requires core INVALID) never fired, r20 banned Lua-side
-- creation, and nobody recreated the shell - the panel never came back
-- ("sometimes it just won't pop up"). Fixes:
--   [A] CoreWorldOk: a Core only counts when its world is the CURRENT
--       world; stale menu Cores are rejected inside levels.
--   [B] HealNoShell: poll-driven no-shell resurrection - zero shells ->
--       validate/respawn the Core in THIS world -> OpenShell through the
--       Core's own factory (JinxingLoaderToggle). 8 s spacing, 5 tries per
--       world, budget reset on every map load (ArmWorld).
--   [C] ToggleB validates the found Core the same way, so B respawns a
--       fresh Core instead of toggling the dead menu one.
--
-- v5.3 (2026-10-02 r39): THE LOBBY CLICK BUG. r37/r38 fixed pressed-B opens,
-- but the map-load auto-shown lobby shell (Core graph shows it, no B press)
-- rendered fine while IsInViewport() kept denying it - the r37 poll cursor net
-- required invp==true, so "poll-heal" never fired, the cursor was never
-- granted and every lobby click died (zero CLICK lines all session).
-- Fixes: render authority is now STRICT VisState=="vis" (IsInViewport is a
-- belt, not a gate), every visible-but-denied shell gets a one-shot
-- AddToViewport (weak-keyed), and the heartbeat reports invp=N.
--
-- v5.2 (2026-10-02 r38): THE CORE RESPAWN BUG. The 01:28 live session (r37)
-- proved the click fix WORKS: menu shell auto-showed, all 21 controls wired
-- click=true press=true, B closed AND reopened with "input true -> ok
-- (open)" + "B -> OPEN ok=true". Then the user joined a level: player
-- restart killed the Core actor, respawn failed try=1/2/3 and the budget
-- burned - B stayed dead in the level, nothing to click at all. uiprobe in
-- the same minute proved LoadAsset reaches our classes in Shipping
-- (loadOk=true loadType=UClass) while respawn's StaticFindObject could not
-- see the GC'd class. Fixes:
--   [A] LoadCoreClass: StaticFindObject -> LoadAsset on both known Core
--       paths (the pak mounts /Game/JinxingLoader/Core/...).
--   [B] every respawn failure logs WHY: no-world / class-not-loadable /
--       spawn-failed - no more blind try=N lines.
--   [C] B-press respawn is never budget-capped (user-driven); passive poll
--       cap rises 3 -> 6 per world.
--
-- v5.1 (2026-10-02 r37): THE CURSOR ACQUISITION BUG. The 01:14 live session
-- with v5.0 loaded proved wiring was perfect (every "NU| wire ... ok=true",
-- TabBtn_15 -> AiPageV46[13]) and B opened the shell, yet "NU| input true
-- -> no-pc" - UEHelpers.GetPlayerController() returned nil mid-level in
-- this game, so the cursor NEVER appeared and zero clicks arrived. This
-- game's working main.lua features (blacklist/NET/AFK/kick) all acquire
-- the PC via FindAllOf("PlayerController") + IsLocalController(); v5.1:
--   [A] FindPC: FindAllOf+IsLocalController primary, UEHelpers secondary.
--   [B] "no-pc" no longer strands the panel: 300/600/1200/2000/3500/5000 ms
--       retry ladder (each logs "NU| input retry k -> res").
--   [C] the 2 s poll self-heals cursor ownership BOTH ways - it follows
--       "any shell renders" (covers the map-load auto-shown shell, which
--       previously rendered with no cursor because no B was ever pressed).
--   [D] rail buttons + nav pills dual-bind OnClicked AND OnPressed (same
--       idempotent handler) as delivery insurance.
--
-- v5.0 (2026-10-01 r36): TWO ROOT CAUSES KILLED, both live-proven by the
-- 00:39 session log (wiring ok=true on every button, yet ZERO click events):
--   [A] IN-GAME INPUT WAS NEVER SET. OpenShell/CloseAllShells called
--       _G.JXPanelMouse - a global that DID NOT EXIST (main.lua kept two
--       local copies and exported neither). Outside the main menu nobody
--       set bShowMouseCursor / GameAndUI, so pointer clicks physically
--       could not reach any widget. This module now owns its InputMode
--       (bShowMouseCursor + WBL:SetInputMode_GameAndUIEx on open; guarded
--       GameOnly restore on close - skipped when no pawn, i.e. menus);
--       main.lua additionally exports _G.JXPanelMouse as belt-and-braces.
--       Every input transition logs "NU| input <on> -> <result>".
--   [B] RAIL TABS JUMPED TO WRONG PAGES. v49 removed PlusPageV183/
--       ProPageV183 from the switcher, shifting every index after 11 down
--       by two: old wiring sent TabBtn_15 (AI) to JXTabGo(15) = NetPage.
--       All rail buttons now wire BY PAGE NAME - index resolved from the
--       live switcher children at wire time (same primitive as the nav
--       pills), then JXTabGo runs so per-page route actions still fire.
--       TabBtn_0..11 are wired too (their native BndEvt still fires first
--       with the same target; Lua's pass adds bookkeeping + telemetry).
--       Every click logs "NU| CLICK <btn> -> <page>"; pcall errors surface
--       as "NU| ERR <btn>: ...". PollOnce auto-releases the cursor if it
--       still owns input while no shell renders (ESC/menu edge).
--
-- v4.6 (2026-10-01 r29): ONE SHELL, LUA OWNS THE TOGGLE. The 21:14 live
-- session proved core:JinxingLoaderToggle() is ENSURE-OPEN: v4.5 invoked it
-- unconditionally on every B press, so rapid presses stacked extra shells
-- that nothing could ever close. New contract, one authority (M.ToggleB;
-- main.lua's JXPakToggle stub routes B/F6/bare-jpanel here too):
--   any shell renders -> CLOSE: collapse every live shell + mouse off
--   none renders      -> OPEN : revive an existing shell (vis 4 = the pak's
--                         authored root state); call the Core UFUNCTION only
--                         when ZERO shells exist (create-once per world)
-- Rapid presses debounced 0.25 s (also stops the "Ref was not function"
-- registry error seen at 21:16:33). Guarded core respawn (<=3 tries, 10 s
-- apart, only when world populated and no core + no shell) fixes the 21:17
-- player-restart "core lost (stale)" state that left B dead forever.
-- Styling wave trimmed to +150/+600 ms. Lua still never constructs UMG
-- itself (Shipping-crash rule) - Core's BP graph builds the widget.
--
-- v4.5 (2026-10-01 r24): B KEY OWNS THE CREATE/TOGGLE AGAIN, VIA CORE. The
-- 02:51 session (minimal rail pak) proved Core BP alive + WBP class resident
-- yet shells=0 across 10+ B presses: this build's Core has NO working native
-- input binding, so the r20 "passive listener" policy stranded the shell
-- uncreated forever. Each physical B press now fires exactly one
-- core:JinxingLoaderToggle() (BP-native ConstructWidget, r6.2-proven; same
-- primitive as the main.lua `panel` command), adopts core.JinxingUi, then
-- the +150/+600/+1500ms wave styles/verifies as before.
--
-- v4.4 (2026-09-30 late): SELF-IDENTIFYING SHELL VERDICT. A tester machine can
-- still mount a STALE old pak alongside ours (old distributions shipped the
-- same internal paths), and the old shell would draw on top. Classification:
--   rail shell (v176 pak, ours)  -> tree contains "TabRailV63"
--   old shell (R14-era paks)     -> tree contains "TabBarV39"
-- Verdict runs at pass start, on B waves, and once per heartbeat window:
--   RAIL    -> normal restyle; verdict logged + written to newui_verdict.txt
--   DUAL    -> both classes alive: OLD shells are auto-COLLAPSED (self-heal)
--   OLD     -> only a stale pak is loaded: title turns into a RED
--              "OLD PAK ACTIVE" banner so anyone can see it instantly
--   UNKNOWN -> shells exist but no marker (report via dump)
-- AcquireShell now prefers a rail instance when several shells exist
-- ("findall-rail" source in telemetry).
--
-- v4.3 (2026-09-30 night): LAYOUT AUTHORITY MOVED TO THE PAK. The 23:12 live
-- session + pre-dump proved the shell tree is RootPanelV29(Border) >
-- ColumnV29(VerticalBox) > [Title, TabBarV39, Status, TabNavBar, Switcher] -
-- my RootMove canvas-slot calls never applied (those widgets are VerticalBox
-- children, not canvas children), so "relayout" was cosmetic-only. The real
-- fix is pak-level: the rail shell (v176 WBP, TabRailV63 left rail, 14 tabs
-- incl. PLUS/PRO) is what the user approved (screenshot 2). So this module now
-- owns ONLY: theme colors, title text, per-page grid inside the switcher.
-- RootMove and the TabBar fill loop are deleted - moving widgets inside the
-- rail shell would fight the pak's own layout.
--
-- v4.2 param shapes (engine-source verified, keep as-is):
--   TextBlock::SetColorAndOpacity(FSlateColor)   -> full form REQUIRED
--   Button::SetBackgroundColor(FLinearColor)     -> FLAT form
--   Border::SetBrushColor(FLinearColor)          -> FLAT form
--   Image::SetColorAndOpacity(FLinearColor)      -> FLAT form
--   FSlateChildSize member is "Value"            -> NOT SizeValue
-- v4.1 (kept): thread safety (ExecuteWithDelay callbacks wrapped in
--   ExecuteInGameThread), Rearm clears M.orig/M.pos.
--
-- ROOT-CAUSE NOTE (2026-09-30, two sessions 18:27 + 18:44): zero pass[...]
-- lines across both. The 18:44 B press happened in a STABLE lobby and still
-- fired nothing - v3.1's only trigger was a 2 s poll gated on
-- type(GetVisibility())=="number" and ==0, which silently never held (enum
-- not a plain number on this build), while juiskin's FindFirstOf shell
-- acquisition DID work (its TINT fired). So the user saw the R14 pak shell
-- with juiskin cyan text and no layout work at all. Fix: visibility parsing
-- made type-agnostic (VisState), and the restyle no longer depends on the
-- poll:
--   [1] passive B listener (same pattern as main.lua PNL - logs only, NEVER
--       toggles; Core's own native input owns the toggle) -> pass attempts
--       at +150/+600/+1500 ms, styled regardless of visibility state
--   [2] shell acquisition upgrade: FindFirstOf(WBP) falls back to the pak
--       Core actor's own JinxingUi property (proven primitive in main.lua
--       UICREATE "Core route: live JinxingUi adopted")
--   [3] world-change re-arm via JXWorldReady wrapper (map load / beginplay /
--       player restart) -> rescan + re-apply 2 s later
-- Plus telemetry: every state transition and a 30 s heartbeat land in
-- UE4SS.log so a session's log always tells the full story.
--
-- HARD RULES (r24): no widget construction, no AddToViewport of Lua-made
--   widgets (the shell is built by Core's own BP graph - we only call its
--   JinxingLoaderToggle UFUNCTION on B, one call per physical press, after
--   the 02:51 session proved the Core's native B binding never fires).
--   Slot ops only, all pcall'd. ASCII source only.
-- v3.1 perf design kept: single pass per shell instance, cached refs, string
--   class dispatch, one walk per pass+dumps.

local M = { name = "JxNewUI", ver = 4 }
local UEHelpers = rawget(_G, "UEHelpers") -- Install receives main.lua's local helper

local Log = Log or function(s) print("[JxNewUI] " .. tostring(s)) end
local Say = (JX and JX.Say) or Log

-- ============ theme v4.7: dark slate + CYAN (user-mandated) ============
-- r29 shipped indigo/violet and the user rejected it: the mandate is CYAN
-- (青色, the juiskin-era identity), a NEW layout in cyan - not a new hue.
-- Values match the cyan re-bake in the v47 WBP cook; runtime restyle must
-- equal the baked look.
local TH = {
    bgPanel = { R = 0.043, G = 0.055, B = 0.071, A = 0.90 },
    bgCtrl  = { R = 0.086, G = 0.110, B = 0.137, A = 0.92 },
    bgHot   = { R = 0.000, G = 0.360, B = 0.500, A = 0.95 },
    accent  = { R = 0.000, G = 0.830, B = 1.000, A = 1.00 },
    txtMain = { R = 0.930, G = 0.960, B = 1.000, A = 1.00 },
    txtDim  = { R = 0.470, G = 0.570, B = 0.640, A = 1.00 },
    txtTab  = { R = 0.780, G = 0.930, B = 0.990, A = 1.00 },
}

local MARG = 20
local PW, PH = 944, 540          -- normalized content rect (switcher slot size)
local TITLE = "JX NEXUS 1.4.1"

-- page grid policy: r35 ALL pages = "skip" (错位根治: the flow/frame grid
-- moves were the misalignment source - MoveTo on box slots fought the pak's
-- authored layout). The global theme sweep still paints every page; positions
-- belong to the pak alone.
local PAGES = {
    ModsPageV43 = "skip", PerfPageV43 = "skip", PlayersPageV43 = "skip",
    ActorPageV43 = "skip", BanPageV43 = "skip", SetPageV43 = "skip",
    SpecialPageV39 = "skip", InfoPageV43 = "skip", RosterPageV39 = "skip",
    MapPageV39 = "skip", MeshPageV43 = "skip", FeatPageV53 = "skip",
    ActorListPageV48 = "skip", ActorPlacePageV48 = "skip",
    SetSubPage = "skip", FeatSubPage = "skip",
    PlusPageV183 = "skip", ProPageV183 = "skip", EntPageV184 = "skip",
    AiPageV46 = "skip", SavePageV46 = "skip", NetPageV46 = "skip",
    KeysPageV46 = "skip", HelpPageV46 = "skip",
    PlusPageV48 = "skip", ProPageV48 = "skip",
}

local TEXTNAMES = { TextBlock = true, EditableText = true, EditableTextBox = true }
local CONTNAMES = {
    ScrollBox = true, WidgetSwitcher = true,
    VerticalBox = true, HorizontalBox = true, CanvasPanel = true,
}

-- ============ state ============
M.enabled = true
M.applied = false
M.autodump = true
M.dumpedPre = false
M.dumpedPost = false
M.shell = nil
M.shellSrc = nil
M.core = nil
M.stats = nil
M.orig = {}    -- visibility snapshot
M.pos = {}     -- slot snapshot for restore
local CLS = {}
local coreRespawns = 0 -- shared by Rearm and RespawnCore (not a stray global)
local RespawnCore  -- forward-declared: defined beside the B machinery below
local StartNativeInput -- assigned after the input callback definitions
local HealNoShell  -- r40 forward-declared: map-change shell resurrection (assigned beside RespawnCore)

local function ResolveClasses()
    if CLS._done then return true end
    local defs = {
        Border = "/Script/UMG.Border", Button = "/Script/UMG.Button",
        TextBlock = "/Script/UMG.TextBlock",
    }
    local okAny = false
    for k, p in pairs(defs) do
        local ok, c = pcall(StaticFindObject, p)
        if ok and c then CLS[k] = c; okAny = true end
    end
    CLS._done = okAny
    return okAny
end

-- r58: native-call census. crashlog.txt shows JxLoader stepping over thousands
-- of null-ish reads inside UE4SS.dll per session (one 61 s session: 4451 skips,
-- site UE4SS.dll+13023274 alone hit 2560 times) and pcall cannot see a native
-- AV. These counters are printed once per pass so the burst can be attributed
-- to one primitive instead of guessed at. Zero behaviour change.
M.nc = M.nc or { cls = 0, name = 0, valid = 0, cnt = 0, child = 0, deadnode = 0 }
local function ClassName(w)
    M.nc.cls = M.nc.cls + 1
    local ok, n = pcall(function() return w:GetClass():GetFName():ToString() end)
    if ok then return n end
    return "?"
end

local function WName(w)
    M.nc.name = M.nc.name + 1
    local ok, n = pcall(function() return w:GetFName():ToString() end)
    if ok then return n end
    return "?"
end

local function Valid(w)
    if not w then return false end
    M.nc.valid = M.nc.valid + 1
    local ok, v = pcall(function() return w:IsValid() end)
    return ok and v == true
end

-- robust visibility read: GetVisibility may return number, string or enum
-- userdata across UE4SS builds - v3.1's poll died silently assuming numbers
local function VisState(w)
    local ok, v = pcall(function() return w:GetVisibility() end)
    if not ok or v == nil then return "?" end
    if type(v) == "number" then
        -- ESlateVisibility: 0 Visible, 1 Collapsed, 2 Hidden, 3 HitTestInvisible,
        -- 4 SelfHitTestInvisible. 3/4 are still RENDERED (the shell root uses 4),
        -- so only 1/2 mean hidden - v4.2 treated any nonzero as hidden, which
        -- starved the poll channel on the shell's normal vis=4 state
        if v == 1 or v == 2 then return "hid" end
        return "vis"
    end
    local s = tostring(v)
    if string.find(s, "Hidden", 1, true) or string.find(s, "Collapsed", 1, true)
        or string.find(s, "Not", 1, true) then
        return "hid"
    end
    if string.find(s, "Visible", 1, true) then return "vis" end
    return "?" .. s:sub(1, 12)
end

local KTL = nil
local function FT(s)
    if not KTL then
        pcall(function() KTL = StaticFindObject("/Script/Engine.Default__KismetTextLibrary") end)
    end
    if not KTL then return nil end
    local ok, t = pcall(function() return KTL:Conv_StringToText(s) end)
    if ok then return t end
    return nil
end

-- ============ v4.4 shell classification ============
-- rail (v176 pak, ours): tree contains TabRailV63; old (R14-era pak):
-- tree contains TabBarV39. Bounded name search - used before Walk is defined
-- and cheap enough for heartbeat calls.
local RAIL_MARK, OLD_MARK = "TabRailV63", "TabBarV39"

local function FindMark(w, name, depth)
    if not w or depth > 6 then return false end
    if WName(w) == name then return true end
    local ok, cnt = pcall(function() return w:GetChildrenCount() end)
    if ok and type(cnt) == "number" and cnt > 0 and cnt < 200 then
        for i = 0, cnt - 1 do
            local okg, ch = pcall(function() return w:GetChildAt(i) end)
            if okg and ch and FindMark(ch, name, depth + 1) then return true end
        end
    end
    return false
end

local function ShellRoot(w)
    local tree = nil
    pcall(function() tree = w.WidgetTree end)
    local root = nil
    if tree then pcall(function() root = tree.RootWidget end) end
    if not root then root = w end
    return root
end

local function ShellKind(w)
    local root = ShellRoot(w)
    if FindMark(root, RAIL_MARK, 0) then return "rail" end
    if FindMark(root, OLD_MARK, 0) then return "old" end
    return "?"
end

local function AllShells()
    local out = {}
    local ok, list = pcall(function() return FindAllOf("WBP_JinxingRoot_C") end)
    if ok and type(list) == "table" then
        for _, w in ipairs(list) do
            if Valid(w) then out[#out + 1] = w end
        end
    end
    return out
end

-- ============ acquisition (v4: findfirst OR core.JinxingUi, with telemetry) ============
local function FindCore()
    if Valid(M.core) then return M.core end
    if M.core then
        Log("NU| core lost (stale)")
        M.core = nil
    end
    local ok, c = pcall(function() return FindFirstOf("BP_JinxingLoaderCore_C") end)
    if ok and Valid(c) then
        M.core = c
        Log("NU| core acquired (findfirst)")
        return c
    end
    return nil
end

local function AcquireShell()
    if Valid(M.shell) then return M.shell, M.shellSrc or "cache" end
    if M.shell then
        Log("NU| shell lost (stale, src=" .. tostring(M.shellSrc) .. ")")
        M.shell = nil
        M.shellSrc = nil
        M.applied = false
        M.dumpedPost = false
    end
    -- v4.4: prefer a RAIL instance when several shells are alive (a stale old
    -- pak may have spawned its own shell; ours must win the styling pass)
    local shells = AllShells()
    for _, cand in ipairs(shells) do
        if ShellKind(cand) == "rail" then
            M.shell = cand
            M.shellSrc = "findall-rail"
            Log("NU| shell acquired (findall-rail, " .. #shells .. " shells)")
            return cand, "findall-rail"
        end
    end
    local okW, w = pcall(function() return FindFirstOf("WBP_JinxingRoot_C") end)
    if okW and Valid(w) then
        M.shell = w
        M.shellSrc = "findfirst"
        Log("NU| shell acquired (findfirst)")
        return w, "findfirst"
    end
    -- Core route: the pak Core actor holds the live shell in .JinxingUi
    -- (proven primitive: main.lua UICREATE "Core route: live JinxingUi adopted")
    local core = FindCore()
    if core then
        local okU, ui = pcall(function() return core.JinxingUi end)
        if okU and Valid(ui) then
            M.shell = ui
            M.shellSrc = "core.JinxingUi"
            Log("NU| shell acquired (core.JinxingUi)")
            return ui, "core.JinxingUi"
        end
    end
    return nil, nil
end

-- ============ tree walk ============
local function Walk(root, maxDepth, cap)
    local out = {}
    local n = 0
    local function rec(node, depth)
        if not node or depth > maxDepth or n >= cap then return end
        -- r58: GetChildAt can hand back a wrapper around a half-destroyed child
        -- (a previous world's widget, a panel mid-teardown). Every method call
        -- on one of those is a native read through a dead pointer - pcall never
        -- sees it, JxLoader steps over it, and the heap pays for it later. One
        -- validity gate here is the cheapest place to stop the whole subtree.
        if not Valid(node) then
            M.nc.deadnode = M.nc.deadnode + 1
            return
        end
        n = n + 1
        out[#out + 1] = { w = node, name = WName(node), cls = ClassName(node), depth = depth }
        M.nc.cnt = M.nc.cnt + 1
        local ok, cnt = pcall(function() return node:GetChildrenCount() end)
        if ok and type(cnt) == "number" and cnt > 0 and cnt < 200 then
            for i = 0, cnt - 1 do
                M.nc.child = M.nc.child + 1
                local okg, ch = pcall(function() return node:GetChildAt(i) end)
                if okg and ch then rec(ch, depth + 1) end
            end
        end
    end
    rec(root, 0)
    return out
end

local function ByName(fl, name)
    for _, e in ipairs(fl) do if e.name == name then return e end end
    return nil
end

local function DeepText(w, depth)
    if not w or depth > 4 then return nil end
    -- r58: same reason as Walk - this recurses on raw GetChildAt results.
    if not Valid(w) then M.nc.deadnode = M.nc.deadnode + 1 return nil end
    if TEXTNAMES[ClassName(w)] then return w end
    local ok, cnt = pcall(function() return w:GetChildrenCount() end)
    if ok and type(cnt) == "number" and cnt > 0 then
        for i = 0, cnt - 1 do
            local okg, ch = pcall(function() return w:GetChildAt(i) end)
            if okg and ch then
                local hit = DeepText(ch, depth + 1)
                if hit then return hit end
            end
        end
    end
    return nil
end

-- ============ slot machinery ============
local function GetSlot(w)
    local ok, s = pcall(function() return w.Slot end)
    if ok and s then return s end
    return nil
end

local function SlotKind(s)
    local ok, n = pcall(function() return s:GetClass():GetFName():ToString() end)
    if ok then return n end
    return "?"
end

local function SavePos(w)
    if M.pos[w] then return end
    local s = GetSlot(w)
    if not s then return end
    local rec = { kind = SlotKind(s) }
    if rec.kind == "CanvasPanelSlot" then
        local okp, p = pcall(function() return s:GetPosition() end)
        if okp and type(p) == "table" then rec.x, rec.y = p.X, p.Y end
        local okz, z = pcall(function() return s:GetSize() end)
        if okz and type(z) == "table" then rec.sw, rec.sh = z.X, z.Y end
    elseif rec.kind == "HorizontalBoxSlot" or rec.kind == "VerticalBoxSlot" then
        local okz, z = pcall(function() return s:GetSize() end)
        if okz and type(z) == "table" then rec.val, rec.sr = z.Value, z.SizeRule end
        local okp, p = pcall(function() return s:GetPadding() end)
        if okp and type(p) == "table" then
            rec.pl, rec.pt = p.Left, p.Top
            rec.pr, rec.pb = p.Right, p.Bottom
        end
    end
    M.pos[w] = rec
end

local function SaveVis(w)
    if M.orig[w] then return end
    local rec = {}
    local ok, v = pcall(function() return w:GetVisibility() end)
    if ok and type(v) == "number" then rec.vis = v end
    M.orig[w] = rec
end

local function MoveTo(rep, w, x, y, sw, sh)
    local s = GetSlot(w)
    if not s then return false end
    local k = SlotKind(s)
    if k == "CanvasPanelSlot" then
        local ok1 = pcall(function() s:SetPosition({ X = x, Y = y }) end)
        local ok2 = true
        if sw and sh then ok2 = pcall(function() s:SetSize({ X = sw, Y = sh }) end) end
        if ok1 and ok2 then
            rep.slotMoves = rep.slotMoves + 1
            return true
        end
    elseif k == "HorizontalBoxSlot" or k == "VerticalBoxSlot" then
        local okp = pcall(function() s:SetPadding({ Left = 6, Top = 4, Right = 6, Bottom = 4 }) end)
        -- FSlateChildSize member is "Value" (engine-source verified) - do NOT rename
        local okf = pcall(function() s:SetSize({ Value = 1.0, SizeRule = 1 }) end)
        if okf then rep.fillSlots = rep.fillSlots + 1 end
        if okp or okf then
            rep.boxSlots = rep.boxSlots + 1
            return okf
        end
    end
    return false
end

-- ============ restyle ============
-- PARAM SHAPES - verified against UE 4.27 engine source (E:\UE_4.27), do NOT
-- "normalize" them to one form: TextBlock::SetColorAndOpacity(FSlateColor)
-- needs the full {SpecifiedColor={R,G,B,A}, ColorUseRule=0} form (juiskin TINT
-- 147 proof); Button::SetBackgroundColor / Border::SetBrushColor /
-- Image::SetColorAndOpacity take FLAT FLinearColor {R,G,B,A} - the full form
-- drops every field there; FSlateChildSize member is "Value" (verified
-- UMG/Public/Components/SlateWrapperTypes.h), NOT SizeValue.
local function StyleText(w, role)
    SaveVis(w)
    local c = TH.txtMain
    if role == "dim" then c = TH.txtDim end
    if role == "tab" then c = TH.txtTab end
    if role == "accent" then c = TH.accent end
    pcall(function()
        w:SetColorAndOpacity({ SpecifiedColor = { R = c.R, G = c.G, B = c.B, A = 1.0 }, ColorUseRule = 0 })
    end)
    pcall(function() w:SetShadowOffset({ X = 1.0, Y = 1.0 }) end)
    pcall(function() w:SetShadowColorAndOpacity({ R = 0, G = 0, B = 0, A = 0.6 }) end)
end

local function StyleButton(w, hot)
    SaveVis(w)
    -- Button::SetBackgroundColor(FLinearColor) - FLAT form (engine-source verified)
    pcall(function() w:SetBackgroundColor(hot and TH.bgHot or TH.bgCtrl) end)
end

-- ============ page grid ============
local function GridPage(rep, pg, mode)
    -- r35: "skip" = frozen layout (错位根治) - the global theme sweep already
    -- paints colors; any slot move here fought the pak's authored positions
    if mode == "skip" then
        rep.pages = rep.pages + 1
        return
    end
    local kids = {}
    local ok, cnt = pcall(function() return pg:GetChildrenCount() end)
    if not ok or type(cnt) ~= "number" or cnt <= 0 then return end
    for i = 0, cnt - 1 do
        local okg, ch = pcall(function() return pg:GetChildAt(i) end)
        if okg and ch then kids[#kids + 1] = { w = ch, cls = ClassName(ch) } end
    end

    local bgs, bars, conts, texts, ctrls = {}, {}, {}, {}, {}
    for _, k in ipairs(kids) do
        local nm = WName(k.w)
        local cn = k.cls
        if cn == "Border" or cn == "Image" then
            bgs[#bgs + 1] = k.w
        elseif CONTNAMES[cn] then
            if string.find(nm, "Bar", 1, true) then
                bars[#bars + 1] = k.w
            else
                conts[#conts + 1] = k.w
            end
        elseif TEXTNAMES[cn] then
            texts[#texts + 1] = k.w
        else
            ctrls[#ctrls + 1] = k.w
        end
    end

    for _, w in ipairs(bgs) do
        SavePos(w)
        MoveTo(rep, w, 0, 0, PW, PH)
        if ClassName(w) == "Border" then
            pcall(function() w:SetBrushColor(TH.bgPanel) end)
        else
            pcall(function()
                w:SetColorAndOpacity({ R = 0.04, G = 0.05, B = 0.07, A = 0.55 })
            end)
        end
    end

    local moved = 0
    if mode == "flow" then
        local y = 8
        if texts[1] then
            SavePos(texts[1])
            if MoveTo(rep, texts[1], MARG, y, PW - 2 * MARG, 28) then moved = moved + 1 end
            StyleText(texts[1], "accent")
            y = y + 34
        end
        for _, w in ipairs(bars) do
            SavePos(w)
            if MoveTo(rep, w, MARG, y, PW - 2 * MARG, 38) then moved = moved + 1 end
            y = y + 44
        end
        local order = {}
        for i, k in ipairs(kids) do order[k.w] = i end
        local flow = {}
        for _, w in ipairs(ctrls) do flow[#flow + 1] = w end
        for i = (texts[1] and 2 or 1), #texts do flow[#flow + 1] = texts[i] end
        table.sort(flow, function(a, b) return (order[a] or 0) < (order[b] or 0) end)

        local avail = PH - y - MARG
        local contH, gridY
        if #conts > 0 and #flow > 0 then
            contH = math.floor(avail * 0.62)
            gridY = y + contH + 8
        else
            contH = avail
            gridY = y
        end
        for _, w in ipairs(conts) do
            SavePos(w)
            if MoveTo(rep, w, MARG, y, PW - 2 * MARG, contH) then moved = moved + 1 end
        end

        if #flow > 0 then
            local m = #flow
            local cols = 2
            if m > 12 then cols = 3 end
            if m > 24 then cols = 4 end
            if m > 36 then cols = 5 end
            local gap = 10
            local cw = math.floor((PW - 2 * MARG - (cols - 1) * gap) / cols)
            local chh = 42
            local availH = PH - gridY - MARG
            if availH < chh then
                rep.notes[#rep.notes + 1] = WName(pg) .. ":noRoomForFlow"
            end
            for i, w in ipairs(flow) do
                local r = math.floor((i - 1) / cols)
                local c = (i - 1) % cols
                SavePos(w)
                if MoveTo(rep, w, MARG + c * (cw + gap), gridY + r * (chh + gap), cw, chh) then moved = moved + 1 end
                local cn = ClassName(w)
                if cn == "Button" then StyleButton(w, false) end
                if TEXTNAMES[cn] then StyleText(w, "main") end
            end
        end
    elseif mode == "frame" then
        local y = 8
        for _, w in ipairs(texts) do
            SavePos(w)
            if MoveTo(rep, w, MARG, y, PW - 2 * MARG, 26) then moved = moved + 1 end
            StyleText(w, "accent")
            y = y + 32
        end
        for _, w in ipairs(bars) do
            SavePos(w)
            if MoveTo(rep, w, MARG, y, PW - 2 * MARG, 38) then moved = moved + 1 end
            y = y + 44
        end
        for _, w in ipairs(conts) do
            SavePos(w)
            if MoveTo(rep, w, MARG, y + 4, PW - 2 * MARG, PH - y - 8 - MARG) then moved = moved + 1 end
        end
        for _, w in ipairs(ctrls) do
            SavePos(w)
            if MoveTo(rep, w, MARG, y + 4, PW - 2 * MARG, 34) then moved = moved + 1 end
            if ClassName(w) == "Button" then StyleButton(w, false) end
        end
    end
    rep.cells = rep.cells + moved
    rep.pages = rep.pages + 1
end

-- ============ dump ============
local function DumpLines(fl, phase)
    local lines = {}
    lines[#lines + 1] = "phase=" .. tostring(phase or "?") .. " count=" .. tostring(#fl)
        .. " t=" .. os.date("%Y-%m-%d %H:%M:%S")
    for _, e in ipairs(fl) do
        local vis = "?"
        local okv, v = pcall(function() return e.w:GetVisibility() end)
        if okv and type(v) == "number" then vis = tostring(v) end
        local extra = ""
        local oks, s = pcall(function() return e.w.Slot end)
        if oks and s then
            local k = SlotKind(s)
            extra = " slot=" .. k
            if k == "CanvasPanelSlot" then
                local okp, p = pcall(function() return s:GetPosition() end)
                local okz, z = pcall(function() return s:GetSize() end)
                if okp and type(p) == "table" then extra = extra .. string.format(" pos=%.0f,%.0f", p.X or -1, p.Y or -1) end
                if okz and type(z) == "table" then extra = extra .. string.format(" sz=%.0fx%.0f", z.X or -1, z.Y or -1) end
            end
        end
        lines[#lines + 1] = string.format("d%-2d %-24s %-16s vis=%s%s", e.depth, e.name, e.cls, vis, extra)
    end
    return table.concat(lines, "\r\n")
end

local function WriteConfig(name, text)
    pcall(function()
        local dir = (_G.JXSidecarDir or "") .. "../config/"
        local f = io.open(dir .. name, "w")
        if f then f:write(text) f:close() end
    end)
end

-- ============ v4.4 verdict (rail vs old pak, self-identifying) ============
-- RAIL: only our rail shell alive. DUAL: ours + stale old pak both spawned -
-- old shells get collapsed so the rail wins visually. OLD: only a stale pak
-- is mounted - title turns into a red warning banner. File is rewritten only
-- when the verdict CHANGES (no io spam).
local lastVerdict = nil
local function RunVerdict(tag)
    local shells = AllShells()
    local rails, olds = 0, 0
    for _, w in ipairs(shells) do
        local k = ShellKind(w)
        if k == "rail" then rails = rails + 1 elseif k == "old" then olds = olds + 1 end
    end
    local v
    if rails > 0 and olds == 0 then v = "RAIL"
    elseif rails > 0 then v = "DUAL"
    elseif olds > 0 then v = "OLD"
    else v = "UNKNOWN" end
    if v == "DUAL" then
        -- ESlateVisibility 1 = Collapsed: old shell stops rendering + layout
        for _, w in ipairs(shells) do
            if ShellKind(w) == "old" then
                pcall(function() w:SetVisibility(1) end)
            end
        end
    end
    M.verdict = v
    if v ~= lastVerdict then
        lastVerdict = v
        local lines = {
            "verdict=" .. v .. " t=" .. os.date("%Y-%m-%d %H:%M:%S") .. " tag=" .. tostring(tag),
            "shells=" .. #shells .. " rail=" .. rails .. " old=" .. olds,
        }
        if v == "OLD" then
            lines[#lines + 1] = "OLD PAK ACTIVE - a stale old shell pak is the only UI."
            lines[#lines + 1] = "Fix: keep only JinxingLoader_P.pak (rail, 3204935B) in"
            lines[#lines + 1] = "  <game>\\EscapeTheBackrooms\\Content\\Paks\\LogicMods"
        elseif v == "DUAL" then
            lines[#lines + 1] = "Dual shells: old shell(s) auto-collapsed; purge the stale pak anyway."
        end
        WriteConfig("newui_verdict.txt", table.concat(lines, "\r\n"))
        Log("VERDICT " .. v .. " shells=" .. #shells .. " rail=" .. rails .. " old=" .. olds)
    end
    return v
end

-- generic title: old shell used TitleTextV29; rail shell name unknown until a
-- live dump - accept the old name or any shallow TextBlock with "title" in it
local WARN_TITLE = "OLD PAK ACTIVE - PURGE STALE PAKS"
local function FindTitle(fl)
    local tt = ByName(fl, "TitleTextV29")
    if tt then return tt end
    for _, e in ipairs(fl) do
        if e.cls == "TextBlock" and e.depth <= 4
            and string.find(string.lower(e.name), "title", 1, true) then
            return e
        end
    end
    return nil
end

local function ApplyTitle(fl, warn)
    local tt = FindTitle(fl)
    if tt then
        local tbw = (tt.cls == "TextBlock") and tt.w or DeepText(tt.w, 0)
        if tbw then
            local ftxt = FT(warn and WARN_TITLE or TITLE)
            if ftxt then pcall(function() tbw:SetText(ftxt) end) end
            if warn then
                pcall(function()
                    tbw:SetColorAndOpacity({ SpecifiedColor = { R = 1.0, G = 0.16, B = 0.10, A = 1.0 }, ColorUseRule = 0 })
                end)
                pcall(function() tbw:SetShadowOffset({ X = 2.0, Y = 2.0 }) end)
            else
                StyleText(tbw, "accent")
            end
        end
    end
    -- r33: persistent build badge (version + pak sha prefix) - external
    -- review asked for at-a-glance new/old detection; JX_BUILD lives in
    -- main.lua line 1 and must be bumped with every pak release
    local bd = ByName(fl, "JxVerBadge")
    if bd and bd.cls == "TextBlock" then
        local ftxt = FT(tostring(_G.JX_BUILD or "JX build ?"))
        if ftxt then pcall(function() bd.w:SetText(ftxt) end) end
        StyleText(bd, "dim")
    end
end

-- ============ v48 new-tab + slider wiring ============
-- r42: truth-fill helpers (defined here: WireNewTabs and the pass consume
-- them; they only use Walk/ByName/FT which are all above).
local function CountLines(path)
    local f = io.open(path, "r")
    if not f then return 0 end
    local n = 0
    for _ in f:lines() do n = n + 1 end
    f:close()
    return n
end

-- r43: positional fills are restricted to the plain text pages (Head+Txt
-- slots only). On rich BP pages first-N-TextBlocks walks straight into
-- page headers and BUTTON LABELS and vandalises them - the r42 Actor fill
-- overwrote PageHdrTxt_3 and the search-bar labels (user: "Actor页没删干
-- 净"). Belt 2: skip any TextBlock whose parent is a Button.
local FILL_SAFE_PAGES = {
    NetPageV46 = true, SavePageV46 = true, KeysPageV46 = true,
    HelpPageV46 = true, AiPageV46 = true,
}
local function FillPageTexts(pgName, lines)
    -- SetText is the proven channel (FillModsList); first-N-TextBlocks keeps
    -- it layout-safe - no moves, no creates, only existing text widgets.
    if not FILL_SAFE_PAGES[pgName] then return false end
    if not (M.shell and Valid(M.shell)) then return false end
    local tree = nil
    pcall(function() tree = M.shell.WidgetTree end)
    local root = nil
    if tree then pcall(function() root = tree.RootWidget end) end
    if not root then return false end
    local fl = Walk(root, 14, 2500)
    local pg = ByName(fl, pgName)
    if not pg then return false end
    local inner = Walk(pg.w, 8, 200)
    local ti = 1
    for _, e in ipairs(inner) do
        if ti <= #lines and e.cls == "TextBlock" then
            local underBtn = false
            pcall(function()
                local par = e.w:GetParent()
                if par and par.IsValid and par:IsValid() then
                    underBtn = (tostring(par:GetClass():GetName()) == "Button")
                end
            end)
            if not underBtn then
                local t = FT(lines[ti])
                if t then pcall(function() e.w:SetText(t) end) end
                ti = ti + 1
            end
        end
    end
    return ti > 1
end

-- TabBtn_15..19 and slider rows keep their Lua handlers in JXUICBS.
-- r51 does NOT register these handlers with UMG multicast delegates.
-- A Lua strong reference cannot by itself validate a C++ registry handle.
-- Sliders continue through JXExecCmd so the existing command gate applies.
local wiredTabs = {}
local function ResetWiring()
    wiredTabs = {}
    M.flat = nil    -- r59: shared walked tree dies with the wiring it came from
    M.wiredInst = nil
    M.wiredShell = nil
    M.wiredSwitcher = nil
    -- r55: drop the exported switcher too - between a shell death and the
    -- next wiring, main.lua would otherwise serve a dead-but-not-yet-Invalid
    -- wrapper to every JXTabGo caller.
    _G.JXWiredSwitcher = nil
    M.wireComplete = false
    M.cbsOrder = {}
    M.sliderOrder = {}
    M.tabIdx = {}
    M.pgIdx = {}
    M.btnPage = {}
    M.curSafeIdx = 0
    M.hsSeekers = 2
    _G.JXUICBS = {}
end

local SLIDER_CATALOG = {
    plus = {
        { feat = "speed",     mn = 300,  mx = 2400, def = 600,  unit = "u/s" },
        { feat = "vision",    mn = 0,    mx = 3,    def = 0,    labels = { "off", "night", "luma", "stealth" } },
        { feat = "jump",      mn = 400,  mx = 2000, def = 700,  unit = "u" },
        { feat = "glide",     mn = 0,    mx = 4,    def = 0,    labels = { "off", "slow", "mid", "fast", "feather" } },
        { feat = "brightness",mn = 0.5,  mx = 2.0,  def = 1.0,  unit = "x" },
        { feat = "exposure",  mn = 0.5,  mx = 2.0,  def = 1.0,  unit = "x" },
        { feat = "sharpen",   mn = 0,    mx = 3,    def = 0,    unit = "" },
        { feat = "fov",       mn = 80,   mx = 150,  def = 100,  unit = "deg" },
        { feat = "sprint",    mn = 500,  mx = 3000, def = 1000, unit = "u" },
        { feat = "climb",     mn = 500,  mx = 5000, def = 1000, unit = "u" },
    },
    pro = {
        { feat = "timescale", mn = 0.25, mx = 3.0,  def = 1.0,  unit = "x" },
        { feat = "gravity",   mn = 0.1,  mx = 2.0,  def = 1.0,  unit = "x" },
        { feat = "pro_speed", mn = 300,  mx = 3000, def = 800,  unit = "u/s" },
        { feat = "pro_jump",  mn = 400,  mx = 3000, def = 800,  unit = "u" },
        { feat = "scale",     mn = 0.5,  mx = 3.0,  def = 1.0,  unit = "x" },
        { feat = "shadow",    mn = 0,    mx = 4,    def = 3,    labels = { "off", "low", "mid", "high", "cinematic" } },
        { feat = "texture",   mn = 0,    mx = 3,    def = 3,    labels = { "off", "low", "mid", "high" } },
        { feat = "aa",        mn = 0,    mx = 4,    def = 4,    unit = "" },
        { feat = "pp",        mn = 0,    mx = 4,    def = 3,    unit = "" },
        { feat = "particles", mn = 100,  mx = 2000, def = 1000, unit = "k" },
        { feat = "drawdist",  mn = 0.5,  mx = 2.0,  def = 1.0,  unit = "x" },
        { feat = "lod",       mn = 0.5,  mx = 2.0,  def = 1.0,  unit = "x" },
        { feat = "aniso",     mn = 0,    mx = 16,   def = 4,    unit = "x" },
    },
}

local function FmtVal(it, v)
    if it.labels then
        local i = math.floor(v + 0.5) + 1
        if it.labels[i] then return it.labels[i] end
    end
    local u = it.unit or ""
    if u ~= "" then return string.format("%g%s", v, u) end
    return string.format("%g", v)
end

-- r44: tab whitelist gate. User spec: only whitelisted users open AI/Pro/
-- Plus; PRO may click PLUS, PLUS may not click PRO/AI; level 0 and blacklist
-- are locked out. Core_WL's JXWL.Allow implements exactly this hierarchy
-- (host pass, Steam64 double-layer, PLUS=1..3 / PRO=3.5+), so reuse it.
local PAGE_NEED = { PlusPageV48 = "PLUS", ProPageV48 = "PRO", AiPageV46 = "PRO" }
local function WlGate(pgName)
    local need = PAGE_NEED[pgName]
    if not need then return true end
    local jw = _G.JXWL
    if type(jw) ~= "table" or type(jw.Allow) ~= "function" then
        return true -- resolver not registered yet (pre-Core_WL boot instant)
    end
    local ok = false
    pcall(function() ok = jw.Allow(need) end)
    return ok
end

local function WireNewTabs(tag)
    if not Valid(M.shell) then return end
    -- r44: recreation guard. A healed/recreated shell is a NEW widget
    -- instance and per-shell OnClicked bindings die with the old one - the
    -- stale ledger then skipped every re-wire ("nothing new to wire" while
    -- the fresh tree had zero handlers). Track the instance address and
    -- reset the ledger + safe-page cursor when it changes.
    local instKey = nil
    pcall(function() instKey = tostring(M.shell:GetAddress()) end)
    -- r52: compare by ADDRESS, never by wrapper identity - UE4SS mints a new
    -- Lua wrapper per find call, so a wrapper compare re-fired ResetWiring on
    -- EVERY pass (same underlying widget, 4 resets in 30 s in the 08:28
    -- session), wiping JXUICBS between registration and dispatch.
    if (instKey and instKey ~= M.wiredInst)
        or (not instKey and M.wiredShell ~= M.shell) then
        ResetWiring()
        M.wiredShell = M.shell
        M.wiredInst = instKey
        Log("NU| shell instance changed (" .. tostring(instKey) .. ") - wiring ledger reset")
    end
    if type(_G.JXTabGo) ~= "function" then
        Log("NU| wire: JXTabGo absent (main.lua not ready)")
        return
    end
    local tree = nil
    pcall(function() tree = M.shell.WidgetTree end)
    local root = nil
    if tree then pcall(function() root = tree.RootWidget end) end
    if not root then root = M.shell end
    local fl = Walk(root, 14, 2500)
    _G.JXUICBS = _G.JXUICBS or {}
    local CBS = _G.JXUICBS
    local n = 0

    -- r36 root fix [B]: rail tabs wire BY PAGE NAME, never a literal index.
    -- v49 removed PlusPageV183/ProPageV183 from the switcher and every page
    -- after index 11 shifted down by two - the old literal wiring sent
    -- TabBtn_15 (AI) to JXTabGo(15) = NetPageV46. Resolve each button's
    -- target from the LIVE switcher children (same primitive as the nav
    -- pills below), then go through JXTabGo so per-page route actions and
    -- TabIndex adoption still run. TabBtn_0..11 are wired as well: their
    -- native BndEvt binding fires first with the same target, our Lua pass
    -- adds bookkeeping + click telemetry ("NU| CLICK").
    local sw = ByName(fl, "JinxingTabSwitcher")
        if sw then
            M.wiredSwitcher = sw.w
            -- r54: export the RENDERED panel's switcher. FindAllOf order is
            -- nondeterministic and main.lua's AcquireTabSwitcher used to serve
            -- a hidden sibling shell's switcher (clicks switched invisibly).
            _G.JXWiredSwitcher = sw.w
        end
    -- r43 RAIL REALIGN. The 854D2A38 pak reordered the switcher:
    --   12=EntPageV184, 13=Ai, 14=Save(AMS), 15=Net, 16=Keys, 17=Help,
    --   18=Plus, 19=Pro, 20=HideSeek
    -- but the Core graph's baked BndEvt bindings for TabBtn_12/13/14 still
    -- SetActiveWidgetIndex(12/13/14) from the OLD layout (12=Plus,13=Pro,
    -- 14=Ent). Symptom set (user-verified 03:31 session): clicking PLUS
    -- opened the entertainment page, clicking PRO opened the AI page,
    -- clicking 娱乐 opened the AMS page. Our name-resolved handler fires
    -- AFTER the BP one and corrects the index, so the button label and the
    -- page it opens now agree again.
    -- r44: rail map is REALITY-checked. TabBtn_12/13/14 do not exist in the
    -- F5531FBD generation (absent from the pak name table and the widget
    -- tree; the tree is TabBtn_0..11 + pills TabNavBtn_0/1/2 + TabBtn_15..19).
    -- The pills carry the only baked bindings (ComponentBoundEvent_60/61/62),
    -- and the r44 pak bytecode patch retargeted their constants to 18/19/12.
    local railMap = {
        TabBtn_0 = "ModsPageV43", TabBtn_1 = "PerfPageV43",
        TabBtn_2 = "PlayersPageV43", TabBtn_3 = "ActorPageV43",
        TabBtn_4 = "BanPageV43", TabBtn_5 = "SetPageV43",
        TabBtn_6 = "SpecialPageV39", TabBtn_7 = "InfoPageV43",
        TabBtn_8 = "RosterPageV39", TabBtn_9 = "MapPageV39",
        TabBtn_10 = "MeshPageV43", TabBtn_11 = "FeatPageV53",
        TabBtn_15 = "AiPageV46", TabBtn_16 = "SavePageV46",
        TabBtn_17 = "NetPageV46", TabBtn_18 = "KeysPageV46",
        TabBtn_19 = "HelpPageV46",
    }
    for nm, pgName in pairs(railMap) do
        local e = ByName(fl, nm)
        if e and not wiredTabs[nm] then
            local idx = -1
            if sw then
                pcall(function()
                    local cnt = sw.w:GetChildrenCount()
                    for i = 0, cnt - 1 do
                        local ch = sw.w:GetChildAt(i)
                        local okn, cn2 = pcall(function() return ch:GetFName():ToString() end)
                        if okn and cn2 == pgName then idx = i break end
                    end
                end)
            end
            if idx >= 0 then
                M.tabIdx = M.tabIdx or {}
                M.tabIdx[nm] = idx
                M.pgIdx = M.pgIdx or {}
                M.pgIdx[pgName] = idx
                local baked = tonumber(nm:match("TabBtn_(%d+)") or "") or -1
                M.btnPage = M.btnPage or {}
                M.btnPage[nm] = pgName
                CBS[nm] = function()
                    if not WlGate(pgName) then
                        Log("NU| gate refused " .. nm .. " -> " .. pgName .. " (needs " .. tostring(PAGE_NEED[pgName]) .. ")")
                        Say("jnewui: insufficient whitelist level for " .. pgName .. " (requires " .. tostring(PAGE_NEED[pgName]) .. ")")
                        pcall(function() sw.w:SetActiveWidgetIndex(M.curSafeIdx or 0) end)
                        return
                    end
                    M.curSafeIdx = idx
                    Log("NU| CLICK " .. nm .. " -> " .. pgName .. "[" .. idx .. "]"
                        .. (baked >= 0 and baked ~= idx and (" (realigned from BP " .. baked .. ")") or ""))
                    -- r54: switch DIRECTLY on the wired (rendered) switcher.
                    -- The old path went through global JXTabGo, whose
                    -- AcquireTabSwitcher serves FindAllOf order - with hidden
                    -- sibling shells alive it served THEIR switcher, so clicks
                    -- switched an invisible panel and the visible one never
                    -- moved (user: "还是没有切呀").
                    local okc = pcall(function() sw.w:SetActiveWidgetIndex(idx) end)
                    if not okc then Log("NU| ERR " .. nm .. ": direct switch failed") end
                    pcall(function()
                        if _G.JX and _G.JX.TabRunRoute then _G.JX.TabRunRoute(idx) end
                    end)
                end
                -- r42: hit-test repair. The 03:02/03:12 sessions had the
                -- editor-added tabs (AI/Net/Keys/Help) visible but eating
                -- ZERO clicks (no "NU| CLICK" echoes) while BP-bound
                -- originals worked: a baked-in non-hittable visibility or a
                -- disabled state renders fine and swallows every hit.
                -- Read both, force them healthy, log the before/after.
                local visN, enB = nil, nil
                pcall(function() visN = e.w:GetVisibility() end)
                pcall(function() enB = e.w.bIsEnabled end)
                local fixed = ""
                if visN ~= nil and visN ~= 0 then
                    pcall(function() e.w:SetVisibility(0) end)
                    fixed = " vis" .. tostring(visN) .. "->0"
                end
                if enB == false then
                    pcall(function() e.w.bIsEnabled = true end)
                    fixed = fixed .. " en->true"
                end
                -- r51: register in our Lua input map only. Keep native BP
                -- bindings untouched; dispatch after release, not on down.
                wiredTabs[nm] = true
                M.cbsOrder[#M.cbsOrder + 1] = { nm = nm, e = e, page = pgName }
                -- r55 rail-fit: the five pipeline-authored tabs render with
                -- ragged proportions (user: "每个标签页的比例不同"). r53's
                -- padding copy was silent and unverifiable (no log line, all
                -- pcall-swallowed, and GetPadding may not even exist as a
                -- UFUNCTION on this slot class - it may never have applied).
                -- Copy padding AND slot Size from TabBtn_0 - property read
                -- first, UFUNCTION setter second - only when both buttons
                -- sit in the SAME slot class so a canvas layout is never
                -- distorted, and log one diagnostic per button so the next
                -- session shows the real layout ground truth.
                if pgName == "AiPageV46" or pgName == "SavePageV46"
                    or pgName == "NetPageV46" or pgName == "KeysPageV46"
                    or pgName == "HelpPageV46" then
                    pcall(function()
                        local s0 = ByName(fl, "TabBtn_0")
                        if s0 and s0.e and s0.e.w and e.w and e.w.Slot then
                            local slot0 = s0.e.w.Slot
                            local cls0, cls1 = "?", "?"
                            pcall(function() cls0 = slot0:GetClass():GetFName():ToString() end)
                            pcall(function() cls1 = e.w.Slot:GetClass():GetFName():ToString() end)
                            local function CopyProp(name, setter)
                                local okr, v = pcall(function() return slot0[name] end)
                                if not okr or v == nil then return false end
                                local okw = pcall(function() e.w.Slot[setter](e.w.Slot, v) end)
                                if not okw then okw = pcall(function() e.w.Slot[name] = v end) end
                                return okw
                            end
                            local didPad = CopyProp("Padding", "SetPadding")
                            local didSize = false
                            if cls0 == cls1 then didSize = CopyProp("Size", "SetSize") end
                            local d0, d1 = "?", "?"
                            pcall(function()
                                local v = s0.e.w:GetDesiredSize()
                                d0 = string.format("%.0fx%.0f", tonumber(v.X) or 0, tonumber(v.Y) or 0)
                            end)
                            pcall(function()
                                local v = e.w:GetDesiredSize()
                                d1 = string.format("%.0fx%.0f", tonumber(v.X) or 0, tonumber(v.Y) or 0)
                            end)
                            Log("NU| railfit " .. nm .. " slot=" .. cls1 .. " ref=" .. cls0
                                .. " pad=" .. tostring(didPad) .. " size=" .. tostring(didSize)
                                .. " want=" .. d0 .. " have=" .. d1)
                        end
                    end)
                end
                n = n + 1
                Log("NU| wire " .. nm .. " -> " .. pgName .. "[" .. idx .. "] input=native-state ok=true"
                    .. " vis=" .. tostring(visN) .. " en=" .. tostring(enB) .. (fixed ~= "" and (" FIXED:" .. fixed) or ""))
            else
                Log("NU| wire " .. nm .. ": page " .. pgName .. " not found in switcher")
            end
        end
    end

    -- PLUS/PRO nav pills + the 娱乐 pill -> their v48/v184 pages (name-
    -- resolved the same way). r44: TabNavBtn_2 wired (it was Lua-orphaned);
    -- gated pages revert to the last allowed page on refusal.
    if sw then
        local want = { TabNavBtn_0 = "PlusPageV48", TabNavBtn_1 = "ProPageV48", TabNavBtn_2 = "EntPageV184" }
        for nm, pgName in pairs(want) do
            local e = ByName(fl, nm)
            if e and not wiredTabs[nm] then
                local idx = -1
                pcall(function()
                    local cnt = sw.w:GetChildrenCount()
                    for i = 0, cnt - 1 do
                        local ch = sw.w:GetChildAt(i)
                        local okn, cn2 = pcall(function() return ch:GetFName():ToString() end)
                        if okn and cn2 == pgName then idx = i break end
                    end
                end)
                if idx >= 0 then
                    M.tabIdx = M.tabIdx or {}
                    M.tabIdx[nm] = idx
                    M.pgIdx = M.pgIdx or {}
                    M.pgIdx[pgName] = idx
                    M.btnPage = M.btnPage or {}
                    M.btnPage[nm] = pgName
                    CBS[nm] = function()
                        if not WlGate(pgName) then
                            Log("NU| gate refused " .. nm .. " -> " .. pgName .. " (needs " .. tostring(PAGE_NEED[pgName]) .. ")")
                            Say("jnewui: insufficient whitelist level for " .. pgName .. " (requires " .. tostring(PAGE_NEED[pgName]) .. ")")
                            pcall(_G.JXTabGo, M.curSafeIdx or 0)
                            return
                        end
                        M.curSafeIdx = idx
                        Log("NU| CLICK " .. nm .. " -> " .. pgName)
                        pcall(function() sw.w:SetActiveWidgetIndex(idx) end)
                    end
                    local visN, enB = nil, nil
                    pcall(function() visN = e.w:GetVisibility() end)
                    pcall(function() enB = e.w.bIsEnabled end)
                    local fixed = ""
                    if visN ~= nil and visN ~= 0 then
                        pcall(function() e.w:SetVisibility(0) end)
                        fixed = " vis" .. tostring(visN) .. "->0"
                    end
                    if enB == false then
                        pcall(function() e.w.bIsEnabled = true end)
                        fixed = fixed .. " en->true"
                    end
                    wiredTabs[nm] = true
                    M.cbsOrder[#M.cbsOrder + 1] = { nm = nm, e = e, page = pgName }
                    n = n + 1
                    Log("NU| wire " .. nm .. " -> " .. pgName .. "[" .. idx .. "] input=native-state ok=true"
                        .. " vis=" .. tostring(visN) .. " en=" .. tostring(enB) .. (fixed ~= "" and (" FIXED:" .. fixed) or ""))
                else
                    Log("NU| wire " .. nm .. ": page " .. pgName .. " not found in switcher")
                end
            end
        end
    end

    -- r43: orphan page rescue + alignment audit. HideSeekPageV49 sits at
    -- switcher slot 20 with NO rail button pointing at it (the rail has
    -- 0..19); resolve it by name so the Ctrl+G hotkey has a live target,
    -- and log the full button->slot map once so page-order drift is
    -- self-evident on every boot.
    if sw then
        M.pgIdx = M.pgIdx or {}
        for _, pgName in ipairs({ "HideSeekPageV49" }) do
            if M.pgIdx[pgName] == nil then
                local idx = -1
                pcall(function()
                    local cnt = sw.w:GetChildrenCount()
                    for i = 0, cnt - 1 do
                        local ch = sw.w:GetChildAt(i)
                        local okn, cn2 = pcall(function() return ch:GetFName():ToString() end)
                        if okn and cn2 == pgName then idx = i break end
                    end
                end)
                if idx >= 0 then
                    M.pgIdx[pgName] = idx
                    Log("NU| page " .. pgName .. " resolved at [" .. idx .. "] (no rail button - Ctrl+G)")
                end
            end
        end
        local parts = {}
        for k = 0, 19 do
            parts[#parts + 1] = k .. ":" .. tostring((M.tabIdx or {})["TabBtn_" .. k])
        end
        Log("NU| align map " .. table.concat(parts, " "))
    end

    -- slider rows: value text live, command fires on release
    -- r43 CASE FIX: the pak widgets are JxPlusSlider_*/JxProSlider_* (title
    -- case, tree dump 03:31) - this loop used to build "JxPLUSSlider_"/
    -- "JxPROSlider_" (grp:upper()), so ZERO of the 23 sliders ever wired
    -- and the Plus/Pro pages read as featureless even when opened.
    for _, grp in ipairs({ "plus", "pro" }) do
        local pfx = "Jx" .. grp:sub(1, 1):upper() .. grp:sub(2)
        for _, it in ipairs(SLIDER_CATALOG[grp]) do
            local snm = pfx .. "Slider_" .. it.feat
            local vnm = pfx .. "Val_" .. it.feat
            local se = ByName(fl, snm)
            local ve = ByName(fl, vnm)
            if se and not wiredTabs[snm] then
                wiredTabs[snm] = true
                n = n + 1
                if ve then
                    CBS[snm .. "_val"] = function(v)
                        pcall(function() ve.w:SetText(FT(FmtVal(it, v))) end)
                    end
                end
                CBS[snm .. "_cmd"] = function(v)
                    -- OnMouseCaptureEnd has no float parameter. Read the
                    -- actual slider, never silently send the catalog default.
                    v = tonumber(v)
                    if not v then pcall(function() v = tonumber(se.w:GetValue()) end) end
                    if not v then Log("NU| ERR slider " .. it.feat .. ": value unavailable") return end
                    if type(_G.JXExecCmd) == "function" then
                        local okc, err = pcall(_G.JXExecCmd,
                            "jxslider " .. it.feat .. " " .. string.format("%g", v))
                        if not okc then Log("NU| ERR slider " .. it.feat .. ": " .. tostring(err)) end
                    else
                        Log("NU| ERR slider " .. it.feat .. ": executor unavailable")
                    end
                end
                local initial = nil
                pcall(function() initial = tonumber(se.w:GetValue()) end)
                M.sliderOrder[#M.sliderOrder + 1] = {
                    nm = snm, e = se, valueKey = snm .. "_val", commandKey = snm .. "_cmd",
                    lastValue = initial, page = (grp == "plus") and "PlusPageV48" or "ProPageV48",
                }
                Log("NU| wire slider " .. it.feat .. " input=native-state ok=true")
            end
        end
    end

    -- HideSeek page: seekers slider + start/stop buttons (r32: user asked for
    -- the slider form - "拉滑条就可以自定义多少个抓捕者")
    local hsSlider = ByName(fl, "JxHS_Seekers")
    local hsVal = ByName(fl, "JxHS_SeekersVal")
    if hsSlider and not wiredTabs["JxHS_Seekers"] then
        wiredTabs["JxHS_Seekers"] = true
        n = n + 1
        if hsVal then
            CBS["JxHS_val"] = function(v)
                pcall(function() hsVal.w:SetText(FT(string.format("%d", math.floor(v)))) end)
            end
        end
        CBS["JxHS_cmd"] = function(v)
            v = tonumber(v)
            if not v then pcall(function() v = tonumber(hsSlider.w:GetValue()) end) end
            if v then M.hsSeekers = math.floor(v) end
        end
        local initial = nil
        pcall(function() initial = tonumber(hsSlider.w:GetValue()) end)
        if initial then M.hsSeekers = math.floor(initial) end
        M.sliderOrder[#M.sliderOrder + 1] = {
            nm = "JxHS_Seekers", e = hsSlider, valueKey = "JxHS_val", commandKey = "JxHS_cmd",
            lastValue = initial, page = "HideSeekPageV49",
        }
        Log("NU| wire hideseek seekers slider input=native-state ok=true")
    end
    local hsBtns = { JxHS_Start = "jxhide start", JxHS_Stop = "jxhide stop" }
    for nm, base in pairs(hsBtns) do
        local e = ByName(fl, nm)
        if e and not wiredTabs[nm] then
            wiredTabs[nm] = true
            M.cbsOrder[#M.cbsOrder + 1] = { nm = nm, e = e, page = "HideSeekPageV49", action = true }
            n = n + 1
            CBS[nm] = function()
                -- The old local 'seekers' was out of scope here. Read the
                -- shared per-shell value, including a just-released drag.
                if base == "jxhide start" and hsSlider and Valid(hsSlider.w) then
                    pcall(function() M.hsSeekers = math.floor(hsSlider.w:GetValue()) end)
                end
                local cmdline = (base == "jxhide start")
                    and ("jxhide start " .. tostring(M.hsSeekers or 2)) or base
                Log("NU| CLICK " .. nm .. " -> " .. cmdline)
                local okc, err = pcall(_G.JXExecCmd, cmdline)
                if not okc then Log("NU| ERR " .. nm .. ": " .. tostring(err)) end
            end
            Log("NU| wire " .. nm .. " -> " .. base .. " input=native-state ok=true")
        end
    end

    M.wireComplete = (sw ~= nil)
    for k = 15, 19 do
        if not wiredTabs["TabBtn_" .. k] then M.wireComplete = false end
    end
    if n > 0 then
        Log("NU| INPUTMAP buttons=" .. #M.cbsOrder .. " sliders=" .. #M.sliderOrder .. " umg-delegates=0")
    elseif not M.wireComplete then
        Log("NU| wire[" .. tostring(tag) .. "] incomplete - retrying on poll")
    end
    -- r42: truth fills - status text that was baked as placeholder now shows
    -- reality (the "明明有网却显示离线" class of lie). r43: the ActorPageV43
    -- fill is DELETED - it positionally vandalised PageHdrTxt_3 and the
    -- search-bar labels (FillPageTexts is now whitelist-gated so it can
    -- never happen again); AMS gets its own identity fill on SavePageV46.
    -- r48: OFF by default. The chronic 0xc0000374 heap-corruption crashes
    -- (ntdll, 15 WER hits since Sep 28) ride on FText marshaling, and these
    -- cosmetic fills ran SetText on EVERY new shell instance. Re-enable by
    -- writing "on" into config/truth_fills.txt. juiskin labels and the
    -- slider/hideseek value texts keep their channels.
    if M.truthFills == nil then
        M.truthFills = false
        pcall(function()
            local tf = (_G.JXSidecarDir or "") .. "../config/truth_fills.txt"
            local h = io.open(tf, "r")
            if h then
                M.truthFills = ((h:read("*l") or ""):lower():find("on", 1, true) ~= nil)
                h:close()
            end
        end)
        if not M.truthFills then
            Log("r48: cosmetic truth fills OFF (0xc0000374 mitigation; config/truth_fills.txt = on re-enables)")
        end
    end
    if M.truthFills then
        pcall(function()
            local cfg = (_G.JXSidecarDir or "") .. "../config/"
            local wl = CountLines(cfg .. "whitelist.txt")
            local jn = _G.JPSNET and _G.JPSNET.status or nil
            local src = (jn and jn.cfgSource) or "none"
            FillPageTexts("NetPageV46", {
                "JX 网络状态(实时)",
                "同步通道: direct/ghproxy",
                "白名单: " .. tostring(wl) .. " 条 | 清单: " .. tostring(src),
            })
            FillPageTexts("SavePageV46", {
                "JX AMS 地图存档 (JXAMS-<图名>.sav)",
                "提取/生成: jxacl | 状态: jams",
                "存图: jxsave | 读图: jxload (帮助页有全表)",
            })
        end)
    end
end

-- ============ Mods page: real loaded-mods list (r34) ============
-- The user mandated the 模组 tab shows the ACTUAL loaded-mod list. The pak
-- ships a dedicated TextBlock (ModListBtn_Info) under ModsPageV43; fill it
-- from main.lua's jmods machinery (UE4SS.log scan -> mods_current.txt).
local function FillModsList(fl)
    local e = ByName(fl, "ModListBtn_Info")
    if not e or e.cls ~= "TextBlock" then return end
    if type(_G.JXListLoadedMods) == "function" then pcall(_G.JXListLoadedMods) end
    local lines = {}
    local path = type(_G.JXModsListFile) == "string" and _G.JXModsListFile or nil
    if path then
        pcall(function()
            local f = io.open(path, "r")
            if f then
                for ln in f:lines() do
                    if #ln > 0 then lines[#lines + 1] = ln end
                    if #lines >= 22 then break end
                end
                f:close()
            end
        end)
    end
    local txt
    if #lines > 0 then
        txt = "已加载模组 Loaded Mods:\n" .. table.concat(lines, "\n")
    else
        txt = "已加载模组 Loaded Mods:\n[稍候] 进入对局后自动生成；或聊天框输入 jmods"
    end
    local ftxt = FT(txt)
    if ftxt then pcall(function() e.w:SetText(ftxt) end) end
end

-- ============ the pass ============
-- opts.force   = style even if M.applied (B-attempt after world change re-arms anyway)
-- opts.anyVis  = skip the visible-only gate (B press means Core just showed it)
function M.Pass(tag, opts)
    opts = opts or {}
    -- r58: the 10:18 session fired five passes inside one millisecond, each one
    -- re-running FindAllOf over every live shell and re-walking the tree. That
    -- is pure native work on objects that may be mid-teardown. Coalesce every
    -- unforced pass inside a 250 ms window; forced passes (B wave, rearm,
    -- jnewui) are never dropped.
    local nowClock = os.clock()
    if not opts.force and type(M.lastPassAt) == "number" and (nowClock - M.lastPassAt) < 0.25 then
        Log("pass[" .. tostring(tag or "?") .. "] coalesced (< 250 ms since the last pass)")
        return { tag = tostring(tag or "?"), walked = 0, texts = 0, buttons = 0, slotMoves = 0,
            boxSlots = 0, fillSlots = 0, cells = 0, pages = 0, tabfills = 0, notes = { "coalesced" } }
    end
    M.lastPassAt = nowClock
    local rep = { tag = tostring(tag or "?"), t = os.date("%H:%M:%S"),
        walked = 0, texts = 0, buttons = 0, slotMoves = 0, boxSlots = 0,
        fillSlots = 0, cells = 0, pages = 0, tabfills = 0, notes = {} }

    local w, src = AcquireShell()
    if not w then
        local coreState = Valid(M.core) and "core-ok-no-ui" or "no-core"
        rep.notes[1] = "shell not found (" .. coreState .. ")"
        Log("pass[" .. rep.tag .. "] skipped: no shell (" .. coreState .. ")")
        return rep
    end
    if M.applied and Valid(M.shell) and not opts.force then
        rep.notes[1] = "already applied"
        Log("pass[" .. rep.tag .. "] skipped: already applied (src=" .. tostring(src) .. ")")
        return rep
    end

    if not ResolveClasses() then
        rep.notes[1] = "class resolve failed"
        Log("pass aborted: UMG classes not found")
        return rep
    end

    local vs = VisState(w)
    rep.shellVis = vs
    if not opts.anyVis and vs == "hid" then
        rep.notes[1] = "shell hidden"
        Log("pass[" .. rep.tag .. "] skipped: shell hidden (src=" .. tostring(src) .. ")")
        return rep
    end

    local tree = nil
    pcall(function() tree = w.WidgetTree end)
    local root = nil
    if tree then pcall(function() root = tree.RootWidget end) end
    if not root then root = w end

    local fl = Walk(root, 14, 2500)
    rep.walked = #fl
    -- r59: publish the walked tree. JxActorUI used to run its own 2500-node
    -- walk every 2 s for widgets that are not exposed as BindWidget properties;
    -- one shared list removes that second walk entirely. Cleared by
    -- ResetWiring() so no handle outlives its world.
    M.flat = fl
    -- v4.4: classify all live shells BEFORE styling (rail/old/dual verdict)
    rep.verdict = RunVerdict("pass:" .. tostring(tag))
    if #fl < 10 then
        rep.notes[1] = "tree too small (" .. #fl .. ")"
        Log("pass[" .. rep.tag .. "] aborted: tree only " .. #fl .. " nodes")
        return rep
    end

    if M.autodump and not M.dumpedPre then
        M.dumpedPre = true
        WriteConfig("newui_tree_pre.txt", DumpLines(fl, "pre"))
        Log("dump(pre): " .. tostring(#fl) .. " widgets")
    end

    -- 1. global theme sweep (string-class dispatch)
    for _, e in ipairs(fl) do
        local wd = e.w
        local cn = e.cls
        if cn == "Border" then
            SaveVis(wd)
            -- Border::SetBrushColor(FLinearColor) - FLAT form
            pcall(function() wd:SetBrushColor(TH.bgPanel) end)
        elseif cn == "TextBlock" then
            local role = "main"
            local nl = string.lower(e.name)
            if string.find(nl, "hint", 1, true) or string.find(nl, "info", 1, true)
                or string.find(nl, "dim", 1, true) then
                role = "dim"
            elseif string.find(nl, "tab", 1, true) then
                role = "tab"
            end
            StyleText(wd, role)
            rep.texts = rep.texts + 1
        elseif cn == "Button" then
            local hot = string.find(e.name, "TabBtn", 1, true) ~= nil
            StyleButton(wd, hot)
            rep.buttons = rep.buttons + 1
        elseif cn == "Image" then
            SaveVis(wd)
            -- Image::SetColorAndOpacity(FLinearColor) - FLAT form
            pcall(function()
                wd:SetColorAndOpacity({ R = 0.04, G = 0.05, B = 0.07, A = 0.55 })
            end)
        end
    end

    -- 2. root chrome: retitle only - positions/sizes belong to the pak rail shell
    -- v4.4: generic title finder (rail shell names may differ) + OLD-PAK red warn
    ApplyTitle(fl, lastVerdict == "OLD")
    pcall(FillModsList, fl)

    -- 5. page grids by real names
    for name, mode in pairs(PAGES) do
        local e = ByName(fl, name)
        if e then
            pcall(GridPage, rep, e.w, mode)
        else
            rep.notes[#rep.notes + 1] = name .. ":absent"
        end
    end

    M.stats = rep
    M.applied = true
    pcall(WireNewTabs, "pass")
    if M.autodump and not M.dumpedPost then
        M.dumpedPost = true
        WriteConfig("newui_tree.txt", DumpLines(fl, "post"))
        Log("dump(post): " .. tostring(#fl) .. " widgets")
    end
    Log(string.format("pass[%s] src=%s vis=%s verdict=%s walked=%d texts=%d btns=%d moves=%d fills=%d tabfills=%d cells=%d pages=%d",
        rep.tag, tostring(src), tostring(rep.shellVis), tostring(rep.verdict), rep.walked, rep.texts, rep.buttons,
        rep.slotMoves, rep.fillSlots, rep.tabfills, rep.cells, rep.pages))
    -- r58: cumulative native-call census (see ClassName/WName/Valid/Walk). Diff
    -- two of these lines and compare with crashlog.txt's SKIPPED counts in the
    -- same seconds to name the primitive that is faulting inside UE4SS.dll.
    Log(string.format("NU| nc cls=%d name=%d valid=%d node=%d child=%d deadnode=%d",
        M.nc.cls, M.nc.name, M.nc.valid, M.nc.cnt, M.nc.child, M.nc.deadnode))
    return rep
end

function M.Dump(phase)
    local w, src = AcquireShell()
    if not w then
        Say("jnewui dump: no shell (core=" .. tostring(Valid(M.core)) .. ")")
        return
    end
    local tree = nil
    pcall(function() tree = w.WidgetTree end)
    local root = nil
    if tree then pcall(function() root = tree.RootWidget end) end
    if not root then root = w end
    local fl = Walk(root, 14, 2500)
    local name = (phase == "pre") and "newui_tree_pre.txt" or "newui_tree.txt"
    WriteConfig(name, DumpLines(fl, phase))
    Say("jnewui dump(" .. tostring(phase) .. "): " .. tostring(#fl) .. " widgets (src=" .. tostring(src) .. ")")
    Log("dump(" .. tostring(phase) .. "): " .. tostring(#fl) .. " widgets")
end

-- ============ restyle sweep (light, no moves) ============
-- Re-asserts theme colors over any juiskin re-tint that landed after the
-- full pass. Runs on every B wave once the layout is applied - one walk,
-- colors + title + tab fills only.
function M.RestyleSweep(tag)
    local w = AcquireShell()
    if not w then
        Log("sweep[" .. tostring(tag) .. "] no shell")
        return nil
    end
    local tree = nil
    pcall(function() tree = w.WidgetTree end)
    local root = nil
    if tree then pcall(function() root = tree.RootWidget end) end
    if not root then root = w end
    local fl = Walk(root, 14, 2500)
    -- v4.4: keep the verdict fresh on every B wave (cheap, writes on change only)
    pcall(RunVerdict, "sweep:" .. tostring(tag))
    local texts, btns = 0, 0
    for _, e in ipairs(fl) do
        if e.cls == "TextBlock" then
            local role = "main"
            local nl = string.lower(e.name)
            if string.find(nl, "hint", 1, true) or string.find(nl, "info", 1, true)
                or string.find(nl, "dim", 1, true) then
                role = "dim"
            elseif string.find(nl, "tab", 1, true) then
                role = "tab"
            end
            StyleText(e.w, role)
            texts = texts + 1
        elseif e.cls == "Button" then
            StyleButton(e.w, string.find(e.name, "TabBtn", 1, true) ~= nil)
            btns = btns + 1
        elseif e.cls == "Border" then
            pcall(function() e.w:SetBrushColor(TH.bgPanel) end)
        end
    end
    ApplyTitle(fl, lastVerdict == "OLD")
    -- r42: the tint cadence calls this every ~10 s - keep the log quiet for it
    if tostring(tag) ~= "tint" then
        Log("sweep[" .. tostring(tag) .. "] walked=" .. #fl .. " texts=" .. texts .. " btns=" .. btns)
    end
    return texts
end

-- ============ restore ============
function M.Restore()
    local nv, np = 0, 0
    for w, rec in pairs(M.orig) do
        pcall(function()
            if rec.vis then w:SetVisibility(rec.vis) end
        end)
        nv = nv + 1
    end
    for w, rec in pairs(M.pos) do
        pcall(function()
            local s = GetSlot(w)
            if s and rec.kind then
                if rec.kind == "CanvasPanelSlot" and rec.x then
                    s:SetPosition({ X = rec.x, Y = rec.y or 0 })
                    if rec.sw then s:SetSize({ X = rec.sw, Y = rec.sh or 0 }) end
                elseif rec.kind == "HorizontalBoxSlot" or rec.kind == "VerticalBoxSlot" then
                    s:SetSize({ Value = rec.val or 1.0, SizeRule = rec.sr or 0 })
                    if rec.pl then
                        s:SetPadding({ Left = rec.pl, Top = rec.pt or 0, Right = rec.pr or 0, Bottom = rec.pb or 0 })
                    end
                end
            end
        end)
        np = np + 1
    end
    M.orig = {}
    M.pos = {}
    M.applied = false
    M.dumpedPost = false
    Say("jnewui: restored vis=" .. nv .. " pos=" .. np .. " (colors need map reload)")
end

-- ============ re-arm on world change (debounced 3s) ============
local lastRearm = -10
function M.Rearm(tag)
    local now = os.time()
    if now - lastRearm < 3 then
        -- r58: the debounce used to drop the whole call. Two world changes
        -- inside 3 s (SplashScreen -> Lobby is exactly that) therefore left the
        -- previous world's shell and its 500+ widget handles in the caches, and
        -- every later pass walked a dead tree. Suppress the rescan, never the
        -- invalidation.
        M.shell, M.shellSrc, M.applied, M.dumpedPost = nil, nil, false, false
        M.orig, M.pos = {}, {}
        ResetWiring()
        Log("NU| rearm (" .. tostring(tag) .. ") debounced - caches dropped, rescan already pending")
        return
    end
    lastRearm = now
    M.shell = nil
    M.shellSrc = nil
    M.applied = false
    M.dumpedPost = false
    -- stale handles from the previous map must not survive into Restore/SavePos
    M.orig = {}
    M.pos = {}
    ResetWiring()   -- discard callbacks, widget refs and sampled state together
    coreRespawns = 0 -- fresh world = fresh respawn budget
    Log("NU| rearm (" .. tostring(tag) .. ") - will rescan")
    -- codebase convention: ExecuteWithDelay callbacks are not guaranteed on the
    -- game thread - FindFirstOf/slot ops must be wrapped in ExecuteInGameThread
    ExecuteWithDelay(2000, function()
        ExecuteInGameThread(function() pcall(M.Pass, "world", { anyVis = true, force = true }) end)
    end)
    ExecuteWithDelay(6000, function()
        ExecuteInGameThread(function() pcall(M.Pass, "world2", { anyVis = true }) end)
    end)
end

-- ============ v5.1 input mode (r37: proven PC acquisition + retry + self-heal) ============
-- The 01:14 live session (r36) proved UEHelpers.GetPlayerController() can
-- return nil mid-level in this game: "NU| input true -> no-pc" fired once,
-- the panel opened cursor-less and ZERO clicks arrived the entire session
-- (wiring itself was all ok=true). main.lua's live-verified features
-- (blacklist / NET netspeed / AFK / kick) all acquire the PC via
-- FindAllOf("PlayerController") + IsLocalController() - adopt that exact
-- chain here, keep UEHelpers only as a secondary fallback, retry on no-pc,
-- and let the 2 s poll self-heal the cursor in BOTH directions so the
-- state can never strand again (map-load auto-shown shell included).
local inputOwned = false
local inputRetryTag = 0

local function FindPC()
    -- primary: exact-class list + local-controller pick (main.lua proven)
    local okA, pcs = pcall(FindAllOf, "PlayerController")
    if okA and type(pcs) == "table" then
        local firstValid = nil
        for _, pc in pairs(pcs) do
            if pc and pc:IsValid() then
                if firstValid == nil then firstValid = pc end
                local isLocal = false
                pcall(function() isLocal = pc:IsLocalController() end)
                if isLocal then return pc, "local" end
            end
        end
        if firstValid then return firstValid, "first" end
    end
    -- secondary: UEHelpers (nil mid-level in this game, harmless to try)
    local okU, pc2 = pcall(function() return UEHelpers.GetPlayerController() end)
    if okU and pc2 and pc2:IsValid() then return pc2, "uehelpers" end
    return nil, "none"
end

local function InputApply(on)
    -- returns "ok" | "no-pc" | "menu-skip"; never throws
    local PC = FindPC()
    if not PC then return "no-pc" end
    local WBL = nil
    pcall(function() WBL = StaticFindObject("/Script/UMG.Default__WidgetBlueprintLibrary") end)
    if on then
        pcall(function() PC.bShowMouseCursor = true end)
        -- r41: the cursor-shown-but-clicks-dead killers. The 03:02 session
        -- had the shell rendering, input "ok", all 21 buttons wired - and
        -- ZERO "NU| CLICK" echo lines: mouse events never reached the
        -- buttons. The remaining switches that can eat UMG clicks live on
        -- the PC and the viewport client; force them on every grant.
        pcall(function() PC.bEnableClickEvents = true end)
        pcall(function() PC.bEnableMouseOverEvents = true end)
        pcall(function()
            local lp = PC.Player
            local vc = lp and lp.ViewportClient or nil
            if vc and vc:IsValid() then vc.bIgnoreInput = false end
        end)
        if WBL and WBL:IsValid() then
            pcall(function() WBL:SetInputMode_GameAndUIEx(PC, nil, 0, false) end)
        end
        return "ok"
    end
    -- off: only hand input back when a pawn exists - menu worlds have no
    -- pawn and the menu owns input there (GameOnly would trap the menu)
    local pawn = nil
    pcall(function() pawn = PC.Pawn end)
    if pawn and pawn:IsValid() then
        pcall(function() PC.bShowMouseCursor = false end)
        if WBL and WBL:IsValid() then
            pcall(function() WBL:SetInputMode_GameOnly(PC) end)
        end
        return "ok"
    end
    return "menu-skip"
end

local function InputMode(on, tag)
    inputRetryTag = inputRetryTag + 1 -- cancels any pending retry ladder
    local okA, res = pcall(InputApply, on)
    if not okA then res = "err" end
    -- own the input ONLY when it actually applied: a "no-pc" open must leave
    -- inputOwned=false so the 2 s poll-heal keeps re-attempting instead of
    -- trusting a state that never took effect (the 01:14 stranding pattern)
    inputOwned = (on and okA and res == "ok") or false
    Log("NU| input " .. tostring(on) .. " -> " .. tostring(res)
        .. (tag and (" (" .. tag .. ")") or ""))
    -- r37: a cursor-less open ("no-pc") is exactly the 01:14 failure - the
    -- PC can be a beat away during possession/map transitions, so retry
    -- instead of giving up. The tag (bumped by any later InputMode call or
    -- a successful retry) cancels the rest; poll-heal is the second net.
    if on and res == "no-pc" then
        local myTag = inputRetryTag
        for k, d in ipairs({ 300, 600, 1200, 2000, 3500, 5000 }) do
            ExecuteWithDelay(d, function()
                ExecuteInGameThread(function()
                    if myTag ~= inputRetryTag then return end
                    local ok2, res2 = pcall(InputApply, true)
                    Log("NU| input retry " .. k .. " -> " .. tostring(ok2 and res2 or "err"))
                    if ok2 and res2 == "ok" then
                        inputOwned = true
                        inputRetryTag = inputRetryTag + 1
                    end
                end)
            end)
        end
    end
end

-- ============ poll (backup channel + heartbeat telemetry) ============
local hb = 0
-- r39: one-shot viewport belt. Auto-shown shells can render while
-- IsInViewport() denies; a single AddToViewport per shell reconciles the
-- bookkeeping (which also feeds focus/hit-testing) without touching layout.
-- Weak keys: dead shells drop out of the table with the GC.
local BeltedShells = setmetatable({}, { __mode = "k" })
local function ViewportBelt(s)
    if BeltedShells[s] then return end
    BeltedShells[s] = true
    local invp = false
    pcall(function() invp = (s:IsInViewport() == true) end)
    if not invp then
        pcall(function() s:AddToViewport(10000) end)
        Log("NU| belt AddToViewport (auto-shown shell)")
    end
end
local function PollOnce()
    if not M.enabled then return end
    if not M.inputStarted and StartNativeInput then StartNativeInput() end
    -- r37: cursor ownership follows "any shell renders" - BOTH directions,
    -- every tick. Covers the 01:14 "no-pc at open" stranding (retry ladder
    -- plus this net), the map-load auto-shown shell (visible but no B was
    -- pressed, so nothing ever set a cursor), and releases input when the
    -- last shell stops rendering (ESC / map change while open).
    -- r39: the auto-shown lobby shell rendered fine while IsInViewport()
    -- kept denying it, so the r37 conjunct never fired and lobby clicks got
    -- no cursor. Visibility is now the ONLY render authority; a denying
    -- invp triggers the one-shot viewport belt instead of vetoing.
    local anyRender = false
    local invpN = 0
    for _, s in ipairs(AllShells()) do
        if Valid(s) and VisState(s) == "vis" then
            anyRender = true
            local invp = false
            pcall(function() invp = (s:IsInViewport() == true) end)
            if invp then invpN = invpN + 1 else ViewportBelt(s) end
        end
    end
    -- r41: fight input theft every tick. The game's own menu code can
    -- re-assert its input mode after we grant ours; a stolen cursor or a
    -- flipped mode = clicks land nowhere ("cursor shown, nothing clicks").
    -- Read the cursor back every tick; if stolen, drop ownership so the
    -- grant below re-applies the FULL input mode. Belt-and-braces: re-apply
    -- the full grant every ~30 s even when the readback looks fine.
    local curShown = "?"
    if anyRender then
        local pc = FindPC()
        if pc then
            local shown = nil
            pcall(function() shown = (pc.bShowMouseCursor == true) end)
            curShown = tostring(shown)
            if shown == false then
                inputOwned = false
                Log("NU| input reassert (cursor was stolen)")
            elseif hb % 15 == 0 and inputOwned then
                InputMode(true, "reassert")
            end
        end
    end
    if anyRender and not inputOwned then
        InputMode(true, "poll-heal")
    elseif not anyRender and inputOwned then
        InputMode(false, "poll-release")
    end
    -- r42: color persistence. The pak graph re-tints its own widgets over
    -- time ("colors fade away" report), so re-assert the palette on a slow
    -- cadence instead of only on B presses. Every 5th tick (~10 s).
    if M.applied and anyRender and hb % 5 == 0 then
        pcall(M.RestyleSweep, "tint")
    end
    local w = AcquireShell()
    -- v4.6: player-restart used to kill the pak Core forever ("core lost
    -- (stale)" 21:17 session); guarded respawn keeps B alive after restart
    if not w and #AllShells() == 0 then
        -- r40: heal the map-change shell death - the widget instance dies
        -- with the old world while the Core ref stays "valid" (dead world),
        -- so the old respawn-only branch never fired and nobody recreated.
        HealNoShell()
    end
    hb = hb + 1
    if hb >= 15 then
        hb = 0
        local vs = w and VisState(w) or "none"
        Log("NU| hb core=" .. tostring(Valid(M.core)) .. " shell=" .. tostring(w ~= nil)
            .. " vis=" .. vs .. " applied=" .. tostring(M.applied) .. " invp=" .. tostring(invpN)
            .. " cur=" .. curShown .. " inputPolls=" .. tostring(M.inputPolls or 0)
            .. " clicks=" .. tostring(M.inputClicks or 0) .. " faults=" .. tostring(M.inputFaults or 0))
        pcall(RunVerdict, "hb")
    end
    if not w then return end
    local vs = VisState(w)
    -- A partial initial wire must retry even after the cosmetic pass was
    -- marked applied. No high-frequency tree walk in the input sampler.
    if vs ~= "hid" and (not M.wireComplete or M.wiredShell ~= w) then
        local okw, err = pcall(WireNewTabs, "poll")
        if not okw then Log("NU| wire retry error: " .. tostring(err):sub(1, 160)) end
    end
    -- "?" = unreadable enum: still attempt (Pass's own gate rejects "hid");
    -- B-listener and world channels remain the primary triggers anyway
    if vs ~= "hid" and not M.applied then
        ExecuteInGameThread(function() pcall(M.Pass, "auto") end)
    end
end

local function StartPoll()
    local function tick()
        -- PollOnce calls AcquireShell (FindFirstOf) - game thread required
        if type(ExecuteInGameThread) == "function" then
            ExecuteInGameThread(function() pcall(PollOnce) end)
        else
            pcall(PollOnce)
        end
        ExecuteWithDelay(2000, tick)
    end
    ExecuteWithDelay(6000, tick)
end

-- ============ v4.6 toggle machinery (Lua-authoritative, one shell) ============
-- The Core UFUNCTION is ensure-open (live proof: 7 presses, shell alive after
-- each). Lua therefore owns open/close; the Core BP is only a factory, called
-- at most once per world lifetime (zero shells -> create).

local function ShellRenders(w)
    -- r39: visibility is the render authority (see PollOnce) - the lobby's
    -- auto-shown shell renders while IsInViewport() denies, so the old
    -- conjunct made every consumer (poll net / close / sibling collapse)
    -- blind to exactly the shell users try to click
    if not Valid(w) then return false end
    return VisState(w) == "vis"
end

local function CloseAllShells()
    local n = 0
    for _, s in ipairs(AllShells()) do
        if ShellRenders(s) then
            pcall(function() s:SetVisibility(1) end)
            n = n + 1
        end
    end
    if inputOwned then InputMode(false, "close") end
    return n
end

local function OpenShell(core)
    -- clear a dead shell ref first (reflection write proven in main.lua
    -- UICREATE): a corpse in core.JinxingUi confuses the pak Core graph
    local okP, cur = pcall(function() return core.JinxingUi end)
    if okP and cur ~= nil and not Valid(cur) then
        pcall(function() core.JinxingUi = nil end)
    end
    local shells = AllShells()
    if #shells == 0 then
        -- create ONCE: BP-native ConstructWidget inside the Core graph
        local okT = pcall(function() core:JinxingLoaderToggle() end)
        Log("NU| B open: core toggle (create) ok=" .. tostring(okT))
        shells = AllShells()
    end
    -- keeper: rail shell first (stale old-pak shells lose), else first alive
    local keep = nil
    for _, s in ipairs(shells) do
        if ShellKind(s) == "rail" then
            keep = s
            break
        end
    end
    if not keep and shells[1] then keep = shells[1] end
    if not keep then
        local okU, ui = pcall(function() return core.JinxingUi end)
        if okU and Valid(ui) then keep = ui end
    end
    if not keep then
        Log("NU| B open: no shell after toggle")
        return false
    end
    if not ShellRenders(keep) then
        pcall(function()
            if keep:IsInViewport() ~= true then keep:AddToViewport(10000) end
        end)
        -- 4 = SelfHitTestInvisible: root passes input through while children
        -- still hit-test - the pak's authored state for the shell root
        pcall(function() keep:SetVisibility(4) end)
    else
        -- r39: visible but off-book (lobby auto-show case) - reconcile now
        -- instead of waiting for the next poll tick
        ViewportBelt(keep)
    end
    local sib = 0
    for _, s in ipairs(shells) do
        if s ~= keep and ShellRenders(s) then
            pcall(function() s:SetVisibility(1) end)
            sib = sib + 1
        end
    end
    M.shell = keep
    M.shellSrc = "b-authoritative"
    M.applied = false
    M.dumpedPost = false
    InputMode(true, "open")
    if sib > 0 then Log("NU| B open: collapsed " .. sib .. " sibling shell(s)") end
    return true
end

-- guarded respawn: the 21:17 session lost the pak Core actor on player
-- restart and B stayed dead forever. <=3 attempts, 10 s apart, only when the
-- world is populated and nothing else holds the UI. SpawnActor fires the BP
-- BeginPlay, which re-arms the Core's own graph.
--
-- r38 (v5.2): the 01:29 live session killed B in the level a NEW way - after
-- the map transition GC'd the Core package, StaticFindObject could not see
-- the (unloaded) class, respawn failed try=1/2/3, the budget burned, and B
-- stayed dead for the rest of the level - while uiprobe simultaneously
-- proved LoadAsset reaches our classes in Shipping (loadOk=true
-- loadType=UClass). Fixes: class via StaticFindObject->LoadAsset ladder,
-- every failure logs WHY (no-world / class-not-loadable / spawn-failed),
-- the B press (user-driven) is never budget-capped, and the passive poll
-- cap rises 3 -> 6 so a settling world cannot strand B either.
local lastRespawnTry = -100
-- r40: no-shell heal state (8 s spacing, per-world budget reset by ArmWorld)
local lastHealTry = -100
local healTries = 0

-- r40: a Core only counts when its world is the CURRENT world. After a map
-- transition the old Core ref can still pass IsValid() while its world is
-- dead - calling JinxingLoaderToggle on it would build the shell in a dead
-- world (the 02:39 lobby failure). If either side cannot be compared, allow
-- (the guarded BP call is the final judge).
local function CoreWorldOk(core)
    local cw = nil
    pcall(function() cw = core:GetWorld() end)
    if not (cw and Valid(cw)) then return false end
    local W = nil
    pcall(function() W = UEHelpers.GetWorld() end)
    if not (W and Valid(W)) then return true end
    if cw == W then return true end
    local a, b = "", ""
    pcall(function() a = cw:GetFullName() or "" end)
    pcall(function() b = W:GetFullName() or "" end)
    if a == "" or b == "" then return cw == W end
    return (a == b) or (a:find(b, 1, true) ~= nil) or (b:find(a, 1, true) ~= nil)
end

-- r40: assigned here (needs OpenShell above; RespawnCore is forward-decl'd).
-- PollOnce calls this whenever zero shells exist: validate/respawn the Core
-- in the CURRENT world, then create the shell through the Core's own
-- factory - the sanctioned create channel (r24), applied to the one case
-- r20's ban left dead.
HealNoShell = function()
    if _G.JXBusy and _G.JXBusy() then return end
    local nowc = os.clock()
    if nowc - lastHealTry < 8 then return end
    if healTries >= 5 then return end
    lastHealTry = nowc
    healTries = healTries + 1
    local core = nil
    if Valid(M.core) and CoreWorldOk(M.core) then core = M.core end
    if not core then
        local fc = FindCore()
        if fc and Valid(fc) and CoreWorldOk(fc) then core = fc end
    end
    if not core then core = RespawnCore("poll") end
    if not (core and Valid(core)) then
        if M.lastRespawnWhy == "no-world" then
            -- r47: loading state - don't count the try, retry in 2 s so the
            -- panel lands within seconds of the floor becoming playable
            healTries = math.max(0, healTries - 1)
            lastHealTry = nowc - 6.5
            ExecuteWithDelay(2000, function()
                ExecuteInGameThread(function() pcall(HealNoShell) end)
            end)
            return
        end
        Log("NU| heal: no usable core in this world (try=" .. healTries .. ")")
        return
    end
    local okO = false
    pcall(function() okO = OpenShell(core) end)
    if okO then
        Log("NU| heal: shell recreated in current world (try=" .. healTries .. ")")
        -- r44: wire the fresh instance NOW. The 04:00 session proved the
        -- rescan window (2-6 s) is exactly when every unwired-button click
        -- report comes from - the user can press a button in under a second.
        ExecuteWithDelay(400, function()
            ExecuteInGameThread(function() pcall(WireNewTabs, "heal") end)
        end)
        ExecuteWithDelay(1200, function()
            ExecuteInGameThread(function() pcall(WireNewTabs, "heal2") end)
        end)
    else
        Log("NU| heal: recreate failed (try=" .. healTries .. ") - retry in 8 s")
    end
end

local function LoadCoreClass()
    local paths = {
        "/Game/JinxingLoader/Core/BP_JinxingLoaderCore.BP_JinxingLoaderCore_C",
        "/Game/Mods/JinxingLoader/BP_JinxingLoaderCore.BP_JinxingLoaderCore_C",
    }
    for _, p in ipairs(paths) do
        local okS, so = pcall(StaticFindObject, p)
        if okS and so and so:IsValid() then
            -- r53: root the class once - it survived GC on every menu map but
            -- was collected between Lobby and Level0, where LoadAsset cannot
            -- reload it ("class-not-loadable" = floor UI death). Rooted here,
            -- StaticFindObject finds it on EVERY later map.
            -- r55: official UE4SS v3.0.1 stable predates UObject:AddToRoot -
            -- the pin silently no-ops there; say so ONCE so a floor regression
            -- on the official runtime is attributable at a glance.
            if so.AddToRoot then
                pcall(function() so:AddToRoot() end)
            elseif not JxNewUI_pinWarned then
                JxNewUI_pinWarned = true
                Log("NU| pin unavailable: UObject.AddToRoot absent on this UE4SS build (official v3.0.1) - floor class pin off, r47 late-retry is the net")
            end
            return so, "static"
        end
        local okL, lo = pcall(LoadAsset, p)
        if okL and lo and lo:IsValid() then
            if lo.AddToRoot then
                pcall(function() lo:AddToRoot() end)
            elseif not JxNewUI_pinWarned then
                JxNewUI_pinWarned = true
                Log("NU| pin unavailable: UObject.AddToRoot absent on this UE4SS build (official v3.0.1) - floor class pin off, r47 late-retry is the net")
            end
            return lo, "load"
        end
    end
    return nil, nil
end

RespawnCore = function(tag)
    local nowc = os.clock()
    if nowc - lastRespawnTry < 10 then
        M.lastRespawnWhy = "throttled"
        return nil
    end
    -- poll attempts are capped per world; a B press is the user explicitly
    -- asking for the panel, so it always retries (10 s spacing still holds)
    local isB = (tag == "b")
    if not isB and coreRespawns >= 6 then
        M.lastRespawnWhy = "budget"
        return nil
    end
    lastRespawnTry = nowc
    if _G.JXBusy and _G.JXBusy() then
        -- busy states must not consume the respawn budget
        lastRespawnTry = -100
        M.lastRespawnWhy = "busy"
        return nil
    end
    local spawned = nil
    local why = "ok"
    pcall(function()
        -- world check: FindFirstOf("GameModeBase") matches only the exact
        -- base class, which the floors do not instance (only the menu did),
        -- so the old gate starved respawn in every level - B stayed dead
        -- outside the main menu. UEHelpers.GetWorld is level-agnostic (the
        -- spawn chains in main.lua use it everywhere, live-proven).
        local W = nil
        pcall(function() W = UEHelpers.GetWorld() end)
        if not (W and Valid(W)) then why = "no-world" error("no world") end
        local cls, via = LoadCoreClass()
        if not cls then why = "class-not-loadable" error("class not found") end
        local ok1, a = pcall(function()
            return W:SpawnActor(cls, { X = 0, Y = 0, Z = 0 }, { Pitch = 0, Yaw = 0, Roll = 0 })
        end)
        if not ok1 or not a then
            ok1, a = pcall(function() return W:SpawnActor(cls, { X = 0, Y = 0, Z = 0 }) end)
        end
        if not ok1 or not a then
            ok1, a = pcall(function() return W:SpawnActor(cls) end)
        end
        if ok1 and a and Valid(a) then
            spawned = a
            Log("NU| core class via " .. tostring(via))
        else
            why = "spawn-failed"
        end
    end)
    M.lastRespawnWhy = why
    if why == "no-world" then
        -- r47: a null world is the LOADING state, not a respawn failure -
        -- burning the poll/heal budget here left every floor without UI for
        -- the whole transition (05:58 session: try=1..5 all no-world, 63 s)
        lastRespawnTry = -100
        return nil
    end
    coreRespawns = coreRespawns + 1
    if spawned then
        M.core = spawned
        Log("NU| core RESPAWNED (" .. tostring(tag) .. ") try=" .. coreRespawns)
    else
        Log("NU| core respawn failed (" .. tostring(tag) .. ") try=" .. coreRespawns .. " why=" .. why)
    end
    return spawned
end

-- ============ the single toggle authority ============
-- Called from our own Key.B bind AND from main.lua's JXPakToggle route
-- (B keybind / F6 / bare jpanel). Debounced so a double entry per physical
-- press (both binds fire) and rapid re-presses are harmless.
local lastBPress = -10
function M.ToggleB()
    local nowc = os.clock()
    if nowc - lastBPress < 0.25 then return true end
    lastBPress = nowc
    if _G.JXBusy and _G.JXBusy() then
        Log("NU| B skipped: UI locked during map load")
        return false
    end
    local renderN = 0
    for _, s in ipairs(AllShells()) do
        if ShellRenders(s) then renderN = renderN + 1 end
    end
    if renderN > 0 then
        local n = CloseAllShells()
        Log("NU| B -> CLOSE (collapsed " .. n .. " of " .. renderN .. " rendering)")
        return true
    end
    local core = FindCore()
    -- r40: reject a stale dead-world Core (menu ref after map change) - B
    -- then respawns a fresh one instead of toggling into a dead world
    if core and Valid(core) and not CoreWorldOk(core) then core = nil end
    if not core then core = RespawnCore("b") end
    if not core then
        Log("NU| B: no core (respawn failed - see why= in the respawn line)")
        return false
    end
    local okO = false
    pcall(function() okO = OpenShell(core) end)
    Log("NU| B -> OPEN ok=" .. tostring(okO))
    return okO
end

-- ============ B listener (channel 1; v4.6: delegates to M.ToggleB) ============
local function ArmB()
    local okk, kb = pcall(function() return Key.B end)
    if not (okk and kb) then
        Log("v4: Key.B unavailable - poll/world channels only")
        return
    end
    local function attempt(tag)
        ExecuteInGameThread(function()
            if M.applied and Valid(M.shell) then
                -- layout already done: re-assert colors (beats juiskin re-tint)
                pcall(M.RestyleSweep, tag)
            else
                pcall(M.Pass, tag, { anyVis = true })
            end
        end)
    end
    pcall(function()
        RegisterKeyBind(kb, function()
            -- main.lua's own B bind routes to the same M.ToggleB; the
            -- debounce inside makes the double entry a no-op
            ExecuteInGameThread(function() pcall(M.ToggleB) end)
            ExecuteWithDelay(150, function() attempt("B1") end)
            ExecuteWithDelay(600, function() attempt("B2") end)
        end)
    end)
    Log("v4.6: B listener armed - Lua-authoritative toggle (render->close, hidden->open/create-once)")
end

-- ============ world-ready wrapper (channel 3) ============
local function ArmWorld()
    local prev = _G.JXWorldReady
    if type(prev) ~= "function" then
        Log("v4: JXWorldReady not defined yet - poll+B channels only")
        return
    end
    _G.JXWorldReady = function(tag, epoch, wid)
        local ok, err = pcall(prev, tag, epoch, wid)
        if not ok then Log("NU| world-ready prev error: " .. tostring(err):sub(1, 120)) end
        -- r40: fresh world -> fresh heal budget
        healTries = 0
        lastHealTry = -100
        pcall(function() M.Rearm(tostring(tag)) end)
    end
    Log("v4: JXWorldReady wrapped (rearm on map load / beginplay / player restart)")
end

-- ============ r42: Ctrl hotkeys into the editor-added pages ============
-- Their clicks are under repair ([A] hit-test fix); hotkeys are the delivery
-- channel that has NEVER failed in this project (Ctrl+O/P/T, Ctrl+arrows, B).
-- r43 adds Ctrl+G for the orphaned HideSeek page (slot 20, no rail button).
local function ArmHotkeys()
    if type(RegisterKeyBind) ~= "function" or type(ModifierKey) ~= "table" then
        Log("r42: hotkeys unavailable (no RegisterKeyBind/ModifierKey)")
        return
    end
    local function jump(nm, label)
        ExecuteInGameThread(function()
            local anyRender = false
            for _, s in ipairs(AllShells()) do
                if ShellRenders(s) then anyRender = true break end
            end
            if not anyRender then pcall(M.ToggleB) end
            -- r43: also accept page-name keys (M.pgIdx) - the HideSeek page
            -- has no rail button, so its only address is the page name
            local idx = (M.tabIdx or {})[nm] or (M.pgIdx or {})[nm]
            -- r44: the same whitelist gate applies to hotkey jumps
            local pg = nm
            if (M.btnPage or {})[nm] then pg = M.btnPage[nm] end
            if not WlGate(pg) then
                Say("jnewui: insufficient whitelist level for " .. tostring(pg) .. " (requires " .. tostring(PAGE_NEED[pg]) .. ")")
                Log("NU| gate refused hotkey " .. nm .. " -> " .. tostring(pg))
                return
            end
            if idx and _G.JXTabGo then
                pcall(_G.JXTabGo, idx)
                Say("jnewui: " .. label .. " (Ctrl hotkey)")
            else
                pcall(M.Pass, "hotkey", { anyVis = true, force = true })
                local idx2 = (M.tabIdx or {})[nm] or (M.pgIdx or {})[nm]
                if idx2 and _G.JXTabGo then pcall(_G.JXTabGo, idx2) end
                Say("jnewui: " .. label .. " (Ctrl hotkey, post-pass)")
            end
        end)
    end
    local binds = {
        { "I", "TabBtn_15", "AI页" },
        { "N", "TabBtn_17", "网络页" },
        { "K", "TabBtn_18", "快捷页" },
        { "H", "TabBtn_19", "帮助页" },
        -- r43: HideSeekPageV49 sits at switcher slot 20 with NO rail button
        -- in the 854D2A38 pak (rail ends at TabBtn_19) - Ctrl+G is its only
        -- entrance; resolved via M.pgIdx (page name, not button name)
        { "G", "HideSeekPageV49", "捉迷藏页" },
    }
    for _, b in ipairs(binds) do
        local okK, key = pcall(function() return Key[b[1]] end)
        if okK and key then
            local nm, label = b[2], b[3]
            local okB = pcall(function()
                RegisterKeyBind(key, { ModifierKey.CONTROL }, function() jump(nm, label) end)
            end)
            Log("r43 hotkey Ctrl+" .. b[1] .. " -> " .. label .. " ok=" .. tostring(okB))
        end
    end
end

-- ============ r51: native-state input (no NewUI UMG delegates) ============
-- Key.LEFT_MOUSE_BUTTON belongs to RegisterKeyBind, NOT IsInputKeyDown(FKey).
-- The keybind records short presses; native IsPressed supplies a fallback
-- and release ordering. Never dispatch while held: BP OnClicked runs on
-- release and must not overwrite a preceding Lua whitelist refusal.
local inputErrors = {}
local function InputFault(key, err)
    M.inputFaults = (M.inputFaults or 0) + 1
    local now = os.time()
    if inputErrors[key] and now - inputErrors[key] < 30 then return end
    inputErrors[key] = now
    Log("NU| INPUT_ERR " .. key .. ": " .. tostring(err):sub(1, 200))
end
local function InputReady()
    return M.enabled and inputOwned and M.wiredShell == M.shell
        and Valid(M.shell) and ShellRenders(M.shell)
end
local function InputFlag(it, method)
    local ok, value = pcall(function() return it.e.w[method](it.e.w) end)
    if ok and type(value) == "boolean" then return value end
    InputFault(it.nm .. "." .. method, ok and "expected boolean" or value)
    return nil
end
local function InputItemVisible(it, active)
    if not it.e or not Valid(it.e.w) then return false end
    if it.action and (M.pgIdx or {})[it.page] ~= active then return false end
    return true
end
local function InputCallable(key, value)
    local fn = (_G.JXUICBS or {})[key]
    if type(fn) ~= "function" then InputFault(key, "handler unavailable") return false end
    local ok, err = pcall(fn, value)
    if not ok then InputFault(key, err) end
    return ok
end
local function ActiveInputPage()
    if not Valid(M.wiredSwitcher) then return nil end
    local ok, idx = pcall(function() return M.wiredSwitcher:GetActiveWidgetIndex() end)
    if not ok or type(idx) ~= "number" then
        InputFault("switcher", ok and "invalid index" or idx)
        return nil
    end
    -- Native pill bindings remain in the pak. Recheck the SAME existing
    -- gate after their native click, including clicks too short to sample.
    for pg in pairs(PAGE_NEED) do
        if (M.pgIdx or {})[pg] == idx and not WlGate(pg) then
            local safe = M.curSafeIdx or 0
            for prior in pairs(PAGE_NEED) do
                if (M.pgIdx or {})[prior] == safe and not WlGate(prior) then safe = 0 end
            end
            if M.inputDenied ~= idx then
                Log("NU| gate restored " .. pg .. " -> [" .. safe .. "]")
            end
            M.inputDenied = idx
            local okg, result = pcall(_G.JXTabGo, safe)
            if not okg or result == false then InputFault("gate-restore", result) return nil end
            return safe
        end
    end
    M.inputDenied = nil
    M.curSafeIdx = idx
    return idx
end
local function ArmInputButton(it, source, pressed)
    if it.pending then
        if pressed then it.sawPressed = true end
        return
    end
    -- A queued keybind may arrive just after the native-state release was
    -- handled. Suppress that delivery, not a new observed native press.
    if source == "lmb" and not pressed and it.lastFire
        and os.clock() - it.lastFire < 0.08 then return end
    it.pending = true
    it.sawPressed = pressed
    it.waitTicks = 0
    it.source = source
    it.keyboard = source == "pressed" and InputFlag(it, "IsHovered") == false
        and InputFlag(it, "HasKeyboardFocus") == true
end
local function PollInputButtons(active)
    for _, it in ipairs(M.cbsOrder or {}) do
        if InputItemVisible(it, active) then
            local pressed = InputFlag(it, "IsPressed")
            if pressed == true then
                if not it.wasPressed then ArmInputButton(it, "pressed", true) end
                it.sawPressed = true
                it.waitTicks = 0
            elseif pressed == false and it.pending then
                it.waitTicks = (it.waitTicks or 0) + 1
                -- An LMB pulse observed before Slate handled the down event
                -- gets two actual game-thread samples to settle.
                if it.sawPressed or it.waitTicks >= 2 then
                    local hit = InputFlag(it, "IsHovered") == true
                    if it.keyboard then hit = InputFlag(it, "HasKeyboardFocus") == true end
                    it.pending = false
                    if hit and InputFlag(it, "GetIsEnabled") == true and VisState(it.e.w) == "vis" then
                        it.lastFire = os.clock()
                        M.inputClicks = (M.inputClicks or 0) + 1
                        Log("NU| CLICKMAP " .. it.nm .. " source=" .. tostring(it.source))
                        InputCallable(it.nm)
                    end
                end
            elseif pressed == nil then
                it.pending = false
            end
            it.wasPressed = pressed == true
        else
            it.pending, it.wasPressed, it.sawPressed = false, false, false
        end
    end
end
local function PollInputSliders(active)
    for _, it in ipairs(M.sliderOrder or {}) do
        local shown = (M.pgIdx or {})[it.page] == active and active ~= nil
        if shown and it.e and Valid(it.e.w) then
            local okv, v = pcall(function() return tonumber(it.e.w:GetValue()) end)
            if okv and v and v == v and math.abs(v) < math.huge then
                local captured = InputFlag(it, "HasMouseCapture")
                if not it.active then
                    it.active, it.lastValue, it.dirty = true, v, false
                elseif it.lastValue == nil or math.abs(v - it.lastValue) > 0.00001 then
                    it.lastValue, it.dirty, it.stableTicks = v, true, 0
                else
                    it.stableTicks = (it.stableTicks or 0) + 1
                end
                local release = captured == false and it.wasCapture == true
                -- Keyboard/controller edits have no mouse capture; a short
                -- quiet period commits them without issuing every frame.
                local settle = captured == false and (it.stableTicks or 0) >= 10
                local commit = it.dirty and (release or settle)
                local now = os.clock()
                if it.dirty and it.valueKey and (commit or now - (it.lastTextAt or -100) >= 0.1) then
                    if (_G.JXUICBS or {})[it.valueKey] then InputCallable(it.valueKey, v) end
                    it.lastTextAt = now
                end
                if commit then
                    it.dirty = false
                    Log("NU| SLIDERMAP " .. it.nm .. " value=" .. string.format("%g", v))
                    InputCallable(it.commandKey, v)
                end
                it.wasCapture = captured == true
            else
                InputFault(it.nm .. ".GetValue", okv and "invalid number" or v)
            end
        else
            it.active, it.dirty, it.wasCapture = false, false, false
        end
    end
end
local function ClearInputSamples()
    for _, it in ipairs(M.cbsOrder or {}) do
        it.pending, it.wasPressed, it.sawPressed = false, false, false
    end
    for _, it in ipairs(M.sliderOrder or {}) do
        it.active, it.dirty, it.wasCapture = false, false, false
    end
end
local function InputPoll()
    M.inputPolls = (M.inputPolls or 0) + 1
    local ready = InputReady()
    if not ready then
        if M.inputVisible then ClearInputSamples() end
        M.inputVisible = false
        return
    end
    M.inputVisible = true
    local active = ActiveInputPage()
    PollInputButtons(active)
    -- A tab handler above can have changed the page in this same tick.
    PollInputSliders(ActiveInputPage())
end
local function InputLmb()
    if not InputReady() then return end
    M.inputLmb = (M.inputLmb or 0) + 1
    local active = ActiveInputPage()
    for _, it in ipairs(M.cbsOrder or {}) do
        if InputItemVisible(it, active) and InputFlag(it, "IsHovered") == true
            and InputFlag(it, "GetIsEnabled") == true and VisState(it.e.w) == "vis" then
            ArmInputButton(it, "lmb", InputFlag(it, "IsPressed") == true)
            return
        end
    end
end
local inputCallbacks = {}
_G.JXUIINPUTCBS = inputCallbacks -- separate from per-shell handler reset
inputCallbacks.game = function()
    local ok, err = pcall(InputPoll)
    M.inputQueued = false
    M.inputQueuedAge = 0
    if not ok then InputFault("poll", err) end
end
inputCallbacks.lmbGame = function()
    local ok, err = pcall(InputLmb)
    if not ok then InputFault("lmb", err) end
end
inputCallbacks.lmb = function()
    if not M.enabled then return end
    local ok, err = pcall(ExecuteInGameThread, inputCallbacks.lmbGame)
    if not ok then InputFault("lmb-queue", err) end
end
inputCallbacks.tick = function()
    -- r52: single-flight escape. A game-thread job lost to a map transition
    -- left inputQueued stuck true and the poll chain brain-dead (08:28
    -- session: inputPolls frozen at 2, clicks dead, zero errors). 8 stuck
    -- ticks clear the flag and re-arm.
    if M.inputQueued then
        M.inputQueuedAge = (M.inputQueuedAge or 0) + 1
        if M.inputQueuedAge > 8 then
            M.inputQueued = false
            M.inputQueuedAge = 0
            InputFault("queue", "stuck single-flight cleared")
        end
    else
        M.inputQueuedAge = 0
        local ok, err = pcall(ExecuteInGameThread, inputCallbacks.game)
        if not ok then M.inputQueued = false; InputFault("queue", err) end
    end
    -- Schedule outside the game-thread action: an ordinary Lua exception
    -- cannot cut the reschedule chain. Native registry failure still needs
    -- diagnosis/restart; this is not a claim to resurrect a dead Lua state.
    local ok, err = pcall(ExecuteWithDelay, M.inputVisible and 20 or 250, inputCallbacks.tick)
    if not ok then M.inputStarted = false; InputFault("schedule", err) end
end
StartNativeInput = function()
    if M.inputStarted then return end
    if not M.lmbAttempted then
        M.lmbAttempted = true
        local ok, ret = pcall(function() return RegisterKeyBind(Key.LEFT_MOUSE_BUTTON, inputCallbacks.lmb) end)
        M.lmbBound = ok and ret ~= false
        if not M.lmbBound then InputFault("lmb-register", ret) end
    end
    local ok, err = pcall(ExecuteWithDelay, 3000, inputCallbacks.tick)
    M.inputStarted = ok
    if not ok then InputFault("start", err) end
    Log("NU| INPUT ready lmb=" .. tostring(M.lmbBound) .. " active=20ms idle=250ms umg-delegates=0")
end

-- ============ install ============
function M.Install(executor, deps)
    if M.installed then return M end
    if type(deps) == "table" and deps.UEHelpers then UEHelpers = deps.UEHelpers end
    if not UEHelpers then Log("NU| install: UEHelpers unavailable; local-PC fallback retained") end
    if type(_G.JXRegCmd) == "function" then
        pcall(_G.JXRegCmd, "jnewui", function(FullCommand, Parameters)
            local a = (Parameters and Parameters[1]) or "status"
            if a == "on" then
                M.enabled = true
                ExecuteInGameThread(function() pcall(M.Pass, "manual", { anyVis = true, force = true }) end)
            elseif a == "off" then
                M.enabled = false
                M.Restore()
            elseif a == "pass" then
                ExecuteInGameThread(function() pcall(M.Pass, "manual", { anyVis = true, force = true }) end)
            elseif a == "dump" then
                ExecuteInGameThread(function() pcall(M.Dump, "manual") end)
            elseif a == "tab" then
                local n = tonumber((Parameters and Parameters[2]) or "1") or 1
                if _G.JXTabGo then pcall(_G.JXTabGo, n - 1) end
                Say("jnewui tab " .. tostring(n))
            elseif a == "status" then
                local s = M.stats
                local w = M.shell
                local vs = Valid(w) and VisState(w) or "none"
                if s then
                    Say(string.format("jnewui v5.11: applied=%s verdict=%s shellSrc=%s vis=%s input=%s last[%s] walked=%d moves=%d cells=%d pages=%d tabfills=%d",
                        tostring(M.applied), tostring(M.verdict), tostring(M.shellSrc), vs, tostring(inputOwned), s.tag, s.walked, s.slotMoves, s.cells, s.pages, s.tabfills))
                else
                    Say("jnewui v5.11: no pass yet (verdict=" .. tostring(M.verdict)
                        .. " core=" .. tostring(Valid(M.core))
                        .. " shell=" .. tostring(Valid(M.shell)) .. " - press B or jnewui pass)")
                end
                Say("r51 input: polls=" .. tostring(M.inputPolls or 0)
                    .. " lmb=" .. tostring(M.inputLmb or 0) .. " clicks=" .. tostring(M.inputClicks or 0)
                    .. " faults=" .. tostring(M.inputFaults or 0) .. " queued=" .. tostring(M.inputQueued == true))
            else
                Say("jnewui: on | off | pass | dump | tab N | status")
            end
            return true
        end)
        Log("v5.11 installed (r51): native-state buttons/sliders + existing tab gates; pak 8A2E8B1F unchanged")
    end
    ArmB()
    ArmHotkeys()
    ArmWorld()
    StartPoll()
    StartNativeInput()
    M.installed = true
    return M
end

Log("JxNewUI v5.11 (r51 native-state input; no NewUI UMG delegates; pak 8A2E8B1F) loaded - rail mark=" .. RAIL_MARK .. " old mark=" .. OLD_MARK)
return M
