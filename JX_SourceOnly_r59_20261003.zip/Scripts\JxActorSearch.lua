
local M = {}
local function fold(s)
    return (s:gsub('[A-Z]', function(c) return string.char(c:byte() + 32) end))
end
local function decode(s)
    
    return (s:gsub('%%(%x%x)', function(h) return string.char(tonumber(h, 16)) end))
end
M.fold = fold
function M.new(data, env)
    assert(type(data) == 'table' and type(env) == 'table')
    local keys, actor = {}, {}
    for i, r in ipairs(data) do
        assert(type(r) == 'table' and #r == 8)
        keys[i] = fold(table.concat({r[1], r[2], r[3], r[4]}, '\n'))
        
        actor[i] = r[8] == 'registry_actor'
    end
    local hits, page, last, filter, errorText = {}, 1, nil, false, nil
    local scans, count = 0, #data
    local function result()
        local rows = {}
        local pages = math.max(1, math.ceil(#hits / 10))
        for n = 1, 10 do
            local r = data[hits[(page - 1) * 10 + n]]
            if r then
                local label = r[8] == 'registry_actor' and 'registry-only Actor ancestry; NOT runtime verified | 仅注册表证据，未经运行时验证'
                    or (r[5] == '' and 'UNKNOWN CLASS; NOT confirmed Actor | 未知类型资产，未确认为Actor' or 'catalog class evidence; NOT confirmed runtime Actor | 有类头证据，未运行时确认')
                rows[n] = r[2] .. ' | ' .. r[3] .. '\n' .. r[4] .. '\nID: ' .. r[1]
                    .. ' | class: ' .. (r[5] ~= '' and r[5] or 'unknown')
                    .. ' | evidence: ' .. r[6] .. ' | lineage: ' .. r[7] .. '\n' .. label .. ' | READ ONLY / NO SPAWN'
            else rows[n] = '' end
        end
        return {rows = rows, total = #hits, page = page, pages = pages, scans = scans,
            error = errorText, filter = filter, query = last,
            status = errorText or ((filter and 'Registry Actor evidence only | 仅Actor证据' or 'ASSET catalog / 资产目录 (not all Actors 非全是Actor)')
                .. ' | ' .. #hits .. '/' .. count .. ' | page ' .. page .. '/' .. pages .. ' | READ ONLY 只读')}
    end
    local function publish()
        local r = result()
        if env.render then env.render(r) end
        return r
    end
    local function search(query)
        errorText = nil
        if type(query) ~= 'string' or #query > 512 then
            errorText = 'Query rejected: maximum 128 Unicode characters / 512 UTF-8 bytes'
            return publish()
        end
        local ok, length = pcall(utf8.len, query)
        if not ok or not length or length > 128 or query:find('%z') then
            errorText = 'Query rejected: invalid UTF-8, NUL or more than 128 characters'
            return publish()
        end
    local key = fold(query)
    if key == last then return publish() end
    last, page, hits = key, 1, {}
    scans = scans + 1
    for i = 1, count do
        if (not filter or actor[i]) and (key == '' or keys[i]:find(key, 1, true)) then
            hits[#hits + 1] = i
        end
    end
    -- r33: real content first - actors/static meshes/blueprints/game data
    -- before the texture+material tail (path heuristic; entry labels stay
    -- honest, tail entries are still listed, just after the spawnable-looking
    -- paths)
    local head, tail = {}, {}
    for _, i in ipairs(hits) do
        local p = data[i][4]
        if p:find('/Textures/', 1, true) or p:find('/Materials/', 1, true) then
            tail[#tail + 1] = i
        else
            head[#head + 1] = i
        end
    end
    hits = {}
    for _, i in ipairs(head) do hits[#hits + 1] = i end
    for _, i in ipairs(tail) do hits[#hits + 1] = i end
    return publish()
end
    local api = {}
    function api.query(q) return search(q) end
    function api.command(full)
        if type(full) ~= 'string' or #full > 4096 then
            errorText = 'Invalid command transport'; publish(); return true
        end
        
        local token, rest = full:match('^(%S+)(.*)$')
        if not token or fold(token) ~= 'jxsearch' or (rest ~= '' and rest:sub(1,1) ~= ' ') then
            errorText = 'Invalid command prefix'; publish(); return true
        end
        rest = rest ~= '' and rest:sub(2) or ''
        
        if rest:sub(1,3) == '@1:' then rest = decode(rest:sub(4)) end
        search(rest)
        return true
    end
    function api.next()
        page = math.min(math.max(1, math.ceil(#hits / 10)), page + 1)
        return publish()
    end
    function api.prev() page = math.max(1, page - 1); return publish() end
    function api.filter()
        filter = not filter
        local q = last or ''; last = nil
        return search(q)
    end
    function api.snapshot() return result() end
    return api
end
return M
