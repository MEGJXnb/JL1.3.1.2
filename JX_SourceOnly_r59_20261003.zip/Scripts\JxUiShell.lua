
local Shell = {}
_G.JXUiShell = Shell

local Log = Log or function(s) print("[JxUiShell] " .. tostring(s)) end
local Say = (JX and JX.Say) or Log

local DEFAULT_SKIN = {
    name = "cyan",
    -- r20: uniform cyan tint retired - JxNewUI v4 owns all colors (role-aware);
    -- this TINT was the residual engine re-cyaning every TextBlock each >=60s reskin
    tint = nil,

    -- r21: RAIL SHELL (v176 pak, TabRailV63 left rail) - 14 tabs, labels from the
    -- user-approved rail layout screenshot (MeshPage tab shows as yuanjing there)
    tabs = {
        ["TabBtn_0"] = "模组",
        ["TabBtn_1"] = "画质",
        ["TabBtn_2"] = "玩家",
        ["TabBtn_3"] = "Actor",
        ["TabBtn_4"] = "黑名单",
        ["TabBtn_5"] = "设置",
        ["TabBtn_6"] = "特级功能",
        ["TabBtn_7"] = "说明",
        ["TabBtn_8"] = "名单",
        ["TabBtn_9"] = "地图",
        ["TabBtn_10"] = "远景",
        ["TabBtn_11"] = "功能",
        ["TabBtn_12"] = "PLUS",
        ["TabBtn_13"] = "PRO"
    },

    -- r21: PLUS/PRO are live tabs in the rail shell (bottom of the rail) - show them
    reveal = {},
    hide = {},

    headers = {
        ["TitleText"] = "JX NEXUS v4",
        ["Title"] = "JX NEXUS v4",
        ["HeaderText"] = "JX NEXUS v4",
        ["PanelTitle"] = "JX NEXUS v4",
        ["MainTitle"] = "JX NEXUS v4",
        ["HeaderTextBlock"] = "JX NEXUS v4",
    },

    buttons = {},
}

Shell.current = DEFAULT_SKIN
Shell.currentName = "cyan"
Shell.lastApply = nil   

local function SkinDir()
    local sd = _G.JXSidecarDir or ""
    
    return sd .. "../config/skins/"
end

local function ValidSkin(t)
    if type(t) ~= "table" then return false end
    for _, k in ipairs({ "tabs", "headers", "buttons" }) do
        if t[k] ~= nil and type(t[k]) ~= "table" then return false end
    end
    if t.reveal ~= nil and type(t.reveal) ~= "table" then return false end
    return true
end

local function MergeSkin(base, over)
    local m = {}
    for k, v in pairs(base) do m[k] = v end
    if type(over) == "table" then
        for _, k in ipairs({ "tabs", "headers", "buttons" }) do
            if type(over[k]) == "table" then
                local t = {}
                for kk, vv in pairs(m[k] or {}) do t[kk] = vv end
                for kk, vv in pairs(over[k]) do
                    if type(vv) == "string" then t[kk] = vv end
                end
                m[k] = t
            end
        end
        if type(over.reveal) == "table" then
            local r = {}
            for _, v in ipairs(over.reveal) do
                if type(v) == "string" then r[#r + 1] = v end
            end
            m.reveal = r
        end
        if type(over.name) == "string" then m.name = over.name end
    end
    return m
end

local function LoadSkinFile(name)
    if not name or name == "" or tostring(name):find("[/\\%.%.]") then
        return nil, "bad skin name"
    end
    local path = SkinDir() .. name .. ".lua"
    local mc, err = loadfile(path)
    if not mc then return nil, (path) .. " -> " .. tostring(err) end
    local ok, t = pcall(mc)
    if not ok then return nil, path .. " ran with error: " .. tostring(t) end
    if not ValidSkin(t) then return nil, path .. " is not a valid skin table" end
    return t, path
end

local KTL = nil
local function FT(s)
    if not KTL then
        pcall(function() KTL = StaticFindObject("/Script/Engine.Default__KismetTextLibrary") end)
    end
    if not KTL then return nil end
    local ok, t = pcall(function() return KTL:Conv_StringToText(s) end)
    if ok then return t end
    return nil
end

local function ClassOf(w)
    local ok, n = pcall(function() return w:GetClass():GetFName():ToString() end)
    if ok then return n end
    return nil
end

local function NameOf(w)
    local ok, n = pcall(function() return w:GetFName():ToString() end)
    if ok then return n end
    return nil
end

local function FindText(w, depth)
    if not w or depth > 4 then return nil end
    if ClassOf(w) == "TextBlock" then return w end
    local ok, cnt = pcall(function() return w:GetChildrenCount() end)
    if ok and type(cnt) == "number" and cnt > 0 then
        for i = 0, cnt - 1 do
            local okg, ch = pcall(function() return w:GetChildAt(i) end)
            if okg and ch then
                local hit = FindText(ch, depth + 1)
                if hit then return hit end
            end
        end
    end
    return nil
end

local function SetLabel(w, text)
    local tb = FindText(w, 0)
    if not tb then return false, "no TextBlock under it" end
    local ft = FT(text)
    if not ft then return false, "Conv_StringToText failed" end
    local ok, e = pcall(function() tb:SetText(ft) end)
    if ok then return true end
    return false, tostring(e)
end

local function Inventory(root)
    local inv = { n = 0 }
    local function walk(node, depth)
        if not node or depth > 12 or inv.n > 900 then return end
        local nm = NameOf(node)
        if nm and nm ~= "" and not inv[nm] then
            inv[nm] = node
            inv.n = inv.n + 1
        end
        local ok, cnt = pcall(function() return node:GetChildrenCount() end)
        if ok and type(cnt) == "number" and cnt > 0 and cnt < 64 then
            for i = 0, cnt - 1 do
                local okg, ch = pcall(function() return node:GetChildAt(i) end)
                if okg and ch then walk(ch, depth + 1) end
            end
        end
    end
    if root then walk(root, 0) end
    return inv
end

local function ForceOpaque(w, depth)
    if not w or (depth or 0) > 12 then return 0 end
    local n = 0
    if pcall(function() w:SetRenderOpacity(1.0) end) then n = n + 1 end
    local ok, cnt = pcall(function() return w:GetChildrenCount() end)
    if ok and type(cnt) == "number" and cnt > 0 and cnt < 64 then
        for i = 0, cnt - 1 do
            local okg, ch = pcall(function() return w:GetChildAt(i) end)
            if okg and ch then n = n + ForceOpaque(ch, (depth or 0) + 1) end
        end
    end
    return n
end

function Shell.Apply(tag)
    local rep = { tag = tostring(tag or "?"), skin = Shell.currentName,
        widgets = 0, labelled = 0, revealed = 0, skipped = {}, notes = {} }

    local okW, w = pcall(function() return FindFirstOf("WBP_JinxingRoot_C") end)
    if not okW or not w then
        rep.notes[#rep.notes + 1] = "panel instance not found (pak not installed / not spawned yet)"
        Shell.lastApply = rep
        Log("juiskin: " .. (rep.notes[1]))
        return rep
    end
    local okA, alive = pcall(function() return w:IsValid() end)
    if okA and alive == false then
        -- r20: respawn disabled - Lua-side CreateWidget/AddToViewport created duplicate
        -- shells behind Core BP's back; Core BP owns shell create/toggle lifecycle
        rep.notes[#rep.notes + 1] = "stale panel reference - respawn disabled r20 (Core owns lifecycle)"
        Log("juiskin: stale shell ref - respawn disabled r20, Core BP owns create/toggle")
        Shell.lastApply = rep
        return rep
    end

    local tree = nil
    pcall(function() tree = w.WidgetTree end)
    local root = nil
    if tree then pcall(function() root = tree.RootWidget end) end
    local inv = Inventory(root)
    rep.widgets = inv.n
    if inv.n == 0 then
        rep.notes[#rep.notes + 1] = "widget inventory empty (panel not built yet?)"
        Shell.lastApply = rep
        Log("juiskin: " .. rep.notes[1])
        return rep
    end

    local opq = 0
    pcall(function() root:SetRenderOpacity(1.0) end)
    local railw = inv["TabRailV63"]
    if railw then opq = opq + ForceOpaque(railw, 0) end
    rep.notes[#rep.notes + 1] = "opacity forced on " .. tostring(opq + 1)
        .. " widget(s) (root+rail); 'juiskin opaque' = whole tree"

    local skin = Shell.current or {}

    for _, nm in ipairs(skin.reveal or {}) do
        local w2 = inv[nm]
        if w2 then
            local okv = pcall(function() w2:SetVisibility(0) end)  
            if okv then rep.revealed = rep.revealed + 1 else rep.skipped[nm] = "SetVisibility failed" end
        else
            rep.skipped[nm] = "widget not in tree"
        end
    end

    for _, nm in ipairs(skin.hide or {}) do
        local w2 = inv[nm]
        if w2 then
            local okh = pcall(function() w2:SetVisibility(1) end)
            if okh then rep.hidden = (rep.hidden or 0) + 1 else rep.skipped[nm] = "hide failed" end
        else
            rep.skipped[nm] = "widget not in tree"
        end
    end

    for _, group in ipairs({ "tabs", "headers", "buttons" }) do
        for nm, text in pairs(skin[group] or {}) do
            local w2 = inv[nm]
            if w2 then
                local ok, why = SetLabel(w2, tostring(text))
                if ok then rep.labelled = rep.labelled + 1 else rep.skipped[nm] = why end
            else
                rep.skipped[nm] = "widget not in tree"
            end
        end
    end

    local tint = skin.tint
    if type(tint) == "table" and tint.R then
        local tinted, skipped = 0, 0
        local TBClass = StaticFindObject("/Script/UMG.TextBlock")
        for nm, w2 in pairs(inv) do
            if type(w2) == "userdata" and TBClass then
                local isText = false
                pcall(function() isText = w2:IsA(TBClass) end)
                if isText then
                    pcall(function() w2:SetColorAndOpacity({ SpecifiedColor = { R = tint.R, G = tint.G, B = tint.B, A = 1.0 }, ColorUseRule = 0 }) end)
                    tinted = tinted + 1
                else
                    skipped = skipped + 1
                end
            end
        end
        rep.notes[#rep.notes + 1] = string.format("cyan tint: %d TextBlock(s) colored, %d skipped", tinted, skipped)
        Log(string.format("juiskin TINT: %d TextBlock(s) cyan, %d skipped (skin=%s)", tinted, skipped, tostring(Shell.currentName)))
    end

    local sw = inv["JinxingTabSwitcher"]
    if sw then
        local okn, n = pcall(function() return sw:GetNumWidgets() end)
        if okn and type(n) == "number" then
            rep.notes[#rep.notes + 1] = "switcher pages=" .. tostring(math.floor(n))
                .. " (jtab " .. tostring(math.floor(n) - 1) .. " = last page)"
        end
        local okv, v = pcall(function() return sw:GetActiveWidgetIndex() end)
        if okv and type(v) == "number" then
            rep.notes[#rep.notes + 1] = "active page=" .. tostring(math.floor(v))
        end
    end
    local t7 = inv["NXTab_14"]   
    rep.notes[#rep.notes + 1] = "NXTab_14 (ent) " ..
        (t7 and "present" or "ABSENT") ..
        (t7 and (function()
            local okv, v = pcall(function() return t7:GetVisibility() end)
            if okv and type(v) == "number" then return " vis=" .. tostring(v) end
            return ""
        end)() or "")

    Shell.lastApply = rep
    Log(string.format("juiskin[%s] skin=%s widgets=%d labelled=%d revealed=%d skipped=%d",
        tostring(tag), tostring(Shell.currentName), rep.widgets, rep.labelled, rep.revealed,
        (function() local c = 0; for _ in pairs(rep.skipped) do c = c + 1 end; return c end)()))
    return rep
end

local function Probe(tag)
    local rep = { tag = tostring(tag or "?"), t = os.date("%H:%M:%S") }
    pcall(function()
        local cls = nil
        pcall(function() cls = StaticFindObject("WidgetBlueprintGeneratedClass", nil, "WBP_JinxingRoot_C", true) end)
        rep.clsResident = cls ~= nil
        
        local okL, rL = pcall(function() return LoadAsset("/Game/Mods/JinxingLoader_P/WBP_JinxingRoot.WBP_JinxingRoot_C") end)
        if not (okL and rL) then
            pcall(function() rL = LoadAsset("/Game/Mods/JinxingLoader_P/WBP_JinxingRoot") end)
        end
        rep.loadOk = okL and rL ~= nil
        if okL and rL then
            pcall(function() rep.loadType = tostring(rL:GetClass()) end)
            if not cls then pcall(function() cls = rL.GeneratedClass end) end
        end
        if not cls then
            pcall(function() cls = StaticFindObject("Class", nil, "WBP_JinxingRoot_C", true) end)
        end
        rep.cls = cls ~= nil
        if not cls then
            pcall(function()
                local n = 0
                local all = FindAllOf("WidgetBlueprintGeneratedClass")
                for _ in pairs(all or {}) do n = n + 1 end
                rep.wbpgcCount = n
            end)
        else
            local pc = nil
            pcall(function() pc = UEHelpers.GetPlayerController() end)
            rep.pc = pc ~= nil
            local existing = nil
            pcall(function() existing = FindFirstOf("WBP_JinxingRoot_C") end)
            if existing and existing.IsValid and existing:IsValid() then
                rep.alreadyShown = true
                return
            end
            -- r20: probe is READ-ONLY - no CreateWidget/AddToViewport from Lua;
            -- Core BP owns shell creation; probe only reports class residency/PC state
            rep.pcKnown = pc ~= nil
            rep.createOk = false
            rep.createSkipped = "r20"
        end
    end)
    
    local parts = {}
    for k, v in pairs(rep) do parts[#parts + 1] = tostring(k) .. "=" .. tostring(v) end
    local line = "[" .. tostring(rep.t) .. " " .. tostring(rep.tag) .. "] " .. table.concat(parts, " ")
    Log("uiprobe: " .. line)
    pcall(function()
        
        local dir = SkinDir():gsub("config/skins/$", "")
        local f = io.open(dir .. "config/uiprobe.txt", "a")
        if f then f:write(line .. "\r\n") f:close() end
    end)
    Say("uiprobe " .. tostring(rep.tag) .. ": class=" .. tostring(rep.cls)
        .. " create=" .. tostring(rep.createOk) .. " shown=" .. tostring(rep.shown))
    return rep
end
Shell.Probe = Probe

local function ApplyCurrent(tag)
    ExecuteInGameThread(function() pcall(Shell.Apply, tag) end)
end

JXRegCmd("jxprobe", function(FullCommand, Parameters, Ar)
    ExecuteInGameThread(function() pcall(Probe, "manual") end)
    return true
end)

JXRegCmd("juiskin", function(FullCommand, Parameters, Ar)
    local a = (Parameters and Parameters[1]) or "status"
    if a == "opaque" then
        ExecuteInGameThread(function()
            pcall(function()
                local okw, w = pcall(function() return FindFirstOf("WBP_JinxingRoot_C") end)
                if not okw or not w then
                    Say("juiskin opaque: panel instance not found")
                    return
                end
                local tree = nil
                pcall(function() tree = w.WidgetTree end)
                local rt = nil
                if tree then pcall(function() rt = tree.RootWidget end) end
                if not rt then rt = w end
                local n = ForceOpaque(rt, 0)
                Say("juiskin opaque: " .. tostring(n) .. " widget(s) forced to opacity 1.0")
            end)
        end)
        return true
    end
    if a == "reload" or a == "apply" then
        local t, path = LoadSkinFile(Shell.currentName)
        if t then
            Shell.current = MergeSkin(DEFAULT_SKIN, t)
            Say("juiskin: reloaded " .. Shell.currentName .. " (" .. tostring(path) .. ")")
        else
            Say("juiskin: file load failed for '" .. Shell.currentName .. "', keeping current. " .. tostring(path))
        end
        ApplyCurrent("manual")
        return true
    end
    if a == "status" then
        local rep = Shell.lastApply or {}
        local skip = {}
        for k, v in pairs(rep.skipped or {}) do skip[#skip + 1] = k .. "(" .. tostring(v) .. ")" end
        Say("juiskin skin=" .. tostring(rep.skin or Shell.currentName)
            .. " last=" .. tostring(rep.tag or "-")
            .. " widgets=" .. tostring(rep.widgets or "?")
            .. " labelled=" .. tostring(rep.labelled or "?")
            .. " revealed=" .. tostring(rep.revealed or "?"))
        for _, n in ipairs(rep.notes or {}) do Say("juiskin: " .. n) end
        if #skip > 0 then Say("juiskin skipped: " .. table.concat(skip, " ")) end
        
        Say("juiskin: pak panel retired (r7.0) - skin has no live target; UI is the canvas (B/F8)")
        Say("juiskin: reload | <skin name> | jtab 14 = entertainment page")
        return true
    end
    
    local t, path = LoadSkinFile(a)
    if not t then
        Say("juiskin: no skin '" .. tostring(a) .. "' (" .. tostring(path) .. "); staying on '" .. Shell.currentName .. "'")
        return true
    end
    Shell.currentName = a
    Shell.current = MergeSkin(DEFAULT_SKIN, t)
    Say("juiskin: skin -> " .. a)
    ApplyCurrent("skin-" .. a)
    return true
end)

pcall(function()
    
    local origWReady = JXWorldReady
    JXWorldReady = function(tag, epoch, wid)
        local r = nil
        if origWReady then r = origWReady(tag, epoch, wid) end
        ExecuteWithDelay(4000, function() ExecuteInGameThread(function() pcall(Shell.Apply, "mapload") end) end)
        for _, ms in ipairs({ 12000, 30000, 60000, 120000 }) do
            ExecuteWithDelay(ms, function() ExecuteInGameThread(function()
                pcall(function()
                    local w = FindFirstOf("WBP_JinxingRoot_C")
                    if w and w.IsValid and w:IsValid() then return end
                    pcall(Probe, "auto")
                end)
            end) end)
        end
        return r
    end
end)

Log("JxUiShell r1.0 ready: juiskin status|reload|<name>; skin dir=" .. SkinDir())
return Shell
