
local DG = { version = "1.0", reportPath = nil, beaconShown = false }

local function Say(s)
    pcall(function() print("[JxDiagnose] " .. tostring(s) .. "\n") end)
end

local Dir = ""
do
    local sc = (_G.JXSidecarDir or "")
    if sc ~= "" then Dir = tostring(sc) end
end
DG.reportPath = (Dir ~= "" and Dir or "") .. "../jx_diagnose.txt"

local function alive(o)
    if o == nil then return false end
    local ok, v = pcall(function() return o:IsValid() end)
    return ok and v == true
end

local function writeSection(title, lines)
    local t = os.date("%Y-%m-%d %H:%M:%S")
    local head = string.format("\r\n== %s @ %s ==\r\n", title, t)
    local body = ""
    for _, l in ipairs(lines) do body = body .. tostring(l) .. "\r\n" end
    pcall(function()
        local f = io.open(DG.reportPath, "a")
        if f then f:write(head .. body); f:close() end
    end)
    Say("== " .. title .. " ==")
    for _, l in ipairs(lines) do Say("  " .. tostring(l)) end
    return head .. body
end

local function report()
    local lines = {}

    lines[#lines + 1] = "sidecars:"
    local modules = {
        { "JxPanels (canvas)",   _G.JxPanels },
        { "JxUiRouter (v63)",    _G.JxUiRouter },
        { "JxUiRescue427 (v66)", _G.JxUiRescue427 },
        { "JxWhitelist (v67)",   _G.JxWhitelist },
        { "JIF (interface)",     _G.JIF },
    }
    for _, m in ipairs(modules) do
        lines[#lines + 1] = string.format("  %-22s %s", m[1],
            type(m[2]) == "table" and "loaded" or "NOT LOADED")
    end

    lines[#lines + 1] = "pak chain:"
    local probe = _G.JxUiProbe
    if type(probe) == "function" then
        local ok, r = pcall(probe)
        if ok and r then
            lines[#lines + 1] = string.format("  Core  : %s", tostring(r.coreState))
            lines[#lines + 1] = string.format("  UIroot: %s", tostring(r.uirootState))
            lines[#lines + 1] = string.format("  F6    : %s", tostring(r.f6State))
            lines[#lines + 1] = string.format("  class : loadable=%s %s",
                tostring(r.pakClassLoadable), tostring(r.pakClassPath or ""))
            lines[#lines + 1] = string.format("  canvas: %s", tostring(r.luaPanel))
        else
            lines[#lines + 1] = "  probe error: " .. tostring(r)
        end
    else
        lines[#lines + 1] = "  probe not published (main.lua older than v63?)"
    end

    lines[#lines + 1] = "HUD canvas:"
    local jp = _G.JxPanels
    if type(jp) == "table" then
        lines[#lines + 1] = string.format("  hook=%s fired=%s",
            tostring(jp.hookPath), tostring(jp.hookFrames or 0))
        if (jp.hookFrames or 0) > 0 then
            lines[#lines + 1] = "  canvas ALIVE (Lua CAN draw on this build)"
        else
            lines[#lines + 1] = "  canvas NOT firing (hook bound but silent)"
        end
    else
        lines[#lines + 1] = "  JxPanels not loaded"
    end

    lines[#lines + 1] = "keys:"
    local binds = _G.JXBinds
    if type(binds) == "table" and type(binds.order) == "table" then
        for _, e in ipairs(binds.order) do
            lines[#lines + 1] = string.format("  %-6s %-28s %s",
                tostring(e.key), tostring(e.id or "?"), tostring(e.label or ""))
        end
    else
        lines[#lines + 1] = "  host bind registry not published (main.lua pre-v63)"
    end

    lines[#lines + 1] = "whitelist:"
    local wl = _G.JxWhitelist
    if type(wl) == "table" then
        local n = 0
        for _ in pairs(wl.rules or {}) do n = n + 1 end
        lines[#lines + 1] = string.format("  steam64 rules=%d file=%s",
            n, tostring(wl.File))
    else
        lines[#lines + 1] = "  JxWhitelist not loaded (jplus/jpro fall back to names)"
    end

    lines[#lines + 1] = "verdict:"
    local probeRes = nil
    if type(probe) == "function" then
        local ok, r = pcall(probe)
        if ok then probeRes = r end
    end
    local anyCanvas = type(jp) == "table" and (jp.hookFrames or 0) > 0
    local pakAlive = probeRes and (tostring(probeRes.coreState):lower() == "alive"
        or tostring(probeRes.uirootState):lower() == "alive")
    if pakAlive then
        lines[#lines + 1] = "  pak UI alive -> panel keys SHOULD work. If not:"
        lines[#lines + 1] = "  send jx_diagnose.txt + crashlog.txt to the developer."
    elseif anyCanvas then
        lines[#lines + 1] = "  pak dead but canvas alive -> F8/jpanel2 opens the Lua panel."
        lines[#lines + 1] = "  pak fix: see 'pak chain' above (mount vs spawn)."
    else
        lines[#lines + 1] = "  NEITHER pak NOR canvas can show anything."
        lines[#lines + 1] = "  => if UE4SS console shows these lines, Lua is alive and"
        lines[#lines + 1] = "     the HUD hook needs the concrete-class retry (auto, 10 s)."
        lines[#lines + 1] = "  => if this console is EMPTY, UE4SS itself is not loading:"
        lines[#lines + 1] = "     check ue4ss.dll + dwmapi.dll + enabled.txt, and read"
        lines[#lines + 1] = "     jx_boot_report.txt written by JxLoader v2.2 (DLL side)."
    end

    writeSection("jxdiag2 report", lines)
    Say("full report written to " .. DG.reportPath)
end

local function beacon(hud)
    if DG.beaconShown then return end
    DG.beaconShown = true
    pcall(function()
        
        local cyan = { R = 0.0, G = 0.8, B = 0.9, A = 0.85 }
        local dark = { R = 0.0, G = 0.0, B = 0.0, A = 0.55 }
        hud:DrawRect(dark, 8, 8, 190, 26)
        hud:DrawRect(cyan, 8, 8, 190, 2)
        hud:DrawText("JX " .. DG.version .. " canvas OK", cyan, 14, 14, nil, 0.72)
        Say("HUD beacon drawn (canvas render path CONFIRMED working)")
    end)
end

do
    local jp = _G.JxPanels
    if type(jp) == "table" and type(jp.OnRender) == "function" then
        local orig = jp.OnRender
        jp.OnRender = function(hud)
            pcall(function()
                if not DG.beaconShown then beacon(hud) end
            end)
            return orig(hud)
        end
    end
end

if type(ExecuteWithDelay) == "function" and type(ExecuteInGameThread) == "function" then
    ExecuteWithDelay(12000, function()
        pcall(function()
            ExecuteInGameThread(function()
                if DG.beaconShown then return end
                pcall(function()
                    local hud = FindFirstOf("HUD")
                    if alive(hud) then beacon(hud) end
                end)
            end)
        end)
    end)
end

local function jpanel2(Parameters)
    local which = ((Parameters and Parameters[1]) or "panel"):lower()
    pcall(function()
        ExecuteInGameThread(function()
            if which == "canvas" then
                local jp = _G.JxPanels
                if type(jp) == "table" and type(jp.Ensure) == "function" then
                    pcall(jp.Ensure)
                    pcall(jp.Toggle)
                    Say("canvas panel toggled via console")
                else
                    Say("canvas panel module not loaded")
                end
                return
            end
            if which == "fix" then
                local ur = _G.JxUiRescue427
                if type(ur) == "table" then
                    
                    local c = (type(JX) == "table" and JX.CmdFn or {})["juix"]
                    if type(c) == "function" then c(nil, { "fix" }) return end
                end
                Say("juix not available; run 'juix fix' directly")
                return
            end
            
            local core = nil
            pcall(function()
                core = FindFirstOf("BP_JinxingLoaderCore_C")
            end)
            if alive(core) then
                pcall(function() core:JinxingLoaderToggle() end)
                Say("pak panel toggled via console")
                return
            end
            local jp = _G.JxPanels
            if type(jp) == "table" and type(jp.Ensure) == "function" then
                pcall(jp.Ensure)
                pcall(jp.Toggle)
                Say("pak Core not found; canvas panel toggled via console")
                return
            end
            Say("no panel path available - run 'jxdiag2' and send the report")
        end)
    end)
    return true
end

local function reg(name, fn)
    if type(JXRegCmd) == "function" then
        JXRegCmd(name, fn)
        return true
    elseif type(RegisterConsoleCommandHandler) == "function" then
        local ok = pcall(RegisterConsoleCommandHandler, name, fn)
        return ok
    end
    return false
end
reg("jxdiag2", function(F, P) report(); return true end)
reg("jpanel2", jpanel2)

writeSection("module load", {
    "JxDiagnose v" .. DG.version .. " loaded",
    "commands: jxdiag2 (write+print report) | jpanel2 [panel|canvas|fix]",
    "HUD beacon: draws once ~12 s after load if the canvas path is alive",
})

_G.JxDiagnose = DG
return DG
