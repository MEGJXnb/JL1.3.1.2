
JPH = {}
_G.JXPlayerHub = JPH
JPH.version = "1.0"

local Log = function(s) print("[JxPlayerHub] " .. tostring(s) .. "\n") end
local Say = (type(JX) == "table" and JX.Say) or (type(JXSay) == "function" and JXSay) or Log

local function CollectRows()
    local rows = {}
    pcall(function() rows = CollectPlayers() end)
    if type(rows) ~= "table" or #rows == 0 then
        pcall(function()
            for _, ps in ipairs(FindAllOf("PlayerState") or {}) do
                if ps and ps:IsValid() then
                    local nm = "?"
                    pcall(function() nm = tostring(ps.PlayerName) end)
                    rows[#rows + 1] = { name = nm, ps = ps }
                end
            end
        end)
    end
    return rows
end

local function Root()
    local sc = (_G.JXSidecarDir or "")
    if sc ~= "" then return tostring(sc):gsub("\\", "/"):gsub("[^/]+/$", "") end
    return ""
end

JPH.auth = { on = false, pass = "", timeout = 45, pending = {} }   
JPH.mute = {}                                                      
JPH.cfg = { authFile = Root() .. "config/auth_pass.txt" }

local function Now() return os.time() end

local function SayF(fmt, ...)
    Say(string.format(fmt, ...))
end

local function FindPlayer(q)
    local rows = CollectRows()
    if type(q) == "number" or tonumber(q) then
        local i = tonumber(q)
        return rows[i], #rows
    end
    q = tostring(q):lower()
    for _, r in ipairs(rows) do
        if r.name and r.name:lower():find(q, 1, true) then return r, #rows end
        if r.steam64 and tostring(r.steam64):find(q, 1, true) then return r, #rows end
    end
    return nil, #rows
end

local function MyPC()
    local pc = nil
    pcall(function() pc = UEHelpers.GetPlayerController() end)
    if not (pc and pc:IsValid()) then pcall(function() pc = FindFirstOf("PlayerController") end) end
    return pc
end

local function MyPawnLoc()
    local pc = MyPC()
    if not (pc and pc:IsValid()) then return nil end
    local pawn = pc.Pawn
    if not (pawn and pawn:IsValid()) then return nil end
    local l = pawn:K2_GetActorLocation()
    return l.X, l.Y, l.Z
end

local function IsHost()
    local ok, r = pcall(function()
        local gi = FindFirstOf("GameInstance")
        if gi and gi:IsValid() then
            local lp = gi:GetFirstLocalPlayerController()
            if lp and lp:IsValid() and lp.PlayerState then
                
                local role = nil
                pcall(function() role = lp.PlayerState.Role end)
                return role ~= nil and role ~= 3
            end
        end
        return false
    end)
    return ok and r or false
end

local function PlayerStats(PS)
    local ping, sanity, voice, alive = "n/a", "n/a", "n/a", "?"
    pcall(function() ping = PS.Ping or PS.CompressedPing or "n/a" end)
    pcall(function()
        local p = PS.Owner and PS.Owner.Pawn or nil
        if p and p:IsValid() then
            alive = tostring(p:IsActorTickEnabled()) ~= "false"
            pcall(function()
                if p.Sanity then sanity = tostring(p.Sanity) end
            end)
            
            if sanity == "n/a" then
                pcall(function()
                    for _, nm in ipairs({ "Sanity", "SanityValue", "CurrentSanity" }) do
                        local ok, v = pcall(function() return p[nm] end)
                        if ok and type(v) == "number" then sanity = string.format("%.0f", v) break end
                    end
                end)
            end
        end
    end)
    pcall(function()
        local v = PS.bIsVoiceMuted
        if v ~= nil then voice = (v == true or v == 1) and "muted" or "open" end
    end)
    return ping, sanity, voice, alive
end

local function ListFull()
    local rows = {}
    pcall(function() rows = CollectPlayers() end)
    SayF("=== 玩家全景 (%d 人 / 房上限 %s) ===", #rows, tostring(Config and Config.MaxPlayers or "?"))
    for i, r in ipairs(rows) do
        local ping, sanity, voice, alive = PlayerStats(r.ps)
        local muted = (r.steam64 and JPH.mute[r.steam64]) or (r.name and JPH.mute[r.name]) or false
        SayF("[%d] %s%s | Steam64=%s | EOS=%s | ping=%s | sanity=%s | voice=%s%s | alive=%s",
            i, r.name or "?", r.localPlayer and "(你)" or "", tostring(r.steam64 or "-"),
            tostring((r.net and r.net ~= "unknown") and r.net or "-"),
            tostring(ping), sanity, voice, muted and "(已静音)" or "", tostring(alive))
    end
    if JPH.auth.on then
        local pend = {}
        for nm, dl in pairs(JPH.auth.pending) do
            if Now() < dl then pend[#pend + 1] = nm else JPH.auth.pending[nm] = nil end
        end
        SayF("密码认证: 开启(超时%d秒) 待认证=%s", JPH.auth.timeout,
            (#pend > 0) and table.concat(pend, ",") or "无")
    end
    return true
end

local function TpTo(q)
    local r = FindPlayer(q)
    if not r or not r.ps then SayF("没找到玩家 %s（jpl list 看编号）", tostring(q)) return true end
    pcall(function()
        local pc = MyPC()
        local pawn = pc and pc.Pawn
        local target = r.ps.Owner and r.ps.Owner.Pawn
        if not (pawn and target and pawn:IsValid() and target:IsValid()) then Say("目标没有 Pawn") return end
        local l = target:K2_GetActorLocation()
        local rot = pawn:K2_GetActorRotation()
        pawn:K2_TeleportTo({ X = l.X, Y = l.Y, Z = l.Z + 60 }, { Pitch = 0, Yaw = rot.Yaw or 0, Roll = 0 })
        SayF("已传送到 %s 身旁", tostring(r.name))
    end)
    return true
end

local function Bring(q)
    if not IsHost() then Say("拉人需要房主权限") return true end
    local r = FindPlayer(q)
    if not r or not r.ps then SayF("没找到玩家 %s", tostring(q)) return true end
    pcall(function()
        local x, y, z = MyPawnLoc()
        if not x then Say("自己没有 Pawn") return end
        local pc = r.ps.Owner
        local pawn = pc and pc.Pawn
        if not (pawn and pawn:IsValid()) then Say("对方没有 Pawn") return end
        local rot = pawn:K2_GetActorRotation()
        pawn:K2_TeleportTo({ X = x + 120, Y = y, Z = z }, { Pitch = 0, Yaw = rot.Yaw or 0, Roll = 0 })
        SayF("已把 %s 拉到身旁", tostring(r.name))
    end)
    return true
end

local function Kick(q)
    local r = FindPlayer(q)
    if not r or not r.ps then SayF("没找到玩家 %s", tostring(q)) return true end
    local who = tostring(r.name or "")
    local id = tostring(r.steam64 or r.net or "")
    
    local blf = _G.JXBlacklistAdd or AddBlacklist
    local added = false
    if type(blf) == "function" then
        pcall(function() added = blf(who ~= "" and who or id) == true end)
    end
    local ef = _G.JXBlacklistEnforce or EnforceBlacklist
    if type(ef) == "function" then pcall(function() ef() end) end
    if type(JXKickToMenu) == "function" and r.ps.Owner and r.ps.Owner:IsValid() then
        pcall(function() JXKickToMenu(r.ps.Owner, "kicked by host") end)
    end
    if added then
        SayF("已踢出 %s (%s) 并加入黑名单", who, id)
    else
        SayF("已踢出 %s (%s)(黑名单本局不可用,未加入)", who, id)
    end
    return true
end

local function LoadPass()
    local f = io.open(JPH.cfg.authFile, "r")
    if f then local s = f:read("*l") f:close() return s or "" end
    return ""
end
local function SavePass(p)
    local f = io.open(JPH.cfg.authFile, "w")
    if f then f:write(tostring(p)) f:close() end
end

local function AuthCmd(action, a, b2)
    if action == "on" then
        local pass = a or LoadPass()
        if pass == "" then Say("用法: jpl auth on <密码>") return true end
        JPH.auth.on = true; JPH.auth.pass = pass
        SavePass(pass)
        SayF("密码认证开启（超时%d秒）。进房者聊天框发送 密码 即可通过。", JPH.auth.timeout)
    elseif action == "off" then
        JPH.auth.on = false; JPH.auth.pending = {}
        Say("密码认证关闭")
    else
        local pass = action or ""
        local f = LoadPass()
        if f ~= "" and pass == f then
            Say("密码正确，欢迎")
            JPH.auth.pending[MyPC() and tostring(MyPC().PlayerState and MyPC().PlayerState:GetPlayerName() or "?") or "?"] = nil
        else
            Say("密码错误")
        end
    end
    return true
end

local function AuthTick()
    local ok, err = pcall(function()
    if JPH.auth.on then
        local expired = {}
        for nm, dl in pairs(JPH.auth.pending) do
            if Now() >= dl then expired[#expired + 1] = nm end
        end
        for _, nm in ipairs(expired) do
            JPH.auth.pending[nm] = nil
            local r = FindPlayer(nm)
            if r and r.ps then
                pcall(function()
                    if type(JXKickToMenu) == "function" and r.ps.Owner then
                        JXKickToMenu(r.ps.Owner, "auth timeout")
                    end
                end)
                SayF("%s 未在时限内通过密码认证，已移出", tostring(nm))
            end
        end
    end
    end)
    if not ok then Log("AuthTick error (suppressed): " .. tostring(err)) end
    pcall(function() ExecuteWithDelay(10000, AuthTick) end)
end

JPH.CheckPass = function(name, pass)
    if not JPH.auth.on then return true end
    if pass == JPH.auth.pass then
        JPH.auth.pending[name] = nil
        return true
    end
    return false
end

local function SessionCmd(sub, a, b2)
    if sub == "open" or sub == "code" then
        local target
        if sub == "open" then
            target = tostring(a or "") .. ":" .. tostring(b2 or "7777")
        else
            target = tostring(a or "")
        end
        if target == "" or target == ":" then Say("用法: jnet open <host> <port> | jnet code <code>") return true end
        local pc = MyPC()
        if not pc then Say("没有 PlayerController") return true end
        pcall(function()
            local gi = pc:GetGameInstance()
            if gi and gi:IsValid() then
                ExecuteInGameThread(function()
                    pcall(function() gi:ReturnToMainMenu() end)
                    ExecuteWithDelay(2500, function()
                        ExecuteInGameThread(function()
                            pcall(function()
                                local w = UEHelpers.GetWorld()
                                local KSL = StaticFindObject("/Script/Engine.Default__KismetSystemLibrary")
                                if KSL and w then
                                    KSL:ExecuteConsoleCommand(w, "open " .. target, pc)
                                    Say("正在直连: " .. target)
                                end
                            end)
                        end)
                    end)
                end)
            else
                
                pcall(function()
                    local w = UEHelpers.GetWorld()
                    local KSL = StaticFindObject("/Script/Engine.Default__KismetSystemLibrary")
                    if KSL and w then KSL:ExecuteConsoleCommand(w, "open " .. target, pc) end
                end)
                Say("正在直连: " .. target)
            end
        end)
        return true
    end
    if sub == "max" then
        local n = tonumber(a)
        if not n or n < 2 or n > 512 then Say("用法: jnet max <2-512>") return true end
        
        -- r57: ExecuteConsoleCommand is not a UE4SS v3.0.1 global (the name is
        -- absent from UE4SS.dll), so this forward was a nil call while the
        -- reply still told the host the cap had been applied. Dispatch through
        -- main's own command registry (JX.CmdFn) and report what really ran.
        local sent = false
        pcall(function()
            local JXT = _G.JX
            local fn = (type(JXT) == "table" and type(JXT.CmdFn) == "table") and JXT.CmdFn["jmax"] or nil
            if type(fn) == "function" then
                fn("jmax " .. math.floor(n), { tostring(math.floor(n)) }, nil)
                sent = true
            elseif type(_G.JXExecCmd) == "function" then
                sent = _G.JXExecCmd("jmax " .. math.floor(n)) and true or false
            end
        end)
        if sent then
            SayF("房间上限 -> %d (jmax 已转发)", n)
        else
            SayF("房间上限没改成 %d: 没找到 jmax 处理器", n)
        end
        return true
    end
    if sub == "close" then
        if not IsHost() then Say("关闭大厅需要房主权限") return true end
        pcall(function()
            local pc = MyPC()
            local gi = pc and pc:GetGameInstance()
            if gi and gi:IsValid() then gi:ReturnToMainMenu() end
        end)
        Say("已返回主菜单（大厅随之关闭）")
        return true
    end
    Say("用法: jnet open <host> <port> | jnet code <code> | jnet max <n> | jnet close | jnet status")
    return true
end

JXRegCmd("jpl", function(FullCommand, Parameters, Ar)
    local sub = tostring((Parameters and Parameters[1]) or "list"):lower()
    local a, b2 = Parameters and Parameters[2], Parameters and Parameters[3]
    if sub == "list" then return ListFull() end
    if sub == "tp" then return TpTo(a) end
    if sub == "bring" then return Bring(a) end
    if sub == "kick" then return Kick(a) end
    if sub == "mute" then
        local r = FindPlayer(a)
        if r and (r.steam64 or r.name) then
            local key = r.steam64 or r.name
            JPH.mute[key] = (tostring(b2 or "on"):lower() ~= "off")
            SayF("%s 语音标记: %s", tostring(r.name), JPH.mute[key] and "静音" or "恢复")
        else
            Say("用法: jpl mute <编号> on|off")
        end
        return true
    end
    if sub == "ban" then
        
        local blf = _G.JXBlacklistAdd or AddBlacklist
        local done = false
        if type(blf) == "function" then
            pcall(function() done = blf(tostring(a or "")) == true end)
        end
        if done then Say("黑名单已加: " .. tostring(a or ""))
        else Say("黑名单没加成(功能本局不可用): " .. tostring(a or "")) end
        return true
    end
    if sub == "pardon" then
        
        local blf = _G.JXBlacklistRemoveEntry or RemoveBlacklist
        local done = false
        if type(blf) == "function" then
            pcall(function() done = blf(tostring(a or "")) == true end)
        end
        if done then Say("黑名单已移: " .. tostring(a or ""))
        else Say("黑名单没移掉(功能本局不可用或不在名单里): " .. tostring(a or "")) end
        return true
    end
    if sub == "wl" then
        local act = tostring(a or "list"):lower()
        if act == "add" then
            
            local done = false
            pcall(function()
                local cf = (type(JX) == "table" and JX.CmdFn) or {}
                local c = cf["jwl"]
                if type(c) == "function" then
                    done = (c("jwl set " .. tostring(b2 or "") .. " 3", { "set", tostring(b2 or ""), "3" }) == true)
                end
            end)
            if done then Say("白名单已加(PLUS): " .. tostring(b2 or ""))
            else Say("白名单没加成 - 用 jwl set <名字> 3 或 jwlsteam add <steam64>") end
        else
            pcall(function()
                local cf = (type(JX) == "table" and JX.CmdFn) or {}
                local c = cf["jwl"]
                if type(c) == "function" then c("jwl list", { "list" }) end
            end)
        end
        return true
    end
    if sub == "auth" then return AuthCmd(a, b2) end
    return ListFull()
end)

JXRegCmd("jnet", function(FullCommand, Parameters, Ar)
    local sub = tostring((Parameters and Parameters[1]) or "status"):lower()
    return SessionCmd(sub, Parameters and Parameters[2], Parameters and Parameters[3])
end)

JPH.IsHost = IsHost
JPH.FindPlayer = FindPlayer
Log("JxPlayerHub r1.0 ready: jpl list|tp|bring|kick|mute|ban|pardon|wl|auth ; jnet open|code|max|close|status")
ExecuteWithDelay(12000, AuthTick)
return JPH
