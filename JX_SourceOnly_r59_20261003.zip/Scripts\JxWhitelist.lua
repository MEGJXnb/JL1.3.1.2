-- JxWhitelist.lua r2.1 (rebuilt clean from r17.6 spec)
-- SteamID64-precise whitelist gate with optional expiry dates.
-- File format (one per line):
--   <steam64> = <plus|pro|6>[:YYYYMMDD]     (bare id = plus, no expiry)

local WL = { version = "2.1" }
WL.File = "whitelist_steam64.txt"
WL.rules = {}
WL.loadedAt = nil
WL.mode = "strict"
local Log = function(s) print("[JxWhitelist] " .. tostring(s) .. "\n") end
local Say = Log

-- resolve a PlayerState to its Steam64 via UniqueNetId
local function IdOfPS(ps)
    if not ps or not ps:IsValid() then return nil end
    local sid = nil
    pcall(function()
        local uid = ps:GetPreferredUniqueNetId()
        if uid and uid.IsValid and uid:IsValid() then sid = uid:ToString() end
    end)
    if not sid then
        pcall(function()
            if ps.UniqueId then sid = tostring(ps.UniqueId) end
        end)
    end
    if sid then
        local d = tostring(sid):match("(%d%d%d%d%d%d%d%d%d%d%d+)")
        if d then return d end
    end
    return nil
end

local function MyOwnSteam64()
    local ok, sid = pcall(function()
        local PC = UEHelpers.GetPlayerController()
        if PC and PC:IsValid() and PC.Player and PC.Player:IsValid() then
            local lp = PC.Player
            if lp.GetPreferredUniqueNetId then
                local uid = lp:GetPreferredUniqueNetId()
                if uid and uid.IsValid and uid:IsValid() then
                    local s = uid:ToString()
                    local d = tostring(s):match("(%d%d%d%d%d%d%d%d%d%d%d+)")
                    if d then return d end
                end
            end
        end
        return nil
    end)
    return (ok and sid) or nil
end

function WL.Reload()
    WL.rules = {}
    local n = 0
    pcall(function()
        local f = io.open(WL.File, "r")
        if not f then
            local w = io.open(WL.File, "w")
            if w then
                w:write("# SteamID64 rules - one per line\n")
                w:write("# <steam64> = <plus|pro|6>[:YYYYMMDD]\n")
            end
            return
        end
        for line in f:lines() do
            local s = line:match("^%s*(.-)%s*$")
            if s ~= "" and s:sub(1, 1) ~= "#" then
                local id, lvls, exp = s:match("^(%d+)%s*=?%s*([%w:]+)$")
                if id then
                    local lvl, expiry = lvls:match("^([%w]+):?(%d*)$")
                    local lnum = tonumber(lvl)
                    local isExpired = false
                    if expiry and #expiry == 8 then
                        local ey, emo, ed = tonumber(expiry:sub(1,4)), tonumber(expiry:sub(5,6)), tonumber(expiry:sub(7,8))
                        local tt = nil
                        if ey and emo and ed then
                            pcall(function() tt = os.time({year=ey, month=emo, day=ed, hour=23, min=59, sec=59}) end)
                        end
                        if tt and os.time() > tt then
                            isExpired = true
                        end
                    end
                    if not isExpired then
                        WL.rules[id] = lvl or "plus"
                        n = n + 1
                    end
                end
            end
        end
        f:close()
    end)
    WL.loadedAt = os.time()
    Say("loaded " .. n .. " rule(s) from " .. WL.File)
    return n
end

function WL.LevelOfSteam64(sid)
    if not sid then return nil end
    return WL.rules[tostring(sid)]
end

function WL.AllowBySteam64(need, forPS)
    local sid
    if forPS then sid = IdOfPS(forPS) else sid = MyOwnSteam64() end
    if not sid then return nil end
    local lvl = WL.rules[tostring(sid)]
    if not lvl then
        if WL.mode == "name" then return nil end
        return false
    end
    local lnum = tonumber(lvl)
    if need == "PRO" then return (lvl == "pro") or (lnum ~= nil and lnum >= 4) end
    return true
end

function WL.Who()
    local rows = {}
    pcall(function()
        local states = UEHelpers.GetAllPlayerStates()
        if not states then return end
        for _, ps in ipairs(states) do
            if ps and ps:IsValid() then
                local name = "?"
                pcall(function() name = tostring(ps.PlayerName) end)
                local sid = IdOfPS(ps)
                local lvl = sid and (WL.rules[sid] or "-") or "?"
                rows[#rows + 1] = { name = name, steam64 = sid or "unresolved", level = lvl }
            end
        end
    end)
    return rows
end

local function dispatch(FullCommand, Parameters)
    local sub = ((Parameters and Parameters[1]) or "list"):lower()
    if sub == "list" then
        local rows = WL.Who()
        Say("=== online players (" .. #rows .. ") ===")
        for i, r in ipairs(rows) do
            Say(string.format("  [%d] %-24s %s  level=%s", i, r.name, r.steam64, r.level))
        end
    elseif sub == "reload" then
        WL.Reload()
    elseif sub == "add" then
        local id = Parameters and Parameters[2]
        if not id then Say("usage: jwlsteam add <steam64> [plus|pro|6][:YYYYMMDD]"); return end
        WL.rules[id] = Parameters and Parameters[3] or "plus"
        Say("added " .. id .. " = " .. WL.rules[id] .. " (live, not persisted)")
    end
    return true
end

if type(JXRegCmd) == "function" then
    JXRegCmd("jwlsteam", dispatch)
end

WL.Reload()
_G.JxWhitelist = WL
Say("v" .. WL.version .. " ready: " .. (function()
    local c = 0; for _ in pairs(WL.rules) do c = c + 1 end; return c
end)() .. " rule(s), mode=" .. WL.mode)

return WL
