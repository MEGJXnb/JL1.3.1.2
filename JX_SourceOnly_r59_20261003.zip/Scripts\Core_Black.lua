-- Core_Black.lua (r46 split) - tiered blacklist + server sync + spread.
--
-- Tiers:
--   local  : config/blacklist.txt        owned by main.lua; manual adds from
--                                        the panel/commands; enforced by main.lua.
--   server : config/blacklist_remote.txt GitHub blacklist.txt; level-6 bans;
--                                        spreads to EVERY loader that syncs.
--   peer   : config/blacklist_peer.txt   spread/import tier; bans shared by
--                                        other loaders (jbl import / server file).
--
-- Rules (user spec 2026-10-02):
--   * a blacklist NEVER disables the target's own loader. Enforcement only
--     kicks the listed player out of OTHER people's hosted rooms (host side,
--     non-local controllers only, fail-open on every error).
--   * local-tier additions are enforced in the adder's own rooms only.
--   * level-6 additions go to the server tier (jbl push stages the entry for
--     the owner to publish as blacklist.txt) and spread to all loaders.
--
-- Join-path safety: every fetch runs on the UE4SS timer/worker context with
-- --connect-timeout 3, keeps the last good cache on failure, and can never
-- stall the connecting screen.
local E = _G.JXEnv or {}
local Log = E.Log or function(s) print("[JX] " .. tostring(s) .. "\n") end
if _G.JX_CORE_BLACK_LOADED then Log("Core_Black: duplicate load skipped") return end
_G.JX_CORE_BLACK_LOADED = true
local ModDir = E.ModDir or (E.JXSidecarDir or "")
local SSay = E.Say or function(s) Log("[BL] " .. tostring(s)) end

local CFG          = ModDir .. "config/"
local SERVER_CACHE = CFG .. "blacklist_remote.txt"
local PEER_CACHE   = CFG .. "blacklist_peer.txt"
local URL_FILE     = CFG .. "blacklist_url.txt"
local STAGE        = "D:\\JL_Work\\JX_Server\\blacklist_server.txt"

local Tiers = { server = {}, peer = {} }
local Order = { server = {}, peer = {} }
local stats = { lastSync = "never", kicks = 0 }

local function ReadLines(path)
    local out = {}
    local h = io.open(path, "rb")
    if not h then return out end
    local data = h:read("*a")
    h:close()
    if not data or #data == 0 or #data > 65536 or data:find("%z") then return out end
    for line in data:gmatch("[^\r\n]+") do
        line = line:gsub("^\239\187\191", ""):gsub("^%s+", ""):gsub("%s+$", "")
        if line ~= "" and line:sub(1, 1) ~= "#" and #line <= 64 then
            out[#out + 1] = line
        end
    end
    return out
end

local function LoadTier(name, path)
    local list, order = {}, {}
    for _, line in ipairs(ReadLines(path)) do
        local k = line:lower()
        if not list[k] then
            list[k] = line
            order[#order + 1] = line
        end
    end
    Tiers[name] = list
    Order[name] = order
    return #order
end

local function PickCurl()
    local c = "C:\\Windows\\System32\\curl.exe"
    local h = io.open(c, "rb")
    if h then h:close() return c end
    return "curl"
end

local function BaseUrl()
    local u = ""
    local f = io.open(URL_FILE, "r")
    if f then u = f:read("*l") or ""; f:close() end
    if u == "" then
        local wf = io.open(CFG .. "jxserver.txt", "r")
        if wf then u = wf:read("*l") or ""; wf:close() end
        u = u:gsub("whitelist%.txt", "blacklist.txt")
    end
    u = u:gsub("^%s+", ""):gsub("%s+$", "")
    if u:sub(1, 8) ~= "https://" and u:sub(1, 7) ~= "http://" then return "" end
    return u
end

local function FetchTo(url, dest)
    local ok = false
    pcall(function()
        -- -f: a 404/403 page body must never land in the cache as entries
        os.execute(string.format('%s -4 -s -f --connect-timeout 3 -m 8 -L "%s" -o "%s"',
            PickCurl(), url, dest:gsub("/", "\\")))
        local h = io.open(dest, "rb")
        if h then
            local d = h:read("*a")
            h:close()
            ok = (d and #d > 0 and #d <= 65536 and not d:find("%z"))
        end
    end)
    if not ok then pcall(function() os.remove(dest) end) end
    return ok
end

local lastAuto = 0
local function Sync(reason)
    local base = BaseUrl()
    if base == "" then
        Log("BL| no blacklist URL (derive from jxserver.txt failed) - sync skipped")
        return false
    end
    local via = "direct"
    local got = FetchTo(base, SERVER_CACHE)
    if not got and base:find("githubusercontent.com", 1, true) then
        via = "mirror"
        got = FetchTo("https://ghproxy.net/" .. base, SERVER_CACHE)
    end
    local nS = 0
    if got then nS = LoadTier("server", SERVER_CACHE) end
    local nP = LoadTier("peer", PEER_CACHE)
    stats.lastSync = os.date("%Y-%m-%d %H:%M:%S") .. " via " .. via .. " (" .. tostring(reason) .. ")"
    Log(string.format("BL| sync(%s): server=%d peer=%d via %s", tostring(reason), nS, nP, via))
    return true
end

local lastKick = 0
local function EnforceRemote()
    if type(_G.JXTransferGuard) == "function" and _G.JXTransferGuard() then return 0 end
    local okP, pcs = pcall(FindAllOf, "PlayerController")
    if not okP or not pcs then return 0 end
    local kicked = 0
    for _, PC in pairs(pcs) do
        if PC and PC:IsValid() then
            pcall(function()
                if PC.IsLocalController and PC:IsLocalController() then return end
                local PS = PC.PlayerState
                if not PS or not PS:IsValid() then return end
                local nm, id = "", ""
                pcall(function() nm = tostring(PS.PlayerName or "") end)
                pcall(function() id = tostring(PS.PlayerId or "") end)
                local nl, il = nm:lower(), id:lower()
                local tier = nil
                for _, tname in ipairs({ "server", "peer" }) do
                    local t = Tiers[tname] or {}
                    if nm ~= "" and t[nl] then tier = tname break end
                    if id ~= "" and id ~= "unknown" and not tier then
                        if t[il] then
                            tier = tname
                        else
                            for k in pairs(t) do
                                if #k >= 15 and k:match("^%d+$") and il:find(k, 1, true) then
                                    tier = tname
                                    break
                                end
                            end
                        end
                    end
                end
                if tier and type(_G.JXKickToMenu) == "function" then
                    if _G.JXKickToMenu(PC, "Removed by host (blacklist:" .. tier .. ")") then
                        kicked = kicked + 1
                        stats.kicks = stats.kicks + 1
                        Log("BL| kicked (" .. tier .. "): " .. nm .. " / " .. id)
                    end
                end
            end)
        end
    end
    if kicked > 0 then lastKick = os.time() end
    return kicked
end

local function Loop()
    pcall(EnforceRemote)
    if os.time() - lastAuto >= 600 then
        lastAuto = os.time()
        pcall(function() Sync("periodic") end)
    end
    ExecuteWithDelay(5000, function() pcall(Loop) end)
end

local function StartLoops()
    ExecuteWithDelay(8000, function() pcall(function() Sync("boot") end) end)
    ExecuteWithDelay(30000, function() pcall(Loop) end)
    -- join coverage: refresh once per world shortly after landing (45 s keeps
    -- clear of the map-load rescue passes), throttled to 1/300 s
    pcall(function()
        RegisterHook("/Script/Engine.PlayerController:ClientRestart", function()
            ExecuteWithDelay(45000, function()
                pcall(function()
                    if os.time() - lastAuto >= 300 then
                        lastAuto = os.time()
                        Sync("join+45s")
                    end
                end)
            end)
        end)
    end)
end

if type(_G.JXRegCmd) == "function" then
    _G.JXRegCmd("jbl", function(FullCommand, Parameters)
        local a = (Parameters and Parameters[1]) or "list"
        if a == "sync" then
            ExecuteWithDelay(0, function() pcall(function() Sync("manual") end) end)
            SSay("jbl: sync running in background - jbl list for the result")
        elseif a == "add" then
            local e = (Parameters and Parameters[2]) or ""
            if _G.JXBlacklistAdd and _G.JXBlacklistAdd(e) then
                SSay("jbl: added to LOCAL blacklist (enforced in your rooms only; jbl push <entry> for the server tier)")
            else
                SSay("jbl: add failed (empty entry?)")
            end
        elseif a == "remove" then
            local e = (Parameters and Parameters[2]) or ""
            if _G.JXBlacklistRemoveEntry and _G.JXBlacklistRemoveEntry(e) then
                SSay("jbl: removed from LOCAL blacklist")
            else
                SSay("jbl: not found in local blacklist")
            end
        elseif a == "list" then
            SSay(string.format("tiers: local(main.txt) | server=%d | peer=%d | kicks=%d | last: %s",
                #Order.server, #Order.peer, stats.kicks, stats.lastSync))
            for _, tname in ipairs({ "server", "peer" }) do
                for i, e in ipairs(Order[tname]) do
                    if i > 20 then SSay("  [" .. tname .. "] ... more"); break end
                    SSay("  [" .. tname .. "] " .. e)
                end
            end
        elseif a == "import" then
            local p = (Parameters and Parameters[2]) or ""
            if p == "" then SSay("usage: jbl import <shared-file-path>") return true end
            local h = io.open(p:gsub("/", "\\"), "rb")
            if not h then SSay("jbl: cannot open " .. p) return true end
            local d = h:read("*a")
            h:close()
            if #d == 0 or #d > 65536 or d:find("%z") then
                SSay("jbl: file rejected (empty/oversized/binary)")
                return true
            end
            local out = io.open(PEER_CACHE, "ab")
            if out then out:write(d); out:close() end
            LoadTier("peer", PEER_CACHE)
            SSay("jbl: imported; peer tier now " .. #Order.peer .. " entr(ies)")
        elseif a == "export" then
            local dst = CFG .. "blacklist_share.txt"
            local out = io.open(dst, "w")
            local n = 0
            if out then
                out:write("# JX blacklist share (peer tier) - " .. os.date() .. "\r\n")
                for _, e in ipairs(Order.peer) do out:write(e .. "\r\n"); n = n + 1 end
                local lf = io.open(CFG .. "blacklist.txt", "r")
                if lf then
                    for line in lf:lines() do
                        line = line:gsub("^%s+", ""):gsub("%s+$", "")
                        if line ~= "" and line:sub(1, 1) ~= "#" then
                            out:write(line .. "\r\n")
                            n = n + 1
                        end
                    end
                    lf:close()
                end
                out:close()
            end
            SSay("jbl: exported " .. n .. " entr(ies) -> " .. dst)
        elseif a == "push" then
            local lvl = 0
            pcall(function()
                if _G.JXWL and _G.JXWL.Level then lvl = tonumber(_G.JXWL.Level()) or 0 end
            end)
            if lvl < 6 then SSay("jbl: push needs whitelist level 6 (server tier)") return true end
            local e = (Parameters and Parameters[2]) or ""
            e = e:gsub("^%s+", ""):gsub("%s+$", "")
            if e == "" or #e > 64 or e:find("[%c]") then SSay("jbl: bad entry") return true end
            pcall(function()
                os.execute('if not exist "D:\\JL_Work\\JX_Server" mkdir "D:\\JL_Work\\JX_Server" >nul 2>nul')
            end)
            local out = io.open(STAGE, "a")
            if out then
                out:write(e .. "\r\n")
                out:close()
                SSay("jbl: staged '" .. e .. "' for the server tier - owner publishes blacklist.txt to spread")
            else
                SSay("jbl: staging unavailable on this machine (server dir missing)")
            end
        else
            SSay("usage: jbl add|remove <entry> | list | sync | import <file> | export | push <entry> (L6)")
        end
        return true
    end)
    Log("BL| jbl ready: add|remove <entry> | list | sync | import | export | push (L6 = server tier)")
end

LoadTier("server", SERVER_CACHE)
LoadTier("peer", PEER_CACHE)
_G.JXBlackTierEnforce = EnforceRemote
_G.JXBlackTierSync = Sync
StartLoops()
Log("BL| Core_Black ready: tiers local/server/peer, host-side kick only, loader never disabled for the listed player")
