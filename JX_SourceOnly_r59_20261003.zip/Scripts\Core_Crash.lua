-- Core_Crash.lua (r16 split from main.lua) - deps bridged via _G.JXEnv
local E = _G.JXEnv or {}
local Log = E.Log or function(s) print("[JX] " .. tostring(s) .. "'\n'") end
-- r25 dedup: two loader paths in main.lua; single-arm guard.
if _G.JX_CORE_CRASH_LOADED then Log("Core_Crash: duplicate load skipped (r25 dedup)") return end
_G.JX_CORE_CRASH_LOADED = true
local ModDir = E.ModDir
function JXCrashReader()
    local function Say(s) Log("[CRASH] " .. tostring(s)) end

    local function ReadCrashLog()
        local h = io.open("Binaries/Win64/crashlog.txt", "r") or io.open("crashlog.txt", "r")
        local out = {}
        if h then
            for line in h:lines() do out[#out + 1] = line end
            h:close()
        end
        return out
    end

    JXRegCmd("jcrash", function(FullCommand, Parameters, Ar)
        local sub = tostring((Parameters and Parameters[1]) or ""):lower()
        ExecuteInGameThread(function()
            pcall(function()
                local cl = ReadCrashLog()
                local exceptions, guarded = {}, 0
                for _, l in ipairs(cl) do
                    if l:find("exception ", 1, true) then exceptions[#exceptions + 1] = l end
                    if l:find("SKIPPED", 1, true) or l:find("SWALLOWED", 1, true) then guarded = guarded + 1 end
                end
                Say(string.format("guard record: %d line(s), %d interception(s) handled by the DLL, %d exception record(s)",
                    #cl, guarded, #exceptions))
                for i = math.max(1, #exceptions - 2), #exceptions do
                    Say("   " .. exceptions[i]:sub(1, 110))
                end
                if sub == "file" then
                    local f = io.open(ModDir .. "logs/crash_report.txt", "w")
                    if f then
                        f:write("crash report bundle - " .. tostring(os.date and os.date("%Y-%m-%d %H:%M:%S") or "?") .. "\r\n")
                        for _, l in ipairs(cl) do f:write(l .. "\r\n") end
                        f:close()
                        Say("full bundle written to logs/crash_report.txt")
                    end
                else
                    Say("jcrash file  - write the full bundle to logs/crash_report.txt")
                end
            end)
        end)
    end)
    Log("crash reader ready: jcrash | jcrash file (member gated)")

    JXRegCmd("jxautofix", function()
        ExecuteInGameThread(function()
            pcall(function()
                local sites, seen = {}, {}
                local function AddSite(mod, off)
                    local key = mod:lower() .. "+" .. off
                    if not seen[key] then
                        seen[key] = true
                        sites[#sites + 1] = mod .. " + " .. off .. " faulted here"
                    end
                end
                local cl = ReadCrashLog()
                for _, l in ipairs(cl) do
                    local mod, dec = l:match("(%S+%.dll)%+(%d%d%d%d+)")
                    if mod and dec then AddSite(mod, "0x" .. string.format("%X", tonumber(dec) or 0)) end
                end
                local uh = io.open("ue4ss/UE4SS.log", "r") or io.open("Binaries/Win64/ue4ss/UE4SS.log", "r")
                if uh then
                    local tail = {}
                    for line in uh:lines() do
                        tail[#tail + 1] = line
                        if #tail > 400 then table.remove(tail, 1) end
                    end
                    uh:close()
                    for _, l in ipairs(tail) do
                        local mod, hex = l:match("(%S+%.dll)%+%s*(0x%x+)")
                        if mod and hex then AddSite(mod, hex) end
                        local mod2, hex2 = l:match("(%S+%.dll) %+ (0x%x+)")
                        if mod2 and hex2 then AddSite(mod2, hex2) end
                    end
                end
                if #sites == 0 then
                    Say("jxautofix: no crash sites found in the logs - nothing to queue")
                    return
                end
                local stamp = os.date and os.date("%Y%m%d_%H%M%S") or tostring(math.floor(os.clock() or 0))
                local f = io.open("crashdrop/auto_" .. stamp .. ".txt", "w")
                    or io.open("Binaries/Win64/crashdrop/auto_" .. stamp .. ".txt", "w")
                if not f then
                    Say("jxautofix: crashdrop folder not writable - run once from desktop JX_宕╂簝淇宸ュ叿")
                    return
                end
                f:write("// jxautofix " .. tostring(os.date and os.date("%Y-%m-%d %H:%M:%S") or "") .. "\r\n")
                for _, s in ipairs(sites) do f:write(s .. "\r\n") end
                f:close()
                Say(string.format("jxautofix: %d crash site(s) queued into crashdrop - guard ingests in <=5 s, interception live", #sites))
                Log("AUTOFIX| " .. #sites .. " site(s) queued (crashdrop/auto_" .. stamp .. ".txt)")
            end)
        end)
    end)
    Say("auto crash fix ready: jxautofix (canvas 宕╂簝 tab)")
end
JXCrashReader()
