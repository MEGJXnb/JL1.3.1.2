-- Core_Popup (r16 split from main.lua) - deps bridged via _G.JXEnv
local E = _G.JXEnv or {}
local Log = E.Log or function(s) print("[JX] " .. tostring(s) .. "'\n'") end
-- r25 dedup: two loader paths in main.lua; single-arm guard (duplicate sweep
-- timers raced UserWidget hiding and burned FindAllOf scans every 2 s).
if _G.JX_CORE_POPUP_LOADED then Log("Core_Popup: duplicate load skipped (r25 dedup)") return end
_G.JX_CORE_POPUP_LOADED = true
local UEHelpers = E.UEHelpers
local ModDir = E.ModDir
local JXAlive = E.JXAlive
local JXName = E.JXName
function JXPopupKiller()
    local Hide = { "WBP_ModLoader", "WBP_Main_Entry", "WBP_ModList", "WBP_ModListInformation",
                   "WBP_CustomConsole", "WBP_DebugLog", "WBP_ModButtonMenu", "WBP_Entry_" }
    local Hidden, Passes, Idle = 0, 0, 0

    local LastReskin = 0
local LastMap, LastAutoSync = "", 0

local function Sweep()
        Passes = Passes + 1
        local n = 0
        
        -- r15.2: Core BP neutering removed - it is the shell B-key input path
        pcall(function()
            local all = FindAllOf("UserWidget")
            if not all then return end
            for _, w in pairs(all) do
                if JXAlive(w) then
                    local cn = nil
                    pcall(function() cn = JXName(w:GetClass()) or "" end)
                    if cn ~= "" then
                        for _, pat in ipairs(Hide) do
                            if cn:find(pat, 1, true) then
                                local was = nil
                                pcall(function() was = w:GetVisibility() end)
                                if was ~= 2 then      
                                    pcall(function() w:SetVisibility(2) end)
                                    pcall(function() w:RemoveFromParent() end)
                                    n = n + 1
                                    Hidden = Hidden + 1
                                end
                            end
                        end
                    end
                end
            end
        end)
        if n > 0 then
            Log(string.format("POPUP| hid %d Z-framework widget(s) this pass (total %d, pass %d)", n, Hidden, Passes))
        end
        
        -- r17.4: map changed? refresh the server whitelist in the background
        pcall(function()
            local world = UEHelpers and UEHelpers.GetWorld and UEHelpers.GetWorld() or nil
            local mn = ""
            if world and world.IsValid and world:IsValid() then pcall(function() mn = world:GetName() end) end
            if mn ~= "" and mn ~= LastMap then
                local first = (LastMap == "")
                LastMap = mn
                if not first and _G.JXServerSync and (os.clock() - LastAutoSync) > 120 then
                    LastAutoSync = os.clock()
                    ExecuteWithDelay(0, function() pcall(_G.JXServerSync) end)
                    Log("POPUP| map changed to " .. mn .. " - background server whitelist refresh kicked")
                end
            end
        end)

        -- r16.2: re-skin a fresh shell instance (map travel) at most once a minute
        pcall(function()
            local w = FindFirstOf("WBP_JinxingRoot_C")
            if w and w.IsValid and w:IsValid() and _G.JXUiShell and _G.JXUiShell.Apply
                and (os.clock() - LastReskin) > 60 then
                LastReskin = os.clock()
                _G.JXUiShell.Apply("reskin")
            end
        end)

        -- r15.2: 3 s during the map-load window, then relax to 15 s (scan cost)
        Idle = 0
        local gap = (Passes <= 10) and 3000 or 15000
        ExecuteWithDelay(gap, function()
            ExecuteInGameThread(function() pcall(Sweep) end)
        end)
    end

    JXRegCmd("jpopup", function(FullCommand, Parameters, Ar)
        local sub = tostring((Parameters and Parameters[1]) or "status"):lower()
        if sub == "now" then
            ExecuteInGameThread(function()
                pcall(Sweep)
                Log(string.format("POPUP| manual sweep done (total hidden %d)", Hidden))
            end)
        else
            Log(string.format("POPUP| watchdog running: %d pass(es), %d widget(s) hidden (jpopup now to force)", Passes, Hidden))
        end
    end)

    ExecuteWithDelay(8000, function() ExecuteInGameThread(function() pcall(Sweep) end) end)
    Log("popup killer ready: hides Z-framework widgets every 12 s (jpopup now|status)")
end
JXPopupKiller()
