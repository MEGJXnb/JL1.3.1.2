#!/usr/bin/env python3
"""JX Server Validator - GitHub-hosted whitelist + identity verification.

Multi-language stack: this Python module handles server-side validation,
JSON config management, and identity generation. The Lua runtime (main.lua)
calls into this data via jxserver sync; this script manages the GitHub side.

Usage:
  python jx_server.py status          Show current whitelist state
  python jx_server.py add <name>      Add a player to the whitelist
  python jx_server.py remove <name>   Remove a player
  python jx_server.py generate-id <name>  Generate a unique player ID
  python jx_server.py validate <name> <id>  Check if name+id are authorized
  python jx_server.py sync            Force sync with GitHub (uses ghproxy)

SaveGame commands (slot JXData, GVAS format, engine save folder):
  python jx_server.py save-status     List JX save files + what is inside
  python jx_server.py save-export     Dump slot JXData to JSON (--out FILE,
                                      or --old FILE for a legacy JXAMS file)
  python jx_server.py save-import <json|->   Write JSON back to the slot
                                      (--to-old DIR also writes legacy
                                      Jxdata-<section>.sav files)

The save file layout is engine-canonical UE4.27 GVAS: the fixed 1153-byte
header template every SaveGameToSlot file on this install starts with, the
SaveGameClassName FString "BP_JXSaveGame.BP_JXSaveGame_C", tagged properties
(SchemaVersion / SavedAt / JXSections / JXPayload) and the "None" terminator
plus the engine's trailing int32. JXPayload holds the jx_save_schema.json
document as compact JSON. See JxSaveGame.lua for the Lua side.
"""
import hashlib
import json
import os
import struct
import subprocess
import sys
import time
from pathlib import Path

# Paths
MOD_DIR = Path(r"E:\SteamLibrary\steamapps\common\EscapeTheBackrooms"
               r"\EscapeTheBackrooms\Binaries\Win64\ue4ss\Mods\JinxingLoaderRT")
CONFIG_DIR = MOD_DIR / "config"
SERVER_DIR = Path(r"D:\JL_Work\JX_Server")
GITHUB_RAW = "https://raw.githubusercontent.com/MEGJXnb/JXLOADER/main/whitelist.txt"
GITHUB_MIRROR = "https://ghproxy.net/" + GITHUB_RAW
LOCAL_CACHE = CONFIG_DIR / "whitelist_remote.txt"
IDENTITY_FILE = CONFIG_DIR / "player_identities.json"
WHITELIST_FILE = CONFIG_DIR / "whitelist.txt"

ENGINE_SAVE_DIR = (Path(os.environ.get("LOCALAPPDATA", ""))
                   / "EscapeTheBackrooms" / "Saved" / "SaveGames")
SLOT_NAME = "JXData"
SLOT_CLASS = "BP_JXSaveGame.BP_JXSaveGame_C"
SCHEMA_VERSION = 1
SECTIONS = ["binds", "actors", "meshes", "entities", "players", "maps"]

# Fixed 1153-byte prefix every GVAS save this engine install writes starts
# with (verified byte-identical across the game's own saves: ACL.sav,
# MAINSAVE.sav, GameSettings_SaveSlot.sav, BlockedPlayers.sav, the mod's
# old BP_JinxingProbeSave probes). GVAS magic, save game version 2, package
# version 522, licensee 0x1B0004, engine version "++UE4+Release-4.27",
# custom version format 3, 55 custom versions.
ENGINE_TEMPLATE_HEX = (
    "47564153020000000A02000004001B00020000000000130000002B2B5545342B52656C65"
    "6173652D342E3237000300000037000000A7FBD240E54C484B755A38B09E494E88070000"
    "00FA7AF5FC8342765058E6A9B9322DA0FF44000000ED0A3111614D552EA39A67AF2C08A1"
    "C511000000F37ABB24834F4656C22D2F1FFF96AD49050000002923A576B545230941D8AE"
    "98D86A2FCF050000000769BC5FAE40C85584F1678E3FF1FF5E0100000012E426FB4D4B15"
    "1F0A557293702F1D96030000004E7CE782A5432333C5136BB4F30D31970000000022D554"
    "9CBE4F26A846072194D082B4612B000000E432D8B00D4F891FB77ECFACA24AFD360A0000"
    "002843C6E1534D2CA2868E6CA38CBD1764000000003CC15E37FB48E406F08400B57E712A"
    "2604000000ED68B0E4E94294F40BDA31A241BB462E280000003F74FCCF8044B043DF1491"
    "9373201D1725000000B5492BB0E94420BBB73204A36003E452030000005C10E4A4B549A1"
    "59C440C5A7EEDF7E5400000000C931C839DC47E65A179C449A7C8E1C3E00000000331BF0"
    "78984FEAEBEA84B4B9A25AB9CC0E0000000F383166E0434D2D27CF09805AA95669000000"
    "009F8BF812FC4A75880CD97CA629BD3A382D0000004CE75A7B104C70D2985758A95A2A21"
    "0B0D000000186929D7DD4BD61DA864E29D8438C13C030000007852A1C2FE4AE7BFFF9017"
    "6C55F71D5301000000D4A3AC6EC14CEC40ED8B86B7C58F420903000000DD75E5292746A3"
    "E076D2109DEADC2C23110000005DA643AF4749D37F8E3E739805BBC1D90F000000EC6C26"
    "6B8F4BC71ED9E40BA307FC420901000000613DF70DEA473FA2E98927B79A49410C010000"
    "0086181D60844F64ACDED316AAD6C7EA0D2F000000686308E7584C236B701B3984915E26"
    "1601000000D6BCFF9D58014F49821221E288A8923C0A000000ACD0AEF26F41FE9A7FAA64"
    "86FCD626FA010000000B1F4F17A545C6B4E82E3FB17D91FBD00A000000834AF9356C4058"
    "E2F50918A37C241096290000006EC18FB6E2421B8B5C2153B4FE448805010000000685E1"
    "B2C2CF7342BBF44EA507BA8B75010000003689F564BA421BFD897296BA4EFAD0D5010000"
    "0027D80E6F954809A68D99919CA40E189002000000E79E7F713A49B0E93291B388078138"
    "1B0800000050326854AF4899809698C88BB7F9ADFB00000000194D0C4370495471699B69"
    "87E5B090DF0F000000BD32FEAA144C9553255E6AB6DDD13210010000008EE1AF23584EE1"
    "4C52C2618DB7BE53B90B000000EAB762A43A4E99F41FECC199B2E1248204000000BDFDB5"
    "2E104DAC018FF33681DAA59333050000004F359D502F49E6F6B28549A71C633C07000000"
    "0040EB564ADC11F5107E34D392E76AC9B202000000004A8AD7974658E8B519A8BAB4467D"
    "481200000086F879551F4C3A937B08BA832FB961630200000052BE2F610B4053DA914F0D"
    "917C85B19F01000000367A23A4C941EACAF818A28FF31B685804000000753F4E80494B88"
    "70068CD6A4DCB67E3C05000000F20A68FBA34BEF59B519A8BA3D44C873020000000EB750"
    "99174E1AB40DFACCBBD67F815701000000965196ABFC08D8458D22D7B79E56AD78010000"
    "00"
)

# The mod's legacy per-map / per-section saves carry the ACL.sav header
# (1202 bytes) instead; recognized by their JXMap property, not the header.
LEGACY_KIND_SECTION = {10: "binds", 20: "actors", 21: "meshes", 22: "entities"}


# ---------------------------------------------------------------------------
# generic GVAS helpers
# ---------------------------------------------------------------------------

def gvas_fstr(b, o):
    """UE FString: int32 length (incl. null) + bytes + null; negative = UTF-16."""
    n, = struct.unpack_from("<i", b, o)
    o += 4
    if n <= 0:
        nb = -n * 2
        return b[o:o + nb - 2].decode("utf-16-le", "replace"), o + nb
    return b[o:o + n - 1].decode("utf-8", "replace"), o + n


def gvas_pack_fstr(s):
    raw = s.encode("utf-8")
    return struct.pack("<i", len(raw) + 1) + raw + b"\0"


def gvas_parse_header(b):
    """Returns dict with header fields + property start offset, or raises."""
    if b[:4] != b"GVAS":
        raise ValueError("not a GVAS file (bad magic)")
    o = 4
    sv, ue4, lic = struct.unpack_from("<iii", b, o)
    o += 12
    o += 6                                  # fixed u32 + u16 engine constants
    engver, o = gvas_fstr(b, o)
    fmt, cnt = struct.unpack_from("<ii", b, o)
    o += 8
    o += cnt * 20                           # custom versions: GUID16 + i32
    cls, o = gvas_fstr(b, o)
    return {"saveGameVersion": sv, "packageVersion": ue4, "licensee": lic,
            "engineVersion": engver, "customVersionFormat": fmt,
            "customCount": cnt, "className": cls, "propsAt": o}


def gvas_parse_props(b, o):
    """Walks tagged properties; returns (scalars dict, order list)."""
    scalars, order = {}, []
    while o + 4 <= len(b):
        name, o = gvas_fstr(b, o)
        if name == "None":
            return scalars, order
        typ, o = gvas_fstr(b, o)
        size, = struct.unpack_from("<q", b, o)
        o += 8
        voff = o
        if typ == "IntProperty":
            scalars[name] = struct.unpack_from("<i", b, voff)[0]
        elif typ == "StrProperty":
            scalars[name], _ = gvas_fstr(b, voff)
        order.append(name)
        o = voff + size
    return scalars, order


def gvas_prop(name, typ, payload):
    return (gvas_pack_fstr(name) + gvas_pack_fstr(typ)
            + struct.pack("<q", len(payload)) + payload)


def gvas_build_slot(doc, saved_at=None):
    """Builds engine-canonical JXData.sav bytes for a schema document."""
    payload = json.dumps(doc, ensure_ascii=True, separators=(",", ":"), sort_keys=True)
    saved_at = saved_at or time.strftime("%Y-%m-%d %H:%M:%S")
    body = (
        gvas_prop("SchemaVersion", "IntProperty", struct.pack("<i", doc.get("schema", SCHEMA_VERSION)))
        + gvas_prop("SavedAt", "StrProperty", gvas_pack_fstr(saved_at))
        + gvas_prop("JXSections", "StrProperty", gvas_pack_fstr(",".join(SECTIONS)))
        + gvas_prop("JXPayload", "StrProperty", gvas_pack_fstr(payload))
    )
    out = bytes.fromhex(ENGINE_TEMPLATE_HEX) + gvas_pack_fstr(SLOT_CLASS) + body
    out += gvas_pack_fstr("None") + struct.pack("<i", 0)
    return out


def gvas_parse_slot(b):
    """Parses JXData.sav bytes -> (doc, meta). Works on engine-written saves
    (no payload -> doc None) and on our fallback writes."""
    hdr = gvas_parse_header(b)
    scalars, order = gvas_parse_props(b, hdr["propsAt"])
    meta = {"className": hdr["className"], "engineVersion": hdr["engineVersion"],
            "packageVersion": hdr["packageVersion"], "props": order,
            "savedAt": scalars.get("SavedAt"), "schemaVersion": scalars.get("SchemaVersion")}
    payload = scalars.get("JXPayload")
    if not payload:
        return None, meta
    return json.loads(payload), meta


# ---------------------------------------------------------------------------
# legacy (main.lua JxamsWrite) reader - used by save-status / save-export --old
# ---------------------------------------------------------------------------

def legacy_parse(b):
    """Parses a JXAMS-<map>.sav / Jxdata-<section>.sav body."""
    anchor = b.find(gvas_pack_fstr("JXMap"))
    if anchor < 0:
        raise ValueError("not a legacy JXAMS file (no JXMap property)")
    scalars = {}
    arrays = {}
    o = anchor
    while o + 4 <= len(b):
        name, o = gvas_fstr(b, o)
        if name == "None":
            break
        typ, o = gvas_fstr(b, o)
        size, = struct.unpack_from("<q", b, o)
        o += 8
        voff = o
        if typ == "StrProperty":
            scalars[name], _ = gvas_fstr(b, voff)
        elif typ == "ArrayProperty":
            et, no = gvas_fstr(b, voff)
            n, = struct.unpack_from("<i", b, no)
            p = no + 4
            rows = []
            if et == "FloatProperty":
                for _ in range(n):
                    rows.append(struct.unpack_from("<f", b, p)[0])
                    p += 4
            elif et == "IntProperty":
                rows = list(struct.unpack_from("<%di" % n, b, p))
            elif et in ("ObjectProperty", "StrProperty"):
                for _ in range(n):
                    s, p = gvas_fstr(b, p)
                    rows.append(s)
            arrays[name] = {"elemType": et, "values": rows}
        o = voff + size
    classes = arrays.get("Classes", {}).get("values", [])
    meshes = arrays.get("Meshes", {}).get("values", [])
    kinds = arrays.get("Kinds", {}).get("values", [])
    floats = arrays.get("Data", {}).get("values", [])
    names = arrays.get("Names", {}).get("values", [])
    player = arrays.get("Player", {}).get("values", [])
    seen = scalars.get("Seen", "-")
    rows = []
    for i in range(len(classes)):
        rows.append({
            "cls": classes[i], "mesh": meshes[i] if i < len(meshes) else "",
            "name": names[i] if i < len(names) else "",
            "kind": kinds[i] if i < len(kinds) else 0,
            "x": floats[i * 4] if i * 4 < len(floats) else 0,
            "y": floats[i * 4 + 1] if i * 4 + 1 < len(floats) else 0,
            "z": floats[i * 4 + 2] if i * 4 + 2 < len(floats) else 0,
            "yaw": floats[i * 4 + 3] if i * 4 + 3 < len(floats) else 0,
        })
    return {
        "map": scalars.get("JXMap"), "rows": rows, "seen": seen,
        "stamp": seen.split("|", 1)[0] if "|" in seen else seen,
        "mpath": seen.split("|", 1)[1] if "|" in seen else "-",
        "player": {"x": player[0] if len(player) > 0 else None,
                   "y": player[1] if len(player) > 1 else None,
                   "z": player[2] if len(player) > 2 else None,
                   "yaw": player[3] if len(player) > 3 else None},
    }


def legacy_build_section(section, rows, stamp, mpath="-"):
    """Builds legacy Jxdata-<section>.sav bytes (ACL header template +
    kind-tagged rows) so this tool can hand main.lua its own format back."""
    # header: copy from any existing legacy file; else refuse (template lives
    # in main.lua's JXAMS_HEADER_HEX). We regenerate it from the constants we
    # parsed out of ACL.sav so the tool works on a fresh machine too.
    def fstr(s):
        raw = s.encode("utf-8")
        return struct.pack("<i", len(raw) + 1) + raw + b"\0"

    header = LEGACY_TEMPLATE
    kind_of = {"binds": 10, "actors": 20, "meshes": 21, "entities": 22}
    kind = kind_of[section]
    cls, msh, knd, flt, nms = [], [], [], [], []
    for r in rows:
        cls.append(fstr(r.get("cls", "")))
        msh.append(fstr(r.get("mesh", "")))
        knd.append(struct.pack("<i", int(r.get("kind", kind))))
        nms.append(fstr(r.get("name", "")))
        flt += [struct.pack("<f", float(r.get("x", 0))),
                struct.pack("<f", float(r.get("y", 0))),
                struct.pack("<f", float(r.get("z", 0))),
                struct.pack("<f", float(r.get("yaw", 0)))]
    def arr(et, vals):
        return fstr(et) + struct.pack("<i", len(vals)) + b"".join(vals)
    body = (
        gvas_prop("JXMap", "StrProperty", fstr("Jxdata/" + section))
        + gvas_prop("Classes", "ArrayProperty", arr("ObjectProperty", cls))
        + gvas_prop("Meshes", "ArrayProperty", arr("StrProperty", msh))
        + gvas_prop("Kinds", "ArrayProperty", arr("IntProperty", knd))
        + gvas_prop("Data", "ArrayProperty", arr("FloatProperty", flt))
        + gvas_prop("Names", "ArrayProperty", arr("StrProperty", nms))
        + gvas_prop("Player", "ArrayProperty", arr("FloatProperty", []))
        + gvas_prop("Seen", "StrProperty", fstr("%s|%s" % (stamp, mpath)))
        + fstr("None")
    )
    return header + body


def _load_legacy_template():
    """Legacy header template: prefer a real legacy file's first 1202 bytes
    (it must parse as GVAS with the JXMap property right after), else build
    the identical bytes from the engine template + the ACL.sav class name
    FString the mod's files carry (byte-equal to ACL.sav[0:1202])."""
    for cand in sorted((MOD_DIR / "saves").glob("JXAMS-*.sav")):
        b = cand.read_bytes()
        if b[:4] == b"GVAS" and len(b) > 1210 and b.find(gvas_pack_fstr("JXMap")) == 1202:
            return b[:1202]
    return (bytes.fromhex(ENGINE_TEMPLATE_HEX)
            + gvas_pack_fstr("/Game/Mods/Box/Blueprint/SL_Actor.SL_Actor_C"))


LEGACY_TEMPLATE = _load_legacy_template()


# ---------------------------------------------------------------------------
# doc <-> legacy rows adapters (mirror of JxSaveGame.lua)
# ---------------------------------------------------------------------------

def doc_from_legacy(leg):
    """Legacy parse result -> (section name, section dict) or maps metadata."""
    map_key = leg["map"] or ""
    if map_key.startswith("Jxdata/"):
        section = map_key.split("/", 1)[1]
        kind = leg["rows"][0]["kind"] if leg["rows"] else \
            {"binds": 10, "actors": 20, "meshes": 21, "entities": 22}.get(section, 0)
        out = []
        if kind == 10:
            for r in leg["rows"]:
                out.append({"id": r["name"], "label": r["cls"], "key": r["mesh"], "mods": int(r["x"])})
        elif kind == 20:
            out = [{"cls": r["cls"]} for r in leg["rows"]]
        elif kind == 21:
            out = [{"path": r["mesh"], "count": int(r["x"])} for r in leg["rows"]]
        elif kind == 22:
            out = [{"name": r["name"], "path": r["cls"]} for r in leg["rows"]]
        else:
            raise ValueError("unknown legacy row kind %r" % kind)
        return section, {"version": SCHEMA_VERSION, "rows": out,
                         "source": "import:" + map_key}
    return "maps", {"version": SCHEMA_VERSION, "rows": [
        {"map": map_key, "stamp": leg["stamp"], "rows": len(leg["rows"]), "mpath": leg["mpath"]},
    ]}


def legacy_rows_from_doc(section, sec):
    """Section dict -> legacy rows (for save-import --to-old)."""
    out = []
    if section == "binds":
        for r in sec.get("rows", []):
            out.append({"cls": r.get("label", r.get("id", "")), "mesh": r.get("key", ""),
                        "name": r.get("id", ""), "kind": 10,
                        "x": r.get("mods", 0), "y": 0, "z": 0, "yaw": 0})
    elif section == "actors":
        for r in sec.get("rows", []):
            out.append({"cls": r.get("cls", ""), "mesh": "", "name": "actor",
                        "kind": 20, "x": 0, "y": 0, "z": 0, "yaw": 0})
    elif section == "meshes":
        for r in sec.get("rows", []):
            out.append({"cls": "/Script/Engine.StaticMeshActor", "mesh": r.get("path", ""),
                        "name": "mesh", "kind": 21, "x": r.get("count", 0), "y": 0, "z": 0, "yaw": 0})
    elif section == "entities":
        for r in sec.get("rows", []):
            out.append({"cls": r.get("path", ""), "mesh": "", "name": r.get("name", ""),
                        "kind": 22, "x": 0, "y": 0, "z": 0, "yaw": 0})
    return out


# ---------------------------------------------------------------------------
# save commands
# ---------------------------------------------------------------------------

def slot_path():
    return ENGINE_SAVE_DIR / (SLOT_NAME + ".sav")


def describe_gvas(path):
    b = path.read_bytes()
    if b[:4] != b"GVAS":
        return "  %-38s %8d  magic=%r (custom format)" % (path.name, len(b), b[:4])
    hdr = gvas_parse_header(b)
    doc, meta = gvas_parse_slot(b)
    flavor = "fallback (JX payload)" if doc else "engine save (no JX payload)"
    line = "  %-38s %8d  GVAS sv=%d %s" % (path.name, len(b), hdr["saveGameVersion"], flavor)
    extra = []
    if doc:
        counts = ", ".join("%s=%d" % (s, len(doc.get("sections", {}).get(s, {}).get("rows", [])))
                           for s in SECTIONS if s in doc.get("sections", {}))
        extra.append("schema=%s" % doc.get("schema"))
        extra.append("saved=%s" % doc.get("savedAt", meta.get("savedAt")))
        if counts:
            extra.append(counts)
    else:
        extra.append("class=%s" % hdr["className"])
    if extra:
        line += "\n      " + "  ".join(extra)
    return line


def describe_legacy(path):
    b = path.read_bytes()
    try:
        leg = legacy_parse(b)
    except Exception as why:
        return "  %-38s %8d  unreadable: %s" % (path.name, len(b), why)
    return ("  %-38s %8d  map=%-22s rows=%-5d seen=%s"
            % (path.name, len(b), str(leg["map"]), len(leg["rows"]), leg["seen"]))


def cmd_save_status():
    print("=== JX SaveGame status ===")
    print("Engine save folder: %s" % ENGINE_SAVE_DIR)
    if ENGINE_SAVE_DIR.exists():
        targets = sorted([p for p in ENGINE_SAVE_DIR.glob("*.sav")
                          if p.name.upper().startswith(("JX", "JINX"))])
        slot = slot_path()
        if not targets and not slot.exists():
            print("  no JX saves yet (the mod writes slot %s on first save)" % SLOT_NAME)
        for p in targets:
            try:
                print(describe_gvas(p))
            except Exception as why:
                print("  %-38s %8d  unreadable: %s" % (p.name, p.stat().st_size, why))
        for p in sorted(ENGINE_SAVE_DIR.glob("JXData.sav.*")):
            print("  %-38s %8d  (backup)" % (p.name, p.stat().st_size))
    else:
        print("  folder does not exist (game never saved)")
    print("Mod legacy saves: %s" % (MOD_DIR / "saves"))
    legacy_dir = MOD_DIR / "saves"
    if legacy_dir.exists():
        for p in sorted(legacy_dir.glob("JXAMS-*.sav")):
            print(describe_legacy(p))
        for p in sorted(legacy_dir.glob("Jxdata-*.sav")):
            print(describe_legacy(p))
    else:
        print("  folder does not exist")
    return True


def cmd_save_export(argv):
    out_path = None
    old_path = None
    args = list(argv)
    while args:
        a = args.pop(0)
        if a == "--out" and args:
            out_path = Path(args.pop(0))
        elif a == "--old" and args:
            old_path = Path(args.pop(0))
        else:
            print("unknown option: %s" % a)
            return False

    if old_path:
        leg = legacy_parse(old_path.read_bytes())
        section, sec = doc_from_legacy(leg)
        data = {"format": "legacy-jxams", "legacyFile": str(old_path), **leg}
        title = "legacy %s" % old_path.name
    else:
        sp = slot_path()
        if not sp.exists():
            print("no slot file at %s (nothing to export)" % sp)
            return False
        doc, meta = gvas_parse_slot(sp.read_bytes())
        if doc is None:
            print("slot exists but carries no JX payload (class=%s, props=%s)"
                  % (meta["className"], meta["props"]))
            return False
        data = doc
        title = "slot %s" % sp

    text = json.dumps(data, ensure_ascii=True, indent=2, sort_keys=True)
    if out_path:
        out_path.write_text(text, encoding="ascii")
        print("exported %s -> %s (%d bytes)" % (title, out_path, len(text)))
    else:
        print(text)
    return True


def cmd_save_import(argv):
    if not argv:
        print("usage: jx_server.py save-import <json-file|-> [--to-old DIR]")
        return False
    src = argv[0]
    to_old = None
    args = list(argv[1:])
    while args:
        a = args.pop(0)
        if a == "--to-old" and args:
            to_old = Path(args.pop(0))
        else:
            print("unknown option: %s" % a)
            return False

    if src == "-":
        doc = json.loads(sys.stdin.read())
    else:
        doc = json.loads(Path(src).read_text(encoding="utf-8"))

    if doc.get("schema") != SCHEMA_VERSION:
        print("REFUSED: document schema %r != %d (wrong file or needs a newer tool)"
              % (doc.get("schema"), SCHEMA_VERSION))
        return False
    if not isinstance(doc.get("sections"), dict):
        print("REFUSED: sections missing")
        return False

    sp = slot_path()
    sp.parent.mkdir(parents=True, exist_ok=True)
    if sp.exists():
        b = sp.read_bytes()
        ours = False
        if b[:4] == b"GVAS":
            try:
                ours = "BP_JXSaveGame_C" in gvas_parse_header(b)["className"]
            except Exception:
                ours = False
        if not ours:
            backup = sp.with_name(sp.name + ".jx-backup")
            backup.write_bytes(b)
            print("backed up the previous (foreign) slot file to %s" % backup)
    saved_at = time.strftime("%Y-%m-%d %H:%M:%S")
    sp.write_bytes(gvas_build_slot(doc, saved_at))
    print("imported -> %s (%d bytes, schema=%s, saved=%s)"
          % (sp, sp.stat().st_size, doc["schema"], saved_at))

    if to_old:
        to_old.mkdir(parents=True, exist_ok=True)
        for section in ("binds", "actors", "meshes", "entities"):
            rows = legacy_rows_from_doc(section, doc["sections"].get(section, {}))
            if not rows and section not in doc["sections"]:
                continue
            data = legacy_build_section(section, rows, saved_at)
            out = to_old / ("Jxdata-%s.sav" % section)
            out.write_bytes(data)
            print("legacy -> %s (%d rows, %d bytes)" % (out, len(rows), len(data)))
    return True


def ensure_dirs():
    """Create required directories if they don't exist."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    SERVER_DIR.mkdir(parents=True, exist_ok=True)


def fetch_whitelist(use_mirror=False):
    """Download whitelist from GitHub, with mirror fallback."""
    url = GITHUB_MIRROR if use_mirror else GITHUB_RAW
    curl = r"C:\Windows\System32\curl.exe"
    if not Path(curl).exists():
        curl = "curl"
    cache = str(LOCAL_CACHE).replace("/", "\\")

    result = subprocess.run(
        [curl, "-4", "-s", "-m", "10", "-L", url, "-o", cache],
        capture_output=True, timeout=15
    )
    return result.returncode == 0


def parse_whitelist(path=LOCAL_CACHE):
    """Parse whitelist file, return set of lowercase names."""
    if not path.exists():
        return set()
    names = set()
    for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
        line = line.strip()
        if line and not line.startswith((";", "#")):
            names.add(line.lower())
    return names


def generate_player_id(name, salt=None):
    """Generate a unique, deterministic player ID from name + secret salt.

    The ID is SHA-256 of (lowercase name + salt), first 16 hex chars.
    Deterministic: same name + same salt = same ID, so it survives restarts.
    """
    if salt is None:
        salt_file = CONFIG_DIR / "jx_salt.key"
        if salt_file.exists():
            salt = salt_file.read_text(encoding="ascii").strip()
        else:
            import secrets
            salt = secrets.token_hex(32)
            salt_file.parent.mkdir(parents=True, exist_ok=True)
            salt_file.write_text(salt, encoding="ascii")

    raw = f"{name.lower()}:{salt}".encode("utf-8")
    return hashlib.sha256(raw).hexdigest()[:16].upper()


def load_identities():
    """Load existing identity database."""
    if IDENTITY_FILE.exists():
        try:
            return json.loads(IDENTITY_FILE.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, UnicodeDecodeError):
            pass
    return {"players": {}, "generated": time.strftime("%Y-%m-%d %H:%M:%S")}


def save_identities(data):
    """Persist identity database."""
    ensure_dirs()
    IDENTITY_FILE.write_text(
        json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8"
    )


def cmd_status():
    """Show current whitelist and identity state."""
    print("=== JX Server Status ===")
    print(f"GitHub URL: {GITHUB_RAW}")

    # Local whitelist
    if WHITELIST_FILE.exists():
        local = parse_whitelist(WHITELIST_FILE)
        print(f"Local whitelist: {len(local)} name(s)")
        for n in sorted(local):
            print(f"  - {n}")
    else:
        print("Local whitelist: not written yet")

    # Cached remote
    if LOCAL_CACHE.exists():
        remote = parse_whitelist()
        print(f"Remote cache: {len(remote)} name(s)")
    else:
        print("Remote cache: empty (run 'sync' to fetch)")

    # Identities
    ids = load_identities()
    print(f"Known identities: {len(ids.get('players', {}))}")
    for name, info in ids.get("players", {}).items():
        print(f"  {name}: ID={info.get('id', '?')} verified={info.get('verified', False)}")

    return True


def cmd_add(name):
    """Add a player to the local whitelist (also updates GitHub instructions)."""
    ensure_dirs()
    name = name.strip()
    if not name:
        print("ERROR: name cannot be empty")
        return False

    current = set()
    if WHITELIST_FILE.exists():
        for line in WHITELIST_FILE.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith((";", "#")):
                current.add(line)

    if name.lower() in {c.lower() for c in current}:
        print(f"'{name}' is already whitelisted")
        return True

    with open(WHITELIST_FILE, "a", encoding="utf-8") as f:
        f.write(name + "\n")
    print(f"Added '{name}' to local whitelist")
    print("NOTE: To update GitHub, edit whitelist.txt in your repo and run 'jxserver sync' in game")
    return True


def cmd_remove(name):
    """Remove a player from the local whitelist."""
    if not WHITELIST_FILE.exists():
        print("No local whitelist file")
        return False

    name_lower = name.strip().lower()
    lines = WHITELIST_FILE.read_text(encoding="utf-8").splitlines()
    kept = [l for l in lines if l.strip().lower() != name_lower]
    if len(kept) == len(lines):
        print(f"'{name}' not found in whitelist")
        return False

    WHITELIST_FILE.write_text("\n".join(kept) + "\n", encoding="utf-8")
    print(f"Removed '{name}' from local whitelist")
    return True


def cmd_generate_id(name):
    """Generate a unique player ID for the given name."""
    name = name.strip()
    if not name:
        print("ERROR: name cannot be empty")
        return False

    pid = generate_player_id(name)
    ids = load_identities()

    if name.lower() not in ids["players"]:
        ids["players"][name.lower()] = {
            "display_name": name,
            "id": pid,
            "created": time.strftime("%Y-%m-%d %H:%M:%S"),
            "verified": False,
        }
        save_identities(ids)

    info = ids["players"][name.lower()]
    print(f"Player: {name}")
    print(f"ID: {info['id']}")
    print(f"Created: {info.get('created', '?')}")
    return True


def cmd_validate(name, player_id):
    """Check if name+ID pair is authorized."""
    name = name.strip()
    expected = generate_player_id(name)

    if player_id.strip().upper() != expected:
        print(f"INVALID: ID mismatch for '{name}'")
        print(f"  Expected: {expected}")
        print(f"  Got:      {player_id}")
        return False

    # Check whitelist
    wl = parse_whitelist(WHITELIST_FILE)
    if name.lower() not in wl:
        print(f"DENIED: '{name}' is not whitelisted")
        return False

    # Mark verified
    ids = load_identities()
    if name.lower() in ids["players"]:
        ids["players"][name.lower()]["verified"] = True
        ids["players"][name.lower()]["last_seen"] = time.strftime("%Y-%m-%d %H:%M:%S")
        save_identities(ids)

    print(f"VERIFIED: '{name}' ({expected})")
    return True


def cmd_sync():
    """Force sync whitelist from GitHub."""
    print("Syncing from GitHub (direct)...")
    if fetch_whitelist(use_mirror=False):
        names = parse_whitelist()
        if names:
            print(f"Direct sync: {len(names)} name(s) fetched")
            for n in sorted(names):
                print(f"  - {n}")
            return True

    print("Direct failed, trying mirror...")
    if fetch_whitelist(use_mirror=True):
        names = parse_whitelist()
        if names:
            print(f"Mirror sync: {len(names)} name(s) fetched")
            return True

    print("Both channels failed")
    return False


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)

    cmd = sys.argv[1].lower()
    if cmd == "status":
        ok = cmd_status()
    elif cmd == "add" and len(sys.argv) > 2:
        ok = cmd_add(sys.argv[2])
    elif cmd == "remove" and len(sys.argv) > 2:
        ok = cmd_remove(sys.argv[2])
    elif cmd == "generate-id" and len(sys.argv) > 2:
        ok = cmd_generate_id(sys.argv[2])
    elif cmd == "validate" and len(sys.argv) > 3:
        ok = cmd_validate(sys.argv[2], sys.argv[3])
    elif cmd == "sync":
        ok = cmd_sync()
    elif cmd == "save-status":
        ok = cmd_save_status()
    elif cmd == "save-export":
        ok = cmd_save_export(sys.argv[2:])
    elif cmd == "save-import" and len(sys.argv) > 2:
        ok = cmd_save_import(sys.argv[2:])
    else:
        print(f"Unknown command: {cmd}")
        print(__doc__)
        ok = False

    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
