
local FS = {
    version  = "1.0",
    on       = false,
    samples  = {},
    maxN     = 30,      
    lastLine = "",
    
    x        = 26,
    y        = 28,      
    scale    = 1.0,
}

local function Log(s) print("[JxFrameStats] " .. tostring(s)) end
local function Say(s)
    if type(JX) == "table" and type(JX.Say) == "function" then JX.Say(s) else Log(s) end
end

local function now()
    local t = nil
    pcall(function()
        local w = FindFirstOf("World")
        if w and w:IsValid() then
            local ok, v = pcall(function() return w:GetRealTimeSeconds() end)
            if ok and type(v) == "number" and v > 0 then t = v end
        end
    end)
    return t or os.time()
end

local lastT = nil
local function sample()
    local t = now()
    local dt = nil
    if lastT and t > lastT and (t - lastT) < 10 then dt = t - lastT end
    lastT = t
    if not dt then return end
    FS.samples[#FS.samples + 1] = dt
    if #FS.samples > FS.maxN then table.remove(FS.samples, 1) end
end

local function avgMs()
    local n, s = #FS.samples, 0
    if n < 5 then return nil end
    for _, v in ipairs(FS.samples) do s = s + v end
    return (s / n) * 1000
end

local KSLC = nil
local function kslCDO()
    if KSLC == nil or (KSLC.IsValid and not KSLC:IsValid()) then
        local k = nil
        pcall(function() k = StaticFindObject("/Script/Engine.Default__KismetSystemLibrary") end)
        KSLC = (k and k:IsValid()) and k or false
    end
    return KSLC or nil
end

local function line()
    local ms = avgMs()
    local fps = ms and math.floor(1000 / ms) or 0
    local sp = nil
    pcall(function()
        local k = kslCDO()
        if k then
            local ok, v = pcall(function() return k:GetConsoleVariableFloatValue("r.ScreenPercentage") end)
            if ok and type(v) == "number" then sp = v end
        end
    end)
    local gcKb = 0
    pcall(function() gcKb = math.floor(collectgarbage("count")) end)
    local cap = (_G.JxFrameStats_CapFPS and (" cap " .. _G.JxFrameStats_CapFPS)) or ""
    return string.format("JX %d fps %.1fms | SP %s%% | Lua %dKB%s",
        fps, ms or 0, sp and string.format("%.0f", sp) or "?", gcKb, cap)
end

local COL = { R = 1.0, G = 0.9, B = 0.2, A = 0.9 }   
local SHADOW = { R = 0, G = 0, B = 0, A = 0.5 }

local function draw(hud)
    if not FS.on then return end
    sample()
    local ms = avgMs()
    if not ms then return end                       
    local ok = pcall(function()
        FS.lastLine = line()
        
        hud:DrawText(FS.lastLine, SHADOW, FS.x + 1, FS.y + 1, nil, FS.scale, false)
        hud:DrawText(FS.lastLine, COL, FS.x, FS.y, nil, FS.scale, false)
    end)
    if not ok then FS.on = false; Log("draw failed -- meter off (see console above)") end
end

local function attach()
    local JP = _G.JxPanels
    if type(JP) ~= "table" or type(JP.OnRender) ~= "function" then
        return false, "JxPanels not loaded (F8 canvas absent)"
    end
    if JP.jfstatsWrapped then return true end       
    local prev = JP.OnRender
    JP.OnRender = function(hud)
        pcall(function() prev(hud) end)
        pcall(function() draw(hud) end)
    end
    JP.jfstatsWrapped = true
    return true
end

if type(JXRegCmd) == "function" then
    JXRegCmd("jfstats", function(FullCommand, Parameters, Ar)
        local sub = ((Parameters and Parameters[1]) or ""):lower()
        if sub == "console" then
            Say(line())
            return true
        end
        if sub == "reset" then
            FS.samples = {}
            Say("frame window cleared")
            return true
        end
        
        local ok, why = attach()
        if not ok then
            Say("meter needs the canvas hook: " .. tostring(why) .. " -- press F8 once, then jfstats again")
            return true
        end
        FS.on = not FS.on
        FS.samples = {}
        Say("frame meter " .. (FS.on and "ON (top-left, yellow)" or "OFF"))
        return true
    end)
end

Log("v" .. FS.version .. " loaded -- 'jfstats' toggles the on-screen meter; 'jfstats console' prints once")
_G.JxFrameStats = FS
return FS
