
local JxSaveGame = {
    SchemaVersion = 1,
    ModuleVersion = "JxSaveGame 1.0",
    SlotName      = "JXData",
    
    SaveClassPath = "/Game/Mods/JinxingLoaderRT/SaveGames/BP_JXSaveGame",
    SaveClassName = "BP_JXSaveGame.BP_JXSaveGame_C",
    
    PayloadProps  = { "SchemaVersion", "SavedAt", "JXSections", "JXPayload" },
    SectionVersion = 1,
}

JxSaveGame.Sections = { "binds", "actors", "meshes", "entities", "players", "maps" }

local function I32(n)
    n = math.floor(tonumber(n) or 0)
    if n > 2147483647 then n = 2147483647 elseif n < -2147483648 then n = -2147483648 end
    return string.pack("<i4", n)
end
local function I64(n)
    n = math.floor(tonumber(n) or 0)
    if n > 9223372036854775807 then n = 9223372036854775807
    elseif n < -9223372036854775808 then n = -9223372036854775808 end
    return string.pack("<i8", n)
end
local function F32(n) return string.pack("<f", tonumber(n) or 0) end

local function FStr(s) s = tostring(s or ""); return I32(#s + 1) .. s .. "\0" end

local function ReadAllBytes(path)
    local f = io.open(path, "rb"); if not f then return nil end
    local d = f:read("*a"); f:close(); return d
end

local function EnsureDir(path)
    
    local p = tostring(path):gsub("/", "\\")
    if p:sub(-1) ~= "\\" then p = p .. "\\" end
    local probe = io.open(p .. "__jx_probe.tmp", "w")
    if probe then
        probe:close()
        os.remove(p .. "__jx_probe.tmp")
        return true
    end
    pcall(function() os.execute('if not exist "' .. p .. '" mkdir "' .. p .. '" >nul 2>nul') end)
    probe = io.open(p .. "__jx_probe.tmp", "w")
    if probe then
        probe:close()
        os.remove(p .. "__jx_probe.tmp")
        return true
    end
    return false
end

local function WriteAllBytes(path, d)
    if type(path) ~= "string" or path == "" then return false end
    if type(d) ~= "string" then return false end
    local parent = path:gsub("\\", "/"):match("^(.*)/[^/]+$")
    if parent and parent ~= "" then EnsureDir(parent) end
    local f = io.open(path, "wb")
    if not f then return false end
    local ok = pcall(function() f:write(d) end)
    f:close()
    if not ok then return false end
    
    local back = ReadAllBytes(path)
    return back ~= nil and #back == #d
end

local function RdFStr(b, o)
    if o + 4 > #b then return nil, o end
    local len = string.unpack("<i4", b, o); o = o + 4
    if len <= 0 or o + len > #b then return nil, o + math.max(len, 0) end
    return b:sub(o, o + len - 2), o + len
end

local Json = {}

local ESCAPE_MAP = { ['"'] = '\\"', ['\\'] = "\\\\", ['\b'] = "\\b",
                     ['\f'] = "\\f", ['\n'] = "\\n", ['\r'] = "\\r", ['\t'] = "\\t" }

local function jsonQuote(s)
    return '"' .. s:gsub('[%c"\\]', function(c)
        if ESCAPE_MAP[c] then return ESCAPE_MAP[c] end
        return string.format("\\u%04x", string.byte(c))
    end) .. '"'
end

local function jsonEncode(v, out)
    local t = type(v)
    if t == "nil" then out[#out + 1] = "null"
    elseif t == "boolean" then out[#out + 1] = tostring(v)
    elseif t == "number" then
        if v ~= v or v == math.huge or v == -math.huge then
            out[#out + 1] = "null"
        elseif math.floor(v) == v and math.abs(v) < 2 ^ 53 then
            out[#out + 1] = string.format("%d", v)
        else
            out[#out + 1] = string.format("%.14g", v)
        end
    elseif t == "string" then out[#out + 1] = jsonQuote(v)
    elseif t == "table" then
        local n = 0
        for _ in pairs(v) do n = n + 1 end
        if n == #v then                       
            out[#out + 1] = "["
            for i = 1, #v do
                if i > 1 then out[#out + 1] = "," end
                jsonEncode(v[i], out)
            end
            out[#out + 1] = "]"
        else                                  
            local keys = {}
            for k in pairs(v) do keys[#keys + 1] = tostring(k) end
            table.sort(keys)
            out[#out + 1] = "{"
            for i, k in ipairs(keys) do
                if i > 1 then out[#out + 1] = "," end
                out[#out + 1] = jsonQuote(k) .. ":"
                jsonEncode(v[k], out)
            end
            out[#out + 1] = "}"
        end
    else error("json: cannot encode a " .. t) end
end

function Json.encode(v) local out = {}; jsonEncode(v, out); return table.concat(out) end

function Json.decode(s)
    local pos = 1
    local function fail(what) error("json: " .. what .. " at " .. pos) end
    local function skip() pos = s:find("[^ \t\r\n]", pos) or #s + 1 end
    local parseValue

    local function parseString()
        pos = pos + 1                       
        local buf = {}
        while true do
            local c = s:sub(pos, pos)
            if c == "" then fail("unterminated string") end
            if c == '"' then pos = pos + 1; break end
            if c == "\\" then
                local e = s:sub(pos + 1, pos + 1)
                local simple = { ['"'] = '"', ["\\"] = "\\", ["/"] = "/",
                                 b = "\b", f = "\f", n = "\n", r = "\r", t = "\t" }
                if simple[e] then buf[#buf + 1] = simple[e]; pos = pos + 2
                elseif e == "u" then
                    local hex = s:sub(pos + 2, pos + 5)
                    if not hex:match("^%x%x%x%x$") then fail("bad \\u escape") end
                    local code = tonumber(hex, 16)
                    if utf8 and utf8.char then
                        buf[#buf + 1] = utf8.char(code)
                    else
                        buf[#buf + 1] = "?"
                    end
                    pos = pos + 6
                else fail("bad escape \\" .. e) end
            else buf[#buf + 1] = c; pos = pos + 1 end
        end
        return table.concat(buf)
    end

    local function parseNumber()
        local a, b = s:find("^%-?%d+%.?%d*[eE]?[-+]?%d*", pos)
        if not a then fail("bad number") end
        local num = tonumber(s:sub(a, b)); pos = b + 1
        return num
    end

    parseValue = function()
        skip()
        local c = s:sub(pos, pos)
        if c == "{" then
            local obj = {}
            pos = pos + 1; skip()
            if s:sub(pos, pos) == "}" then pos = pos + 1; return obj end
            while true do
                skip()
                if s:sub(pos, pos) ~= '"' then fail("expected key") end
                local key = parseString()
                skip()
                if s:sub(pos, pos) ~= ":" then fail("expected :") end
                pos = pos + 1
                obj[key] = parseValue(); skip()
                local d = s:sub(pos, pos)
                if d == "," then pos = pos + 1
                elseif d == "}" then pos = pos + 1; return obj
                else fail("expected , or }") end
            end
        elseif c == "[" then
            local arr = {}
            pos = pos + 1; skip()
            if s:sub(pos, pos) == "]" then pos = pos + 1; return arr end
            while true do
                arr[#arr + 1] = parseValue(); skip()
                local d = s:sub(pos, pos)
                if d == "," then pos = pos + 1
                elseif d == "]" then pos = pos + 1; return arr
                else fail("expected , or ]") end
            end
        elseif c == '"' then return parseString()
        elseif s:sub(pos, pos + 3) == "true" then pos = pos + 4; return true
        elseif s:sub(pos, pos + 4) == "false" then pos = pos + 5; return false
        elseif s:sub(pos, pos + 3) == "null" then pos = pos + 4; return nil
        elseif c == "-" or (c >= "0" and c <= "9") then return parseNumber()
        else fail("unexpected character '" .. c .. "'") end
    end

    local v = parseValue()
    skip()
    if pos <= #s then fail("trailing data") end
    return v
end

JxSaveGame.Json = Json

local function EngineSavesDir()
    local lad = os.getenv and os.getenv("LOCALAPPDATA") or nil
    if lad and lad ~= "" then
        return lad:gsub("\\", "/") .. "/EscapeTheBackrooms/Saved/SaveGames/"
    end
    return nil
end

function JxSaveGame.EngineSavesDir() return EngineSavesDir() end

function JxSaveGame.SlotPath(overrideDir)
    local dir = overrideDir or EngineSavesDir()
    if dir then return dir .. JxSaveGame.SlotName .. ".sav", dir end
    return nil, nil
end

function JxSaveGame.Stamp()
    return os.date("%Y-%m-%d %H:%M:%S")
end

local function Prop(name, typ, payload)
    return FStr(name) .. FStr(typ) .. I64(#payload) .. payload
end

local function PropInt(name, n) return Prop(name, "IntProperty", I32(n)) end
local function PropStr(name, s) return Prop(name, "StrProperty", FStr(s)) end

local function WalkProps(b, o, cb)
    for _ = 1, 1024 do
        local name, no = RdFStr(b, o); if not name then return nil end
        if name == "None" then return no end
        local typ, no2 = RdFStr(b, no); if not typ then return nil end
        local size = string.unpack("<i8", b, no2)
        local voff = no2 + 8
        cb(name, typ, size, voff)
        o = voff + size
    end
    return nil
end

local ENGINE_TEMPLATE_HEX =
    "47564153020000000A02000004001B00020000000000130000002B2B5545342B52656C656173652D342E3237000300000037000000A7FBD240E54C484B755A38B09E494E8807000000FA7AF5FC8342765058E6A9B9322DA0FF44000000ED0A3111614D552EA39A67AF2C08A1C511000000F37ABB24834F4656C22D2F1FFF96AD49050000002923A576B545230941D8AE98D86A2FCF050000000769BC5FAE40C85584F1678E3FF1FF5E0100000012E426FB4D4B151F0A557293702F1D96030000004E7CE782A5432333C5136BB4F30D31970000000022D5549CBE4F26A846072194D082B4612B000000E432D8B00D4F891FB77ECFACA24AFD360A0000002843C6E1534D2CA2868E6CA38CBD1764000000003CC15E37FB48E406F08400B57E712A2604000000ED68B0E4E94294F40BDA31A241BB462E280000003F74FCCF8044B043DF14919373201D1725000000B5492BB0E94420BBB73204A36003E452030000005C10E4A4B549A159C440C5A7EEDF7E5400000000C931C839DC47E65A179C449A7C8E1C3E00000000331BF078984FEAEBEA84B4B9A25AB9CC0E0000000F383166E0434D2D27CF09805AA95669000000009F8BF812FC4A75880CD97CA629BD3A382D0000004CE75A7B104C70D2985758A95A2A210B0D000000186929D7DD4BD61DA864E29D8438C13C030000007852A1C2FE4AE7BFFF90176C55F71D5301000000D4A3AC6EC14CEC40ED8B86B7C58F420903000000DD75E5292746A3E076D2109DEADC2C23110000005DA643AF4749D37F8E3E739805BBC1D90F000000EC6C266B8F4BC71ED9E40BA307FC420901000000613DF70DEA473FA2E98927B79A49410C0100000086181D60844F64ACDED316AAD6C7EA0D2F000000686308E7584C236B701B3984915E261601000000D6BCFF9D58014F49821221E288A8923C0A000000ACD0AEF26F41FE9A7FAA6486FCD626FA010000000B1F4F17A545C6B4E82E3FB17D91FBD00A000000834AF9356C4058E2F50918A37C241096290000006EC18FB6E2421B8B5C2153B4FE448805010000000685E1B2C2CF7342BBF44EA507BA8B75010000003689F564BA421BFD897296BA4EFAD0D50100000027D80E6F954809A68D99919CA40E189002000000E79E7F713A49B0E93291B3880781381B0800000050326854AF4899809698C88BB7F9ADFB00000000194D0C4370495471699B6987E5B090DF0F000000BD32FEAA144C9553255E6AB6DDD13210010000008EE1AF23584EE14C52C2618DB7BE53B90B000000EAB762A43A4E99F41FECC199B2E1248204000000BDFDB52E104DAC018FF33681DAA59333050000004F359D502F49E6F6B28549A71C633C070000000040EB564ADC11F5107E34D392E76AC9B202000000004A8AD7974658E8B519A8BAB4467D481200000086F879551F4C3A937B08BA832FB961630200000052BE2F610B4053DA914F0D917C85B19F01000000367A23A4C941EACAF818A28FF31B685804000000753F4E80494B8870068CD6A4DCB67E3C05000000F20A68FBA34BEF59B519A8BA3D44C873020000000EB75099174E1AB40DFACCBBD67F815701000000965196ABFC08D8458D22D7B79E56AD7801000000"

local function EngineTemplate()
    return (ENGINE_TEMPLATE_HEX:gsub("%x%x", function(cc)
        return string.char(tonumber(cc, 16))
    end))
end

function JxSaveGame.BuildSlotBytes(doc)
    local payload = Json.encode(doc)
    local sects = table.concat(JxSaveGame.Sections, ",")
    local body =
        PropInt("SchemaVersion", doc.schema or JxSaveGame.SchemaVersion) ..
        PropStr("SavedAt", doc.savedAt or JxSaveGame.Stamp()) ..
        PropStr("JXSections", sects) ..
        PropStr("JXPayload", payload)
    
    return EngineTemplate()
        .. FStr(JxSaveGame.SaveClassName)
        .. body
        .. FStr("None") .. I32(0)
end

function JxSaveGame.ParseGvasHeader(b)
    if not b or #b < 32 or b:sub(1, 4) ~= "GVAS" then
        return nil, "not a GVAS file (bad magic)"
    end
    local ok, res = pcall(function()
        local o = 5
        local sv, ue4, lic = string.unpack("<i4i4i4", b, o); o = o + 12
        o = o + 6                            
        local engver, no = RdFStr(b, o); o = no
        local fmt = string.unpack("<i4", b, o); o = o + 4
        local cnt = string.unpack("<i4", b, o); o = o + 4
        o = o + cnt * 20                     
        local cls, no2 = RdFStr(b, o)
        return { saveGameVersion = sv, packageVersion = ue4, licensee = lic,
                 engineVersion = engver, customVersionFormat = fmt,
                 customCount = cnt, className = cls, headerEnd = no2 }
    end)
    if not ok then return nil, tostring(res) end
    return res
end

local function ParseProps(b, o)
    local scalars, arrays, order = {}, {}, {}
    local at = WalkProps(b, o, function(name, typ, size, voff)
        order[#order + 1] = name
        if typ == "IntProperty" then
            scalars[name] = string.unpack("<i4", b, voff)
        elseif typ == "StrProperty" then
            scalars[name] = RdFStr(b, voff)
        elseif typ == "ArrayProperty" then
            local et, no = RdFStr(b, voff)
            arrays[name] = { elemType = et, offset = no, size = size }
        end
    end)
    return scalars, arrays, order, at
end

function JxSaveGame.ParseSlotBytes(b)
    local hdr, why = JxSaveGame.ParseGvasHeader(b)
    if not hdr then return nil, why end
    local okP, scalars, arrays = pcall(ParseProps, b, hdr.headerEnd)
    if not okP then return nil, "broken property body: " .. tostring(scalars) end
    local info = {
        flavor = scalars.JXPayload and "fallback" or "engine",
        className = hdr.className,
        engineVersion = hdr.engineVersion,
        saveGameVersion = hdr.saveGameVersion,
        packageVersion = hdr.packageVersion,
        savedAt = scalars.SavedAt,
        schemaVersion = scalars.SchemaVersion,
        sections = scalars.JXSections,
    }
    if not scalars.JXPayload then
        
        return { schema = nil, module = nil, savedAt = nil,
                 sections = {}, _external = true }, info
    end
    local okJ, doc = pcall(Json.decode, scalars.JXPayload)
    if not okJ then return nil, "payload JSON broken: " .. tostring(doc) end
    return doc, info
end

local OLD_HEADER_HEX =
    "47564153020000000a02000004001b00020000000000130000002b2b5545342b52656c65"
    ..
    "6173652d342e3237000300000037000000a7fbd240e54c484b755a38b09e494e88070000"
    ..
    "00fa7af5fc8342765058e6a9b9322da0ff44000000ed0a3111614d552ea39a67af2c08a1"
    ..
    "c511000000f37abb24834f4656c22d2f1fff96ad49050000002923a576b545230941d8ae"
    ..
    "98d86a2fcf050000000769bc5fae40c85584f1678e3ff1ff5e0100000012e426fb4d4b15"
    ..
    "1f0a557293702f1d96030000004e7ce782a5432333c5136bb4f30d31970000000022d554"
    ..
    "9cbe4f26a846072194d082b4612b000000e432d8b00d4f891fb77ecfaca24afd360a0000"
    ..
    "002843c6e1534d2ca2868e6ca38cbd1764000000003cc15e37fb48e406f08400b57e712a"
    ..
    "2604000000ed68b0e4e94294f40bda31a241bb462e280000003f74fccf8044b043df1491"
    ..
    "9373201d1725000000b5492bb0e94420bbb73204a36003e452030000005c10e4a4b549a1"
    ..
    "59c440c5a7eedf7e5400000000c931c839dc47e65a179c449a7c8e1c3e00000000331bf0"
    ..
    "78984feaebea84b4b9a25ab9cc0e0000000f383166e0434d2d27cf09805aa95669000000"
    ..
    "009f8bf812fc4a75880cd97ca629bd3a382d0000004ce75a7b104c70d2985758a95a2a21"
    ..
    "0b0d000000186929d7dd4bd61da864e29d8438c13c030000007852a1c2fe4ae7bfff9017"
    ..
    "6c55f71d5301000000d4a3ac6ec14cec40ed8b86b7c58f420903000000dd75e5292746a3"
    ..
    "e076d2109deadc2c23110000005da643af4749d37f8e3e739805bbc1d90f000000ec6c26"
    ..
    "6b8f4bc71ed9e40ba307fc420901000000613df70dea473fa2e98927b79a49410c010000"
    ..
    "0086181d60844f64acded316aad6c7ea0d2f000000686308e7584c236b701b3984915e26"
    ..
    "1601000000d6bcff9d58014f49821221e288a8923c0a000000acd0aef26f41fe9a7faa64"
    ..
    "86fcd626fa010000000b1f4f17a545c6b4e82e3fb17d91fbd00a000000834af9356c4058"
    ..
    "e2f50918a37c241096290000006ec18fb6e2421b8b5c2153b4fe448805010000000685e1"
    ..
    "b2c2cf7342bbf44ea507ba8b75010000003689f564ba421bfd897296ba4efad0d5010000"
    ..
    "0027d80e6f954809a68d99919ca40e189002000000e79e7f713a49b0e93291b388078138"
    ..
    "1b0800000050326854af4899809698c88bb7f9adfb00000000194d0c4370495471699b69"
    ..
    "87e5b090df0f000000bd32feaa144c9553255e6ab6ddd13210010000008ee1af23584ee1"
    ..
    "4c52c2618db7be53b90b000000eab762a43a4e99f41fecc199b2e1248204000000bdfdb5"
    ..
    "2e104dac018ff33681daa59333050000004f359d502f49e6f6b28549a71c633c07000000"
    ..
    "0040eb564adc11f5107e34d392e76ac9b202000000004a8ad7974658e8b519a8bab4467d"
    ..
    "481200000086f879551f4c3a937b08ba832fb961630200000052be2f610b4053da914f0d"
    ..
    "917c85b19f01000000367a23a4c941eacaf818a28ff31b685804000000753f4e80494b88"
    ..
    "70068cd6a4dcb67e3c05000000f20a68fba34bef59b519a8ba3d44c873020000000eb750"
    ..
    "99174e1ab40dfaccbbd67f815701000000965196abfc08d8458d22d7b79e56ad78010000"
    ..
    "002d0000002f47616d652f4d6f64732f426f782f426c75657072696e742f534c5f416374"
    ..
    "6f722e534c5f4163746f725f4300"

local function OldHeader()
    return (OLD_HEADER_HEX:gsub("%x%x", function(cc)
        return string.char(tonumber(cc, 16))
    end))
end

function JxSaveGame.ExportOldBytes(map, rows, player, stamp, mpath)
    rows = rows or {}
    local cls, msh, knd, flt, nms = {}, {}, {}, {}, {}
    for i, r in ipairs(rows) do
        cls[i] = FStr(r.cls or "")
        msh[i] = FStr(r.mesh or "")
        knd[i] = I32(r.kind or 0)
        nms[i] = FStr(r.name or "")
        flt[#flt + 1] = F32(r.x); flt[#flt + 1] = F32(r.y)
        flt[#flt + 1] = F32(r.z); flt[#flt + 1] = F32(r.yaw or 0)
    end
    local aC = FStr("ObjectProperty") .. I32(#rows) .. table.concat(cls)
    local aM = FStr("StrProperty") .. I32(#rows) .. table.concat(msh)
    local aK = FStr("IntProperty") .. I32(#rows) .. table.concat(knd)
    local aF = FStr("FloatProperty") .. I32(#rows * 4) .. table.concat(flt)
    local aN = FStr("StrProperty") .. I32(#rows) .. table.concat(nms)
    local vP, nP = "", 0
    if player and (player.x or player.y or player.z) then
        nP = 4
        vP = F32(player.x) .. F32(player.y) .. F32(player.z) .. F32(player.yaw or 0)
    end
    local aP = FStr("FloatProperty") .. I32(nP) .. vP
    return OldHeader()
        .. PropStr("JXMap", map)
        .. Prop("Classes", "ArrayProperty", aC)
        .. Prop("Meshes", "ArrayProperty", aM)
        .. Prop("Kinds", "ArrayProperty", aK)
        .. Prop("Data", "ArrayProperty", aF)
        .. Prop("Names", "ArrayProperty", aN)
        .. Prop("Player", "ArrayProperty", aP)
        .. PropStr("Seen", tostring(stamp or "unknown") .. "|" .. tostring(mpath or "-"))
        .. FStr("None")
end

function JxSaveGame.ImportOldBytes(b)
    if not b then return nil, "no bytes" end
    local at = b:find(FStr("JXMap"), 1, true)
    if not at then return nil, "not a JXAMS file (no JXMap property)" end
    local ok, result = pcall(function()
        local map, classes, meshes, kinds, floats, names = nil, {}, {}, {}, {}, {}
        local player, seen, stamp, mpath = {}, nil, nil, nil
        WalkProps(b, at, function(name, typ, size, voff)
            if typ == "StrProperty" then
                local v = RdFStr(b, voff)
                if name == "JXMap" then map = v
                elseif name == "Seen" then
                    seen = v
                    stamp = v and tostring(v):match("^([^|]*)") or nil
                    mpath = v and tostring(v):match("|(.*)$") or nil
                end
            elseif typ == "ArrayProperty" then
                local et, no = RdFStr(b, voff)
                if et then
                    local n = string.unpack("<i4", b, no)
                    local p = no + 4
                    if et == "FloatProperty" then
                        
                        local dst = (name == "Player") and player or floats
                        for k = 1, n do
                            dst[k] = string.unpack("<f", b, p); p = p + 4
                        end
                    elseif et == "IntProperty" then
                        for k = 1, n do
                            kinds[k] = string.unpack("<i4", b, p); p = p + 4
                        end
                    elseif et == "ObjectProperty" then
                        for k = 1, n do
                            local s, np = RdFStr(b, p); p = np
                            classes[k] = s
                        end
                    elseif et == "StrProperty" then
                        for k = 1, n do
                            local s, np = RdFStr(b, p); p = np
                            if name == "Meshes" then meshes[k] = s
                            elseif name == "Names" then names[k] = s end
                        end
                    end
                end
            end
        end)
        local rows = {}
        for i = 1, #classes do
            rows[i] = { cls = classes[i], mesh = meshes[i] or "", name = names[i] or "",
                        kind = kinds[i] or 0,
                        x = floats[(i - 1) * 4 + 1] or 0, y = floats[(i - 1) * 4 + 2] or 0,
                        z = floats[(i - 1) * 4 + 3] or 0, yaw = floats[(i - 1) * 4 + 4] or 0 }
        end
        return { map = map, rows = rows, seen = seen, stamp = stamp, mpath = mpath,
                 player = { x = player[1], y = player[2], z = player[3], yaw = player[4] } }
    end)
    if not ok then return nil, tostring(result) end
    return result
end

local OldFromDoc = {
    binds = function(sec)
        local rows = {}
        for i, r in ipairs(sec.rows or {}) do
            rows[i] = { cls = tostring(r.label or r.id), mesh = tostring(r.key or ""),
                        name = tostring(r.id), kind = 10,
                        x = tonumber(r.mods) or 0, y = 0, z = 0, yaw = 0 }
        end
        return rows
    end,
    actors = function(sec)
        local rows = {}
        for i, r in ipairs(sec.rows or {}) do
            rows[i] = { cls = tostring(r.cls), mesh = "", name = "actor", kind = 20,
                        x = 0, y = 0, z = 0, yaw = 0 }
        end
        return rows
    end,
    meshes = function(sec)
        local rows = {}
        for i, r in ipairs(sec.rows or {}) do
            rows[i] = { cls = "/Script/Engine.StaticMeshActor", mesh = tostring(r.path),
                        name = "mesh", kind = 21,
                        x = tonumber(r.count) or 0, y = 0, z = 0, yaw = 0 }
        end
        return rows
    end,
    entities = function(sec)
        local rows = {}
        for i, r in ipairs(sec.rows or {}) do
            rows[i] = { cls = tostring(r.path), mesh = "", name = tostring(r.name), kind = 22,
                        x = 0, y = 0, z = 0, yaw = 0 }
        end
        return rows
    end,
}

local DocFromOldRows = {
    [10] = function(rows)
        local out = {}
        for i, r in ipairs(rows) do
            out[i] = { id = r.name, label = r.cls, key = r.mesh, mods = math.floor(r.x or 0) }
        end
        return out
    end,
    [20] = function(rows)
        local out = {}
        for i, r in ipairs(rows) do out[i] = { cls = r.cls } end
        return out
    end,
    [21] = function(rows)
        local out = {}
        for i, r in ipairs(rows) do
            out[i] = { path = r.mesh, count = math.floor(r.x or 0) }
        end
        return out
    end,
    [22] = function(rows)
        local out = {}
        for i, r in ipairs(rows) do out[i] = { name = r.name, path = r.cls } end
        return out
    end,
}

local KindToSection = { [10] = "binds", [20] = "actors", [21] = "meshes", [22] = "entities" }
local SectionToKind = { binds = 10, actors = 20, meshes = 21, entities = 22 }

function JxSaveGame.SectionToOldRows(section, sec)
    local fn = OldFromDoc[section]
    if not fn then return nil, "no old-format mapping for section " .. tostring(section) end
    return fn(sec)
end

function JxSaveGame.OldRowsToSection(kind, rows)
    local fn = DocFromOldRows[kind]
    if not fn then return nil end
    return fn(rows)
end

function JxSaveGame.NewDocument()
    local doc = { schema = JxSaveGame.SchemaVersion, module = JxSaveGame.ModuleVersion,
                  savedAt = JxSaveGame.Stamp(), sections = {} }
    for _, s in ipairs(JxSaveGame.Sections) do
        doc.sections[s] = { version = JxSaveGame.SectionVersion, rows = {} }
    end
    return doc
end

function JxSaveGame.Validate(doc)
    local errs = {}
    if type(doc) ~= "table" then return nil, { "document is not a table" } end
    if doc.schema ~= JxSaveGame.SchemaVersion then
        errs[#errs + 1] = "schema " .. tostring(doc.schema)
            .. " does not match module schema " .. tostring(JxSaveGame.SchemaVersion)
    end
    doc.sections = doc.sections or {}
    for _, s in ipairs(JxSaveGame.Sections) do
        local sec = doc.sections[s]
        if sec == nil then
            doc.sections[s] = { version = JxSaveGame.SectionVersion, rows = {} }
        elseif type(sec) ~= "table" or type(sec.rows) ~= "table" then
            errs[#errs + 1] = "section " .. s .. " has no rows table"
        end
    end
    return doc, errs
end

function JxSaveGame.AbsorbOld(doc, old, sectionHint)
    if not old or not old.map then return false, "nothing to absorb" end
    local mapKey = tostring(old.map)
    if mapKey:find("^Jxdata/", 1, true) then
        
        local kind = old.rows and old.rows[1] and old.rows[1].kind
        local section = sectionHint or KindToSection[kind or 0]
        if not section then return false, "unknown row kind " .. tostring(kind) end
        local fn = DocFromOldRows[sectionHint and SectionToKind[sectionHint] or kind]
        local rows = (fn and #old.rows > 0) and fn(old.rows) or {}
        doc.sections[section] = { version = JxSaveGame.SectionVersion,
                                  rows = rows, source = "import:" .. mapKey }
        return true, section
    end
    
    local maps = doc.sections.maps or { version = JxSaveGame.SectionVersion, rows = {} }
    for _, r in ipairs(maps.rows) do
        if r.map == mapKey then
            r.stamp = old.stamp or r.stamp
            r.mpath = old.mpath or r.mpath
            r.rows = #old.rows
            return true, "maps"
        end
    end
    maps.rows[#maps.rows + 1] = { map = mapKey, stamp = old.stamp or (old.seen or "-"),
                                  rows = #old.rows, mpath = old.mpath or "-" }
    doc.sections.maps = maps
    return true, "maps"
end

local Engine = { cached = nil }

local function engineFind(path)
    local o
    pcall(function() o = StaticFindObject(path) end)
    if o and o.IsValid and o:IsValid() then return o end
    if type(LoadAsset) == "function" then
        pcall(function() o = LoadAsset(path) end)
    end
    if o and o.IsValid and o:IsValid() then return o end
    return nil
end

function Engine.Get()
    if Engine.cached then return Engine.cached end
    if type(StaticFindObject) ~= "function" then
        Engine.cached = { available = false, why = "no-engine" }
        return Engine.cached
    end
    local gs = engineFind("/Script/Engine.Default__GameplayStatics")
    local cls = engineFind(JxSaveGame.SaveClassPath .. "." .. JxSaveGame.SaveClassName)
                 or engineFind(JxSaveGame.SaveClassPath)
    local baseCls = engineFind("/Script/Engine.SaveGame")
    Engine.cached = {
        available = (gs ~= nil),
        why = gs and nil or "no-gameplaystatics",
        gs = gs,
        saveClass = cls,       
        baseClass = baseCls,   
    }
    return Engine.cached
end

function JxSaveGame.EngineStatus()
    local e = Engine.Get()
    return {
        engine = e.available or false,
        saveClassFound = e.saveClass ~= nil,
        className = e.saveClass and JxSaveGame.SaveClassPath or nil,
        baseClassFound = e.baseClass ~= nil,
        reason = e.why,
    }
end

function JxSaveGame.FindSaveGameClass()
    local e = Engine.Get()
    return e.saveClass
end

function JxSaveGame.SaveGameToSlot(doc, slotName)
    slotName = slotName or JxSaveGame.SlotName
    local e = Engine.Get()
    if not e.available then return false, "unavailable", e.why end
    
    local cls = e.saveClass
    if not cls then return false, "unavailable", "no BP SaveGame class; using fallback file" end

    local sg
    local okC = pcall(function() sg = e.gs:CreateSaveGameObject(cls) end)
    if not okC or not sg or (sg.IsValid and not sg:IsValid()) then
        return false, "unavailable", "CreateSaveGameObject failed"
    end

    local payload = Json.encode(doc)
    local setAny = false
    local wants = {
        { "SchemaVersion", doc.schema or JxSaveGame.SchemaVersion },
        { "SavedAt",       doc.savedAt or JxSaveGame.Stamp() },
        { "JXSections",    table.concat(JxSaveGame.Sections, ",") },
        { "JXPayload",     payload },
    }
    for _, p in ipairs(wants) do
        local okS = pcall(function() sg[p[1]] = p[2] end)
        if okS then setAny = true end
    end

    local okSave = false
    pcall(function() okSave = e.gs:SaveGameToSlot(sg, slotName, 0) end)
    if not okSave then return false, "unavailable", "SaveGameToSlot returned false" end

    if setAny and e.saveClass then
        local back = JxSaveGame.RealLoadFromSlot(slotName)
        if not (back and back.doc) then
            return true, "bp-class",
                "saved, but the payload did not read back - the BP variables need the SaveGame flag"
        end
    end
    if not setAny then
        return true, e.saveClass and "bp-class" or "native-class",
            "no matching properties on the class (the body saves empty)"
    end
    return true, e.saveClass and "bp-class" or "native-class"
end

function JxSaveGame.RealLoadFromSlot(slotName)
    slotName = slotName or JxSaveGame.SlotName
    local e = Engine.Get()
    if not e.available then return { doc = nil, info = { reason = e.why } } end
    local sg
    local ok = pcall(function() sg = e.gs:LoadGameFromSlot(slotName, 0) end)
    if not ok or not sg or (sg.IsValid and not sg:IsValid()) then
        return { doc = nil, info = { reason = "LoadGameFromSlot returned null" } }
    end
    local payload
    pcall(function() payload = sg.JXPayload end)
    if type(payload) == "string" and payload ~= "" then
        local okJ, doc = pcall(Json.decode, payload)
        if okJ then return { doc = doc, info = { via = "engine" } } end
    end
    
    return { doc = nil, info = { via = "engine", reason = "no JXPayload property on object" } }
end

function JxSaveGame.DoesSlotExist(slotName)
    slotName = slotName or JxSaveGame.SlotName
    local e = Engine.Get()
    if not e.available then return nil end
    local r
    pcall(function() r = e.gs:DoesSaveGameExist(slotName, 0) end)
    return r
end

function JxSaveGame.Save(doc, opts)
    opts = opts or {}
    local vdoc, verrs = JxSaveGame.Validate(doc)
    if not vdoc then return false, "invalid", table.concat(verrs, "; ") end
    doc = vdoc
    doc.savedAt = JxSaveGame.Stamp()

    if not opts.fallbackOnly then
        local ok, how, warn = JxSaveGame.SaveGameToSlot(doc, opts.slot)
        if ok then return true, how, warn end
    end

    local path = opts.path or JxSaveGame.SlotPath()
    if not path then return false, "no-path", "LOCALAPPDATA unavailable" end

    local prev = ReadAllBytes(path)
    if prev and not opts.noBackup then
        local hdr = JxSaveGame.ParseGvasHeader(prev)
        local ours = hdr and hdr.className
            and hdr.className:find("BP_JXSaveGame_C", 1, true) ~= nil
        if hdr and not ours then
            WriteAllBytes(path .. ".engine-bak", prev)
        end
    end

    local bytes = JxSaveGame.BuildSlotBytes(doc)
    if not WriteAllBytes(path, bytes) then return false, "io", "cannot write " .. path end
    return true, "fallback-gvas", path
end

function JxSaveGame.Load(opts)
    opts = opts or {}
    local path = opts.path or JxSaveGame.SlotPath()
    if path then
        local b = ReadAllBytes(path)
        if b then
            local doc, info = JxSaveGame.ParseSlotBytes(b)
            if doc then
                if not doc._external then
                    local v = JxSaveGame.Validate(doc)
                    if v then doc = v end
                end
                return doc, info.flavor == "engine" and "engine" or "fallback-gvas", info
            end
            
            if not opts.fallbackOnly and Engine.Get().available then
                local r = JxSaveGame.RealLoadFromSlot(opts.slot)
                if r and r.doc then return r.doc, "engine", r.info end
                return nil, "none", { parseError = info, engineReason = r.info and r.info.reason }
            end
            return nil, "none", { parseError = info }
        end
    end
    if not opts.fallbackOnly and Engine.Get().available then
        local r = JxSaveGame.RealLoadFromSlot(opts.slot)
        if r and r.doc then return r.doc, "engine", r.info end
    end
    return nil, "none", { reason = "slot file not found" }
end

function JxSaveGame.MigrateFromMod(modSavesDir)
    local doc = JxSaveGame.NewDocument()
    local report = { imported = {}, skipped = {} }
    if type(modSavesDir) ~= "string" then
        return nil, { imported = {}, skipped = { { file = "-", why = "no saves dir" } } }
    end

    for _, s in ipairs(JxSaveGame.Sections) do
        if s ~= "maps" and s ~= "players" then
            local b = ReadAllBytes(modSavesDir .. "Jxdata-" .. s .. ".sav")
            if b then
                local old = JxSaveGame.ImportOldBytes(b)
                if old then
                    local ok, what = JxSaveGame.AbsorbOld(doc, old, s)
                    if ok then
                        report.imported[#report.imported + 1] =
                            { file = "Jxdata-" .. s .. ".sav", section = what, rows = #old.rows }
                    else
                        report.skipped[#report.skipped + 1] =
                            { file = "Jxdata-" .. s .. ".sav", why = what }
                    end
                else
                    report.skipped[#report.skipped + 1] =
                        { file = "Jxdata-" .. s .. ".sav", why = tostring(old) }
                end
            end
        end
    end

    local files = {}
    pcall(function()
        
        local listDir = tostring(modSavesDir):gsub("/", "\\")
        local f = io.popen('dir /b "' .. listDir .. 'JXAMS-*.sav" 2>nul')
        if f then
            for ln in f:lines() do files[#files + 1] = ln end
            f:close()
        end
    end)
    for _, fn in ipairs(files) do
        local b = ReadAllBytes(modSavesDir .. fn)
        local old = b and JxSaveGame.ImportOldBytes(b)
        if old then
            local ok, what = JxSaveGame.AbsorbOld(doc, old)
            if ok then
                report.imported[#report.imported + 1] = { file = fn, section = what, rows = #old.rows }
            end
        else
            report.skipped[#report.skipped + 1] = { file = fn, why = tostring(old) }
        end
    end
    return doc, report
end

function JxSaveGame.ExportToMod(doc, modSavesDir, sections)
    local vdoc, verrs = JxSaveGame.Validate(doc)
    if not vdoc then return nil, verrs end
    doc = vdoc
    local results = {}
    for _, s in ipairs(sections or JxSaveGame.Sections) do
        if s ~= "maps" and s ~= "players" then
            local sec = doc.sections[s]
            if sec and sec.rows then
                local rows = JxSaveGame.SectionToOldRows(s, sec)
                if rows then
                    local bytes = JxSaveGame.ExportOldBytes("Jxdata/" .. s, rows, nil,
                                                            doc.savedAt or JxSaveGame.Stamp(), "-")
                    local ok = WriteAllBytes(modSavesDir .. "Jxdata-" .. s .. ".sav", bytes)
                    results[#results + 1] = { file = "Jxdata-" .. s .. ".sav", ok = ok, rows = #rows }
                end
            end
        end
    end
    return results
end

function JxSaveGame.PlayersFromIdentities(jsonText)
    local ok, data = pcall(Json.decode, jsonText)
    if not ok or type(data) ~= "table" or type(data.players) ~= "table" then
        return nil, "not a player_identities.json document"
    end
    local rows = {}
    for name, info in pairs(data.players) do
        rows[#rows + 1] = {
            name = info.display_name or name,
            id = tostring(info.id or ""),
            verified = info.verified and true or false,
        }
    end
    table.sort(rows, function(a, b) return a.name < b.name end)
    return rows
end

JxSaveGame._Engine = Engine
return JxSaveGame
