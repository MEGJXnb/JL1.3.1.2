
-- JxUiRouter v64 (r22): wording un-staled - the pak WBP shell IS the live UI
-- (left rail, press B); the retired-path/canvas text was canvas-era only.
local JR = { version = "64.0" }

local function say(msg)
    print("[JxUiRouter] " .. tostring(msg))
end

local function fmtProbe(r)
    if not r then return "(probe returned nothing)" end
    local lines = {
        "UI layer status:",
        "  Core  (BP_JinxingLoaderCore_C) : " .. tostring(r.coreState),
        "  pak UI root (WBP_JinxingRoot)  : " .. tostring(r.uirootState),
        "  F6 widget (WBP_JinxingF6)      : " .. tostring(r.f6State),
        "  legacy canvas panel (retired)  : " .. tostring(r.luaPanel),
        "  engine busy (map change)       : " .. tostring(r.busy),
    }
    if r.core then

        lines[#lines + 1] =
            "  pak ModActor class             : " ..
            (r.pakClassLoadable and "LOADABLE" or "not probed")
        lines[#lines + 1] =
            "  verdict: pak shell chain alive. The live UI is the pak WBP shell (left rail) -- press B."
    elseif r.busy then
        lines[#lines + 1] =
            "  verdict: engine mid map-change -- wait 2-3 s, press again."
    elseif r.pakClassLoadable then
        lines[#lines + 1] =
            "  pak ModActor class             : LOADABLE -- pak mounted, actor not spawned."
        lines[#lines + 1] =
            "    fix: UE4SS-settings.ini [ModManager] bEnableBlueprintModLoader=true,"
        lines[#lines + 1] =
            "        LogicMods pak name must end with _P.pak, then RESTART the game."
    else
        lines[#lines + 1] =
            "  pak ModActor class             : not loadable - LogicMods pak missing or not mounted."
        lines[#lines + 1] =
            "    fix: reinstall JinxingLoader_P.pak into Content\\Paks\\LogicMods,"
        lines[#lines + 1] =
            "        keep the _P.pak name suffix, then RESTART the game."
    end
    return table.concat(lines, "\n")
end

local function probeOnGameThread()
    local out = {}
    local ok, err = pcall(function()
        local probe = _G.JxUiProbe
        if type(probe) ~= "function" then
            out.text = "JxUiProbe not published (main.lua too old -- deploy the current main.lua)"
            return
        end
        local r = probe()
        out.r = r
        out.text = fmtProbe(r)
    end)
    if not ok then
        out.text = "probe error: " .. tostring(err)
    end
    say(out.text)
    return out.r
end

if type(JXRegCmd) == "function" then
    JXRegCmd("jxdiag", function()
        pcall(function()
            if type(ExecuteInGameThread) == "function" then
                ExecuteInGameThread(function() pcall(probeOnGameThread) end)
            else
                probeOnGameThread()
            end
        end)
        return true
    end)

    JXRegCmd("jxuirescan", function()
        pcall(function()
            local reset = _G.JxUiResetMemos
            if type(reset) == "function" then
                reset()
                say("UI memo caches dropped, re-probing...")
            else
                say("JxUiResetMemos not published (main.lua too old -- deploy the current main.lua)")
            end
            if type(ExecuteInGameThread) == "function" then
                ExecuteInGameThread(function() pcall(probeOnGameThread) end)
            else
                probeOnGameThread()
            end
        end)
        return true
    end)
else
    say("JXRegCmd unavailable -- command registration skipped (non-fatal)")
end

if type(ExecuteWithDelay) == "function" and type(ExecuteInGameThread) == "function" then
    ExecuteWithDelay(8000, function()
        pcall(function()
            say("boot self-check running...")
            ExecuteInGameThread(function()
                local ok, r = pcall(probeOnGameThread)
                if ok and r and r.core then
                    say("self-check PASS: pak Core alive; the WBP shell is the UI (press B).")
                else
                    say("self-check WARN: pak panel chain is dead -- press a panel key")
                    say("or run 'jxdiag'. If the panel title shows OLD PAK ACTIVE, a stale")
                    say("old pak is mounted - see config\\newui_verdict.txt for the fix.")
                end
            end)
        end)
    end)
else
    say("ExecuteWithDelay/ExecuteInGameThread unavailable -- boot self-check skipped")
end

_G.JxUiRouter = JR
say("loaded v" .. JR.version .. " (commands: jxdiag, jxuirescan; boot self-check +8s)")
