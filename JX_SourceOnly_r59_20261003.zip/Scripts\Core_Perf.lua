-- Core_Perf (r16 split from main.lua) - deps bridged via _G.JXEnv
local E = _G.JXEnv or {}
local Log = E.Log or function(s) print("[JX] " .. tostring(s) .. "'\n'") end
-- r25 dedup: main.lua loads Core_* via TWO paths (r16 individual bridge loaders
-- + the r16 bulk coreMods loader at main.lua:11590). Guard = arm features once.
if _G.JX_CORE_PERF_LOADED then Log("Core_Perf: duplicate load skipped (r25 dedup)") return end
_G.JX_CORE_PERF_LOADED = true
local UEHelpers = E.UEHelpers
local ModDir = E.ModDir
local JXAlive = E.JXAlive
local JXName = E.JXName
function JXPerfVerify()
    local function Say(s) Log("[PERFCHK] " .. tostring(s)) end

    local function ReadNum(name)
        local v = nil
        pcall(function()
            local KSL = StaticFindObject("/Script/Engine.Default__KismetSystemLibrary")
            if JXAlive(KSL) then v = KSL:GetConsoleVariableFloatValue(name) end
        end)
        return v
    end

    local function TierWants(tier)
        local want = {}
        local h2 = io.open(ModDir .. "config/boost_pack.ini", "r")
        if not h2 then return want end
        local prefix = "tier." .. tier .. "."
        for line in h2:lines() do
            local k, v = line:match("^([%w_%.]+)%s*=%s*(.-)%s*$")
            if k and v and k:sub(1, #prefix) == prefix then
                local cname, cval = v:match("^(%S+)%s+(.+)$")
                if cname then want[cname] = cval end
            end
        end
        h2:close()
        return want
    end

    local function ApplyTier(tier)
        local n = 0
        local h = io.open(ModDir .. "config/boost_pack.ini", "r")
        if not h then return 0 end
        local prefix = "tier." .. tier .. "."
        for line in h:lines() do
            local k, v = line:match("^([%w_%.]+)%s*=%s*(.-)%s*$")
            if k and v and k:sub(1, #prefix) == prefix then
                -- r56: resolve at call time. This file loads before main
                -- fills _G.JXEnv.JXQueue, so a load-time capture would pin
                -- nil and every tier application silently no-op'd.
                local q = E.JXQueue
                if type(q) == "function" then
                    q({ v })
                    n = n + 1
                end
            end
        end
        h:close()
        return n
    end

    local function Verify(tier, write_report)
        local want = TierWants(tier)
        local names, ok, bad = {}, 0, 0
        local lines = {}
        for n, _ in pairs(want) do names[#names + 1] = n end
        table.sort(names)
        for _, n in ipairs(names) do
            local got = ReadNum(n)
            local w = tonumber(want[n])
            local good = (got ~= nil) and (w == nil or math.abs(got - w) < 0.51)
            if good then ok = ok + 1 else bad = bad + 1 end
            lines[#lines + 1] = string.format("%-42s want=%-8s got=%-8s %s",
                n, tostring(want[n]), tostring(got), good and "ok" or "NOT-APPLIED")
        end
        Say(string.format("tier '%s': %d applied, %d NOT applied", tier, ok, bad))
        for _, l in ipairs(lines) do Say(l) end
        if write_report then
            local h = io.open(ModDir .. "config/perf_report.txt", "w")
            if h then
                h:write("perf report - tier " .. tier .. "\r\n")
                for _, l in ipairs(lines) do h:write(l .. "\r\n") end
                h:close()
            end
        end
        return ok, bad
    end

    JXRegCmd("jperfcheck", function(FullCommand, Parameters, Ar)
        local tier = (Parameters and Parameters[1]) or "pro"
        ExecuteInGameThread(function() pcall(function() ApplyTier(tier) end) end)
        ExecuteWithDelay(3000, function()
            ExecuteInGameThread(function() pcall(Verify, tier, true) end)
        end)
    end)

    ExecuteWithDelay(30000, function()
        ExecuteInGameThread(function()
            pcall(function() ApplyTier("pro") end)
            ExecuteWithDelay(3000, function()
                ExecuteInGameThread(function() pcall(Verify, "pro", true) end)
            end)
        end)
    end)
    Log("perf verify ready: jperfcheck <tier>, plus a boot pass on tier 'pro' at 30 s")
end
JXPerfVerify()
