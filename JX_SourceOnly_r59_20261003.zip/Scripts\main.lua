-- r33 build identity (external-review request): printed at load and shown
-- as a persistent corner badge in the panel, so "new or old build" is
-- visible at a glance instead of guessed. Update JX_BUILD with the new pak
-- sha1 prefix on every pak release.
JX_BUILD = "1.4.1 | pak E19AE6B3 | r59"
print("[JX] build " .. JX_BUILD)

local UEHelpers = require("UEHelpers")

local TAG = "[JinxingLoaderRT] "
local function Log(msg) print(TAG .. tostring(msg) .. "\n") end

do
    local ok, err = pcall(function()
        local gpath = debug and debug.getinfo and debug.getinfo(1, "S").source or ""
        if type(gpath) == "string" and gpath:sub(1, 1) == "@" then
            gpath = gpath:sub(2):gsub("\\", "/"):match("^(.*/)[^/]+$") or ""
        else
            gpath = ""
        end
        _G.JXSidecarDir = gpath
        local function TryOne(name)
            local mc = loadfile(gpath .. name)
            if mc then
                local okm, merr = pcall(mc)
                if okm then
                    Log(name .. " loaded")
                else
                    Log(name .. " load error: " .. tostring(merr))
                end
            else
                Log(name .. " not found (non-fatal)")
            end
        end
        TryOne("JxCrashGuard.lua")       
        TryOne("JinxingInterface.lua")   
        TryOne("JxNetSuite.lua")         
        
        local sv = loadfile(gpath .. "JxSaveGame.lua")
        if sv then
            local oks, sres = pcall(sv)
            if oks and type(sres) == "table" then
                _G.JXSaveGameLib = sres
                Log("JxSaveGame.lua loaded (library)")
            else
                Log("JxSaveGame.lua load error: " .. tostring(sres))
            end
        else
            Log("JxSaveGame.lua not found (non-fatal)")
        end
        
    end)
    if not ok then Log("early sidecar load failed (non-fatal): " .. tostring(err)) end
end

do
    local rawFAO = FindAllOf
    FindAllOf = function(x)
        if x == nil then return nil end
        local ok, r = pcall(rawFAO, x)
        if ok then return r end
        return nil
    end
    _G.FindAllOf = FindAllOf
end

function RunGuarded(label, fn, a1, a2)
    local ok, err = pcall(fn, a1, a2)
    if not ok then Log(tostring(label) .. ": failed - " .. tostring(err)) end
    return ok
end

function J3LoadObject(path)
    if type(path) ~= "string" or path == "" then return nil end
    local o = nil
    pcall(function() o = StaticFindObject(path) end)
    if o and o:IsValid() then return o end
    if type(LoadAsset) == "function" then
        pcall(function() o = LoadAsset(path) end)
    end
    if o and o:IsValid() then return o end
    
    if not path:find("%.") then
        pcall(function() o = StaticFindObject(path .. "." .. path) end)
        if o and o:IsValid() then return o end
    end
    return nil
end

function JXSay(s)
    s = tostring(s)
    Log(s)
    pcall(function()
        local pc = nil
        pcall(function() pc = UEHelpers.GetPlayerController() end)
        if pc and pc:IsValid() then
            pcall(function() pc:ClientMessage(s) end)
        end
    end)
end

local JX = { busyUntil = 0, actorSweepBudget = 4 }

local JXNameCache = setmetatable({}, { __mode = "k" })
local JXNC = { gen = 0, maps = {}, cap = 4096 }
local JXThrottleAt = {}
local JXPump = { queue = {}, running = false, waits = 0 }

local function JXClock()
    local ok, t = pcall(function() return os.clock() end)
    local now = math.floor(((ok and t) or 0) * 1000)
    
    if now < (JXClockLast or 0) then
        if JX then JX.busyUntil = 0 end
    end
    JXClockLast = now
    return now
end

local function JXBeginTransition(ms)
    
    local base = JXClock()
    local deadline = base + (ms or 3000)
    
    if deadline > base + 15000 then deadline = base + 15000 end
    if deadline > JX.busyUntil then JX.busyUntil = deadline end
end

local function JXBusy()
    return JXClock() < JX.busyUntil
end

_G.JXForceUnlock = function()
    JX.busyUntil = 0
    JXClockLast = JXClock()
end

_G.JXBusy = JXBusy
_G.JXUIBusy = function() return JXBusy() end

JX.transferUntil = 0
function JXTransferBegin(ms)
    local deadline = JXClock() + (ms or 12000)
    if deadline > (JX.transferUntil or 0) then JX.transferUntil = deadline end
end
function JXTransferGuard()
    return JXClock() < (JX.transferUntil or 0)
end

function JXNameCacheNewGen()
    JXNC.gen = JXNC.gen + 1
    JXNC.maps[JXNC.gen] = 0
    JXNameCache = setmetatable({}, { __mode = "k" })
end

local function JXName(obj)
    if not obj then return "" end
    local cached = JXNameCache[obj]
    if cached ~= nil then return cached end
    local s = ""
    pcall(function()
        if obj.GetFullName then s = tostring(obj:GetFullName()) end
    end)
    if s ~= "" and s ~= "nil" then
        
        local g = JXNC.gen
        local n = (JXNC.maps[g] or 0) + 1
        if n > JXNC.cap then
            
            JXNameCacheNewGen()
            g = JXNC.gen
            n = 1
        end
        JXNC.maps[g] = n
        JXNameCache[obj] = s
        return s
    end
    pcall(function() s = tostring(obj) end)
    return s
end

local function JXAlive(obj)
    if not obj then return false end
    local ok, v = pcall(function() return obj:IsValid() end)
    return (ok and v) or false
end

local function JXThrottle(key, ms)
    local t = JXClock()
    local last = JXThrottleAt[key]
    if last and (t - last) < (ms or 250) then return false end
    JXThrottleAt[key] = t
    return true
end

local function JXMemo(slot, ttl, factory, missTtl)
    local t = JXClock()
    local e = slot[1]
    if e then
        local age = t - e.at
        if e.obj ~= nil then
            if age < (ttl or 10000) and JXAlive(e.obj) then return e.obj end
        elseif age < (missTtl or 3000) then
            
            return nil
        end
        slot[1] = nil
    end
    if JXBusy() then return nil end
    local obj = nil
    pcall(function() obj = factory() end)
    if JXAlive(obj) then
        slot[1] = { obj = obj, at = t }
        return obj
    end
    slot[1] = { obj = nil, at = t }
    return nil
end

local CmdReady = nil    

PerfEcho = {}
local function PerfRememberEcho(cmd)
    local name, val = tostring(cmd):match("^(%S+)%s+(%-?[%d%.]+)%s*$")
    if name and val then PerfEcho[name] = tonumber(val) end
end
local function JXExecCmd(PC, cmd)
    
    if not JXAlive(PC) then return false end
    local KSL = StaticFindObject("/Script/Engine.Default__KismetSystemLibrary")
    if not JXAlive(KSL) then return false end
    PerfRememberEcho(cmd)
    return (pcall(function() KSL:ExecuteConsoleCommand(PC, cmd, PC) end))
end

-- r56: sidecar-facing executor. Two forms: (PC, cmd) direct, or (cmdline)
-- which routes through JXExecutor (it acquires the player controller).
-- Without this export JxNewUI sliders/buttons and JxSliderHub all ran nil.
_G.JXExecCmd = function(a, b)
    if b ~= nil then return JXExecCmd(a, b) end
    return JXExecutor(a)
end

local function JXRunPump()
    if #JXPump.queue == 0 then return 0 end
    local PC = nil
    pcall(function() PC = UEHelpers.GetPlayerController() end)
    if not JXAlive(PC) then
        
        if CmdReady == nil then
            Log("cvar exec: no player controller yet, " .. tostring(#JXPump.queue) .. " queued")
        end
        return 0
    end
    local n = 0
    while #JXPump.queue > 0 and n < 64 do
        local cmd = table.remove(JXPump.queue, 1)
        n = n + 1
        local ok = JXExecCmd(PC, cmd)
        if CmdReady == nil then
            CmdReady = ok
            Log("cvar exec: ExecuteConsoleCommand works=" .. tostring(ok)
                .. " pc=" .. tostring(JXAlive(PC)) .. " first=" .. tostring(cmd))
        end
    end
    return n
end

local function JXQueue(list)
    if not list then return end
    for _, cmd in ipairs(list) do JXPump.queue[#JXPump.queue + 1] = cmd end
    JXRunPump()
end

-- r57: sidecars read the bare global JXQueue (JxFpsTurbo.lua:43). Only
-- _G.JXEnv.JXQueue existed, so that batching path was a nil global and every
-- caller fell through to its own single-shot route. One export, no new local.
_G.JXQueue = JXQueue

local BOOST_LEVELS = {
    off = {
        "gc.TimeBetweenPurgingPendingKillObjects 60",
        "r.Streaming.FramesForFullUpdate 1",
        "r.MaxAnisotropy 16",
        "fx.MaxCPUParticlesPerEmitter 0",
        "r.LightFunctionQuality 1",
        "r.DetailMode 2",
    },
    balanced = {
        "gc.TimeBetweenPurgingPendingKillObjects 120",
        "r.Streaming.FramesForFullUpdate 5",
        "r.MaxAnisotropy 4",
        "fx.MaxCPUParticlesPerEmitter 500",
        "r.LightFunctionQuality 1",
        "r.DetailMode 2",
    },
    max = {
        "gc.TimeBetweenPurgingPendingKillObjects 300",
        "r.Streaming.FramesForFullUpdate 10",
        "r.MaxAnisotropy 1",
        "fx.MaxCPUParticlesPerEmitter 100",
        "r.LightFunctionQuality 0",
        "r.DetailMode 1",
    },
}

local JXEarlyRoot = nil
do
    local src = nil
    pcall(function()
        local info = debug and debug.getinfo and debug.getinfo(1, "S")
        src = info and info.source or nil
    end)
    if type(src) == "string" and src ~= "" then
        src = src:gsub("^@", ""):gsub("\\", "/")
        local root = src:match("^(.-)[Ss]cripts/[^/]*$")
        if root and root ~= "" then
            if root:sub(-1) ~= "/" then root = root .. "/" end
            local probe = io.open(root .. "config/spawn_catalog.txt", "r")
            if probe then probe:close(); JXEarlyRoot = root end
        end
    end
    if not JXEarlyRoot then
        for _, cand in ipairs({ "ue4ss/Mods/JinxingLoaderRT/", "Mods/JinxingLoaderRT/" }) do
            local probe = io.open(cand .. "config/spawn_catalog.txt", "r")
            if probe then probe:close(); JXEarlyRoot = cand; break end
        end
    end
end
local JXRootOr = (JXEarlyRoot or "Mods/JinxingLoaderRT/")
local JXUe4ssMods = ((JXRootOr):gsub("JinxingLoaderRT/$", ""))

local BoostFile = JXRootOr .. "config/boost.txt"  
local BoostLevel = "balanced"

local function BoostLoad()
    local f = io.open(BoostFile, "r")
    if not f then return "balanced" end
    local lv = f:read("*l")
    f:close()
    lv = (lv or ""):gsub("^%s+", ""):gsub("%s+$", "")
    if BOOST_LEVELS[lv] then return lv end
    return "balanced"
end

local function BoostApply(lv)
    if not BOOST_LEVELS[lv] then
        Log("usage: jboost off|balanced|max")
        return false
    end
    BoostLevel = lv
    pcall(function()
        local f = io.open(BoostFile, "w")
        if f then f:write(lv .. "\n"); f:close() end
    end)
    JXQueue(BOOST_LEVELS[lv])
    Log("engine boost -> " .. lv .. " (" .. #BOOST_LEVELS[lv] .. " cvars queued)")
    return true
end

local TAB_COUNT   = 12
local TabIndex    = 0
local TabSwSlot   = {}

local function JxIsTabSwitcherName(n)
    if n == nil or n == "" then return false end
    if n:find("JinxingTabSwitcher", 1, true) then return true end
    if n:find("SubSwitcher", 1, true) then return false end
    return (n:find("JinxingTab", 1, true) ~= nil) or (n:find("TabSwitcher", 1, true) ~= nil)
end

local function AcquireTabSwitcher()
    -- r54: prefer the switcher JxNewUI actually wired (the RENDERED panel's).
    -- Multiple shells coexist after heal/recreate; FindAllOf order is
    -- nondeterministic and used to serve a HIDDEN sibling's switcher - clicks
    -- then switched an invisible panel (user: "还是没有切呀").
    local wired = _G.JXWiredSwitcher
    if wired and wired.IsValid and wired:IsValid() and JXAlive(wired) then
        TabSwSlot[1] = wired
        return wired
    end
    return JXMemo(TabSwSlot, 10000, function()
        local all = FindAllOf("WidgetSwitcher")
        if not all then return nil end
        local a, b = nil, nil
        for _, w in pairs(all) do
            if JXAlive(w) then
                local s = JXName(w)
                if JxIsTabSwitcherName(s) then
                    if s:find("JinxingTabSwitcher", 1, true) then return w end
                    if not a and s:find("JinxingTab", 1, true) then a = w end
                    if not b then b = w end
                end
            end
        end
        return a or b
    end, 4000)
end

local function CurrentTabIndex()
    local sw = AcquireTabSwitcher()
    if sw then
        local ok, v = pcall(function() return sw.ActiveWidgetIndex end)
        if ok and type(v) == "number" then return v end
    end
    return TabIndex
end

local function JxTabPush(from)
    local h = JX.TabHist
    if type(h) ~= "table" then h = {}; JX.TabHist = h end
    if #h == 0 or h[#h] ~= from then h[#h + 1] = from end
    while #h > 16 do table.remove(h, 1) end
end

local function JxTabGo(idx, rememberFrom)
    local sw = AcquireTabSwitcher()
    if sw and not JXAlive(sw) then
        
        TabSwSlot[1] = nil
        sw = nil
    end
    if not sw and type(JxTabSelfHeal) == "function" then
        
        JxTabSelfHeal()
        TabSwSlot[1] = nil
        sw = AcquireTabSwitcher()
    end
    if not sw then
        Log("jtab: panel unreachable this frame - press B once, then retry")
        return false
    end
    
    local n = TAB_COUNT
    local got = nil
    pcall(function() got = sw:GetNumWidgets() end)
    if type(got) ~= "number" or got <= 0 then
        pcall(function() got = sw:GetChildrenCount() end)
    end
    if type(got) == "number" and got > 0 then n = math.floor(got) end
    if idx < 0 then idx = n - 1 end
    if idx >= n then idx = 0 end
    
    local wact = nil
    pcall(function() wact = sw:GetActiveWidgetIndex() end)
    if type(wact) == "number" then
        wact = math.floor(wact)
        if wact ~= TabIndex then
            Log("tab: page " .. tostring(TabIndex) .. " in Lua, " .. tostring(wact)
                .. " on the widget (the panel moved it); adopting " .. tostring(wact))
            TabIndex = wact
        end
    end
    local was = CurrentTabIndex()
    
    local backNav = (rememberFrom == false)
    if backNav then JX.TabQuiet = true end
    local ok, err = pcall(function() sw:SetActiveWidgetIndex(idx) end)
    if backNav then JX.TabQuiet = false end
    if not ok then
        Log("jtab: SetActiveWidgetIndex(" .. tostring(idx) .. ") failed: " .. tostring(err))
        return false
    end
    
    if JX.TabHookArmed and (JX.TabMine or 0) == 0 then
        JX.TabHookArmed = false
        local fires, unnamed = (JX.TabHookFires or 0), (JX.TabHookNoName or 0)
        Log("tab hook: armed but did not recognise this switcher"
            .. (JX.TabHookOther and (" (a switcher named " .. tostring(JX.TabHookOther) .. " did fire)")
                or (fires > 0 and (" (it fired " .. tostring(fires) .. " time(s) but named none of them: "
                    .. tostring(JX.TabHookWhy or "unknown") .. ")")
                    or " (it never fired at all)"))
            .. " - page tracking stays on the Lua side")
        if unnamed > 0 then
            Log("tab hook: " .. tostring(unnamed) .. " of " .. tostring(fires)
                .. " fires could not name their object, so the hook cannot tell the panel's"
                .. " switcher from the game's. 'jtab' and the Ctrl+arrow binds are unaffected.")
        end
    end
    if not backNav and not JX.TabHookArmed and was ~= idx then JxTabPush(was) end
    TabIndex = idx
    
    if was ~= idx then
        Log("jtab -> page " .. idx .. " of " .. n .. " (was " .. tostring(was) .. ")")
        
        if type(JX.TabRunRoute) == "function" then pcall(JX.TabRunRoute, idx) end
    end
    return true
end

-- r30: export for JxNewUI WireNewTabs - TabBtn_15..19 click bindings call
-- this; without it the new rail tabs were dead (bind step bailed out early)
_G.JXTabGo = JxTabGo

local function TabNoteIndex(self, idx)
    JX.TabHookFires = (JX.TabHookFires or 0) + 1
    local n = ""
    local ok, e = pcall(function()
        if self and self.IsValid then n = tostring(self:GetFullName()) end
    end)
    if not ok or n == "" then
        
        JX.TabHookNoName = (JX.TabHookNoName or 0) + 1
        if JX.TabHookWhy == nil then
            
            local msg = (not ok) and tostring(e) or "GetFullName answered nothing"
            JX.TabHookWhy = msg:match("main%.lua:%d+: (.*)$") or msg
        end
        return
    end
    if JxIsTabSwitcherName(n) then
        JX.TabMine = (JX.TabMine or 0) + 1
    else
        
        if JX.TabHookOther == nil then JX.TabHookOther = n end
        return
    end
    if JX.TabQuiet then return end          
    if type(idx) ~= "number" then return end
    if JXBusy() then return end
    idx = math.floor(idx)
    local was = TabIndex
    if was == idx then return end
    JxTabPush(was)
    TabIndex = idx
    Log("tab: pak button switched to page " .. idx .. " (was " .. tostring(was)
        .. ") - 'jtab back' returns there")
end

JX.TabHookArmed = false
do
    local ret, err = nil, nil
    local ok = pcall(function()
    
    end)
    JX.TabHookArmed = ok and (ret ~= false)
    Log("tab hook: /Script/UMG.WidgetSwitcher:SetActiveWidgetIndex "
        .. (JX.TabHookArmed and "armed" or ("NOT armed (" .. tostring(ok and ret or err) .. ")"))
        .. " - the pak's own tab buttons are tracked from here")
end

local ModsListFile = JXRootOr .. "logs/mods_current.txt"

local PanelNoteLogged = false
local function PaintModsIntoPanel(text)
    if text and #text > 0 and not PanelNoteLogged then
        PanelNoteLogged = true
        Log("panel text: off on this build (SetText takes an FText, which this UE4SS build cannot marshal)")
    end
    return false
end

local function ListLoadedMods()
    -- r33: dual-path open (style parity with Core_Crash.lua) - the relative
    -- name only resolves when CWD is Binaries/Win64; fall back to the two
    -- known install locations
    local f = io.open("UE4SS.log", "r")
    if not f then
        f = io.open("E:/SteamLibrary/steamapps/common/EscapeTheBackrooms/EscapeTheBackrooms/Binaries/Win64/UE4SS.log", "r")
    end
    if not f then
        local root = (JXRootOr or ""):match("^(.*[\\/]ue4ss[\\/])")
        if root ~= "" then f = io.open(root .. "..\\UE4SS.log", "r") end
    end
    if not f then
        Log("jmods: cannot open UE4SS.log (run the game from Binaries/Win64)")
        return 0
    end
    
    pcall(function() f:seek("end", -262144) end)
    local state, order = {}, {}
    for line in f:lines() do
        local name = line:match("Loading mod:%s*(%S+)")
        if name then
            if state[name] == nil then order[#order + 1] = name end
            state[name] = "OK"
        end
        local bad = line:match("ModClass for '(%S+)' is not valid")
        if bad then
            if state[bad] == nil then order[#order + 1] = bad end
            if state[bad] ~= "OK" then state[bad] = "NO ModActor" end
        end
    end
    f:close()
    if #order == 0 then
        Log("jmods: nothing recorded yet - enter a level, then run jmods again")
        return 0
    end
    local out, shown = {}, 0
    for _, n in ipairs(order) do
        local mark = (state[n] == "OK") and "[OK] " or "[--] "
        out[#out + 1] = mark .. n
        if shown < 24 then shown = shown + 1 end
    end
    local text = "Loaded mods (" .. #order .. "):\n" .. table.concat(out, "\n")
    
    pcall(function()
        local mf = io.open(ModsListFile, "w")
        if mf then mf:write(text .. "\n"); mf:close() end
    end)
    local painted = PaintModsIntoPanel(text)
    Log("jmods: " .. #order .. " entries "
        .. (painted and "(painted into the panel)" or "(file + log; panel text not paintable on this build)"))
    for _, n in ipairs(out) do Log("  " .. n) end
    return #order
end

-- r34: Mods-page list exports - JxNewUI fills ModListBtn_Info from these
_G.JXListLoadedMods = ListLoadedMods
_G.JXModsListFile = ModsListFile

local JxActor = { protect = false, marker = false, markerRef = nil, blocked = 0, baseline = -1 }

local function ActorClassToken(a)
    local cls = ""
    pcall(function()
        local c = a:GetClass()
        if c and c.GetFName then cls = tostring(c:GetFName():ToString()) end
    end)
    return cls
end

local DeleteGuardInstalled = true
local function InstallDeleteGuard()
    Log("v3.62 delete guard is polling-based (no K2_DestroyActor hook - that hook crashed map switches)")
end

JxActor.tp = function(a, x, y, z, yaw)
    local ok, err = pcall(function()
        if not JXAlive(a) then error("no actor") end
        local r = a:K2_TeleportTo({ X = x, Y = y, Z = z }, { Pitch = 0, Yaw = yaw or 0, Roll = 0 })
        if r == false then error("refused (blocked or invalid request)") end
    end)
    return ok, err
end

JxActor.spawn = function(cls, x, y, z, yaw)
    local W = UEHelpers.GetWorld()
    if not (W and W:IsValid()) then return nil, "no world" end
    if not (cls and cls:IsValid()) then return nil, "class not loaded" end
    local shapes = {
        { "vector+yaw", function()
            return W:SpawnActor(cls, { X = x, Y = y, Z = z },
                { Pitch = 0, Yaw = yaw or 0, Roll = 0 })
        end },
        { "vector", function() return W:SpawnActor(cls, { X = x, Y = y, Z = z }) end },
        { "bare", function() return W:SpawnActor(cls) end },
    }
    local lastErr = "no shape tried"
    for _, s in ipairs(shapes) do
        local ok, a = pcall(s[2])
        if ok and JXAlive(a) then
            pcall(function() JxActor.tp(a, x, y, z, yaw) end)
            return a, nil, s[1]
        end
        lastErr = tostring(a):gsub("%s+", " "):sub(1, 120)
    end
    return nil, lastErr
end

local function ClearScaleMarker()
    if JxActor.markerRef then
        pcall(function()
            if JXAlive(JxActor.markerRef) then JxActor.markerRef:K2_DestroyActor() end
        end)
        JxActor.markerRef = nil
    end
end

local function SpawnScaleMarker()
    local pos = nil
    pcall(function()
        local PC = UEHelpers.GetPlayerController()
        if not (PC and PC:IsValid() and PC.Pawn and PC.Pawn:IsValid()) then return end
        pos = PC.Pawn:K2_GetActorLocation()
    end)
    if not pos then
        Log("jactor: no pawn to place a marker on")
        return false
    end
    if JxActor.markerRef and JXAlive(JxActor.markerRef) then
        ClearScaleMarker()
        Log("jactor: scale marker removed")
        JxActor.marker = false
        return true
    end
    local spawned, why, shape = false, nil, nil
    pcall(function()
        local cls = J3LoadObject("/Script/Engine.StaticMeshActor")
        if not (cls and cls:IsValid()) then why = "StaticMeshActor class not loaded"; return end
        
        local mx, my, mz, myaw = pos.X + 120, pos.Y, pos.Z - 80, 0
        local v = ViewPoint(200, 0)
        if v then mx, my, mz, myaw = v.x, v.y, v.z, v.yaw or 0 end
        local a, err, sh = JxActor.spawn(cls, mx, my, mz, myaw)
        if not JXAlive(a) then why = err; return end
        shape = sh
        pcall(function()
            a:SetActorScale3D({ X = 1.0, Y = 1.0, Z = 2.0 })   
            local mesh = J3LoadObject("/Engine/BasicShapes/Cube.Cube")
            if mesh then pcall(function() a.StaticMeshComponent:SetStaticMesh(mesh) end) end
        end)
        JxActor.markerRef = a
        spawned = true
    end)
    if spawned then
        Log("jactor: scale marker spawned next to you (local only, spawn shape="
            .. tostring(shape) .. ")")
    else
        Log(string.format("jactor: spawn refused by the build (%s) - your position is X=%.0f Y=%.0f Z=%.0f",
            tostring(why), pos.X, pos.Y, pos.Z))
    end
    JxActor.marker = spawned
    return spawned
end

local function ScanAllActors(write_file)
    local counts, order, total = {}, {}, 0
    pcall(function()
        local all = FindAllOf("Actor")
        if not all then return end
        for _, a in pairs(all) do
            if JXAlive(a) then
                local cls = ActorClassToken(a)
                if cls ~= "" then
                    if counts[cls] == nil then order[#order + 1] = cls end
                    counts[cls] = (counts[cls] or 0) + 1
                    total = total + 1
                end
            end
        end
    end)
    table.sort(order)
    Log("jactor census: " .. total .. " live actors, " .. #order .. " classes")
    local dump = { "map=" .. CurrentMapName(), "time=" .. Now(),
                   string.format("total=%d classes=%d", total, #order) }
    local shown = 0
    for _, cls in ipairs(order) do
        local line = string.format("  %-52s %d", cls, counts[cls])
        if shown < 40 then Log(line); shown = shown + 1 end
        dump[#dump + 1] = cls .. "=" .. counts[cls]
    end
    if write_file then
        pcall(function()
            local f = io.open(JXRootOr .. "logs/actors_current.txt", "w")
            if f then f:write(table.concat(dump, "\n") .. "\n"); f:close() end
        end)
        Log("census written to logs/actors_current.txt")
    end
    return total, counts, order
end

local function RosterMeshes(write_file, cap)
    cap = cap or 400
    local rows, n = {}, 0
    pcall(function()
        local all = FindAllOf("StaticMeshActor")
        if not all then return end
        for _, a in pairs(all) do
            if JXAlive(a) then
                n = n + 1
                if n <= cap then
                    local name, pos = "", nil
                    pcall(function()
                        name = JXName(a)
                        pos = a:K2_GetActorLocation()
                    end)
                    if pos then
                        rows[#rows + 1] = string.format("%s|%.0f|%.0f|%.0f",
                            name, pos.X, pos.Y, pos.Z)
                    end
                end
            end
        end
    end)
    Log("jactor meshes: " .. n .. " static mesh actors"
        .. (n > cap and (" (first " .. cap .. " captured)") or ""))
    if write_file then
        pcall(function()
            local f = io.open(JXRootOr .. "logs/meshes_current.txt", "w")
            if f then
                f:write("map=" .. CurrentMapName() .. "\n")
                f:write(table.concat(rows, "\n") .. "\n")
                f:close()
            end
        end)
        Log("mesh roster written to logs/meshes_current.txt")
    end
    return n, rows
end
local function CountStaticMeshActors()
    local n = 0
    pcall(function()
        local all = FindAllOf("StaticMeshActor")
        if not all then return end
        for _, a in pairs(all) do if JXAlive(a) then n = n + 1 end end
    end)
    return n
end

local function ActorWatchTick(rounds)
    if not JxActor.protect or JXBusy() then return end
    local n = CountStaticMeshActors()
    if JxActor.baseline < 0 then JxActor.baseline = n end
    if n < JxActor.baseline then
        Log(string.format("jactor: object count dropped %d -> %d (%d gone)",
            JxActor.baseline, n, JxActor.baseline - n))
    end
    JxActor.baseline = n
    if rounds > 0 then
        ExecuteWithDelay(6000, function()
            ExecuteInGameThread(function() pcall(ActorWatchTick, rounds - 1) end)
        end)
    end
end

local JxSet = { chat = false, word = false, nameclean = false, bench = false }

local AD_WORDS = {
    string.char(0xE6, 0x8A, 0x96, 0xE9, 0x9F, 0xB3),           
    string.char(0xE5, 0x93, 0x94, 0xE5, 0x93, 0xA9),           
    string.char(0xE5, 0xBF, 0xAB, 0xE6, 0x89, 0x8B),           
}

local function NameHasAd(name)
    if not name then return false end
    for _, w in ipairs(AD_WORDS) do
        if name:find(w, 1, true) then return true end
    end
    return false
end

local function ScanAdNames()
    local hits = 0
    pcall(function()
        local PCs = FindAllOf("PlayerController")
        if not PCs then return end
        for _, PC in pairs(PCs) do
            if JXAlive(PC) and PC.PlayerState and PC.PlayerState:IsValid() then
                local n = PlayerName(PC.PlayerState)
                if NameHasAd(n) then
                    hits = hits + 1
                    AppendLine(JoinLogFile, string.format("%s  AD-NAME  %s", Now(), n))
                    Log("ad name detected: " .. n)
                end
            end
        end
    end)
    return hits
end

do
    
    local candidates = {
        "ue4ss/Mods/JxLoader/JxLoader.dll",   
        "Mods/JxLoader/JxLoader.dll",         
        "JxLoader.dll",                       
    }
    local loaded = false
    for _, path in ipairs(candidates) do
        local ok, loader = pcall(package.loadlib, path, "JxInit")
        if ok and loader ~= nil then
            Log("JxLoader.dll armed via '" .. path .. "' -> crashlog.txt next to the DLL")
            loaded = true
            break
        end
    end
    if not loaded then
        Log("JxLoader.dll not loaded (tried " .. #candidates .. " paths); crash logging off")
    end
end

do
    
end

do
    local CmdFile = JXRootOr .. "config/jxui_cmd.txt"
    local LastCmd = ""
    local function PollUI()
        ExecuteInGameThread(function()
            pcall(function()
                local f = io.open(CmdFile, "r")
                if f then
                    local line = f:read("*l") or ""
                    f:close()
                    line = line:match("^%s*(.-)%s*$")
                    if line ~= "" and line ~= LastCmd then
                        LastCmd = line
                        Log("JxUI cmd: " .. line)
                        -- r57: ExecuteConsoleCommand is NOT a UE4SS v3.0.1
                        -- global (verified: the name is absent from UE4SS.dll
                        -- while every real global appears 3x). The nil call
                        -- aborted the enclosing pcall, so this file bridge
                        -- never dispatched one command. Route it through the
                        -- project executor (one-arg form acquires the PC).
                        local okx = false
                        if type(_G.JXExecCmd) == "function" then
                            okx = _G.JXExecCmd(line) and true or false
                        end
                        Log("JxUI cmd dispatched=" .. tostring(okx))
                    end
                end
            end)
            ExecuteWithDelay(2000, PollUI)
        end)
    end
    
    ExecuteWithDelay(18000, function()
        ExecuteInGameThread(function()
            pcall(function()
                local f = io.open(CmdFile, "r")
                if f then
                    local line = (f:read("*l") or ""):match("^%s*(.-)%s*$")
                    f:close()
                    if line ~= "" then
                        Log("JxUI cmd stale leftover discarded: " .. line)
                        local w = io.open(CmdFile, "w")
                        if w then w:close() end
                        return
                    end
                end
                Log("JxUI cmd poller SKIPPED (overlay disabled, no cmd file) - saves 2 file opens/sec")
            end)
        end)
    end)
end

local ModDir       = JXEarlyRoot or "Mods/JinxingLoaderRT/"
local SettingsFile = ModDir .. "config/settings.txt"
local BlacklistF   = ModDir .. "config/blacklist.txt"
JoinLogFile  = ModDir .. "logs/join_records.txt"
local PlayersFile  = ModDir .. "logs/players_current.txt"

-- r56: global - JxPlayerHub reads it for the room-cap display
Config = { MaxPlayers = 128 }
local Blacklist = {}          
local BlacklistOrder = {}     
local SeenThisSession = {}

local function FileLines(path)
    local out = {}
    local f = io.open(path, "r")
    if not f then return out end
    for line in f:lines() do
        local t = line:gsub("^%s+", ""):gsub("%s+$", "")
        if t ~= "" and t:sub(1, 1) ~= ";" and t:sub(1, 1) ~= "#" then
            out[#out + 1] = t
        end
    end
    f:close()
    return out
end

function AppendLine(path, line)
    local f = io.open(path, "a")
    if not f then return end
    f:write(line .. "\n")
    f:close()
end

local function WriteAll(path, text)
    local f = io.open(path, "w")
    if not f then return end
    f:write(text)
    f:close()
end

function Now()
    return os.date("%Y-%m-%d %H:%M:%S")
end

local function LoadConfig()
    for _, line in ipairs(FileLines(SettingsFile)) do
        local k, v = line:match("^([%w_]+)%s*=%s*(.+)$")
        if k == "max_players" then
            local n = tonumber(v)
            if n and n >= 1 and n <= 512 then Config.MaxPlayers = math.floor(n) end
        end
    end
    Blacklist = {}
    BlacklistOrder = {}
    for _, line in ipairs(FileLines(BlacklistF)) do
        if not Blacklist[line:lower()] then
            Blacklist[line:lower()] = true
            BlacklistOrder[#BlacklistOrder + 1] = line
        end
    end
    Log(string.format("config loaded: max_players=%d, blacklist entries=%d",
        Config.MaxPlayers, #BlacklistOrder))
end

local function PlayerId(PS)
    local ok, id = pcall(function()
        if PS.UniqueId then
            local u = PS.UniqueId
            if type(u) == "userdata" and u.ToString then return u:ToString() end
            if u.UniqueNetId and u.UniqueNetId.ToString then return u.UniqueNetId:ToString() end
        end
        return nil
    end)
    if ok and id and tostring(id) ~= "" then return tostring(id) end
    return "unknown"
end

function PlayerName(PS)
    
    local function Pick(v)
        if v == nil then return nil end
        if type(v) == "string" then return v end
        if type(JxStr) == "function" then
            local ok, s = pcall(JxStr, v)
            if ok and type(s) == "string" and s ~= "" then return s end
        end
        local ok, s = pcall(function() return v:ToString() end)
        if ok and type(s) == "string" and s ~= "" then return s end
        return tostring(v)
    end
    local candidates = {}
    pcall(function()
        local n = PS.PlayerName
        if n and n ~= "" then candidates[#candidates + 1] = Pick(n) end
    end)
    pcall(function()
        local n = PS.PlayerNamePrivate
        if n and n ~= "" then candidates[#candidates + 1] = Pick(n) end
    end)
    pcall(function()
        local s = PS:ToString()
        if s and s ~= "" then candidates[#candidates + 1] = tostring(s) end
    end)
    pcall(function()
        local fn = PS:GetFullName() or ""
        local tail = fn:match("([%w_%-]+)%.[%w_%-]+_C$") or fn:match("PersistentLevel%.([%w_%-%.]+)$")
        if tail and tail ~= "" then candidates[#candidates + 1] = tail end
    end)
    for _, n in ipairs(candidates) do
        n = tostring(n):gsub("^%s+", ""):gsub("%s+$", "")
        if n ~= "" and n ~= "None" and n ~= "player" then return n end
    end
    return "player"
end

local function GetSteam64()
    local ok, id = pcall(function()
        local GI = UEHelpers.GetGameInstance()
        if not GI or not GI:IsValid() then return nil end
        local OSS = GI:GetOnlineSubsystem("Steam")
        if not OSS or not OSS:IsValid() then OSS = GI:GetOnlineSubsystem(nil) end
        if OSS and OSS:IsValid() then
            local Ident = OSS:GetIdentityInterface()
            if Ident and Ident:IsValid() then
                local UID = Ident:GetUniquePlayerId(0)
                if UID and UID:IsValid() then
                    local s = UID:ToString()
                    if s then return s end
                end
            end
        end
        local PC = UEHelpers.GetPlayerController()
        if PC and PC:IsValid() and PC.Player and PC.Player:IsValid() then
            local LP = PC.Player
            if LP.GetPreferredUniqueNetId then
                local uid = LP:GetPreferredUniqueNetId()
                if uid and uid:IsValid() then return uid:ToString() end
            end
        end
        return nil
    end)
    if not ok or not id then return "unknown" end
    id = tostring(id)
    local digits = id:match("(%d%d%d%d%d%d%d%d%d%d%d+)")
    if digits then return digits end
    return id
end

local function Steam64FromNetId(netid)
    if not netid or netid == "unknown" then return nil end
    local d = tostring(netid):match("(%d%d%d%d%d%d%d%d%d%d%d+)")
    if d then return d end
    return nil
end

local function GetPlatformId()
    local ok, s = pcall(function()
        local states = UEHelpers.GetAllPlayerStates()
        if states and states[1] and states[1]:IsValid() then
            local u = states[1].UniqueId
            if u then
                if type(u) == "userdata" and u.ToString then return u:ToString() end
                if u.UniqueNetId and u.UniqueNetId.ToString then return u.UniqueNetId:ToString() end
            end
        end
        return nil
    end)
    if ok and s then return tostring(s) end
    return "unknown"
end

local LastAppliedCap = nil
local LastQuietTry = 0

local function ApplyMaxPlayers(bVerbose)
    if not bVerbose then
        local t = os.time()
        if t - LastQuietTry < 2 then return false end
        LastQuietTry = t
    end
    local GM = UEHelpers.GetGameModeBase()
    if not GM or not GM:IsValid() then
        if bVerbose then Log("no authority GameMode here (client, or not in a session yet)") end
        return false
    end
    local wrote = false
    local ok = pcall(function()
        local GS = GM.GameSession
        if GS and GS:IsValid() then
            GS.MaxPlayers = Config.MaxPlayers
            wrote = true
        end
    end)
    if not ok then
        if bVerbose then Log("failed writing GameSession.MaxPlayers") end
        return false
    end
    if not wrote then
        if bVerbose then Log("GameSession not available yet; cap not applied") end
        return false
    end
    if bVerbose or LastAppliedCap ~= Config.MaxPlayers then
        Log("MaxPlayers applied: " .. Config.MaxPlayers)
        LastAppliedCap = Config.MaxPlayers
    end
    return true
end

local Fly = { On = false, PrevMaxFly = nil }
do
-- r56: global - FlyVerticalTick (a later chunk) read this as a nil global,
-- so vertical fly never saw the toggle state
FlyOn = false

local FlyTickOn = false
local FlyTickN = 0
local FlyLastWhy = ""
local FlyJumpUntil = 0
local FlyCrouchUntil = 0
local FLY_TICK_MS = 100
local FLY_CLIMB = 900.0

local FLY_CRUISE = 900.0

local function ReadNumProp(obj, name)
    local v = nil
    pcall(function() v = obj[name] end)
    if type(v) == "number" then return v end
    return nil
end
local function ReadMoveMode(Move) return ReadNumProp(Move, "MovementMode") end

local function RealMoveComp(m)
    if not m then return false end
    local ok = false
    pcall(function() ok = m:IsValid() end)
    if not ok then return false end
    if ReadNumProp(m, "MaxFlySpeed") ~= nil then return true end
    if ReadMoveMode(m) ~= nil then return true end
    return false
end

local function FlyCtx()
    local PC, pawn, cm = nil, nil, nil
    pcall(function() PC = UEHelpers.GetPlayerController() end)
    pcall(function() pawn = UEHelpers.GetPlayer() end)
    if JXAlive(pawn) then
        
        pcall(function()
            local m = pawn:GetCharacterMovement()
            if RealMoveComp(m) then cm = m end
        end)
        if not cm then
            pcall(function()
                local m = pawn:GetMovementComponent()
                if RealMoveComp(m) then cm = m end
            end)
        end
        if not cm then
            pcall(function()
                local m = pawn.CharacterMovement
                if RealMoveComp(m) then cm = m end
            end)
        end
    end
    return PC, pawn, cm
end

local function FlyWriteZ(cm, z)
    local ok = false
    pcall(function()
        local v = cm.Velocity
        v.Z = z
        ok = true
    end)
    return ok
end

local function FlyReadZ(cm)
    local z = nil
    pcall(function() z = tonumber(cm.Velocity.Z) end)
    return z
end

local function FlyVertical(pawn, cm)
    if not (JXAlive(pawn) and JXAlive(cm)) then return 0.0, "noctx" end
    local up = (JXClock() < FlyJumpUntil)
    if not up then
        pcall(function()
            local b = pawn.bPressedJump
            if b == true or b == 1 then up = true end
        end)
    end
    local down = (JXClock() < FlyCrouchUntil)
    if not down then
        pcall(function()
            local b = cm.bWantsToCrouch
            if b == true or b == 1 then down = true end
        end)
    end
    if up and not down then return FLY_CLIMB, "jump" end
    if down and not up then return -FLY_CLIMB, "crouch" end
    return 0.0, "level"
end

-- r56: globals - FlyVerticalTick lives in a later chunk and read these as
-- nil globals, so vertical fly (crouch/jump) never moved the pawn
function FlyAcquirePawn()
    local pawn, cm = nil, nil
    pcall(function() pawn = UEHelpers.GetPlayer() end)
    if JXAlive(pawn) then
        pcall(function()
            local m = pawn:GetCharacterMovement()
            if RealMoveComp(m) then cm = m end
        end)
        if not cm then
            pcall(function()
                local m = pawn:GetMovementComponent()
                if RealMoveComp(m) then cm = m end
            end)
        end
        if not cm then
            pcall(function()
                local m = pawn.CharacterMovement
                if RealMoveComp(m) then cm = m end
            end)
        end
    end
    return pawn, cm
end

local FLY_REACQ_TICKS = 150      
local FlyWait = 0
local FlyLastZ = nil             

local FlyCache = { pawn = nil, cm = nil, age = 0 }
local FlyLastZSent = nil      
local FlyBridgeOn = false     

local function FlyBridgeOff()
    pcall(function()
        local a = FindFirstOf("BP_JinxingLoaderCore_C")
        if a and a:IsValid() then
            a.JXFlyAssist = false
        end
    end)
    FlyBridgeOn = false
    FlyLastZSent = nil
end
local function FlyTickBody()
    FlyTickN = FlyTickN + 1
    if not (JXAlive(FlyCache.pawn) and JXAlive(FlyCache.cm)) or (FlyCache.age % 100) == 0 then
        FlyCache.pawn, FlyCache.cm = FlyAcquirePawn()
        FlyCache.age = 0
    end
    FlyCache.age = FlyCache.age + 1
    local pawn, cm = FlyCache.pawn, FlyCache.cm
    if not (JXAlive(pawn) and JXAlive(cm)) then
        if not Fly.On then
            FlyTickOn = false
            Log("fly driver stopped: pawn or movement component is gone")
            return
        end
        FlyWait = FlyWait + 1
        if FlyWait == 1 then
            Log("fly: pawn gone (level change) - holding flight until the new pawn is up")
        end
        if FlyWait > FLY_REACQ_TICKS then
            FlyTickOn = false
            Fly.On = false
            FlyOn = false
            FlyBridgeOff()
            Log("fly OFF - no usable pawn for " .. tostring(FLY_REACQ_TICKS / 10) .. "s, flight cannot drive anything")
            return
        end
        
        if JXAlive(pawn) and (FlyWait % 10) == 1 and Fly.Set then
            if Fly.Set(true) then
                FlyWait = 0
                Log("fly re-armed on the new pawn after the level change")
            end
        end
        return
    end
    if FlyWait > 0 then FlyWait = 0 end
    local z, why = FlyVertical(pawn, cm)
    
    if z ~= FlyLastZSent then
        local bridged = false
        
        if not FlyCoreDead then
            pcall(function()
                local a = FindFirstOf("BP_JinxingLoaderCore_C")
                if a and a:IsValid() and a:GetWorld() ~= nil then
                    a.JXFlyZTarget = z
                    a.JXFlyAssist = true
                    bridged = true
                else
                    FlyCoreDead = true
                end
            end)
        end
        if bridged and not FlyBridgeOn then
            Log("fly: blueprint assist engaged (per-frame native Z writes; lua keeps the key scan)")
        end
        FlyBridgeOn = bridged
        FlyLastZSent = z
        if not bridged then
            FlyWriteZ(cm, z)
        end
    elseif not FlyBridgeOn then
        FlyWriteZ(cm, z)
    end
    
    if why ~= FlyLastWhy then
        FlyLastWhy = why
        Log("fly input -> " .. why .. " vz=" .. string.format("%.0f", z))
    end
    if FlyTickN <= 3 or (FlyTickN % 30) == 0 then
        
        local pz = nil
        pcall(function()
            local l = pawn:K2_GetActorLocation()
            pz = tonumber(l.Z)
        end)
        local dz = "n/a"
        if pz ~= nil then
            if FlyLastZ ~= nil then dz = string.format("%+.0f", pz - FlyLastZ) end
            FlyLastZ = pz
        end
        Log("fly tick " .. FlyTickN .. " vz=" .. string.format("%.0f", z)
            .. " now=" .. string.format("%.0f", FlyReadZ(cm) or -99999.0)
            .. " z=" .. (pz ~= nil and string.format("%.0f", pz) or "?")
            .. " dz=" .. dz .. " via=" .. why)
    end
end

local function FlyTick()
    if not FlyTickOn then return end
    local ok, err = pcall(FlyTickBody)
    if not ok then
        
        Log("fly driver tick error (driver keeps running): " .. tostring(err))
        FlyCache.pawn, FlyCache.cm = nil, nil
    end
    if FlyTickOn then
        ExecuteWithDelay(FLY_TICK_MS, function() ExecuteInGameThread(function() pcall(FlyTick) end) end)
    end
end

local function FlyStart()
    if FlyTickOn then return end
    FlyTickOn = true
    FlyTickN = 0
    FlyLastZ = nil
    ExecuteInGameThread(function() pcall(FlyTick) end)
end

local function FlyStop()
    if not FlyTickOn then return end
    FlyTickOn = false
    local _, _, cm = FlyCtx()
    if JXAlive(cm) then FlyWriteZ(cm, 0.0) end
    FlyBridgeOff()
    Log("fly driver stopped after " .. FlyTickN .. " ticks")
end

local function FlyKeyHooks()
    local a = pcall(RegisterHook, "/Script/Engine.Character:Jump", function()
        FlyJumpUntil = JXClock() + 350
    end)
    local b = pcall(RegisterHook, "/Script/Engine.Character:StopJumping", function()
        FlyJumpUntil = 0
    end)
    local c = pcall(RegisterHook, "/Script/Engine.Character:Crouch", function()
        FlyCrouchUntil = JXClock() + 350
    end)
    local d = pcall(RegisterHook, "/Script/Engine.Character:UnCrouch", function()
        FlyCrouchUntil = 0
    end)
    Log("fly keys: Jump=" .. tostring(a) .. " StopJumping=" .. tostring(b)
        .. " Crouch=" .. tostring(c) .. " UnCrouch=" .. tostring(d))
end
FlyKeyHooks()

local function SetFly(enable)
    local Pawn = UEHelpers.GetPlayer()
    if not Pawn or not Pawn:IsValid() then
        
        Log("fly: no local pawn yet - wait until you are spawned in a level")
        return false
    end

    local Move = nil
    pcall(function()
        local m = Pawn:GetCharacterMovement()
        if RealMoveComp(m) then Move = m end
    end)
    if not Move then
        pcall(function()
            local m = Pawn:GetMovementComponent()
            if RealMoveComp(m) then Move = m end
        end)
    end
    if not Move then
        pcall(function()
            local m = Pawn.CharacterMovement
            if RealMoveComp(m) then Move = m end
        end)
    end
    if not Move then
        Log("fly: " .. JXName(Pawn) .. " has no usable movement component (collision untouched)")
        return false
    end

    local Want = enable and 5 or 1   
    local ok, e = pcall(function()
        if enable then
            
            pcall(function() Fly.PrevMaxFly = tonumber(Move.MaxFlySpeed) end)
            Move.MaxFlySpeed = FLY_CRUISE
            
            Move.BrakingDecelerationFlying = 1200.0
        else
            
            if type(Fly.PrevMaxFly) == "number" and Fly.PrevMaxFly > 0 then
                pcall(function() Move.MaxFlySpeed = Fly.PrevMaxFly end)
            end
        end
        
        local called = false
        pcall(function()
            Move:SetMovementMode(Want, 0)
            called = true
        end)
        if not called then
            Move.MovementMode = Want
        end
        
        pcall(function() Move.bCheatFlying = false end)
    end)
    if not ok then
        Log("fly: " .. (enable and "enable" or "disable") .. " failed - " .. tostring(e))
        return false
    end

    local now = ReadMoveMode(Move)
    local live = false
    local why = ""
    if now ~= nil then
        live = (math.floor(now) == Want)
        if not live then why = "readback " .. tostring(now) .. " != " .. tostring(Want) end
    else
        
        local mfs = ReadNumProp(Move, "MaxFlySpeed")
        if mfs ~= nil then
            live = true
            why = "mode readback unavailable (proxy); accepted on MaxFlySpeed=" .. tostring(mfs)
        else
            why = "MovementMode and MaxFlySpeed both unreadable on this object"
        end
    end
    if enable and not live then
        
        Log("fly: not enabled (" .. why .. ") - collision left ON so the pawn stays solid")
        return false
    end
    pcall(function() Pawn:SetActorEnableCollision(not enable) end)
    FlyOn = enable
    Fly.On = enable   
    if enable then
        FlyStart()
        Log("fly ON (noclip) - mode " .. tostring(now) .. ", collision off, vertical driver on"
            .. " (level flight; hold Space to climb, Ctrl to descend)")
    else
        FlyStop()
        Log("fly OFF - movement mode readback " .. tostring(now) .. (live and ", collision restored" or ", collision restored (mode not 1 yet)"))
    end
    if why ~= "" then Log("fly: " .. why) end
    return true
end

local function ToggleFly() SetFly(not FlyOn) end

Fly.Set = SetFly
Fly.Toggle = ToggleFly

Fly.ReArm = function()
    if not Fly.On then return false end
    if FlyTickOn then return true end
    local ok = SetFly(true)
    if ok then Log("fly re-armed on the new pawn after the map change") end
    return ok
end

Fly.Status = function() return FlyLastWhy, FlyTickN end
Fly.Up = function() FlyJumpUntil = JXClock() + 1500; FlyCrouchUntil = 0 end
Fly.Down = function() FlyCrouchUntil = JXClock() + 1500; FlyJumpUntil = 0 end
end   

-- r56: global - JxPlayerHub reads this for the player-census rows
function CollectPlayers()
    local rows = {}
    local states = UEHelpers.GetAllPlayerStates()
    for i = 1, #states do
        local PS = states[i]
        if PS and PS:IsValid() then
            local net = PlayerId(PS)
            local sid = Steam64FromNetId(net) or GetSteam64()
            local isLocal = false
            pcall(function()
                local PC = UEHelpers.GetPlayerController()
                if PC and PC:IsValid() and PS == PC.PlayerState then isLocal = true end
            end)
            rows[#rows + 1] = { ps = PS, name = PlayerName(PS), net = net,
                                steam64 = sid, localPlayer = isLocal }
        end
    end
    return rows
end

local function ListPlayers()
    local rows = CollectPlayers()
    local lines = {}
    for i, r in ipairs(rows) do
        lines[#lines + 1] = string.format("[%d] %-24s Steam64=%s net=%s%s",
            i, r.name, r.steam64, r.net, r.localPlayer and " (you)" or "")
    end
    local body = string.format("=== players in room: %d (cap %d) @ %s ===\n",
        #rows, Config.MaxPlayers, Now()) .. table.concat(lines, "\n") .. "\n"
    body = body .. string.format("Your Steam64: %s | Platform: %s\n", GetSteam64(), GetPlatformId())
    print(TAG .. body)
    WriteAll(PlayersFile, body)
    return rows
end

function JXKickToMenu(PC, why)
    if not JXAlive(PC) then return false end
    if pcall(function() PC:ClientReturnToMainMenu(why) end) then return true end
    return JXExecCmd(PC, "disconnect")
end

local function IsBlacklisted(name, id)
    if name and Blacklist[name:lower()] then return true end
    if id and id ~= "unknown" and Blacklist[id:lower()] then return true end
    if id then
        local d = Steam64FromNetId(id)
        if d and Blacklist[d] then return true end
    end
    return false
end

local function SaveBlacklist()
    local lines = {}
    for _, e in ipairs(BlacklistOrder) do lines[#lines + 1] = e end
    WriteAll(BlacklistF, "# One entry per line: a player name or a SteamID64.\n"
        .. table.concat(lines, "\n") .. "\n")
end

local function AddBlacklist(entry)
    entry = tostring(entry):gsub("^%s+", ""):gsub("%s+$", "")
    if entry == "" then return false end
    if not Blacklist[entry:lower()] then
        Blacklist[entry:lower()] = true
        BlacklistOrder[#BlacklistOrder + 1] = entry
        SaveBlacklist()
    end
    return true
end

local function RemoveBlacklist(idx)
    local e = BlacklistOrder[idx]
    if not e then return false end
    Blacklist[e:lower()] = nil
    table.remove(BlacklistOrder, idx)
    SaveBlacklist()
    return true
end

local function EnforceBlacklist()
    
    if JXTransferGuard() then return 0 end
    
    if not JXThrottle("blacklist", 2000) then return 0 end
    local kicked = 0
    local PCs = FindAllOf("PlayerController")
    if not PCs then return 0 end
    for _, PC in pairs(PCs) do
        if PC and PC:IsValid() then
            local ok = pcall(function()
                local PS = PC.PlayerState
                if not PS or not PS:IsValid() then return end
                if PC.IsLocalController and PC:IsLocalController() then return end
                local name, id = PlayerName(PS), PlayerId(PS)
                if IsBlacklisted(name, id) then
                    if JXKickToMenu(PC, "Removed by host (blacklist)") then
                        kicked = kicked + 1
                        AppendLine(JoinLogFile, string.format("%s  KICKED (blacklist)  name=%s id=%s", Now(), name, id))
                        Log("kicked blacklisted player: " .. name .. " / " .. id)
                    end
                end
            end)
            if not ok then Log("blacklist check failed on a controller (ignored)") end
        end
    end
    return kicked
end

_G.JXBlacklistAdd = AddBlacklist
_G.JXBlacklistEnforce = EnforceBlacklist
_G.JXBlacklistRemoveEntry = function(entry)
    entry = tostring(entry):gsub("^%s+", ""):gsub("%s+$", ""):lower()
    if entry == "" then return false end
    for idx = #BlacklistOrder, 1, -1 do
        if tostring(BlacklistOrder[idx]):lower() == entry then
            return RemoveBlacklist(idx)
        end
    end
    return false
end

local function RecordJoin(PS)
    if not PS or not PS:IsValid() then return end
    local name, id = PlayerName(PS), PlayerId(PS)
    local key = name .. "|" .. id
    if SeenThisSession[key] then return end
    SeenThisSession[key] = true
    local sid = Steam64FromNetId(id) or GetSteam64()
    AppendLine(JoinLogFile, string.format("%s  JOIN  name=%s id=%s steam64=%s", Now(), name, id, sid))
    Log("join recorded: " .. name .. " / " .. id .. " / " .. sid)
end

local U = (utf8 and utf8.char) or function() return "?" end

local L = {
    players   = U(0x73A9, 0x5BB6),                          
    blacklist = U(0x9ED1, 0x540D, 0x5355),                  
    settings  = U(0x8BBE, 0x7F6E),                          
    page      = U(0x9875),                                  
    kick      = U(0x8E22, 0x51FA, 0x5E76, 0x62C9, 0x9ED1),  
    unban     = U(0x79FB, 0x9664),                          
    close     = U(0x5173, 0x95ED),                          
    switch    = U(0x6362, 0x9875),                          
    cap       = U(0x4EBA, 0x6570, 0x4E0A, 0x9650),          
    opt       = U(0x5168, 0x5C40, 0x4F18, 0x5316),          
    on        = U(0x5F00),                                  
    off       = U(0x5173),                                  
    none      = U(0x65E0, 0x73A9, 0x5BB6),                  
    empty     = U(0x7A7A),                                  
    you       = U(0x4F60),                                  
    enterAct  = U(0x786E, 0x8BA4),                          
    maps      = U(0x5730, 0x56FE),                          
    travel    = U(0x5207, 0x6362, 0x5730, 0x56FE),          
    nomaps    = U(0x65E0, 0x5730, 0x56FE),                  
    scanning  = U(0x626B, 0x63CF, 0x4E2D),                  
    current   = U(0x5F53, 0x524D),                          
    quality   = U(0x753B, 0x8D28, 0x533A, 0x5757),          
    viewdist  = U(0x89C6, 0x8DDD),                          
    slod      = U(0x9759, 0x6001, 0x7F51, 0x683C, 0x4F4E, 0x4C4F, 0x44), 
    blod      = U(0x9AA8, 0x9ABC, 0x4F4E, 0x4C4F, 0x44),    
    flod      = U(0x690D, 0x88AB, 0x4C4F, 0x44),            
    pool      = U(0x7EB9, 0x7406, 0x6C60),                  
    uro       = U(0x9AA8, 0x9ABC, 0x66F4, 0x65B0),          
    aa        = U(0x6297, 0x9527, 0x9F7F),                  
    presPerf  = U(0x6027, 0x80FD, 0x9884, 0x8BBE),          
    presBal   = U(0x5747, 0x8861, 0x9884, 0x8BBE),          
    presQual  = U(0x753B, 0x8D28, 0x9884, 0x8BBE),          
    restDef   = U(0x6062, 0x590D, 0x9ED8, 0x8BA4),          
    apply     = U(0x5E94, 0x7528),                          
    lr        = U(0x62C9, 0x6ED1),                          
    auto      = U(0x81EA, 0x52A8),                          
    preset    = U(0x9884, 0x8BBE),                          
    post      = U(0x540E, 0x5904, 0x7406),                  
    fx        = U(0x7279, 0x6548),                          
    fol       = U(0x690D, 0x88AB),                          
    tex       = U(0x7EB9, 0x7406),                          
    mip       = U(0x7EB9, 0x7406, 0x504F, 0x79FB),          
    det       = U(0x7EC6, 0x8282),                          
    per        = U(0x5143, 0x7D20),                          
}

local MapsFile   = ModDir .. "config/maps.txt"
local MapList    = {}
local MapScan    = "idle"        
local MapScanMsg = ""

local SEED_MAPS = {
    "/Game/Maps/Level0",
    "/Game/Maps/Tunnel/OldElevator",
    "/Game/Maps/Garage/GarageLevel2",
    "/Game/Maps/Garage/BottomFloor",
    "/Game/Maps/Garage/MiddleFloor",
    "/Game/Maps/Pipes",
    "/Game/Maps/ElectricalStation",
    "/Game/Maps/Office",
    "/Game/Maps/Hotel",
    "/Game/Maps/Hotel/Hive",
    "/Game/Maps/Hotel/BoilerRoom",
    "/Game/Maps/LevelFun",
    "/Game/Maps/Poolrooms",
    "/Game/Maps/LevelRun",
    "/Game/Maps/TheEnd",
    "/Game/Maps/Level94",
    "/Game/Maps/AnimatedKingdom",
    "/Game/Maps/LightsOut",
    "/Game/Maps/OceanMap",
    "/Game/Maps/CaveLevel",
    "/Game/Maps/Level0/ManillaRoom",
    "/Game/Maps/Level9",
    "/Game/Maps/Level10",
    "/Game/Maps/Level3999",
    "/Game/Maps/Level0/Pitfalls",
    "/Game/Maps/Snackrooms",
    "/Game/Maps/LevelDash",
    "/Game/Maps/Level188_Expanded",
    "/Game/Maps/LevelCheat",
    "/Game/Maps/Poolrooms_Expanded",
    "/Game/Maps/LevelFun_Expanded",
    "/Game/Maps/Fun/Zone1_Modified",
    "/Game/Maps/Fun/Zone2_Modified",
    "/Game/Maps/Fun/Zone3_Baked",
    "/Game/Maps/Fun/Zone4",
    "/Game/Maps/Level52",
    "/Game/Maps/TheEnd/TheEndExpansion",
    "/Game/Maps/TheHub",
    "/Game/Maps/Grassrooms_Expanded",
    "/Game/Maps/Level974",
}

local PerfFile = ModDir .. "config/perf.txt"

local FX_FANOUT = {
    
    [0] = { "r.TranslucencyLightingVolumeDim 24", "r.EmitterSpawnRateScale 0.125", "r.ParticleLightQuality 0", "fx.Niagara.QualityLevel 0" },
    [1] = { "r.TranslucencyLightingVolumeDim 32", "r.EmitterSpawnRateScale 0.25",  "r.ParticleLightQuality 0", "fx.Niagara.QualityLevel 1" },
    [2] = { "r.TranslucencyLightingVolumeDim 48", "r.EmitterSpawnRateScale 0.5",   "r.ParticleLightQuality 1", "fx.Niagara.QualityLevel 2" },
    [3] = { "r.TranslucencyLightingVolumeDim 64", "r.EmitterSpawnRateScale 1.0",   "r.ParticleLightQuality 2", "fx.Niagara.QualityLevel 3" },
    [4] = { "r.TranslucencyLightingVolumeDim 64", "r.EmitterSpawnRateScale 1.0",   "r.ParticleLightQuality 2", "fx.Niagara.QualityLevel 4" },
}

local MOTION_FAN = {
    [0] = { "r.DefaultFeature.MotionBlur 0", "r.MotionBlurQuality 0", "r.MotionBlur.Amount 0", "r.MotionBlur.Max -1" },
    [1] = { "r.DefaultFeature.MotionBlur 1", "r.MotionBlurQuality 1", "r.MotionBlur.Amount 0.25" },
    [2] = { "r.DefaultFeature.MotionBlur 1", "r.MotionBlurQuality 2", "r.MotionBlur.Amount 0.5" },
    [3] = { "r.DefaultFeature.MotionBlur 1", "r.MotionBlurQuality 3", "r.MotionBlur.Amount 0.75" },
    [4] = { "r.DefaultFeature.MotionBlur 1", "r.MotionBlurQuality 4", "r.MotionBlur.Amount 1.0" },
}
local PerfItems = {
    { key = "viewdist", cvar = "r.ViewDistanceScale",          min = 0.4,  max = 1.2, step = 0.1,  def = 1.0, cur = 1.0, label = L.viewdist },
    { key = "slod",     cvar = "r.StaticMeshLODDistanceScale", min = 0.5,  max = 4.0, step = 0.25, def = 1.0, cur = 1.0, label = L.slod },
    { key = "blod",     cvar = "r.SkeletalMeshLODDistanceScale",min = 0.5, max = 4.0, step = 0.25, def = 1.0, cur = 1.0, label = L.blod },
    { key = "flod",     cvar = "foliage.LODDistanceScale",     min = 0.5,  max = 3.0, step = 0.25, def = 1.0, cur = 1.0, label = L.flod },
    
    { key = "pool",     cvar = "r.Streaming.PoolSize",         min = -1,   max = 2048,step = 128,  def = -1,  cur = -1,  label = L.pool, auto = -1 },
    { key = "uro",      cvar = "a.URO.Enable",                 min = 0,    max = 1,   step = 1,    def = 0,   cur = 0,   label = L.uro },
    { key = "aa",       cvar = "sg.AntiAliasingQuality",       min = 0,    max = 4,   step = 1,    def = 4,   cur = 4,   label = L.aa },
    
    { key = "shadow",   cvar = "sg.ShadowQuality",             min = 0,    max = 4,   step = 1,    def = 3,   cur = 3,   label = L.shadow },
    { key = "post",     cvar = "sg.PostProcessQuality",        min = 0,    max = 4,   step = 1,    def = 3,   cur = 3,   label = L.post },
    { key = "fx",       fan = FX_FANOUT,                        min = 0,    max = 4,   step = 1,    def = 3,   cur = 3,   label = L.fx },
    
    { key = "motion",   fan = MOTION_FAN,                       min = 0,    max = 4,   step = 1,    def = 0,   cur = 0,   label = nil },
    
    { key = "fol",      cvar = "sg.FoliageQuality",            min = 0,    max = 3,   step = 1,    def = 3,   cur = 3,   label = L.fol },
    { key = "tex",      cvar = "sg.TextureQuality",            min = 0,    max = 3,   step = 1,    def = 3,   cur = 3,   label = L.tex },
    { key = "mip",      cvar = "r.MipMapLODBias",              min = 0,    max = 4,   step = 1,    def = 0,   cur = 0,   label = L.mip },
    { key = "det",      cvar = "r.DetailMode",                 min = 0,    max = 2,   step = 1,    def = 2,   cur = 2,   label = L.det },
}

-- r57: JxPerfGuard.lua line 4 captures _G.JXPerfBridge at load time and
-- nothing in the tree ever defined it, so its B stayed nil for good: Exec fell
-- through to the bare ExecuteConsoleCommand global (NOT a UE4SS v3.0.1 symbol,
-- verified against UE4SS.dll), so no cvar it asked for was ever applied, the
-- slider-item feed (PerfItems) was dead, and jguard reported "bridge missing".
-- Closures only - no new top-level local (main chunk is near the 200 cap).
_G.JXPerfBridge = {
    Log = Log,
    Exec = function(PC, cmd)
        if PC ~= nil and JXExecCmd(PC, cmd) then return true end
        if type(JXExecutor) == "function" then return JXExecutor(cmd) and true or false end
        return false
    end,
    Queue = function(list) JXQueue(list) return true end,
    PerfItems = function() return PerfItems end,
    SidecarDir = function() return _G.JXSidecarDir or "" end,
}

local PerfPresets = {
    
    { key = "perf", label = L.presPerf, vals = { viewdist = 0.7, slod = 0.5, blod = 0.5, flod = 0.5, pool = 1024, uro = 1, aa = 1, shadow = 1, post = 1, fx = 1, fol = 1, tex = 1, mip = 2, det = 1 } },
    
    { key = "bal",  label = L.presBal,  vals = { viewdist = 0.85, slod = 0.75, blod = 0.75, flod = 0.75, pool = -1,  uro = 1, aa = 2, shadow = 2, post = 2, fx = 2, fol = 2, tex = 2, mip = 1, det = 2 } },
    
    { key = "qual", label = L.presQual, vals = { viewdist = 1.0, slod = 1.0, blod = 1.0, flod = 1.0, pool = -1,   uro = 0, aa = 4, shadow = 4, post = 4, fx = 4, fol = 3, tex = 3, mip = 0, det = 2 } },
}
local function PerfIdxFromKey(k)
    for i, it in ipairs(PerfItems) do
        if it.key == k then return i end
    end
    return nil
end
local function PerfClamp(i, v)
    local it = PerfItems[i]
    if not it then return end
    if v < it.min then v = it.min end
    if v > it.max then v = it.max end
    
    if it.auto ~= nil and v == it.auto then
        it.cur = v
        return
    end
    v = math.floor((v / it.step) + 0.5) * it.step
    if v < it.min then v = it.min end
    if v > it.max then v = it.max end
    it.cur = v
end

local PERF_FIRSTRUN = { viewdist = 0.9, slod = 0.8, blod = 0.8, flod = 0.8, uro = 0 }

local function PerfLoad()
    local f = io.open(PerfFile, "r")
    if not f then
        for k, v in pairs(PERF_FIRSTRUN) do
            local i = PerfIdxFromKey(k)
            if i then PerfClamp(i, v) end
        end
        return
    end
    
    for line in f:lines() do
        local k, v = line:match("^([%w_]+)%s*=%s*(%-?[%d%.]+)%s*$")
        if k then
            local i = PerfIdxFromKey(k)
            if i then PerfClamp(i, tonumber(v) or PerfItems[i].def) end
        end
    end
    f:close()
    
    local pi = PerfIdxFromKey("pool")
    if pi and PerfItems[pi].cur == 0 and PerfItems[pi].auto ~= nil then
        PerfClamp(pi, PerfItems[pi].auto)
    end

    -- r30: a.URO.Enable=1 makes the engine skip animation updates, which
    -- reads as "player has no actions" in the floors; older perf.txt saves
    -- persisted uro=1, so force it back off on every load
    local ui = PerfIdxFromKey("uro")
    if ui then PerfClamp(ui, 0) end
end

PerfDirty = false
PerfFlushPending = false
local PERF_FLUSH_MS = 400

local PerfFlushToDisk
local function PerfSave()
    PerfDirty = true
    if PerfFlushPending then return end
    PerfFlushPending = true
    ExecuteWithDelay(PERF_FLUSH_MS, function()
        ExecuteInGameThread(function() pcall(PerfFlushToDisk) end)
    end)
end

local function PerfWriteGameIni()
    pcall(function()
        local lad = os.getenv("LOCALAPPDATA")
        if not lad or lad == "" then return end
        local ini = lad .. "\\EscapeTheBackrooms\\Saved\\Config\\WindowsNoEditor\\GameUserSettings.ini"
            
            local map = {
                { key = "aa",     ini = "SG.AntiAliasingQuality", sg = "sg.AntiAliasingQuality" },
                { key = "shadow", ini = "SG.ShadowQuality",       sg = "sg.ShadowQuality" },
                { key = "post",   ini = "SG.PostProcessQuality",  sg = "sg.PostProcessQuality" },
                { key = "fol",    ini = "SG.FoliageQuality",      sg = "sg.FoliageQuality" },
                { key = "tex",    ini = "SG.TextureQuality",      sg = "sg.TextureQuality" },
                { ini = "SG.ResolutionQuality",   sg = "sg.ResolutionQuality",   fix = 100, float = true },
                { ini = "SG.ViewDistanceQuality", sg = "sg.ViewDistanceQuality", fix = 3 },
                { ini = "SG.EffectsQuality",      sg = "sg.EffectsQuality",      fix = 3 },
                { ini = "SG.ShadingQuality",      sg = "sg.ShadingQuality",      fix = 3 },
            }
            local want, order, oursU, wantSg, oursSgU = {}, {}, {}, {}, {}
            for _, m in ipairs(map) do
                local v
                if m.fix ~= nil then
                    v = m.float and string.format("%g", m.fix) or string.format("%d", m.fix)
                else
                    local i = PerfIdxFromKey(m.key)
                    if i then v = string.format("%d", math.floor(PerfItems[i].cur + 0.5)) end
                end
                if v then
                    if want[m.ini] == nil then order[#order + 1] = m.ini end
                    want[m.ini] = v
                    oursU[m.ini:upper()] = true
                    wantSg[m.sg] = v
                    oursSgU[m.sg:upper()] = true
                end
            end
            local rf = io.open(ini, "r")
            local src = {}
            if rf then
                for line in rf:lines() do src[#src + 1] = line end
                rf:close()
            end
            local out, gusSeen, inGus = {}, false, false
            local scalSeen, inScal = false, false
            local function trimTailBlanks()
                while #out > 0 and out[#out] == "" do out[#out] = nil end
            end
            for _, line in ipairs(src) do
                local sec = line:match("^%s*%[([^%]]+)%]%s*$")
                if sec then
                    local isGus = (sec:upper() == "/SCRIPT/ENGINE.GAMEUSERSETTINGS")
                    local isScal = (sec:upper() == "SCALABILITYGROUPS")
                    if (isGus and gusSeen) or (isScal and scalSeen) then
                        inGus, inScal = false, false   
                    else
                        trimTailBlanks()
                        out[#out + 1] = ""
                        out[#out + 1] = "[" .. sec .. "]"
                        if isGus then
                            gusSeen, inGus, inScal = true, true, false
                            for _, name in ipairs(order) do
                                out[#out + 1] = name .. "=" .. want[name]
                            end
                        elseif isScal then
                            scalSeen, inScal, inGus = true, true, false
                            for _, m in ipairs(map) do
                                out[#out + 1] = m.sg .. "=" .. wantSg[m.sg]
                            end
                        else
                            inGus, inScal = false, false
                        end
                    end
                elseif inGus then
                    local k = line:match("^%s*([%w%.]+)%s*=")
                    local ku = k and k:upper() or nil
                    
                    if not (ku and oursU[ku]) and line ~= "" then out[#out + 1] = line end
                elseif inScal then
                    local k = line:match("^%s*([%w%.]+)%s*=")
                    local ku = k and k:upper() or nil
                    if not (ku and oursSgU[ku]) and line ~= "" then out[#out + 1] = line end
                else
                    out[#out + 1] = line
                end
            end
            if not gusSeen then
                trimTailBlanks()
                out[#out + 1] = ""
                out[#out + 1] = "[/Script/Engine.GameUserSettings]"
                for _, name in ipairs(order) do
                    out[#out + 1] = name .. "=" .. want[name]
                end
            end
            if not scalSeen then
                trimTailBlanks()
                out[#out + 1] = ""
                out[#out + 1] = "[ScalabilityGroups]"
                for _, m in ipairs(map) do
                    out[#out + 1] = m.sg .. "=" .. wantSg[m.sg]
                end
            end
            local body = table.concat(out, "\r\n") .. "\r\n"
            local old = table.concat(src, "\r\n") .. "\r\n"
            if body == old then return end   
            local wf = io.open(ini, "w")
            if not wf then return end
            wf:write(body)
            wf:close()
            Log("perf: quality mirrored into GameUserSettings.ini (survives game restarts)")
        end)
    end

PerfFlushToDisk = function()
    PerfFlushPending = false
    if not PerfDirty then return end
    PerfDirty = false
    pcall(function()
        local f = io.open(PerfFile, "w")
        if not f then return end
        local out = { "# JinxingLoaderRT perf sliders (ASCII only)" }
        for _, it in ipairs(PerfItems) do
            out[#out + 1] = it.key .. "=" .. string.format("%g", it.cur)
        end
        f:write(table.concat(out, "\n") .. "\n")
        f:close()
    end)
    PerfWriteGameIni()
end

local function PerfQueueOne(i)
    local it = PerfItems[i]
    if not it then return 0 end
    if it.fan then
        local lines = it.fan[math.floor(it.cur + 0.5)] or it.fan[it.def] or {}
        for _, line in ipairs(lines) do
            JXPump.queue[#JXPump.queue + 1] = line
        end
        return #lines
    end
    if not it.cvar then return 0 end
    JXPump.queue[#JXPump.queue + 1] = string.format("%s %g", it.cvar, it.cur)
    return 1
end

local function PerfApplyOne(i)
    local it = PerfItems[i]
    if not it then return false end
    
    local PC = nil
    pcall(function() PC = UEHelpers.GetPlayerController() end)
    if it.fan then
        local lines = it.fan[math.floor(it.cur + 0.5)] or it.fan[it.def] or {}
        local ok = true
        for _, line in ipairs(lines) do
            if not JXExecCmd(PC, line) then ok = false end
        end
        return ok
    end
    if not it.cvar then return false end
    return JXExecCmd(PC, string.format("%s %g", it.cvar, it.cur))
end

local function PerfApplyAll(attempt)
    local queued = 0
    for i = 1, #PerfItems do
        queued = queued + PerfQueueOne(i)
    end
    JXRunPump()
    return queued
end
local function PerfApplyPreset(pk)
    for _, p in ipairs(PerfPresets) do
        if p.key == pk then
            for k, v in pairs(p.vals) do
                local i = PerfIdxFromKey(k)
                if i then PerfClamp(i, v) end
            end
            PerfSave()
            PerfApplyAll(0)
            Log("perf preset -> " .. p.key)
            
            pcall(function()
                for _, key in ipairs({ "aa", "shadow", "post", "fol", "tex", "viewdist", "slod" }) do
                    local i = PerfIdxFromKey(key)
                    if i then Log("  preset " .. p.key .. " check: " .. JXVerifyItem(i)) end
                end
            end)
            return true
        end
    end
    return false
end
local function PerfRestoreDefaults()
    for i, it in ipairs(PerfItems) do it.cur = it.def end
    PerfSave()
    PerfApplyAll(0)
    Log("perf sliders restored to defaults")
end

local function PerfBar(i)
    local it = PerfItems[i]
    if not it then return "" end
    local cells = 14
    local t = (it.max ~= it.min) and ((it.cur - it.min) / (it.max - it.min)) or 0
    local filled = math.floor(t * cells + 0.5)
    if filled < 0 then filled = 0 end
    if filled > cells then filled = cells end
    return "[" .. string.rep("=", filled) .. string.rep("-", cells - filled) .. "]"
end
local function PerfRowText(i)
    local it = PerfItems[i]
    if not it then return "" end
    local val = string.format("%g", it.cur)
    if it.cur == 0 and it.min == 0 then val = L.auto end
    return string.format("%s %s %s", it.label, PerfBar(i), val)
end

local function NormaliseMapPath(path)
    if type(path) ~= "string" then return nil end
    local p = path:gsub("^%s+", ""):gsub("%s+$", "")
    p = p:gsub("%.[%w_%-%s]+$", "")          
    if p == "" then return nil end
    return p
end

local function IsOwnLevelPath(path)
    if type(path) ~= "string" then return false end
    if path:sub(1, 6) ~= "/Game/" then return false end
    if path:find("/Mods/", 1, true) then return false end
    if path:find("/Engine/", 1, true) then return false end
    if path:find("/Temp/", 1, true) then return false end
    if path:find("/Developers/", 1, true) then return false end
    return true
end

local function AddMap(path)
    local p = NormaliseMapPath(path)
    if not p then return end
    if not IsOwnLevelPath(p) then return end   
    for _, existing in ipairs(MapList) do
        if existing == p then return end
    end
    MapList[#MapList + 1] = p
end

local function LoadMaps()
    for _, line in ipairs(FileLines(MapsFile)) do AddMap(line) end
    
    for _, p in ipairs(SEED_MAPS) do AddMap(p) end
end

local function SaveMaps()
    local lines = {
        "# Owned game levels only (other mods' maps are excluded, see IsOwnLevelPath).",
        "# Run 'jmaps' to rescan after a game update.",
    }
    for _, p in ipairs(MapList) do
        if IsOwnLevelPath(p) then lines[#lines + 1] = p end
    end
    WriteAll(MapsFile, table.concat(lines, "\n") .. "\n")
end

local function ScanMaps()
    MapScan = "ok"
    MapScanMsg = "baked pak list (registry scan disabled on this build: it ends the process)"
    Log("jmaps: " .. MapScanMsg)
    Log(string.format("  %d levels known (%d baked + cache + visited)", #MapList, #SEED_MAPS))
    return 0
end

local function WorldMapPath()
    local p = nil
    pcall(function()
        local s = JXName(UEHelpers.GetWorld())
        if s then
            p = s:match("(/[%w_]+/[^%s]+)")
            if p then p = NormaliseMapPath(p) end  
        end
    end)
    if p then
        if p:find("/Engine/", 1, true) or p:find("/Temp/", 1, true)
            or p:find("/Script/", 1, true) or p:find("/Developers/", 1, true) then
            p = nil
        end
    end
    return p
end

function CurrentMapName()
    local p = WorldMapPath()
    if p then
        local leaf = p:match("([^/]+)$")
        if leaf and leaf ~= "" and leaf ~= "-" then return leaf end
    end
    
    local n = nil
    pcall(function()
        local s = JXName(UEHelpers.GetWorld())
        if s then n = s:match("([%w_%-]+)%.[%w_]+%s*$") or s:match("([%w_%-]+)%s*$") end
    end)
    if n and n ~= "" and n ~= "World" and n:sub(1, 8) ~= "Untitled" then return n end
    return "-"
end

function MapIdentity()
    local path = WorldMapPath()
    if path then
        return (path:gsub("[^%w_%-]", "_")), (path:match("([^/]+)$") or path), path, "world"
    end
    local disp = CurrentMapName()
    if disp and disp ~= "-" and disp ~= "World" then
        return (disp:gsub("[^%w_%-]", "_")), disp, "-", "world-leaf"
    end
    
    JX.mapSeq = (JX.mapSeq or 0) + 1
    local k = "world" .. JX.mapSeq
    return k, k, "-", "session"
end

local function RecordVisitedMap()
    pcall(function()
        local name = CurrentMapName()
        if not name or name == "-" then return end
        if not name:match("^[A-Za-z0-9_]+$") then return end
        if name:sub(1, 8) == "Untitled" then return end
        local path = "/Game/Maps/" .. name
        local before = #MapList
        AddMap(path)
        if #MapList > before then
            SaveMaps()
            Log("discovered floor: " .. path .. " (" .. #MapList .. " total)")
        else
            Log("entered floor: " .. path)
        end
    end)
end

local function WorldNameOf()
    local w = nil
    pcall(function() w = UEHelpers.GetWorld() end)
    return JXName(w)
end

function JXTravelStep(path, info, PC, stage)
    if stage == 1 then
        
        if not (PC and PC:IsValid()) then return nil end
        local ok, e = pcall(function() return JXExecCmd(PC, "servertravel " .. path) end)
        if not ok then
            Log("travel route 1 threw: " .. tostring(e))
            return nil
        end
        return "console-servertravel(host,relative)", "keeps", nil
    elseif stage == 2 or stage == 3 then
        
        local absolute = (stage == 3)
        local ok, e = pcall(function()
            local World = UEHelpers.GetWorld()
            if not World or not World:IsValid() then error("no-world") end
            World:ServerTravel(path, absolute)
        end)
        if not ok then
            Log(string.format("travel route %d (%s) threw: %s", stage,
                absolute and "absolute" or "relative", tostring(e)))
            return nil
        end
        if absolute then
            return "ServerTravel(host,absolute)", "keeps",
                "absolute server travel drops the current URL's options and port, so the other player(s) may be dropped even though they were told to follow"
        end
        return "ServerTravel(host,relative)", "keeps", nil
    elseif stage == 4 then
        
        if not (PC and PC:IsValid()) then return nil end
        local ok, e = pcall(function() return JXExecCmd(PC, "open " .. path) end)
        if not ok then
            Log("travel route 4 threw: " .. tostring(e))
            return nil
        end
        return "console-open(client-load)", "drops",
            "this route loads the map into this process only, so a host that takes it loses the room"
    elseif stage == 5 then
        
        local ok, e = pcall(function()
            local World = UEHelpers.GetWorld()
            if not World or not World:IsValid() then error("no-world") end
            local GS = UEHelpers.GetGameplayStatics()
            if not (GS and GS:IsValid()) then error("no-gameplaystatics") end
            local name = (FName and FName(path)) or path
            GS:OpenLevel(World, name, false)
        end)
        if not ok then
            Log("travel route 5 threw: " .. tostring(e))
            return nil
        end
        return "OpenLevel(client-load)", "drops",
            "this route loads the map into this process only, so a host that takes it loses the room"
    end
    return nil
end

function JXTravelNext(path, before, info, PC, stage)
    
    if stage >= 4 and info.authority and info.remotes > 0 then
        Log(string.format(
            "host map switch stopped before route %d: no server route moved the world, and the %d other player(s) in the room would lose it if a client-load route was used -- the room was kept, the map was not switched",
            stage, info.remotes))
        return false
    end
    if stage > 5 then
        Log("map switch failed: all five routes were tried and the world never moved (" .. tostring(path) .. ")")
        return false
    end
    local mode, kind, note = JXTravelStep(path, info, PC, stage)
    if not mode then
        return JXTravelNext(path, before, info, PC, stage + 1)
    end
    if info.authority then
        
        JXTransferBegin(30000)
    end
    Log(string.format("map switch requested -> %s [%s] route %d, world was %s (netmode=%s players=%d others=%d)",
        path, mode, stage, tostring(before), tostring(info.netMode), info.players, info.remotes))
    if kind == "keeps" and info.remotes > 0 then
        Log(string.format("host travel: %d other player(s) are being sent to the new map with us", info.remotes))
    elseif kind == "keeps" then
        Log("host travel: no other players in the room yet")
    elseif note then
        Log("WARNING: " .. note)
    end
    ExecuteWithDelay(1200, function()
        ExecuteInGameThread(function() pcall(function()
            JXTravelCheck(path, before, info, PC, stage, mode, 1)
        end) end)
    end)
    return true
end

function JXTravelCheck(path, before, info, PC, stage, mode, tries)
    local now = WorldNameOf()
    
    local named = (now ~= "" and now:find("/", 1, true) ~= nil)
    if named and now ~= before then
        Log(string.format("travel confirmed %s after route %d (%s): %s -> %s",
            (tries == 1 and "1.2s") or (tries == 2 and "3.2s") or "6.2s",
            stage, mode, tostring(before), tostring(now)))
        return
    end
    if tries < 3 then
        local nextAt = (tries == 1) and 2000 or 3000
        Log(string.format("route %d (%s): world is still %s %s in, and a loading level answers with its old name - reading again in %ds before giving up on this route",
            stage, mode, tostring(now), (tries == 1 and "1.2s") or "3.2s", math.floor(nextAt / 1000)))
        ExecuteWithDelay(nextAt, function()
            ExecuteInGameThread(function() pcall(function()
                JXTravelCheck(path, before, info, PC, stage, mode, tries + 1)
            end) end)
        end)
        return
    end
    Log(string.format("no world change 6.2s after route %d (%s), world is still %s - %s",
        stage, mode, tostring(now), stage < 5 and "trying the next route" or "there is no route left"))
    JXTravelNext(path, before, info, PC, stage + 1)
end

function JXTravelInfo()
    local info = { authority = false, netMode = "-", players = 0, remotes = 0, pc = nil }
    pcall(function()
        local World = UEHelpers.GetWorld()
        if World and World:IsValid() then
            local ok, nm = pcall(function() return World:GetNetMode() end)
            if ok and nm ~= nil then info.netMode = tostring(nm) end
        end
        local GM = nil
        pcall(function() GM = UEHelpers.GetGameModeBase() end)
        info.authority = (GM ~= nil and GM:IsValid())
        pcall(function()
            local PCs = FindAllOf("PlayerController")
            if not PCs then return end
            for i = 1, #PCs do
                local pc = PCs[i]
                if pc and pc:IsValid() then
                    info.players = info.players + 1
                    local isLocal = false
                    pcall(function() isLocal = pc:IsLocalController() end)
                    if not isLocal then info.remotes = info.remotes + 1 end
                    if isLocal and not info.pc then info.pc = pc end
                end
            end
        end)
    end)
    
    if info.remotes > 0 then info.authority = true end
    
    local nm = tostring(info.netMode)
    if nm:find("Client", 1, true) then
        info.authority = false
        info.why = "netmode says this process is a client"
    elseif nm:find("Listen", 1, true) or nm:find("Standalone", 1, true) then
        info.authority = true
    end
    if not info.authority then info.why = info.why or "no GameModeBase and no remote players" end
    return info
end

local function TravelTo(path)
    if not path or path == "" then return false, "empty-path" end
    if not IsOwnLevelPath(path) then
        Log("travel rejected (not an owned game level): " .. path)
        return false, "not-owned"
    end
    
    local loadable = nil
    pcall(function()
        loadable = (LoadAsset(path) ~= nil)
    end)
    if loadable == false then
        Log("travel rejected (map package not in this build - protects guests): " .. path)
        return false, "map-not-in-build"
    end
    local before = WorldNameOf()
    local info = JXTravelInfo()
    local PC = info.pc
    if not (PC and PC:IsValid()) then
        pcall(function() PC = UEHelpers.GetPlayerController() end)
    end
    
    if info.authority and not path:find("?", 1, true) then
        path = path .. "?listen"
    end
    local ok = false
    if info.authority then
        
        ok = JXTravelNext(path, before, info, PC, 1)
    else
        
        Log("travel: this process is not the server, starting at the client route")
        
        Log("travel: guest switch - this loads the map into your OWN room; the host's room and everyone in it are untouched")
        ok = JXTravelNext(path, before, info, PC, 4)
    end
    if not ok then return false, "no route was issued (the log says which ones were tried)" end
    return true, ""
end

local Panel = { open = false, page = 1, sel = 1, widget = nil }
local PAGE_COUNT = 5   

local function ReadOptFlag()
    local f = io.open("Mods/Jinxingopt/config/settings.txt", "r")
    if not f then return true end
    for line in f:lines() do
        local k, v = line:match("^([%w_]+)%s*=%s*(.+)%s*$")
        if k == "auto_apply" then
            f:close()
            return v == "1" or v:lower() == "true"
        end
    end
    f:close()
    return true
end

local function WriteOptFlag(on)
    pcall(function()
        local f = io.open("Mods/Jinxingopt/config/settings.txt", "w")
        if not f then return end
        f:write("# Jinxingopt settings (ASCII only)\nauto_apply = " .. (on and "1" or "0") .. "\n")
        f:close()
    end)
end

local function PanelRows()
    local rows = {}
    if Panel.page == 1 then
        local players = Panel.open and CollectPlayers() or {}
        for i, r in ipairs(players) do
            rows[#rows + 1] = {
                text = string.format("%s  %s%s  Steam64=%s",
                    r.name, r.localPlayer and ("[" .. L.you .. "] ") or "", "", r.steam64),
                ps = r.ps, name = r.name, id = r.net,
            }
        end
        if #rows == 0 then rows[#rows + 1] = { text = L.none } end
    elseif Panel.page == 2 then
        for i, e in ipairs(BlacklistOrder) do
            rows[#rows + 1] = { text = e, idx = i }
        end
        if #rows == 0 then rows[#rows + 1] = { text = L.empty } end
        
        rows[#rows + 1] = { text = "sedet", kind = "sedet" }
    elseif Panel.page == 3 then
        rows[#rows + 1] = { text = string.format("%s: %d   (%s 32-512)", L.cap, Config.MaxPlayers, "32-512"), kind = "cap" }
        rows[#rows + 1] = { text = string.format("%s: %s", L.opt, ReadOptFlag() and L.on or L.off), kind = "opt" }
        rows[#rows + 1] = { text = string.format("Steam64: %s", GetSteam64()), kind = "info" }
    elseif Panel.page == 5 then
        
        for i, it in ipairs(PerfItems) do
            rows[#rows + 1] = { text = PerfRowText(i), kind = "perf", idx = i }
        end
        for _, p in ipairs(PerfPresets) do
            rows[#rows + 1] = { text = p.label, kind = "preset", pk = p.key }
        end
        rows[#rows + 1] = { text = L.restDef, kind = "restore" }
    else
        local here = CurrentMapName()
        for i, p in ipairs(MapList) do
            local short = p:match("/([^/]+)$") or p
            local isHere = (here ~= "-" and short == here)
            rows[#rows + 1] = { text = (isHere and "* " or "  ") .. p,
                                kind = "map", path = p }
        end
        if #rows == 0 then
            local hint = MapScanMsg
            rows[#rows + 1] = { text = L.nomaps .. " [" .. tostring(hint) .. "] " .. "jmaps" }
        end
    end
    return rows
end

local function PanelHeader()
    local titles = { L.players, L.blacklist, L.settings, L.maps, L.quality }
    local footer
    if Panel.page == 1 then
        footer = "UP/DOWN " .. U(0x9009, 0x62E9) .. "  ENTER=" .. L.kick
    elseif Panel.page == 2 then
        footer = "UP/DOWN " .. U(0x9009, 0x62E9) .. "  ENTER=" .. L.unban
                .. "  (sedet row: ENTER=SEDET)"
    elseif Panel.page == 3 then
        footer = "UP/DOWN " .. U(0x9009, 0x62E9) .. "  ENTER=" .. L.enterAct .. "  LEFT/RIGHT=" .. L.cap
    elseif Panel.page == 5 then
        footer = "UP/DOWN " .. U(0x9009, 0x62E9)
                .. "  LEFT/RIGHT=" .. L.lr
                .. "  ENTER=" .. L.apply .. "/" .. L.preset
    else
        footer = "UP/DOWN " .. U(0x9009, 0x62E9) .. "  ENTER=" .. L.travel
                .. "  (" .. L.current .. ":" .. CurrentMapName() .. ")"
    end
    return string.format("== %s [%d/%d] ==\n", titles[Panel.page], Panel.page, PAGE_COUNT)
        .. footer .. (Panel.page == 5 and "  PgUp/PgDn=" or "  LEFT/RIGHT=")
        .. L.switch .. "  B=" .. L.close .. "\n"
end

local UIMode = "none"
local UIDiag = ""

local function MakeTextWidget(PC, zorder)
    
    do return nil, nil, "lua-ui-disabled-shipping" end
end

local function EnableScreenText(PC)
    pcall(function()
        if PC and PC:IsValid() then
            
            JXExecCmd(PC, "DisableAllScreenMessages 0")
        end
    end)
end

local function ShowOnScreen(PC, body)
    
    return false
end

local function RenderPanel()
    pcall(function()
        local PC = UEHelpers.GetPlayerController()
        if not PC or not PC:IsValid() then return end
        if not Panel.widget or not Panel.widget:IsValid() then
            local w, tb, why = MakeTextWidget(PC, 80)
            if w and tb then
                Panel.widget, Panel.text = w, tb
                UIMode, UIDiag = "umg", why or "ok"
                pcall(function() w:SetPositionInViewport({ X = 60.0, Y = 60.0 }, false) end)
                pcall(function() w:SetRenderOpacity(0.92) end)
            else
                
                if UIMode ~= "printstring" and UIMode ~= "console" then
                    UIDiag = tostring(why)
                    Log("UMG unavailable (" .. UIDiag .. "), using on-screen fallback")
                end
                Panel.widget, Panel.text = nil, nil
            end
        end
        local rows = PanelRows()
        if Panel.sel > #rows then Panel.sel = #rows end
        if Panel.sel < 1 then Panel.sel = 1 end
        local lines = { PanelHeader() }
        for i, r in ipairs(rows) do
            local mark = (i == Panel.sel) and "> " or "  "
            lines[#lines + 1] = mark .. r.text
        end
        local body = table.concat(lines, "\n")
        
        if ShowOnScreen(PC, body) then
            UIMode = "printstring"
        else
            UIMode = "console"
        end
        print(TAG .. "\n" .. body .. "\n")
    end)
end

local function PanelAct()
    if Panel.page == 1 then
        local players = CollectPlayers()
        local r = players[Panel.sel]
        if not r or r.localPlayer then return end
        if not IsBlacklisted(r.name, r.net) then
            AddBlacklist(r.name ~= "player" and r.name or r.net)
            if r.steam64 and r.steam64 ~= "unknown" then AddBlacklist(r.steam64) end
        end
        pcall(function()
            local PCs = FindAllOf("PlayerController")
            for _, PC in pairs(PCs or {}) do
                if PC and PC:IsValid() and PC.PlayerState == r.ps then
                    JXKickToMenu(PC, "Removed by host (blacklist)")
                end
            end
        end)
        AppendLine(JoinLogFile, string.format("%s  KICKED (panel)  name=%s id=%s", Now(), r.name, r.net))
        Log("panel kicked: " .. r.name)
        RenderPanel()
    elseif Panel.page == 2 then
        local rows2 = PanelRows()
        local r2 = rows2[Panel.sel]
        if r2 and r2.kind == "sedet" then
            
            if type(JXSedet) == "function" then
                ExecuteInGameThread(function() pcall(JXSedet, "sedet", {}, "sedet") end)
                Log("panel: sedet row -> SEDET (report in config/sedet.txt)")
            else
                Log("panel: sedet row pressed but JXSedet is not in scope")
            end
            RenderPanel()
            return
        end
        RemoveBlacklist(Panel.sel)
        if Panel.sel > 1 then Panel.sel = Panel.sel - 1 end
        Log("blacklist entry removed")
        RenderPanel()
    elseif Panel.page == 3 then
        if Panel.sel == 2 then
            WriteOptFlag(not ReadOptFlag())
            Log("global optimisation flag -> " .. tostring(ReadOptFlag()))
            RenderPanel()
        end
    elseif Panel.page == 5 then
        
        local rows = PanelRows()
        local r = rows[Panel.sel]
        if r and r.kind == "perf" and r.idx then
            PerfApplyOne(r.idx)
            PerfSave()
            Log("perf slider applied: " .. PerfItems[r.idx].key)
        elseif r and r.kind == "preset" and r.pk then
            PerfApplyPreset(r.pk)
        elseif r and r.kind == "restore" then
            PerfRestoreDefaults()
        end
        RenderPanel()
    else
        local rows = PanelRows()
        local r = rows[Panel.sel]
        if r and r.kind == "map" and r.path then
            TravelTo(r.path)
        else
            Log("no cached levels - run 'jmaps' to scan")
        end
    end
end

local function PerfPanelAdjust(delta)
    local rows = PanelRows()
    local r = rows[Panel.sel]
    if not (r and r.kind == "perf" and r.idx) then return end
    local it = PerfItems[r.idx]
    PerfClamp(r.idx, it.cur + delta * it.step)
    PerfApplyOne(r.idx)
    PerfSave()
    RenderPanel()
end

local function PanelAdjustCap(delta)
    local n = Config.MaxPlayers + delta
    if n < 32 then n = 32 end
    if n > 512 then n = 512 end
    Config.MaxPlayers = n
    pcall(function()
        local f = io.open(SettingsFile, "w")
        if f then
            f:write("# JinxingLoaderRT settings.\nmax_players = " .. n .. "\n")
            f:close()
        end
    end)
    ApplyMaxPlayers(true)
    RenderPanel()
end

local function PanelRefreshLoop()
    if not Panel.open then return end
    ExecuteInGameThread(function() pcall(RenderPanel) end)
    ExecuteWithDelay(900, function()
        pcall(function() if Panel.open then PanelRefreshLoop() end end)
    end)
end

local PakUISlot   = {}            
local PakUIOpen   = false        
local PakUIPrefer = true         
local PakUIHints  = { "WBP_JinxingRoot", "JinxingRoot", "JinxingMain" }

local function WidgetHint(w)
    local s = ""
    pcall(function()
        if w.GetFullName then
            local g = w:GetFullName()
            if g then s = tostring(g) end
        end
    end)
    if s == "" then
        pcall(function() s = tostring(w) end)
    end
    if s == "" then
        pcall(function()
            if w.GetName then
                local n = w:GetName()
                if n then s = tostring(n) end
            end
        end)
    end
    return s or ""
end

local function WidgetIsPakMenu(w)
    local s = WidgetHint(w)
    if s == "" then return false end
    for _, hint in ipairs(PakUIHints) do
        if s:find(hint, 1, true) then return true end
    end
    return false
end

local function AcquirePakUIRoot()
    return JXMemo(PakUISlot, 10000, function()
        local hit = nil
        local all = FindAllOf("UserWidget")
        if not all then return nil end
        for _, w in pairs(all) do
            if JXAlive(w) then
                local s = JXName(w)
                if s ~= "" then
                    for _, hint in ipairs(PakUIHints) do
                        if s:find(hint, 1, true) then hit = w; break end
                    end
                end
            end
            if hit then break end
        end
        return hit
    end, 3000)
end

local function ShowPakUI(show)
    local ui = AcquirePakUIRoot()
    if not ui or not ui:IsValid() then return false end
    if show then
        pcall(function()
            pcall(function() ui:SetVisibility(0) end)
            if ui:IsInViewport() ~= true then ui:AddToViewport(10000) end
        end)
    else
        pcall(function()
            pcall(function() ui:SetVisibility(2) end)
            if ui:IsInViewport() == true then ui:RemoveFromParent() end
        end)
    end
    return true
end

local function LogPakUIState(tag)
    local ui = AcquirePakUIRoot()
    Log(string.format("%s: pak UI %s (open=%s)", tag,
        ui and ui:IsValid() and "present" or "absent", tostring(PakUIOpen)))
end

local LoaderCoreSlot  = {}            
local LoaderCoreNames = { "BP_JinxingLoaderCore_C", "BP_JinxingLoaderCore" }

local function JXIsLiveCore(a)
    if not JXAlive(a) then return false end
    local n = JXName(a)
    if n == "" then return false end
    if n:find("Default__", 1, true) then return false end
    return n:find("BP_JinxingLoaderCore", 1, true) ~= nil
end

local function AcquireLoaderCore()
    return JXMemo(LoaderCoreSlot, 10000, function()
        for _, cls in ipairs(LoaderCoreNames) do
            local hit = nil
            pcall(function()
                local a = FindFirstOf(cls)
                if JXIsLiveCore(a) then hit = a end
            end)
            if not hit then
                pcall(function()
                    local all = FindAllOf(cls)
                    if not all then return end
                    for _, a in pairs(all) do
                        if JXIsLiveCore(a) then hit = a; return end
                    end
                end)
            end
            if hit then return hit end
        end
        
        return nil
    end, 4000)
end

local PakPanelMouseOn = false
local function SetPanelMouse(show)
    pcall(function()
        -- r37: UEHelpers.GetPlayerController() returned nil mid-level in the
        -- 01:14 live session (the JxNewUI "no-pc" cursor stranding). Use the
        -- chain this file's proven features (blacklist/NET/AFK/kick) use:
        -- exact-class list + local-controller pick, UEHelpers as fallback.
        local PC = nil
        local okA, pcs = pcall(FindAllOf, "PlayerController")
        if okA and type(pcs) == "table" then
            local firstValid = nil
            for _, pc in pairs(pcs) do
                if pc and pc:IsValid() then
                    if firstValid == nil then firstValid = pc end
                    local isLocal = false
                    pcall(function() isLocal = pc:IsLocalController() end)
                    if isLocal then PC = pc break end
                end
            end
            if not PC then PC = firstValid end
        end
        if not (PC and PC:IsValid()) then
            pcall(function() PC = UEHelpers.GetPlayerController() end)
        end
        if not (PC and PC:IsValid()) then return end
        pcall(function() PC.bShowMouseCursor = show and true or false end)
        local WBL = StaticFindObject("/Script/UMG.Default__WidgetBlueprintLibrary")
        if WBL and WBL:IsValid() then
            if show then
                pcall(function() WBL:SetInputMode_GameAndUIEx(PC, nil, 0, false) end)
            else
                pcall(function() WBL:SetInputMode_GameOnly(PC) end)
            end
        end
    end)
    PakPanelMouseOn = show and true or false
end
-- r36: JxNewUI's open/close calls _G.JXPanelMouse; until now that global was
-- NEVER defined (this helper and its PNL twin were locals), so in-game the
-- shell opened with no cursor and no GameAndUI input mode - clicks were dead
_G.JXPanelMouse = SetPanelMouse

local function ToggleViaLoaderCore()
    local core = AcquireLoaderCore()
    if not core or not core:IsValid() then return false end
    local ok, err = pcall(function() core:JinxingLoaderToggle() end)
    if ok then
        
        local panelOpen = false
        pcall(function()
            local ui = core.JinxingUi
            panelOpen = (ui ~= nil and ui:IsValid())
        end)

local JXLastMemberProbe = 0
local JXMemberInk = { R = 0.05, G = 0.06, B = 0.10, A = 1.0 }
local function JXMemberPageProbe()
    local now = (os and os.clock and os.clock()) or 0
    if now - JXLastMemberProbe < 10 then return end
    JXLastMemberProbe = now
    ExecuteInGameThread(function()
        pcall(function()
            local boxes = FindAllOf("VerticalBox")
            if not boxes then Log("MEMBERPROBE| no VerticalBox list") return end
            local found = 0
            for _, w in pairs(boxes) do
                if JXAlive(w) then
                    local nm = ""
                    pcall(function() nm = JXName(w) end)
                    if nm:find("PlusPageV183", 1, true) or nm:find("ProPageV183", 1, true) then
                        found = found + 1
                        pcall(function() w:SetVisibility(0) end)
                    end
                end
            end

            local tb = FindAllOf("TextBlock")
            local painted, viaProp, viaSet = 0, 0, 0
            if tb then
                for _, t in pairs(tb) do
                    if JXAlive(t) then
                        local nm = ""
                        pcall(function() nm = JXName(t) end)
                        if nm:find("PlusPageV183", 1, true) or nm:find("ProPageV183", 1, true) then
                            painted = painted + 1
                            local ok1 = pcall(function()
                                t.ColorAndOpacity.SpecifiedColor = JXMemberInk
                            end)
                            if ok1 then viaProp = viaProp + 1 end
                            local ok2 = pcall(function() t:SetColorAndOpacity(JXMemberInk) end)
                            if ok2 then viaSet = viaSet + 1 end
                        end
                    end
                end
            end

            local bt = FindAllOf("Button")
            local bshown = 0
            if bt then
                for _, b in pairs(bt) do
                    if JXAlive(b) then
                        local nm = ""
                        pcall(function() nm = JXName(b) end)
                        if nm:find("PlusPageV183", 1, true) or nm:find("ProPageV183", 1, true) then
                            pcall(function() b:SetVisibility(0) end)
                            bshown = bshown + 1
                        end
                    end
                end
            end

            Log(string.format(
                "MEMBERPROBE| pages=%d labels=%d (prop=%d set=%d) buttons=%d",
                found, painted, viaProp, viaSet, bshown))
        end)
    end)
end

        SetPanelMouse(panelOpen)
        -- r20: JXMemberPageProbe retired - PlusPageV183/ProPageV183 targets do not
        -- exist in the R14 shell; every call was 3x FindAllOf cost for zero effect
        -- if panelOpen then pcall(JXMemberPageProbe) end
        Log("panel -> pak Core JinxingLoaderToggle() (same panel as B), open="
            .. tostring(panelOpen) .. ", mouse=" .. tostring(panelOpen))
    else
        Log("panel: JinxingLoaderToggle unavailable, falling back: " .. tostring(err))
    end
    return ok
end

function JxTabSelfHeal()
    if JXBusy() then return false end
    local ui = AcquirePakUIRoot()
    if ui and ui:IsValid() then return false end
    local ok = ToggleViaLoaderCore()
    if not ok then
        Log("jtab: no live panel and the Core did not answer - JinxingLoader_P missing or its ModActor was not spawned this level")
    end
    return ok
end

local F6UiSlot  = {}                  
local F6UiOpen = false

local function AcquireF6Ui()
    return JXMemo(F6UiSlot, 10000, function()
        local hit = nil
        local all = FindAllOf("UserWidget")
        if not all then return nil end
        for _, w in pairs(all) do
            if JXAlive(w) then
                local s = JXName(w)
                if s ~= "" and s:find("WBP_JinxingF6", 1, true) then hit = w; break end
            end
        end
        return hit
    end, 3000)
end

_G.JxUiProbe = function()
    local r = { coreState = "n/a", uirootState = "n/a", f6State = "n/a",
                luaPanel = "n/a", busy = JXBusy(), core = nil,
                pakClassLoadable = false }
    pcall(function()
        local core = AcquireLoaderCore()
        r.core = (JXIsLiveCore(core) and core) or nil
        r.coreState = r.core and "ALIVE" or
            (JXAlive(core) and "CDO-only (class loaded, no live actor)" or "absent")
    end)
    pcall(function()
        local ui = AcquirePakUIRoot()
        r.uirootState = JXAlive(ui) and "ALIVE" or "absent (no WBP_JinxingRoot instance)"
    end)
    pcall(function()
        local f6 = AcquireF6Ui()
        r.f6State = JXAlive(f6) and "ALIVE" or "absent (WBP_JinxingF6 pak not in?)"
    end)
    pcall(function()
        local JP = _G.JxPanels
        r.luaPanel = (type(JP) == "table" and type(JP.hookFrames) == "number"
                      and JP.hookFrames > 0)
                      and "ALIVE (canvas hook rendering)" or "absent (F8 canvas)"
    end)
    pcall(function()
        local cdo = StaticFindObject("/Game/Mods/JinxingLoader/BP_JinxingLoaderCore.Default__BP_JinxingLoaderCore_C")
        r.pakClassLoadable = JXAlive(cdo) or false
    end)
    return r
end

local function ToggleF6Ui()
    local ui = AcquireF6Ui()
    if not ui or not ui:IsValid() then return false end
    
    local wasOpen = F6UiOpen
    pcall(function()
        local vis = tonumber(ui:GetVisibility())
        local invp = (ui:IsInViewport() == true)
        if vis ~= nil then wasOpen = (vis == 0 and invp) end
    end) 
    local open = not wasOpen
    F6UiOpen = open
    pcall(function()
        if open then
            pcall(function() ui:SetVisibility(0) end)                       
            if ui:IsInViewport() ~= true then pcall(function() ui:AddToViewport(10000) end) end
        else
            pcall(function() ui:SetVisibility(2) end)                       
        end
    end)
    SetPanelMouse(open)
    Log("F6 panel -> " .. (open and "shown" or "hidden") .. " (WBP_JinxingF6, mouse=" .. tostring(open) .. ")")
    return true
end

local function TogglePanel()
    
    if JXBusy() then Log('panel: UI locked during map load - press again when the room is up') return end
    
    if PakUIPrefer and ToggleViaLoaderCore() then return end
    
    local handled = false
    pcall(function()
        local ui = PakUIPrefer and AcquirePakUIRoot() or nil   
        if ui and ui:IsValid() then
            local nowOpen = PakUIOpen
            pcall(function()
                local vis = tonumber(ui:GetVisibility())
                local invp = (ui:IsInViewport() == true)
                if vis ~= nil then nowOpen = (vis == 0 and invp) end
            end)
            PakUIOpen = not nowOpen
            if ShowPakUI(PakUIOpen) then
                handled = true
                Log("panel -> pak UI " .. (PakUIOpen and "shown" or "hidden"))
            end
        end
    end)
    if handled then return end
    
    if PakUIPrefer then
        
        PakUISlot[1], F6UiSlot[1], LoaderCoreSlot[1] = nil, nil, nil
        if not JXBusy() and ToggleViaLoaderCore() then return end
        local ui2 = (not JXBusy()) and AcquirePakUIRoot() or nil
        if ui2 and ui2:IsValid() then
            local nowOpen = false
            pcall(function()
                local vis = tonumber(ui2:GetVisibility())
                nowOpen = (vis == 0 and ui2:IsInViewport() == true)
            end)
            PakUIOpen = not nowOpen
            if ShowPakUI(PakUIOpen) then
                Log("panel -> pak UI (rescanned) " .. (PakUIOpen and "shown" or "hidden"))
                return
            end
        end
        local jp = _G.JxPanels
        if type(jp) == "table" and type(jp.Ensure) == "function"
            and type(jp.Toggle) == "function" then
            local okp, boundp = pcall(jp.Ensure)
            if okp and boundp then
                pcall(jp.Toggle)
                Log("panel -> Lua-drawn member panel (pak chain dead; F8 path, hook="
                    .. tostring(jp.hookPath) .. ")")
                return
            end
        end
        Log("panel: pak chain dead and canvas panel unavailable - press B (pak) or F8; ui=" .. UIMode)
        return
    end
    
    Panel.open = not Panel.open
    if Panel.open then
        Panel.page, Panel.sel = 1, 1
        RenderPanel()
        Log("panel opened (F6 keyboard panel, arrows+Enter, no mouse needed) ui=" .. UIMode
            .. (UIDiag ~= "" and (", diag=" .. UIDiag) or ""))
        
    else
        if Panel.widget and Panel.widget:IsValid() then
            pcall(function() Panel.widget:RemoveFromParent() end)
        end
        Panel.widget, Panel.text = nil, nil
        Log("panel closed")
    end
end

local function ToggleTextPanel()
    local prev = PakUIPrefer
    PakUIPrefer = false
    pcall(function()
        
        if PakUIOpen then pcall(function() ShowPakUI(false) end); PakUIOpen = false end
        TogglePanel()
    end)
    PakUIPrefer = prev
end

local function PanelNav(delta)
    if not Panel.open then return end
    Panel.sel = Panel.sel + delta
    local rows = PanelRows()
    if Panel.sel < 1 then Panel.sel = #rows end
    if Panel.sel > #rows then Panel.sel = 1 end
    RenderPanel()
end

local function PanelSwitch(delta)
    if not Panel.open then return end
    Panel.page = Panel.page + delta
    if Panel.page < 1 then Panel.page = PAGE_COUNT end
    if Panel.page > PAGE_COUNT then Panel.page = 1 end
    Panel.sel = 1
    RenderPanel()
end

local function BootStep(label, fn)
    local ok, err = pcall(fn)
    if not ok then Log("boot: " .. label .. " failed - " .. tostring(err)) end
    return ok
end
BootStep("LoadConfig", LoadConfig)
BootStep("LoadMaps", LoadMaps)
    BootStep("PerfLoad", PerfLoad)   
    
    pcall(function() PerfSave() end)

local function TryScan(attempt)
    local gained = ScanMaps()
    if gained and gained > 0 then SaveMaps() end
    Log(string.format("level scan #%d: +%d new, %d total (%s)",
        attempt, gained or 0, #MapList, MapScanMsg))
    if #MapList == 0 and attempt < 3 then
        ExecuteWithDelay(8000, function()
            ExecuteInGameThread(function() pcall(TryScan, attempt + 1) end)
        end)
    end
end

local LoadBudgetDefaults = {
    "s.AsyncLoadingUseFullTimeLimit 0",
    "s.AsyncLoadingTimeLimit 5",
    "s.PriorityAsyncLoadingExtraTime 15",
    "s.LevelStreamingActorsUpdateTimeLimit 5",
    "s.PriorityLevelStreamingActorsUpdateExtraTime 5",
    "s.LevelStreamingComponentsRegistrationGranularity 10",
    "s.UnregisterComponentsTimeLimit 1",
    "s.LevelStreamingComponentsUnregistrationGranularity 5",
}

local function ResetLoadBudgets()
    JXQueue(LoadBudgetDefaults)
end

local function ResetFramePacing()
    
    JXQueue({ "t.MaxFPS 0", "r.MotionBlurQuality 0", "r.MotionBlur.Max 0", "r.MotionBlur.Amount 0" })
end

local function ApplyCvars(reason, force)
    local now = JXClock()
    if not force and (now - (JX.cvarLast or 0)) < 2500 then return false end
    JX.cvarLast = now

    JXQueue({
        "net.MaxClientRate 100000",
        "net.MaxServerRate 100000",
        "net.MaxRepArraySize 8192",
    })
    local VERIFY = "t.MaxFPS"
    local SENTINEL = "37"
    local function ReadCVar(name)
        local v = nil
        pcall(function()
            local KSL = StaticFindObject("/Script/Engine.Default__KismetSystemLibrary")
            if JXAlive(KSL) then v = KSL:GetConsoleVariableFloatValue(name) end
        end)
        return v
    end
    JXQueue({ VERIFY .. " " .. SENTINEL })
    local sentinel = ReadCVar(VERIFY)

    ResetLoadBudgets()
    ResetFramePacing()          
    PerfApplyAll(0)
    JXQueue(BOOST_LEVELS[BoostLevel])

    local after = ReadCVar(VERIFY)
    local sane1 = ReadCVar("r.ScreenPercentage")
    local sane2 = ReadCVar("r.MaxAnisotropy")
    Log(string.format("cvar verify (%s): sentinel t.MaxFPS=%s (want 37) | after pass=%s (want 0)"
        .. " | reads r.ScreenPercentage=%s r.MaxAnisotropy=%s | queue left=%d",
        tostring(reason), tostring(sentinel), tostring(after),
        tostring(sane1), tostring(sane2), #JXPump.queue))
    return true
end

function JxEnsureModActor()
    if JXBusy() then return "busy" end
    if AcquireLoaderCore() then return "core" end
    local cls = J3LoadObject("/Game/Mods/JinxingLoader_P/ModActor.ModActor_C")
    if not (cls and cls:IsValid()) then return "noclass" end
    
    local clsName = ""
    pcall(function() clsName = tostring(cls:GetFullName()) end)
    local present = false
    pcall(function()
        local all = FindAllOf("ModActor_C")
        if not all then return end
        for _, a in pairs(all) do
            if JXAlive(a) then
                local n = ""
                pcall(function() n = tostring(a:GetClass():GetFullName()) end)
                if n ~= "" and n == clsName then present = true; return end
            end
        end
    end)
    if present then return "actor" end
    local x, y, z = 0, 0, 0
    pcall(function()
        local PC = UEHelpers.GetPlayerController()
        if PC and PC:IsValid() and PC.Pawn and PC.Pawn:IsValid() then
            local p = PC.Pawn:K2_GetActorLocation()
            if p then x, y, z = p.X, p.Y, p.Z end
        end
    end)
    local a, err, shape = JxActor.spawn(cls, x, y, z, 0)
    if not JXAlive(a) then
        Log("modactor: re-spawn failed: " .. tostring(err))
        return "fail"
    end
    Log("modactor: pak ModActor was missing in this level - re-spawned it ("
        .. tostring(shape) .. ") so the panel, the B key and the tab buttons work here too")
    return "spawned"
end

pcall(function()
    if RegisterLoadMapPreHook then
        RegisterLoadMapPreHook(function()
            
            Log("map load pre-hook fired")
            JXBeginTransition(4000)
            JXNameCacheNewGen()
            PakUISlot[1], F6UiSlot[1], LoaderCoreSlot[1] = nil, nil, nil
        end)
        Log("v2.9 transition guard armed (pre-hook)")
    end
end)

function JXWorldReady(tag, epoch, wid)
    if epoch == nil then return false end
    if epoch == JX.worldReady then return false end
    JX.worldReady = epoch
    
    JX.worldReadyAt = JXClock()
    
    JX.worldRuns = (JX.worldRuns or 0) + 1
    
    local cameFromTravel = false
    pcall(function() cameFromTravel = JXTransferGuard() end)
    Log("world ready (" .. tostring(tag) .. "): " .. tostring(wid)
        .. " - clearing the loader caches and re-applying the session state")
    JXBeginTransition(2500)
    
    JXNameCacheNewGen()
    JXTransferBegin(12000)
    PakUISlot[1], F6UiSlot[1], LoaderCoreSlot[1] = nil, nil, nil
    
    JX.actorSweepBudget = 4
    JxActor.protect = false   
    JXPump.queue = {}
    
    pcall(function()
        if type(_G.JXPanelKeepaliveReseed) == "function" then _G.JXPanelKeepaliveReseed() end
        local jp = _G.JxPanels
        if jp and type(jp.RestartWatchdog) == "function" then pcall(jp.RestartWatchdog) end
        _G.JXCanvasReopenPending = true
        
        pcall(function()
            ExecuteWithDelay(8000, function()
                ExecuteInGameThread(function() pcall(_G.JXAutoBoostApply) end)
            end)
        end)
        
        local function StripLegacyCore(pass)
            if true then return "retired r14: Core BP is the shell input path again" end
            local pc0 = nil
            pcall(function() pc0 = UEHelpers.GetPlayerController() end)
            local stripped = 0
            for _, cls in ipairs({ "BP_JinxingLoaderCore_C" }) do
                local all = FindAllOf(cls)
                if all then
                    for _, a in pairs(all) do
                        if a and a:IsValid() and a:GetClass():GetName() == cls then
                            pcall(function() a:SetActorTickEnabled(false) end)
                            if pc0 and pc0:IsValid() then
                                pcall(function() a:DisableInput(pc0) end)
                            end
                            if pass == "+6s" then
                                pcall(function() a:K2_DestroyActor() end)
                            end
                            stripped = stripped + 1
                        end
                    end
                end
            end
            if stripped > 0 then
                Log("R9.4| legacy Core handled on " .. stripped .. " actor(s) ["
                    .. pass .. (pass == "+6s" and ", destroyed" or ", input stripped")
                    .. "] - old panel cannot spawn")
            end
        end
        for _, delay in ipairs({ 0, 500, 1500, 3000, 6000 }) do
            local pass = "+" .. (delay / 1000) .. "s"
            if delay == 0 then
                pcall(function() StripLegacyCore(pass) end)
            else
                pcall(function()
                    ExecuteWithDelay(delay, function()
                        ExecuteInGameThread(function() pcall(StripLegacyCore, pass) end)
                    end)
                end)
            end
        end
        pcall(function()
            local pcs = FindAllOf("PlayerController")
            if pcs then
                local n = 0
                for _, pc in pairs(pcs) do
                    if pc and pc:IsValid() then
                        pcall(function() pc.CurrentNetSpeed = 100000 end)
                        n = n + 1
                    end
                end
                if n > 1 then Log("NET| " .. n .. " controller(s) raised to 100000 net speed (anti-lag-drop)") end
            end
        end)
    end)
    
    ExecuteInGameThread(function()
        local runs = JX.worldRuns or 0
        local rescueAt = cameFromTravel and 1200 or 4500
        if cameFromTravel then
            Log("loader replay: this world began inside a transfer this file issued, so "
                .. "it is a seamless travel and BPModLoaderMod's LoadMap post-hook is not "
                .. "coming - rescue pass in 1.2 s")
        end
        ExecuteWithDelay(rescueAt, function()
            ExecuteInGameThread(function()
                if (JX.worldRuns or 0) ~= runs then return end  
                if JX.loadMapRun == runs then
                    Log("loader replay: an ordinary LoadMap reached " .. tostring(wid)
                        .. " (run " .. tostring(runs) .. "), so BPModLoaderMod walks its own "
                        .. "list there - the rescue pass stands down, the +9 s pass stays as "
                        .. "the safety net")
                    return
                end
                pcall(function()
                    if JXReplayLoader then JXReplayLoader(tag .. "/rescue", wid) end
                end)
            end)
        end)
        
        ExecuteWithDelay(3500, function()
            ExecuteInGameThread(function()
                pcall(function()
                    SeenThisSession = {}
                    ApplyMaxPlayers(true)
                    RecordVisitedMap()
                    RunAutoLoad()
                    
                    if J3AutoSaveTick then pcall(J3AutoSaveTick) end
                end)
                
                if Fly.On and Fly.ReArm then
                    local tries = 0
                    local function Rearm()
                        tries = tries + 1
                        if Fly.ReArm() then return end
                        if tries < 6 then
                            ExecuteWithDelay(1200, function() ExecuteInGameThread(function() pcall(Rearm) end) end)
                        else
                            Log("fly: could not re-arm after the map change (no usable pawn)")
                        end
                    end
                    Rearm()
                end
            end)
        end)
        
        ExecuteWithDelay(6000, function()
            ExecuteInGameThread(function()
                if type(JxEnsureModActor) ~= "function" then return end
                local tries = 0
                local function Heal()
                    tries = tries + 1
                    local okh, rh = pcall(JxEnsureModActor)
                    if not okh then rh = "busy" end
                    local r = rh
                    if r == "core" or r == "actor" or r == "spawned" then
                        Log("modactor: level self-check -> " .. r)
                    elseif r == "busy" and tries < 4 then
                        ExecuteWithDelay(2000, function() ExecuteInGameThread(function() pcall(Heal) end) end)
                    else
                        Log("modactor: level self-check -> " .. r
                            .. " (pak retired r7.0; canvas is the UI, Lua commands all work)")
                    end
                end
                Heal()
            end)
        end)
        
        ExecuteWithDelay(9000, function()
            ExecuteInGameThread(function()
                pcall(function()
                    if JXReplayLoader then pcall(JXReplayLoader, tag .. "/fill", wid) end
                end)
            end)
        end)
        
        ExecuteWithDelay(12000, function()
            ExecuteInGameThread(function()
                if (JX.worldRuns or 0) ~= runs then return end
                pcall(function()
                    if JXReplaySweep then JXReplaySweep("12s", wid) end
                end)
            end)
        end)
        
        ApplyCvars("map load", true)
        
        ExecuteWithDelay(1500, function()
            ExecuteInGameThread(function()
                pcall(function()
                    local i = PerfIdxFromKey and PerfIdxFromKey("motion") or nil
                    if i then
                        Log("r3.82: motion blur after map load -> " .. JXVerifyItem(i))
                    end
                end)
            end)
        end)
        
        ExecuteWithDelay(10000, function() ExecuteInGameThread(function()
            -- r57: same nil global as the JxUI bridge - this second pass only
            -- logged success, it never set a cvar. Queue it on the pump so the
            -- echo table records it like every other cvar write.
            local okm = false
            pcall(function()
                if type(_G.JXQueue) == "function" then
                    _G.JXQueue({ 'r.MotionBlurQuality 0', 'r.MotionBlur.Amount 0', 'r.DefaultFeature.MotionBlur 0' })
                    okm = true
                end
            end)
            Log('motion blur second pass: re-asserted after scalability queued=' .. tostring(okm))
        end) end)
        if Panel.open then
            Panel.open = false
            Panel.widget, Panel.text = nil, nil
            PakUIOpen = false
            Log("panel auto-closed on map change")
        end
    end)
    return true
end

JX.burstStep = 40
JX.burstN = 0
JX.worldName = nil
JX.worldEpoch = 0
JX.worldReady = 0

JX.worldRuns = 0

JX.loadMapRun = -1

JX.replayPass = {}
JX.replayMax = 4

JX.replayMade = {}

function JXWorldId()
    local wid = nil
    pcall(function()
        local W = UEHelpers.GetWorld()
        if W and W:IsValid() then wid = JXName(W) end
    end)
    if wid == nil or wid == "" or wid == "nil" then return nil end
    return wid
end

function JXWorldEpoch()
    local wid = JXWorldId()
    if not wid then return nil, nil end
    if wid ~= JX.worldName then
        JX.worldName = wid
        JX.worldEpoch = (JX.worldEpoch or 0) + 1
    end
    return JX.worldEpoch, wid
end

function JXLoaderEntries()
    local out = {}
    local f = io.open("Mods/BPModLoaderMod/loaded_mods.txt", "r")
    if not f then return out end
    local pending = nil
    pcall(function()
        for line in f:lines() do
            local mark, name = line:match("^%[%s*([^%]]-)%s*%]%s+(%S+)")
            if mark then
                if mark == "OK" then pending = name else pending = nil end
            elseif pending then
                local path = line:match("^%s*(/Game/[%w%._%-/]+)%s*$")
                if path then
                    out[#out + 1] = { name = pending, path = path }
                    pending = nil
                end
            end
        end
    end)
    f:close()
    return out
end

function JXSpawnLikeLoader(cls)
    local W = nil
    pcall(function() W = UEHelpers.GetWorld() end)
    if not (W and W:IsValid()) then return nil, "no world" end
    if not (cls and cls:IsValid()) then return nil, "class not loaded" end
    local a = nil
    pcall(function() a = W:SpawnActor(cls, {}, {}) end)
    if not JXAlive(a) then pcall(function() a = W:SpawnActor(cls, {}) end) end
    if not JXAlive(a) then pcall(function() a = W:SpawnActor(cls) end) end
    if JXAlive(a) then return a, nil end
    local s, err = JxActor.spawn(cls, 0, 0, 0, 0)
    if JXAlive(s) then return s, nil end
    return nil, tostring(err)
end

function JXEntryCount(clsFull, shortName, wid)
    local all = nil
    pcall(function() all = FindAllOf(shortName) end)
    if not all then return 0 end
    local prefix = tostring(wid) .. ":"
    local n = 0
    for _, a in pairs(all) do
        if JXAlive(a) then
            
            local same = false
            pcall(function()
                local cn = JXName(a:GetClass()) or ""
                same = (cn == clsFull) or (cn == shortName)
                    or (cn:find(shortName, 1, true) ~= nil)
                    or (clsFull ~= "" and clsFull:find(cn, 1, true) ~= nil)
            end)
            if same then
                local here = false
                pcall(function()
                    local aw = a:GetWorld()
                    if aw ~= nil then
                        -- r36: JXName(aw) is the SHORT map name (e.g.
                        -- "LevelFun") while wid is the full path - the old
                        -- strict equality NEVER matched, so the presence
                        -- check always saw 0 and the replay re-spawned actors
                        -- BPModLoaderMod had already created (yumao/Fps
                        -- duplicated every map until the sweep caught up)
                        local ws = JXName(aw) or ""
                        here = (ws ~= "" and ws == wid) or (ws ~= "" and wid:find(ws, 1, true) ~= nil)
                    end
                end)
                if not here then
                    local full = JXName(a)
                    if #full >= #prefix and full:sub(1, #prefix) == prefix then here = true end
                end
                if here then n = n + 1 end
            end
        end
    end
    return n
end

function JXEntryPresent(clsFull, shortName, wid)
    return JXEntryCount(clsFull, shortName, wid) > 0
end

function JXParsePakManifest()
    local f = io.open(ModDir .. "config/pak_manifest.txt", "r")
    if not f then return {} end
    local mods = {}
    local cur = nil
    pcall(function()
        for line in f:lines() do
            
            local sec = line:match("^%s*===%s*MOD%s+([%w%._%-]+)%s*===%s*$")
                or line:match("^%s*##%s*MOD%s+([%w%._%-]+)%s*$")
            if sec then
                cur = { name = sec, mount = nil, assets = {}, sizes = {} }
                mods[#mods + 1] = cur
            elseif cur then
                
                local mp = line:match("Mount point%s+([^%s]+)")
                if mp then cur.mount = mp end
                
                local a, sz = line:match('"([^"]+)%.uasset".-size:%s*(%d+)')
                if not a then a = line:match('"([^"]+)%.uasset"') end
                if a and a ~= "" then
                    cur.assets[#cur.assets + 1] = a
                    if sz then cur.sizes[a] = tonumber(sz) end
                end
            end
        end
    end)
    f:close()
    
    return mods
end
JXParsePakManifest = JXParsePakManifest

JXEntryTiers = {
    
    { "Main_ModActor", "ModActor" },
    
    { "MapActor", "BP_%w+_LC", "%w+_LC", "MainMenu" },
    
    { "BP_%w+", "%w+Actor" },
}

function JXPakAssetPath(mount, asset)
    local raw = (mount or "") .. (asset or "")
    raw = raw:gsub("^[%.%/]+", "")
    local tail = raw:match("Content/(.*)") or raw
    tail = tail:gsub("/+$", "")
    if tail == "" then return "/Game" end
    return "/Game/" .. tail
end
JXPakAssetPath = JXPakAssetPath

function JXPickEntry(mount, assets, sizes, pak)
    local stem = (pak or ""):gsub("_P$", ""):lower()
    local function base(a) return (a:gsub("%.uasset$", "")) end
    local function leaf(a) return (base(a):match("([^/]+)$")) or "" end
    local function dirleaf(a)
        local d = base(a):match("^(.*)/[^/]+$")
        if not d then return "" end
        return ((d:match("([^/]+)$") or ""):lower():gsub("_p$", ""))
    end
    local function depth(a)
        local n = 0
        for _ in base(a):gmatch("/") do n = n + 1 end
        return n
    end
    
    local function isWidget(a)
        local lf = leaf(a)
        return lf:match("^WBP_") ~= nil or lf:match("^W_") ~= nil
            or base(a):lower():find("/umg/", 1, true) ~= nil
    end
    local mods, nMods = {}, 0
    for _, a in ipairs(assets) do
        if JXPakAssetPath(mount, base(a)):lower():find("/mods/", 1, true) then
            nMods = nMods + 1
            if not isWidget(a) then mods[#mods + 1] = a end
        end
    end
    if nMods == 0 then
        return nil, "override pak - replaces game assets, no entry actor to start"
    end
    for ti, tier in ipairs(JXEntryTiers) do
        
        local hits, matched = {}, {}
        for si, shape in ipairs(tier) do
            for _, a in ipairs(mods) do
                local lf = leaf(a)
                if not matched[a] and lf:match("^" .. shape .. "$") then
                    matched[a] = true
                    hits[#hits + 1] = { a, si }
                end
            end
        end
        if #hits > 0 then
            
            table.sort(hits, function(x, y)
                local ax, ay = x[1], y[1]
                local sx = (sizes and (sizes[ax] or sizes[base(ax)])) or 0
                local sy = (sizes and (sizes[ay] or sizes[base(ay)])) or 0
                if sx ~= sy then return sx > sy end            
                if x[2] ~= y[2] then return x[2] < y[2] end     
                local dx, dy = depth(ax), depth(ay)
                if dx ~= dy then return dx < dy end             
                local ddx, ddy = dirleaf(ax), dirleaf(ay)
                if ddx ~= ddy then return ddx == stem end       
                return ax < ay                                  
            end)
            local alts = {}
            for i = 2, #hits do alts[#alts + 1] = leaf(hits[i][1]) end
            local why = "entry from tier " .. tostring(ti) .. " shape "
                .. tier[hits[1][2]] .. ", " .. tostring(#hits) .. " candidate(s)"
            if #alts > 0 then
                why = why .. " - runners-up left alone: " .. table.concat(alts, ", ", 1,
                    math.min(#alts, 4))
            end
            return JXPakAssetPath(mount, base(hits[1][1])), why
        end
    end
    return nil, "no entry-shaped asset among " .. tostring(nMods)
        .. " under Mods/ - pin this one with a row in config/extra_mods.txt"
end
JXPickEntry = JXPickEntry

function JXManifestEntries()
    local out = {}
    local mods = JXParsePakManifest()
    for _, m in ipairs(mods) do
        
        if m.name == "JinxingLoader_P" or m.name == "JinxingLoader" then
            Log("pak manifest: " .. m.name .. " is this loader's own pak - not an entry")
        else
            local picked, why = JXPickEntry(m.mount, m.assets, m.sizes, m.name)
            if picked then
                out[#out + 1] = { name = m.name, path = picked, src = "manifest" }
                Log("pak manifest: " .. m.name .. " -> " .. picked .. " (" .. why .. ")")
            else
                Log("pak manifest: " .. m.name .. ": " .. why)
            end
        end
    end
    return out
end
JXManifestEntries = JXManifestEntries

function JXScanOnePak(path)
    local MAGIC = "\xE1\x12\x6F\x5A"    
    local rec = { path = path, assets = 0, mount = nil, pick = nil, why = "" }
    local f = io.open(path, "rb")
    if not f then rec.why = "cannot open"; return rec end
    local size = f:seek("end")
    if not size or size < 64 then f:close(); rec.why = "file too small"; return rec end
    local head = math.min(size, 512)
    f:seek("set", size - head)
    local tail = f:read(head) or ""
    local p, q = nil, tail:find(MAGIC, 1, true)
    while q do p = q; q = tail:find(MAGIC, p + 1, true) end
    if not p or p + 21 > #tail then
        f:close(); rec.why = "no pak footer magic in the last 512 bytes"; return rec
    end
    local ver, idxOff, idxSize = tail:unpack("<I4i8i8", p + 4)
    if type(idxOff) ~= "number" or type(idxSize) ~= "number" or idxOff <= 0
        or idxSize <= 0 or idxOff + idxSize > size then
        f:close(); rec.why = "implausible index offset/size (encrypted index?)"; return rec
    end
    local want = idxSize + 262144
    if idxOff + want > size then want = size - idxOff end
    f:seek("set", idxOff)
    local blob = f:read(want) or ""
    f:close()
    if #blob < 16 then rec.why = "empty index window"; return rec end
    local mount = blob:sub(1, 4096):match("EscapeTheBackrooms/([%w%._%-/]*)")
    if mount == nil then
        rec.why = "no plain mount point in the index head"
        return rec
    end
    rec.mount = mount
    
    local seen, names, cur = {}, {}, ""
    for run in blob:gmatch("[%w%._%-/]+") do
        if run:match("^[%w%._%-/]+/$") then
            
            cur = (run:gsub("/+$", "")) .. "/"
        elseif run:match("%.uasset$") then
            local rel = run
            if not rel:find("/", 1, true) then rel = cur .. rel end
            rel = rel:gsub("^Content/", "")
            if rel ~= "" and not seen[rel] and #names < 2000 then
                seen[rel] = true
                names[#names + 1] = rel
            end
        end
    end
    rec.assets = #names
    
    rec.pick, rec.why = JXPickEntry(mount, names, nil, path:match("([^/\\]+)%.pak$") or "")
    return rec
end

function JXRawPakScan()
    local DIR = "../../Content/Paks/LogicMods/"
    JX.pakScan = JX.pakScan or {}          
    JX.pakScanReport = {}                  
    local out = {}
    
    local listing = ModDir .. "config/_pakscan_list.txt"
    
    pcall(function()
        os.execute('if not exist "' .. (ModDir .. "config"):gsub("/", "\\")
            .. '" mkdir "' .. (ModDir .. "config"):gsub("/", "\\") .. '" >nul 2>nul')
    end)
    local okCmd = os.execute('dir /b "' .. DIR:gsub("/", "\\") .. '*.pak" > "'
        .. listing:gsub("/", "\\") .. '" 2>nul')
    local names = {}
    local f = io.open(listing, "r")
    if f then
        for line in f:lines() do
            local nm = line:match("^%s*([%w%._%-]+)%s*$")
            if nm and nm:lower():sub(-4) == ".pak" then names[#names + 1] = nm:sub(1, -5) end
        end
        f:close()
    end
    JX.pakScanReport.cleared = okCmd and "listing read" or "dir command returned no status"
    JX.pakScanReport.count = #names
    for _, name in ipairs(names) do
        local rec = JX.pakScan[name]
        local why
        if name:match("^JinxingLoader") then
            why = "this loader's own pak - never an entry"
        else
            if not rec then
                rec = JXScanOnePak(DIR .. name .. ".pak")
                JX.pakScan[name] = rec
            end
            why = rec.why
            if rec.pick then
                out[#out + 1] = { name = name, path = rec.pick, src = "pak-scan" }
            end
        end
        JX.pakScanReport[#JX.pakScanReport + 1] = {
            name = name,
            mount = rec and rec.mount or nil,
            assets = rec and rec.assets or 0,
            pick = rec and rec.pick or nil,
            why = why,
        }
    end
    if #names == 0 then Log("pak scan: no .pak found under " .. DIR .. " (or the listing failed)") end
    return out
end

function JXExtraEntries()
    local out = {}
    local byName = {}
    
    pcall(function()
        local derived = JXManifestEntries()
        for _, e in ipairs(derived) do
            out[#out + 1] = e
            byName[e.name] = #out
        end
        if #derived > 0 then
            Log("pak manifest: " .. #derived .. " entry candidate(s) derived from config/pak_manifest.txt")
        end
    end)
    
    pcall(function()
        local found = JXRawPakScan()
        for _, e in ipairs(found) do
            if not byName[e.name] then
                out[#out + 1] = e
                byName[e.name] = #out
                Log("pak scan: " .. e.name .. " -> " .. e.path)
            end
        end
        if #found > 0 then
            Log("pak scan: " .. #found .. " entry candidate(s) discovered in LogicMods")
        end
    end)
    
    local f = io.open(ModDir .. "config/extra_mods.txt", "r")
    if not f then return out end
    
    local byPath = {}
    for i = 1, #out do byPath[out[i].path] = i end
    pcall(function()
        for line in f:lines() do
            
            line = line:gsub("^\239\187\191", "")
            local nm, p = line:match("^%s*([%w%._%-]+)%s*=%s*(/Game/[%w%._%-/]+)%s*$")
            if nm and p then
                local slot = byName[nm] or byPath[p]
                if slot then
                    Log("extra_mods: " .. nm .. " overrides the " .. tostring(out[slot].src)
                        .. " entry " .. out[slot].name .. " -> " .. p)
                    out[slot] = { name = nm, path = p, src = "extra_mods" }
                    byName[nm] = slot
                else
                    out[#out + 1] = { name = nm, path = p, src = "extra_mods" }
                    byName[nm] = #out
                end
            end
        end
    end)
    f:close()
    return out
end

function JXReplayLoader(tag, wid)
    if not wid or wid == "" then return 0 end
    
    local key = tostring(JX.worldRuns or wid)
    local pass = (JX.replayPass[key] or 0) + 1
    if pass > (JX.replayMax or 4) then
        Log("loader replay: world run " .. key .. " (" .. tostring(wid)
            .. ") already had its " .. tostring(JX.replayMax)
            .. " passes - not running another one")
        return 0
    end
    JX.replayPass[key] = pass
    local entries = JXLoaderEntries()
    
    local extras = JXExtraEntries()
    for i = 1, #extras do entries[#entries + 1] = extras[i] end
    if #extras > 0 then
        Log(string.format("loader replay: %d extra entry(ies) read from config/extra_mods.txt", #extras))
        for _, e in ipairs(extras) do
            Log("loader replay:   extra -> " .. e.name .. " " .. e.path)
        end
    end
    if #entries == 0 then
        Log("loader replay: Mods/BPModLoaderMod/loaded_mods.txt lists no resolved entry - nothing to replay")
        return 0
    end
    local spawned, present, failed = 0, 0, 0
    for _, e in ipairs(entries) do
        local leaf = e.path:match("([^/]+)$")
        -- r36: class-name tolerance. Cooked paks keep the package file name
        -- but the inner UClass may differ, and a plain find misses anything
        -- not yet loaded. Try <leaf>_C first (authored shape), then the
        -- package's primary object (in cooked BPs that IS the UClass
        -- whatever its inner name), then the CDO (its class is the target).
        local cls = nil
        local via = ""
        if leaf then
            cls = J3LoadObject(e.path .. "." .. leaf .. "_C")
            if cls and cls:IsValid() then via = leaf .. "_C" else cls = nil end
        end
        if not cls and leaf then
            local prim = J3LoadObject(e.path)
            if prim and prim:IsValid() then
                local iscls = false
                pcall(function() iscls = (JXName(prim:GetClass()) == "Class") end)
                if iscls then cls = prim; via = "<primary class>" end
            end
        end
        if not cls and leaf then
            local cdo = J3LoadObject(e.path .. ".Default__" .. leaf .. "_C")
            if cdo and cdo:IsValid() then
                pcall(function() cls = cdo:GetClass() end)
                if cls and cls:IsValid() then via = "CDO->class" else cls = nil end
            end
        end
        if cls and cls:IsValid() then
            if JXEntryPresent(JXName(cls), leaf .. "_C", wid) then
                present = present + 1
            else
                local a, err = JXSpawnLikeLoader(cls)
                if JXAlive(a) then
                    spawned = spawned + 1
                    -- r53: root the class so the next map transition cannot
                    -- GC it (Level0 session: classes that spawned fine on one
                    -- map went not-resident on the next). r55: no-ops with a
                    -- one-time notice on official UE4SS v3.0.1 (pre-AddToRoot).
                    if cls.AddToRoot then
                        pcall(function() cls:AddToRoot() end)
                    elseif not JX_pinWarned then
                        JX_pinWarned = true
                        Log("pin unavailable: UObject.AddToRoot absent on this UE4SS build - replay class pin off, per-map re-spawn is the net")
                    end

                    local made = JX.replayMade[key]
                    if not made then made = {}; JX.replayMade[key] = made end
                    made[#made + 1] = { cls = JXName(cls), a = a }
                    Log("loader replay: re-created " .. e.name .. " in " .. tostring(wid)
                        .. " (entry " .. e.path .. (via ~= "" and (" via " .. via) or "") .. ")")
                else
                    failed = failed + 1
                    Log("loader replay: could not re-create " .. e.name .. " (" .. tostring(err) .. ")")
                end
            end
        else
            failed = failed + 1

            -- r47: capture WHY so a real asset failure is visible in the log
            local whyDetail = ""
            pcall(function()
                local so = StaticFindObject(e.path .. "." .. tostring(leaf) .. "_C")
                if so and so:IsValid() then whyDetail = "static-found-late" end
            end)
            if whyDetail == "" then
                pcall(function() whyDetail = "not-resident (EDL pending or pak not mounted here)" end)
            end
            Log("loader replay: " .. e.name .. " entry class did not load here (tried "
                .. e.path .. "." .. tostring(leaf) .. "_C; " .. whyDetail .. ")")
        end
    end
    Log(string.format("loader replay (%s) pass %d in %s: %d re-created, %d already there, %d not loadable, %d entry(ies) listed",
        tostring(tag), pass, tostring(wid), spawned, present, failed, #entries))
    if spawned == 0 and failed == 0 then

        JX.replayPass[key] = JX.replayMax or 4
    end
    -- r47: transition-window class loads fail while EDL is still settling and
    -- the 4 passes used to burn within seconds of each other. Z_Arsenal_P is
    -- the hard case - its assets live under Mods/Z_Traps_P/ so BPModLoaderMod's
    -- filename convention (/Game/Mods/Z_Arsenal_P/ModActor) finds NOTHING and
    -- OUR replay is its only loader. Retry once more a full minute after
    -- arrival, when the world and its dependency chains are fully streamed.
    if failed > 0 and pass < (JX.replayMax or 4) then
        local lateWid = wid
        ExecuteWithDelay(60000, function()
            ExecuteInGameThread(function()
                pcall(function() JXReplayLoader(tostring(tag) .. "+60s", lateWid) end)
            end)
        end)
        Log("loader replay: " .. failed .. " entr(ies) failed - late retry in 60 s (pass " .. (pass + 1)
            .. "/" .. tostring(JX.replayMax or 4) .. ")")
    end
    return spawned
end

function JXReplaySweep(tag, wid)
    if not wid or wid == "" then return 0 end
    local key = tostring(JX.worldRuns or wid)
    local made = JX.replayMade and JX.replayMade[key]
    if not made or #made == 0 then return 0 end
    JX.replayMade[key] = nil   
    local removed = 0
    for _, rec in ipairs(made) do
        if JXAlive(rec.a) then
            local short = rec.cls:match("([^%.]+)$")
            local live = 0
            if short then live = JXEntryCount(rec.cls, short, wid) end
            if live > 1 then
                local ok = pcall(function() rec.a:K2_DestroyActor() end)
                if not ok then pcall(function() rec.a:Destroy() end) end
                removed = removed + 1
                Log("loader replay: " .. tostring(rec.cls) .. " is alive " .. live
                    .. " times in " .. tostring(wid) .. " - removed the copy this replay "
                    .. "created, the loader's own copy stays")
            end
        end
    end
    Log("loader replay sweep (" .. tostring(tag) .. ") in " .. tostring(wid) .. ": "
        .. removed .. " duplicate(s) removed of " .. #made .. " creation(s) this replay made")
    return removed
end

function JXOnActorBeginPlay()
    JX.burstN = (JX.burstN or 0) + 1
    local step = JX.burstStep or 40
    if step < 1 then step = 1 end
    if JX.burstN % step ~= 0 then return end
    pcall(function()
        ExecuteInGameThread(function()
            local epoch, wid = JXWorldEpoch()
            if not epoch then return end
            if epoch == JX.worldReady then return end
            JXWorldReady("beginplay burst", epoch, wid)
        end)
    end)
end

pcall(function()
    if RegisterBeginPlayPostHook then
        RegisterBeginPlayPostHook(JXOnActorBeginPlay)
        Log("v3.13 world-ready trigger armed (beginplay burst, one world read per "
            .. tostring(JX.burstStep) .. " actors) - this is the trigger a host map switch reaches")
    else
        Log("v3.13 world-ready trigger NOT armed: RegisterBeginPlayPostHook is missing in this UE4SS build")
    end
end)

RegisterLoadMapPostHook(function(Engine, World)
    local epoch, wid = JXWorldEpoch()
    
    if epoch then
        local when = "arrived before the beginplay trigger latched a world - this hook is the one that latched it"
        if epoch == JX.worldReady and (JX.worldReadyAt or 0) > 0 then
            when = tostring(JXClock() - JX.worldReadyAt)
                .. " ms after the beginplay trigger latched this world"
        end
        Log("map load post-hook reached: " .. tostring(wid) .. " (run "
            .. tostring(JX.worldRuns or 0) .. ", " .. when .. ")")
    end
    if not epoch then
        
        JXBeginTransition(2500)
        PakUISlot[1], F6UiSlot[1], LoaderCoreSlot[1] = nil, nil, nil
        JX.actorSweepBudget = 4
        JxActor.protect = false
        JXPump.queue = {}
        Log("map load: the new world was not readable in the post-hook - recovery left to the beginplay trigger")
        return
    end
    JXWorldReady("map load", epoch, wid)
    
    JX.loadMapRun = JX.worldRuns or 0
end)

RegisterHook("/Script/Engine.PlayerController:ClientRestart", function(self)
    
    local ok, err = pcall(function()
    
    if JXBusy() then return end
    ExecuteInGameThread(function()
        pcall(function()
            local PC = self:get()
            if PC and PC:IsValid() and PC.PlayerState and PC.PlayerState:IsValid() then
                RecordJoin(PC.PlayerState)
                if IsBlacklisted(PlayerName(PC.PlayerState), PlayerId(PC.PlayerState)) then
                    EnforceBlacklist()
                end
            end
        end)
        pcall(function() ApplyMaxPlayers(false) end)
        
        pcall(function() ApplyCvars("join") end)
        
        if JXWorldReady then
            local epoch, wid = JXWorldEpoch()
            if epoch then JXWorldReady("player restart", epoch, wid) end
        end
        
        if not JX.scannedBoot and #MapList == 0 then
            JX.scannedBoot = true
            -- r46: map enumeration is heavy - defer it off the join instant so
            -- the connecting/landing path stays snappy
            ExecuteWithDelay(4000, function()
                ExecuteInGameThread(function() pcall(TryScan, 1) end)
            end)
        end
    end)
    end)
    if not ok then Log("HOOK| ClientRestart guarded: " .. tostring(err)) end
end)

JX.Cmd = {}
JX.CmdOrder = {}

JX.Errs = {}
function JXErrShow(tag, err)
    local msg = "[" .. tostring(tag) .. "] " .. tostring(err)
    table.insert(JX.Errs, os.date("%H:%M:%S ") .. msg)
    if #JX.Errs > 20 then table.remove(JX.Errs, 1) end
    JX.ErrSayT = JX.ErrSayT or 0
    JX.ErrSayN = (JX.ErrSayN or 0) + 1
    local now = os.clock()
    if now - JX.ErrSayT >= 5 then
        JX.ErrSayT = now
        pcall(function() JXSay(msg) end)
    end
end
JX.Say = JXSay

_G.JX = JX

function JXRegCmd(name, fn)
        
    local safe = function(a, b)
        
        local gates = (type(JX) == "table" and type(JX.Gates) == "table") and JX.Gates[name] or nil
        if gates and not gates.Allow(a) then
            pcall(gates.Refuse, gates.need, name)
            return true
        end
        local okr, r = pcall(fn, a, b)
        if not okr then
            Log("cmd '" .. tostring(name) .. "' handler error: " .. tostring(r))
            pcall(JXErrShow, "cmd " .. tostring(name), r)
            return true
        end
        if r == nil then return true end
        return r
    end
    local ok, ret = pcall(RegisterConsoleCommandHandler, name, safe)
    
    local good = ok and (ret ~= false)
    local t = JX.Cmd
    if type(t) ~= "table" then t = {}; JX.Cmd = t end
    if t[name] == nil then
        local o = JX.CmdOrder
        if type(o) ~= "table" then o = {}; JX.CmdOrder = o end
        o[#o + 1] = name
    end
    local cf = JX.CmdFn
    if type(cf) ~= "table" then cf = {}; JX.CmdFn = cf end
    cf[name] = fn
    t[name] = good
    if not good then
        Log("wiring: '" .. name .. "' FAILED to register ("
            .. (ok and ("returned " .. tostring(ret)) or ("threw " .. tostring(ret))) .. ")")
    end
    return ret
end

do
    local sd = _G.JXSidecarDir or ""
    local function TryLate(name)
        local mc = loadfile(sd .. name)
        if mc then
            local okm, merr = pcall(mc)
            if okm then
                Log(name .. " loaded (late)")
            else
                Log(name .. " late load error: " .. tostring(merr))
                pcall(JXErrShow, "load " .. tostring(name), merr)
            end
        else
            Log(name .. " not found for late load (non-fatal)")
        end
    end
    TryLate("JxSliderHub.lua")
    TryLate("JxHideSeek.lua")
    -- r16: JxHUDPanel retired (old PLUS/PRO canvas UI, HUD had no dispatch)
    TryLate("JxUiRescue427.lua")
    TryLate("JxUiRouter.lua")
    TryLate("JxUiShell.lua")
    
    TryLate("JxWhitelist.lua")
    pcall(function()
        local JW = _G.JxWhitelist
        if type(JW) == "table" and type(JW.File) == "string" and not JW.File:find("[\\/]") then
            JW.File = ModDir .. "config/whitelist_steam64.txt"
            if type(JW.Reload) == "function" then JW.Reload() end
            Log("JxWhitelist file bound to config dir: " .. JW.File)
        end
    end)
    TryLate("JxDiagnose.lua")
    TryLate("JxPlayerHub.lua")
    
    TryLate("JxFpsTurbo.lua")
    TryLate("JxUiLinkCheck.lua")
    
    TryLate("JxFrameStats.lua")

    JXRegCmd("junlock", function(FullCommand, Parameters, Ar)
        if type(_G.JXForceUnlock) == "function" then
            _G.JXForceUnlock()
            Log("JXBusy window released by 'junlock' - panel keys active again")
            print("[JX] UI lock released")
        else
            Log("junlock: JXForceUnlock not exposed (main.lua older than r4.3?)")
        end
        return true
    end)

do
    JXRegCmd("jerr", function(FullCommand, Parameters, Ar)
        local n = tonumber(Parameters and Parameters[1] or "") or 10
        local errs = JX.Errs or {}
        if #errs == 0 then
            JXSay("jerr: no recorded errors")
        else
            JXSay("jerr: " .. #errs .. " recorded, last " .. math.min(n, #errs))
            for i2 = math.max(1, #errs - n + 1), #errs do
                JXSay("  " .. errs[i2])
            end
        end
        return true
    end)
    Log("jerr ready: errors are shown on screen (throttled) and buffered")
end
end

do
    local SG = _G.JXSaveGameLib
    if type(SG) == "table" then
        local function ModSaves()
            return (ModDir or (JXSidecarDir or "")) .. "saves/"
        end
        local function SlotSay(s) Log("jxslot: " .. tostring(s)) end
        JXRegCmd("jxslot", function(FullCommand, Parameters)
            local action = tostring(Parameters or ""):match("%S+") or "status"
            if action == "status" then
                local okS, st = pcall(function() return SG.EngineStatus() end)
                if not okS or type(st) ~= "table" then
                    SlotSay("status error: " .. tostring(st)); return true
                end
                local exists = false
                pcall(function() exists = SG.DoesSlotExist() or false end)
                local p = select(1, SG.SlotPath())
                SlotSay("engine=" .. tostring(st.engine)
                    .. " saveClass=" .. tostring(st.saveClassFound)
                    .. " (" .. tostring(st.className or "-") .. ")"
                    .. " slot=" .. tostring(p)
                    .. " exists=" .. tostring(exists))
                return true
            end
            if action == "export" then
                
                local okE, doc = pcall(function() return SG.MigrateFromMod(ModSaves()) end)
                if not okE or type(doc) ~= "table" then
                    SlotSay("export failed: " .. tostring(doc)); return true
                end
                local okW, res = pcall(function() return SG.Save(doc) end)
                if okW and res ~= false then
                    SlotSay("exported mod saves -> " .. tostring(SG.SlotName) .. ".sav")
                else
                    SlotSay("save failed: " .. tostring(res))
                end
                return true
            end
            if action == "import" then
                
                local okL, doc = pcall(function() return SG.Load({}) end)
                if not okL or type(doc) ~= "table" then
                    SlotSay("import failed: " .. tostring(doc)); return true
                end
                local okX, xres = pcall(function()
                    return SG.ExportToMod(doc, ModSaves(), SG.Sections)
                end)
                if okX and xres then
                    SlotSay("imported " .. tostring(SG.SlotName) .. ".sav -> mod saves")
                else
                    SlotSay("export-to-mod failed: " .. tostring(xres))
                end
                return true
            end
            SlotSay("usage: jxslot status|export|import")
            return true
        end)
        Log("jxslot wired (status|export|import, GVAS " .. tostring(SG.SlotName) .. ")")
    else
        Log("jxslot NOT wired: JxSaveGame library missing (non-fatal)")
    end
end

JXPakTokens = "jactor jbanlist jbench jboost jcap jchat jfly jguard jkick jkill "
    .. "jlink jlist jlistplaced jload jmaps jmax jmods jname jpardon jperf "
    .. "jplace jpos jreload jsave jstatus jtab jword sedet jgrid jloc jsub jxtabs"

JXRegCmd("jwiring", function()
    ExecuteInGameThread(function()
        pcall(function()
            local say = function(s) Log("wiring: " .. s) end

            local core = nil
            pcall(function() core = AcquireLoaderCore() end)
            say("Core = " .. (JXAlive(core) and "live" or "ABSENT (panel buttons fall back to Lua)"))

            local clsName, mcount = "", 0
            pcall(function()
                local cls = J3LoadObject("/Game/Mods/JinxingLoader_P/ModActor.ModActor_C")
                if cls and cls:IsValid() then clsName = tostring(cls:GetFullName()) end
            end)
            pcall(function()
                local all = FindAllOf("ModActor_C")
                if not all then return end
                for _, a in pairs(all) do
                    if JXAlive(a) then
                        local n = ""
                        pcall(function() n = tostring(a:GetClass():GetFullName()) end)
                        if clsName ~= "" and n == clsName then mcount = mcount + 1 end
                    end
                end
            end)
            say("pak class = " .. (clsName ~= "" and clsName or "NOT LOADED")
                .. " | instances of it live in this level = " .. mcount
                .. (mcount == 0 and "  <- no panel and no B key here" or ""))

            local sw = nil
            pcall(function() sw = AcquireTabSwitcher() end)
            if JXAlive(sw) then
                local pages, act = -1, -1
                pcall(function() pages = sw:GetNumWidgets() end)
                if type(pages) ~= "number" or pages <= 0 then
                    pcall(function() pages = sw:GetChildrenCount() end)
                end
                pcall(function() act = sw:GetActiveWidgetIndex() end)
                say("switcher = " .. JXName(sw) .. " | pages=" .. tostring(pages)
                    .. " | active=" .. tostring(act) .. " | Lua TabIndex=" .. tostring(TabIndex))
            else
                say("switcher = not found (panel closed, or the widget is not built yet)")
            end
            say("tab hook = " .. (JX.TabHookArmed and "armed" or "NOT armed")
                .. " | fires=" .. tostring(JX.TabHookFires or 0)
                .. " | ours=" .. tostring(JX.TabMine or 0)
                .. " | unnamed=" .. tostring(JX.TabHookNoName or 0)
                .. (JX.TabHookWhy and (" (" .. tostring(JX.TabHookWhy) .. ")") or "")
                .. " | other=" .. tostring(JX.TabHookOther or "-")
                .. " | back-trail=" .. tostring(type(JX.TabHist) == "table" and #JX.TabHist or 0))

            local reg, refused, list = 0, {}, {}
            for _, n in ipairs(JX.CmdOrder or {}) do
                if JX.Cmd[n] == false then
                    refused[#refused + 1] = n
                else
                    reg = reg + 1
                    list[#list + 1] = n
                end
            end
            say("console handlers registered = " .. reg
                .. (reg == 0 and "  <- the file never reached its registrations" or ""))
            say("registered: " .. table.concat(list, " "))
            if #refused > 0 then say("REFUSED by UE4SS: " .. table.concat(refused, " ")) end

            local miss = {}
            for tok in string.gmatch(JXPakTokens, "%S+") do
                if JX.Cmd[tok] == nil then miss[#miss + 1] = tok end
            end
            if #miss == 0 then
                say("every one of the 27 pak tokens has a handler")
            else
                say("MISSING pak tokens (" .. #miss .. "): " .. table.concat(miss, " ")
                    .. "  <- those panel buttons do nothing")
            end
        end)
    end)
    return true
end)

JXRegCmd("jmax", function(FullCommand, Parameters, Ar)
    ExecuteInGameThread(function()
        local n = tonumber(Parameters[1])
        if n and n >= 1 and n <= 512 then
            Config.MaxPlayers = math.floor(n)
            Log("max players -> " .. Config.MaxPlayers)
        end
        ApplyMaxPlayers(true)
    end)
    return true
end)

JXRegCmd("jcap", function(FullCommand, Parameters, Ar)
    ExecuteInGameThread(function()
        local n = tonumber(Parameters[1])
        if n and n >= 32 and n <= 512 then
            Config.MaxPlayers = math.floor(n)
            ApplyMaxPlayers(true)
        else
            Log("usage: jcap 32-512 (current " .. Config.MaxPlayers .. ")")
        end
    end)
    return true
end)

JXRegCmd("jban", function(FullCommand, Parameters, Ar)
    ExecuteInGameThread(function()
        local target = Parameters and Parameters[1] or nil
        if not target or target == "" then
            Log("usage: jban <name|steam64|netid>")
            return
        end
        AddBlacklist(target)
        Log("blacklisted: " .. target)
        EnforceBlacklist()
    end)
    return true
end)

JXRegCmd("jpardon", function(FullCommand, Parameters, Ar)
    ExecuteInGameThread(function()
        local target = Parameters and Parameters[1] or nil
        if not target or target == "" then
            for i, e in ipairs(BlacklistOrder) do Log(string.format("[%d] %s", i, e)) end
            Log("usage: jpardon <index|name|id>")
            return
        end
        local idx = tonumber(target)
        if idx and BlacklistOrder[idx] then
            RemoveBlacklist(idx)
            Log("pardoned: " .. tostring(BlacklistOrder[idx] or target))
        else
            for i, e in ipairs(BlacklistOrder) do
                if e:lower() == target:lower() then RemoveBlacklist(i) Log("pardoned: " .. e) return end
            end
            Log("not found in blacklist: " .. target)
        end
    end)
    return true
end)

JXRegCmd("jlist", function()
    ExecuteInGameThread(function() RunGuarded("jlist", ListPlayers) end)
    return true
end)

JXRegCmd("jreload", function()
    ExecuteInGameThread(function()
        pcall(function()
            LoadConfig()
            ApplyMaxPlayers(true)
            EnforceBlacklist()
        end)
    end)
    return true
end)

JXRegCmd("jkick", function(FullCommand, Parameters, Ar)
    ExecuteInGameThread(function()
        local target = Parameters and Parameters[1] or nil
        
        if not target or target == "" then
            Log("usage: jkick <name|steam64|netid>  (kick + blacklist)")
            RunGuarded("jkick usage", ListPlayers)
            return
        end
        AddBlacklist(target)
        
        local n = EnforceBlacklist()
        if n == 0 then
            Log("jkick: '" .. target .. "' is blacklisted, but nobody in this room matches it."
                .. " Names must match exactly as the game reports them - jlist shows them.")
        end
    end)
    return true
end)

JXRegCmd("jfly", function(FullCommand, Parameters, Ar)
    ExecuteInGameThread(function()
        
        local sub = Parameters and Parameters[1] or ""
        sub = tostring(sub):lower()
        if sub == "up" or sub == "down" then
            if not Fly.On then
                Log("jfly " .. sub .. ": flight is off - press F4 first")
                return
            end
            if sub == "up" then Fly.Up() else Fly.Down() end
            Log("jfly " .. sub .. ": 1.5s vertical pulse")
            return
        end
        if sub == "on" or sub == "off" then
            local want = (sub == "on")
            if Fly.On ~= want then
                local ok2, err2 = pcall(Fly.Set, want)
                if not ok2 then Log("jfly " .. sub .. ": " .. tostring(err2)) end
            else
                Log("jfly " .. sub .. ": already " .. sub)
            end
            return
        end
        
        local ok, err = pcall(Fly.Toggle)
        if not ok then
            Log("jfly: " .. tostring(err))
        else
            Log("jfly toggle -> " .. (Fly.On and "ON" or "OFF"))
        end
    end)
    return true
end)

JXRegCmd("jpanel", function(FullCommand, Parameters, Ar)
    ExecuteInGameThread(function()
        
        local jp = _G.JxPanels
        local sub = Parameters and Parameters[1] or nil
        if sub == "text" then
            RunGuarded("jpanel text", ToggleTextPanel)
        elseif sub == "status" then
            Log("PNL| canvas open=" .. tostring(jp and jp.open) .. " tab=" .. tostring(jp and jp.tab))
        elseif sub == "hide" then
            if jp and jp.ForceClose then jp.ForceClose() else Log("PNL| canvas not loaded") end
        elseif sub == "show" then
            if jp and jp.Open then jp.Open() else Log("PNL| canvas not loaded") end
        elseif type(_G.JXPakToggle) == "function" then
            _G.JXPakToggle()
        else
            Log("PNL| no panel host loaded (canvas absent)")
        end
    end)
    return true
end)

JXRegCmd("jmaps", function()
    ExecuteInGameThread(function()
        local gained = ScanMaps()
        if gained > 0 then SaveMaps() end
        Log(string.format("levels: %d total (+%d new) [%s]", #MapList, gained, MapScanMsg))
        for i, p in ipairs(MapList) do Log(string.format("  [%d] %s", i, p)) end
    end)
    return true
end)

JXRegCmd("jtravel", function(FullCommand, Parameters, Ar)
    ExecuteInGameThread(function()
        local arg = Parameters and Parameters[1] or nil
        if not arg or arg == "" then
            Log("usage: jtravel <index|next|prev|rand|/Game/Maps/Name>  (list with jmaps)")
            return
        end
        local n = #MapList
        if n == 0 then Log("no owned levels cached - run 'jmaps' first"); return end
        local here = CurrentMapName()
        local curIdx = 0
        for i, p in ipairs(MapList) do
            local short = p:match("/([^/]+)$") or p
            if short == here then curIdx = i end
        end
        local target = nil
        if arg == "next" then
            target = MapList[(curIdx % n) + 1]
        elseif arg == "prev" then
            local pi = curIdx
            if pi == 0 then pi = n end       
            target = MapList[((pi - 2 + n) % n) + 1]
        elseif arg == "rand" then
            target = MapList[math.random(1, n)]
        else
            local idx = tonumber(arg)
            if idx and MapList[idx] then
                target = MapList[idx]
            elseif arg:sub(1, 1) == "/" then
                target = NormaliseMapPath(arg)
            end
        end
        if not target then
            Log("unknown target: " .. tostring(arg) .. "  (use index / next / prev / rand / full path)")
            return
        end
        local ok, err = TravelTo(target)
        if not ok then Log("travel failed: " .. tostring(err)) end
    end)
    return true
end)

JXRegCmd("jperf", function(FullCommand, Parameters, Ar)
    ExecuteInGameThread(function()
        local sub = Parameters and Parameters[1] or nil
        if not sub or sub == "list" then
            for i, it in ipairs(PerfItems) do
                Log(string.format("  [%s] %s = %s (%s..%s)", i, it.key,
                    string.format("%g", it.cur), string.format("%g", it.min), string.format("%g", it.max)))
                if it.fan then
                    local lines = it.fan[math.floor(it.cur + 0.5)] or {}
                    Log("       -> " .. table.concat(lines, " | "))
                end
            end
            return
        end
        
        if sub == "motion" or sub == "check" then
            local want = PerfItems[PerfIdxFromKey("motion") or 0]
            local wv = want and want.cur or -1
            local lines = want and want.fan and want.fan[math.floor(wv + 0.5)] or {}
            Log("jperf check: motion item believes cur=" .. string.format("%g", wv)
                .. " -> should have sent [" .. table.concat(lines, " | ") .. "]")
            
            local PC = nil
            pcall(function() PC = UEHelpers.GetPlayerController() end)
            if not JXAlive(PC) then
                Log("jperf check: no player controller yet - values are applied on the next map load")
                return
            end
            local want1 = "r.DefaultFeature.MotionBlur"
            local want2 = "r.MotionBlurQuality"
            
            pcall(function() JXExecCmd(PC, want1) end)
            pcall(function() JXExecCmd(PC, want2) end)
            Log("jperf check: asked the engine for " .. want1 .. " and " .. want2
                .. " - compare their echoed values above against ["
                .. table.concat(lines, " | ") .. "]")
            Log("jperf check: if the two disagree, the write is being dropped; if")
            Log("jperf check: r.DefaultFeature.MotionBlur echoes 0, motion blur is OFF")
            Log("jperf check: regardless of the quality number - they are separate cvars.")
            return
        end
        if sub == "set" then
            local k = Parameters[2]
            local v = tonumber(Parameters[3])
            local i = k and PerfIdxFromKey(k) or nil
            if not i or not v then Log("usage: jperf set <key> <value>"); return end
            PerfClamp(i, v)
            PerfApplyOne(i)
            PerfSave()
            Log("perf " .. k .. " -> " .. string.format("%g", PerfItems[i].cur))
            return
        end
        if sub == "preset" then
            PerfApplyPreset(Parameters[2] or "bal")
            return
        end
        
        if sub == "perf" or sub == "bal" or sub == "qual" then
            PerfApplyPreset(sub)
            return
        end
        if sub == "reset" then
            PerfRestoreDefaults()
            return
        end
        Log("usage: jperf list | set <key> <value> | preset perf|bal|qual | perf|bal|qual | reset")
    end)
    return true
end)

JXRegCmd("jboost", function(FullCommand, Parameters, Ar)
    ExecuteInGameThread(function()
        local sub = Parameters and Parameters[1] or nil
        if not sub or sub == "" then
            Log("jboost: level=" .. BoostLevel
                .. "  (usage: jboost off|balanced|max; queued="
                .. tostring(#JXPump.queue) .. ")")
            return
        end
        BoostApply(sub)
    end)
    return true
end)

JXRegCmd("jguard", function()
    Log(string.format("guard: busy=%s budget=%d queue=%d core=%s pakui=%s f6=%s",
        tostring(JXBusy()), JX.actorSweepBudget, #JXPump.queue,
        tostring(LoaderCoreSlot[1] ~= nil), tostring(PakUISlot[1] ~= nil),
        tostring(F6UiSlot[1] ~= nil)))
    return true
end)

local Slot = {}
local AutoSlot = nil        
local SaveDir = nil
do   
    
    pcall(function()
        local la = os.getenv and os.getenv("LOCALAPPDATA") or nil
        if la and la ~= "" and not la:find("%") then
            SaveDir = la .. "\\EscapeTheBackrooms\\Saved\\SaveGames\\"
        end
    end)
    if not SaveDir then
        pcall(function()
            local ph = io.popen('echo %LOCALAPPDATA%')
            if ph then
                local la = ph:read("*l")
                ph:close()
                if la and la ~= "" and not la:find("%") then
                    SaveDir = la .. "\\EscapeTheBackrooms\\Saved\\SaveGames\\"
                end
            end
        end)
    end
    if not SaveDir then SaveDir = "../../Saved/SaveGames/" end
local OrderFile = JXRootOr .. "config/map_order.txt"
local AutoFile  = JXRootOr .. "config/autoload.txt"
Slot.OrderFile = OrderFile
Slot.AutoFile  = AutoFile

Slot.SavesDir    = ModDir .. "saves/"

local function SanitiseName(s)
    s = tostring(s or ""):gsub("[^%w_%-]", ""):sub(1, 40)
    if s == "" then return nil end
    return s
end

function ViewRay()
    local out = nil
    pcall(function()
        local PC = UEHelpers.GetPlayerController()
        if not (PC and PC:IsValid()) then return end

        local pitch, yaw, roll = nil, nil, nil
        local src = nil

        local ok, r = pcall(function() return PC:GetControlRotation() end)
        if ok and r ~= nil then
            local p, y, rr
            pcall(function() p = tonumber(r.Pitch) end)
            pcall(function() y = tonumber(r.Yaw) end)
            pcall(function() rr = tonumber(r.Roll) end)
            if p ~= nil and y ~= nil then
                pitch, yaw, roll = p, y, rr or 0
                src = "GetControlRotation"
            end
        end

        if pitch == nil then
            local cam = nil
            pcall(function() cam = PC.PlayerCameraManager end)
            if cam ~= nil then
                local ok2, r2 = pcall(function() return cam:GetCameraRotation() end)
                if ok2 and r2 ~= nil then
                    local p, y, rr
                    pcall(function() p = tonumber(r2.Pitch) end)
                    pcall(function() y = tonumber(r2.Yaw) end)
                    pcall(function() rr = tonumber(r2.Roll) end)
                    if p ~= nil and y ~= nil then
                        pitch, yaw, roll = p, y, rr or 0
                        src = "CameraRotation"
                    end
                end
            end
        end

        local pawn = nil
        pcall(function() pawn = PC.Pawn end)
        if pitch == nil and pawn ~= nil and pawn:IsValid() then
            local ok3, r3 = pcall(function() return pawn:K2_GetActorRotation() end)
            if ok3 and r3 ~= nil then
                local p, y
                pcall(function() p = tonumber(r3.Pitch) end)
                pcall(function() y = tonumber(r3.Yaw) end)
                if y ~= nil then
                    pitch, yaw, roll = p or 0, y, 0
                    src = "PawnRotation(no-pitch)"
                end
            end
            if src == nil then
                local ok4, r4 = pcall(function() return pawn:K2_GetActorRotation() end)
                if ok4 and r4 ~= nil then
                    local y = tonumber(r4.Yaw)
                    if y ~= nil then pitch, yaw, roll = 0, y, 0; src = "PawnRotation(no-pitch)" end
                end
            end
        end

        if yaw == nil then return end
        pitch = pitch or 0

        local ox, oy, oz = nil, nil, nil
        local osrc = nil
        local cam2 = nil
        pcall(function() cam2 = PC.PlayerCameraManager end)
        if cam2 ~= nil then
            pcall(function()
                local loc = cam2:GetCameraLocation()
                if loc ~= nil then ox, oy, oz = loc.X, loc.Y, loc.Z; osrc = "camera" end
            end)
        end
        if ox == nil and pawn ~= nil and pawn:IsValid() then
            pcall(function()
                local loc = pawn:K2_GetActorLocation()
                if loc ~= nil then ox, oy, oz = loc.X, loc.Y, loc.Z; osrc = "pawn" end
            end)
        end
        if ox == nil then return end

        local pRad = math.rad(pitch)
        local yRad = math.rad(yaw)
        local cp = math.cos(pRad)
        local dx = cp * math.cos(yRad)
        local dy = cp * math.sin(yRad)
        local dz = math.sin(pRad)

        out = {
            x = ox, y = oy, z = oz,
            pitch = pitch, yaw = yaw, roll = roll or 0,
            dx = dx, dy = dy, dz = dz,
            src = src or "unknown", osrc = osrc or "unknown",
        }
    end)
    return out
end

function ViewPoint(dist, lift)
    local v = ViewRay()
    if not v then return nil end
    dist = tonumber(dist) or 120
    lift = tonumber(lift) or 0
    return {
        x = v.x + v.dx * dist,
        y = v.y + v.dy * dist,
        z = v.z + v.dz * dist + lift,
        yaw = v.yaw, pitch = v.pitch, roll = v.roll,
        src = v.src, osrc = v.osrc,
    }
end

-- r56: globals - the save/slot do-block closes right after these; every
-- later caller (jload restore, sprint/jump/glide/markergo/whereami, fly
-- vertical) got nil globals before
function PlayerXform()
    local out = nil
    pcall(function()
        local PC = UEHelpers.GetPlayerController()
        if not (PC and PC:IsValid() and PC.Pawn and PC.Pawn:IsValid()) then return end
        local loc = PC.Pawn:K2_GetActorLocation()
        local rot = PC.Pawn:K2_GetActorRotation()
        out = { x = loc.X, y = loc.Y, z = loc.Z, yaw = rot.Yaw }
    end)
    return out
end

function TeleportTo(x, y, z, yaw)
    local PC = UEHelpers.GetPlayerController()
    if not (PC and PC:IsValid() and PC.Pawn and PC.Pawn:IsValid()) then
        return false, "no pawn"
    end
    return JxActor.tp(PC.Pawn, x, y, z, yaw)
end

function JXAfterLoad(tag, what, fn)
    local tries = 0
    local function Attempt()
        tries = tries + 1
        if JXBusy() then
            if tries < 12 then
                ExecuteWithDelay(1200, function() ExecuteInGameThread(function() pcall(Attempt) end) end)
            else
                Log(tag .. ": " .. what .. " NOT applied - the level was still loading after "
                    .. tries .. " attempts")
            end
            return
        end
        fn(tries)
    end
    ExecuteWithDelay(2500, function() ExecuteInGameThread(function() pcall(Attempt) end) end)
end

function Slot.SaveMap(note)
    if not Slot.P_SaveMap then
        Log("jsave: the JXAMS writer is not loaded yet - cannot save")
        return false
    end
    return Slot.P_SaveMap(note)
end

function Slot.LoadMap(which)
    if not Slot.P_LoadMap then
        Log("jload: the JXAMS reader is not loaded yet")
        return false
    end
    return Slot.P_LoadMap(which)
end

function Slot.ListMaps()
    if not Slot.P_ListMaps then Log("jslots: the JXAMS reader is not loaded yet"); return end
    return Slot.P_ListMaps()
end

function Slot.DataCmd(parameters)
    if not Slot.P_DataCmd then Log("jxdata: the data store is not loaded yet"); return end
    return Slot.P_DataCmd(parameters)
end

function Slot.PeekMap(key)
    if not Slot.P_PeekMap then return nil end
    return Slot.P_PeekMap(key)
end

local function ApplyOrder(spec)
    local wanted = {}
    for idx in spec:gmatch("%d+") do
        local p = MapList[tonumber(idx)]
        if p then wanted[#wanted + 1] = p end
    end
    if #wanted ~= #MapList then
        Log("jorder: need all " .. #MapList .. " indices, got " .. #wanted)
        return false
    end
    local seen = {}
    for _, p in ipairs(wanted) do
        if seen[p] then Log("jorder: duplicate entry " .. p); return false end
        seen[p] = true
    end
    MapList = wanted
    WriteAll(OrderFile, "# jtravel order, one owned-map index per line was saved as a list:\n"
        .. table.concat(wanted, "\n") .. "\n")
    Log("map order applied (" .. #wanted .. " maps)")
    return true
end

local function LoadOrder()
    local saved = FileLines(OrderFile)
    if #saved == 0 then return end
    local map = {}
    for _, p in ipairs(MapList) do map[p] = true end
    local restored = {}
    for _, p in ipairs(saved) do
        if map[p] then restored[#restored + 1] = p; map[p] = nil end
    end
    for _, p in ipairs(MapList) do if map[p] then restored[#restored + 1] = p end end
    MapList = restored
    Log("map order restored (" .. #restored .. " maps)")
end

local function LoadAuto()
    local l = FileLines(AutoFile)
    local v = (l[1] or ""):gsub("%s", "")
    AutoSlot = (v ~= "" and v ~= "off") and true or nil
    if AutoSlot then
        Log("auto-load: ON - each map's own JXAMS save is restored after it loads "
            .. "(jautoload off stops it)")
    end
end

function RunAutoLoad()   
    if not AutoSlot or JXBusy() then return end
    if not Slot.P_AutoRestore then
        Log("auto-load: the JXAMS reader is not loaded yet")
        return
    end
    Slot.P_AutoRestore()
end

Slot.SanitiseName = SanitiseName
Slot.PlayerXform  = PlayerXform
Slot.ApplyOrder   = ApplyOrder
Slot.LoadOrder    = LoadOrder
Slot.LoadAuto     = LoadAuto
end   

JXRegCmd("jmods", function()
    ExecuteInGameThread(function() RunGuarded("jmods", ListLoadedMods) end)
    return true
end)

-- r39: Z_Arsenal_P step-wise diagnostic loader. Offline forensics cleared the
-- pak completely (dependency closure complete, import names match mahiro's
-- exports, unversioned cooked = normal, compression legal, 78/78 uexp pairs,
-- 167/167 entries, sibling class+CDO names exact), so the replay loader's
-- persistent 4-pass failure is only observable in-engine. This walks the
-- exact dependency chain TrapActor needs, in load order, logging each hop,
-- then probes the bare package, the class variants, and finally spawns - the
-- first FAIL line names the culprit link next session.
JXRegCmd("jarsenal", function()
    ExecuteInGameThread(function()
        RunGuarded("jarsenal", function()
            local T = "/Game/Mods/Z_Traps_P/"
            local deps = {
                { "BFL_DebugLog",  "/Game/Mods/Z_DebugLog_P/BlueprintLibraries/BFL_DebugLog.BFL_DebugLog_C" },
                { "BP_M_ModActor", "/Game/Mods/Z_ModLoader_P/Blueprints/BP_M_ModActor.BP_M_ModActor_C" },
                { "sTART",         T .. "sTART.sTART_C" },
                { "Cube",          T .. "Cube.Cube_C" },
                { "Cube2",         T .. "Cube2.Cube2_C" },
                { "Cube4",         T .. "Cube4.Cube4_C" },
                { "Cube6",         T .. "Cube6.Cube6_C" },
                { "Cube7",         T .. "Cube7.Cube7_C" },
                { "Cube8",         T .. "Cube8.Cube8_C" },
                { "Cube9",         T .. "Cube9.Cube9_C" },
                { "Cube10",        T .. "Cube10.Cube10_C" },
                { "Gunmanager",    T .. "Gunmanager.Gunmanager_C" },
                { "HammerManager", T .. "HammerManager.HammerManager_C" },
            }
            local okN, failN = 0, 0
            for _, d in ipairs(deps) do
                local o = J3LoadObject(d[2])
                if o and JXAlive(o) then
                    okN = okN + 1
                    Log("jarsenal dep ok   " .. d[1])
                else
                    failN = failN + 1
                    Log("jarsenal DEP FAIL " .. d[1] .. " -> " .. d[2])
                end
            end
            -- bare package probe: does the uasset load at all without an
            -- object name? distinguishes package-level from object-level fail
            local bareOk, bare = pcall(LoadAsset, T .. "TrapActor")
            Log("jarsenal bare pkg  " .. tostring(bareOk and bare ~= nil))
            -- class variants, loader-style (leaf_C / primary-as-Class / CDO)
            local cls = J3LoadObject(T .. "TrapActor.TrapActor_C")
            if not (cls and JXAlive(cls)) then
                local pkg = nil
                pcall(function() pkg = StaticFindObject(T .. "TrapActor") end)
                if pkg and pkg:IsValid() then
                    pcall(function()
                        if pkg.TrapActor_C and pkg.TrapActor_C:IsValid() then
                            cls = pkg.TrapActor_C
                        end
                    end)
                end
                Log("jarsenal variant2 (primary-as-class) " .. tostring(cls and JXAlive(cls)))
            end
            if not (cls and JXAlive(cls)) then
                local cdo = J3LoadObject(T .. "TrapActor.Default__TrapActor_C")
                if cdo and JXAlive(cdo) then
                    pcall(function() cls = cdo:GetClass() end)
                    Log("jarsenal variant3 (cdo->class) " .. tostring(cls and JXAlive(cls)))
                end
            end
            if not (cls and JXAlive(cls)) then
                Log("jarsenal CLASS FAIL TrapActor (deps ok=" .. okN .. " fail=" .. failN .. ")")
                JXSay("jarsenal: class FAIL deps " .. okN .. "ok/" .. failN .. "fail - see UE4SS.log")
                return
            end
            Log("jarsenal class ok  TrapActor_C (deps ok=" .. okN .. " fail=" .. failN .. ")")
            local a, err = JXSpawnLikeLoader(cls)
            if JXAlive(a) then
                Log("jarsenal spawn ok")
                JXSay("jarsenal: deps " .. okN .. "ok/" .. failN .. "fail, class ok, SPAWNED")
            else
                Log("jarsenal SPAWN FAIL " .. tostring(err))
                JXSay("jarsenal: class ok but spawn FAIL - see UE4SS.log")
            end
        end)
    end)
    return true
end)

JXRegCmd("jtab", function(FullCommand, Parameters, Ar)
    ExecuteInGameThread(function()
        local arg = Parameters and Parameters[1] or "next"
        local n = tonumber(arg)
        if n then
            JxTabGo(math.floor(n), true)
        elseif arg == "next" then
            JxTabGo(CurrentTabIndex() + 1, true)
        elseif arg == "prev" then
            JxTabGo(CurrentTabIndex() - 1, true)
        elseif arg == "back" then
            local h = JX.TabHist
            if type(h) ~= "table" or #h == 0 then
                Log("jtab back: no previous page recorded yet (switch once first)")
            else
                local to = table.remove(h)
                Log("jtab back -> page " .. tostring(to))
                JxTabGo(tonumber(to) or 0, false)
            end
        elseif arg == "reset" then
            JX.TabHist = {}
            Log("jtab history cleared")
        else
            Log("usage: jtab <0-13|next|prev|back|reset> (the panel has 14 pages now)")
        end
    end)
    return true
end)

JxActor3 = JxActor3 or {
    
    on = true,
    placed = {},          
    nextSlot = 1,
    links = {},           
    hookTried = {},       
    jposWatch = false,
    lastClass = nil,      
    box = true,           
}

J3Log = function(msg) Log("v1.3.1 " .. msg) end

J3PaintBox = function(needle, text)
    return false
end

local function J3DumpAllActors(filter)
    local line, n = {}, 0
    pcall(function()
        local all = FindAllOf("Actor")
        if not all then return end
        for _, a in pairs(all) do
            if JXAlive(a) then
                local cls = ActorClassToken(a)
                if cls ~= "" and (not filter or cls:find(filter, 1, true)) then
                    local loc = nil
                    pcall(function() loc = a:K2_GetActorLocation() end)
                    line[#line + 1] = string.format("%s|%s|%.0f %.0f %.0f",
                        J3ZH(cls), cls,
                        loc and loc.X or 0, loc and loc.Y or 0, loc and loc.Z or 0)
                    n = n + 1
                end
            end
        end
    end)
    table.sort(line)
    pcall(function()
        local f = io.open(JXRootOr .. "logs/actors_all.txt", "w")
        if f then f:write(table.concat(line, "\n") .. "\n") f:close() end
    end)
    Log("jactor all: " .. n .. " actors (logs/actors_all.txt)" .. (filter and (" filter=" .. filter) or ""))
    local shown = {}
    for i = 1, math.min(n, 14) do shown[#shown + 1] = line[i] end
    if n > 14 then shown[#shown + 1] = "..." .. n .. " total" end
    J3PaintBox("ActorLstBox_Info", table.concat(shown, "\n"))
end

J3SpawnAt = function(clsPath, x, y, z, yaw, meshAsset)
    local cls = J3LoadObject(clsPath)
    if not (cls and cls:IsValid()) then
        return nil, "class not found: " .. tostring(clsPath)
    end
    local out, err, shape = JxActor.spawn(cls, x, y, z, yaw)
    if not JXAlive(out) then return nil, tostring(err or "spawn failed") end
    if JxActor3.box == false then
        pcall(function() out:SetActorEnableCollision(false) end)
    end
    if meshAsset then
        local mesh = J3LoadObject(meshAsset)
        if mesh and mesh:IsValid() then
            pcall(function() out.StaticMeshComponent:SetStaticMesh(mesh) end)
        end
    end
    return out, nil, shape
end

local function J3PlayerXform()
    return Slot.PlayerXform()
end

local function J3Record(slot, clsPath, meshAsset, a)
    local loc = nil
    local rot = nil
    pcall(function()
        loc = a:K2_GetActorLocation()
        rot = a:K2_GetActorRotation()
    end)
    if loc then
        JxActor3.placed[slot] = {
            cls = clsPath, mesh = meshAsset,
            x = loc.X, y = loc.Y, z = loc.Z,
            yaw = rot and rot.Yaw or 0, ref = a,
        }
    end
end

local J3HookNames = { "Interact", "Use", "Trigger", "Pull", "Activate", "Toggle", "OnInteract" }
local function J3TryLink(slotA, slotB)
    local A = JxActor3.placed[slotA]
    local B = JxActor3.placed[slotB]
    if not (A and A.ref and B and B.ref) then return end
    JxActor3.links[slotA] = slotB
    JxActor3.hookTried[slotA] = JxActor3.hookTried[slotA] or {}
    for _, name in ipairs(J3HookNames) do
        if not JxActor3.hookTried[slotA][name] then
            local ok, err = pcall(RegisterPostProcessEventHook, A.ref, name, function(...)
                ExecuteInGameThread(function()
                    pcall(function()
                        local t = JxActor3.placed[slotB]
                        if t and t.ref and t.ref:IsValid() then
                            pcall(function() t.ref:SetActorHiddenInGame(false) end)
                            pcall(function() t.ref:SetActorEnableCollision(true) end)
                            J3Log("linked pair " .. slotA .. " -> " .. slotB .. " triggered (event " .. name .. ")")
                        end
                    end)
                end)
            end)
            JxActor3.hookTried[slotA][name] = ok or false
            if ok then J3Log("link armed: #" .. slotA .. " event " .. name .. " -> #" .. slotB) end
        end
    end
end

JXRegCmd("jbox", function(FullCommand, Parameters, Ar)
    ExecuteInGameThread(function()
        local on = Parameters and Parameters[1] == "on"
        JxActor3.box = on
        Log("placed objects collision: " .. (on and "ON (default)" or "OFF (walk-through)"))
    end)
    return true
end)

JXRegCmd("jplace", function(FullCommand, Parameters, Ar)
    ExecuteInGameThread(function()
        if not JxActor3.on then J3Log("jplace: actor system is OFF (jactor on first)"); return end
        local p = Parameters or {}
        local arg0 = p[1] or ""
        if arg0 == "at" then
            
            local px, py, pz = tonumber(p[2]), tonumber(p[3]), tonumber(p[4])
            local yaw = tonumber(p[5]) or (J3PlayerXform() and J3PlayerXform().yaw or 0)
            if not (px and py and pz) then J3Log("jplace at <X> <Y> <Z> [yaw]"); return end
            local a, err = J3SpawnAt(JxActor3.lastClass or "/Script/Engine.StaticMeshActor", px, py, pz, yaw or 0, nil)
            if not a then J3Log("jplace at failed: " .. tostring(err)); return end
            local slot = JxActor3.nextSlot
            JxActor3.nextSlot = JxActor3.nextSlot + 1
            J3Record(slot, JxActor3.lastClass, nil, a)
            J3Log(string.format("placed #%d at (%.1f, %.1f, %.1f) yaw=%.1f", slot, px, py, pz, yaw or 0))
            return
        end
        local clsPath = p[1] or ""
        local meshAsset = nil
        local dist = 120
        if clsPath == "mesh" then
            clsPath = "/Script/Engine.StaticMeshActor"
            meshAsset = p[2]
            dist = tonumber(p[3]) or 120
        elseif clsPath == "last" then
            clsPath = JxActor3.lastClass or ""
        else
            dist = tonumber(p[2]) or 120
        end
        if clsPath == "" then J3Log("usage: jplace <classpath | mesh <asset> | last> [dist]"); return end
        if not JxActor3.on then J3Log("jplace: actor system OFF"); return end
        
        local v = ViewPoint(dist, -20)
        if not v then J3Log("jplace: no player position yet"); return end
        local dirAngle = v.yaw or 0
        local a, err = J3SpawnAt(clsPath, v.x, v.y, v.z, dirAngle, meshAsset)
        if not a then J3Log("jplace failed: " .. tostring(err)); return end
        JxActor3.lastClass = clsPath
        local slot = JxActor3.nextSlot
        JxActor3.nextSlot = JxActor3.nextSlot + 1
        J3Record(slot, clsPath, meshAsset, a)
        local p3 = JxActor3.placed[slot]
        if not p3 then
            J3Log("jplace: spawned but record failed")
            return
        end
        
        local col = "unknown"
        pcall(function()
            local e = a:GetActorEnableCollision()
            if e ~= nil then col = e and "on" or "off" end
        end)
        J3Log(string.format("placed #%d %s at (%.1f, %.1f, %.1f) yaw=%.1f pitch=%.1f dist=%.0f collision=%s aim=%s@%s",
            slot, clsPath, p3.x, p3.y, p3.z, p3.yaw, v.pitch or 0, dist, col,
            tostring(v.src), tostring(v.osrc)))
        J3PaintBox("ActorCoordBox_Info", string.format("X=%.1f Y=%.1f Z=%.1f yaw=%.1f pitch=%.1f\nlast: #%d %s\naim: %s @ %s",
            p3.x, p3.y, p3.z, p3.yaw, v.pitch or 0, slot, clsPath,
            tostring(v.src), tostring(v.osrc)))
    end)
    return true
end)

JXRegCmd("jkill", function(FullCommand, Parameters, Ar)
    ExecuteInGameThread(function()
        local arg = Parameters and Parameters[1]
        local slot = nil
        if arg == "last" then
            local maxK = nil
            for k in pairs(JxActor3.placed) do if maxK == nil or k > maxK then maxK = k end end
            slot = maxK
        else
            slot = tonumber(arg)
        end
        local p = JxActor3.placed[slot]
        if not p then J3Log("jkill: no placed slot #" .. tostring(slot) .. " (jlistplaced)"); return end
        pcall(function()
            if p.ref and p.ref:IsValid() then p.ref:K2_DestroyActor() end
        end)
        for k, v in pairs(JxActor3.links) do if v == slot then JxActor3.links[k] = nil end end
        JxActor3.placed[slot] = nil
        J3Log("jkill: slot #" .. tostring(slot) .. " destroyed")
    end)
    return true
end)

JXRegCmd("jlistplaced", function(FullCommand, Parameters, Ar)
    ExecuteInGameThread(function()
        local n = 0
        for k, v in pairs(JxActor3.placed) do
            n = n + 1
            J3Log(string.format("#%d %s mesh=%s (%.1f, %.1f, %.1f)", k, v.cls, v.mesh or "-", v.x, v.y, v.z))
        end
        J3Log("placed objects: " .. n .. (JxActor3.on and "" or " (actor system OFF)"))
    end)
    return true
end)

JXRegCmd("jlink", function(FullCommand, Parameters, Ar)
    ExecuteInGameThread(function()
        local p = Parameters or {}
        if p[1] == "last" then
            local slots = {}
            for k in pairs(JxActor3.placed) do slots[#slots + 1] = k end
            table.sort(slots)
            local a = slots[#slots - 1]
            local b = slots[#slots]
            if a and b then J3TryLink(a, b) else J3Log("jlink last: need at least two placed slots") end
            return
        end
        local a = tonumber(p[1] or 0)
        local b = tonumber(p[2] or 0)
        if a <= 0 or b <= 0 or a == b then J3Log("usage: jlink <slotA> <slotB> | last  (see jlistplaced)"); return end
        J3TryLink(a, b)
    end)
    return true
end)

JXRegCmd("jpos", function(FullCommand, Parameters, Ar)
    ExecuteInGameThread(function()
        local w = Parameters and Parameters[1]
        if w == "watch" then
            local f = (Parameters[2] == "1" or Parameters[2] == "on")
            JxActor3.jposWatch = f
            J3Log("pos watch " .. (f and "ON (every 2 s in log)" or "OFF"))
            return
        end
        local x = J3PlayerXform()
        if x then
            J3Log(string.format("pos X=%.1f Y=%.1f Z=%.1f yaw=%.1f", x.x, x.y, x.z, x.yaw))
        else
            J3Log("pos: no pawn")
        end
    end)
    return true
end)

JxActor3.autoSave = false
JxActor3.savedMap = nil

local function J3StatusText()
    local n = 0
    for _ in pairs(JxActor3.placed) do n = n + 1 end
    return string.format("actor=%s | placed=%d | guard=%s | marker=%s | cap=%s | tab=%d",
        JxActor3.on and "on" or "off", n,
        tostring(JxActor.protect), tostring(JxActor.marker),
        tostring(Config and Config.MaxPlayers or "?"), TabIndex or 0)
end

local function J3PaintStatus()
    J3PaintBox("JinxingStatusBox_Info", J3StatusText())
end

local function J3MaybeAutosave()
    if not JxActor3.autoSave then return end
    local m = CurrentMapName()
    if m and m ~= "" and m ~= (JxActor3.savedMap or "") then
        JxActor3.savedMap = m
        pcall(J3SaveAllActors)
    end
end

J3AutoSaveTick = J3MaybeAutosave

JXRegCmd("jstatus", function()
    ExecuteInGameThread(function()
        local st = J3StatusText()
        Log("status: " .. st)
        J3PaintStatus()
    end)
    return true
end)

J3ZH = function(cls)
    if not cls or cls == "" then return "" end
    local low = cls:lower()
    local parts = {}
    local ZH = {
        { "lever", U(0x62C9, 0x6746) },
        { "ladder", U(0x68AF, 0x5B50) },
        { "door_frame", U(0x95E8, 0x6846) },
        { "door", U(0x95E8) },
        { "windturbine", U(0x98CE, 0x8F66) },
        { "trampoline", U(0x8E60, 0x5E8A) },
        { "glowstick", U(0x8367, 0x5149, 0x68D2) },
        { "elevator", U(0x7535, 0x68AF) },
        { "refrigerator", U(0x51B0, 0x7BB1) },
        { "locker", U(0x50A8, 0x7269, 0x67DC) },
        { "padlock", U(0x6302, 0x9501) },
        { "valve", U(0x9600, 0x95E8) },
        { "television", U(0x7535, 0x89C6) },
        { "note", U(0x4FBF, 0x6761) },
        { "slide", U(0x6ED1, 0x68AF) },
        { "siren", U(0x8B66, 0x62A5, 0x5668) },
        { "smilerpit", U(0x7B11, 0x9B6D, 0x5751) },
        { "pit", U(0x5751) },
        { "fusebox", U(0x914D, 0x7535, 0x76D2) },
        { "typewriter", U(0x6253, 0x5B57, 0x673A) },
        { "mirrorball", U(0x955C, 0x9762, 0x7403) },
        { "discolight", U(0x8FEA, 0x65AF, 0x79D1, 0x706F) },
        { "arcade", U(0x8857, 0x673A) },
        { "foosball", U(0x684C, 0x4E0A, 0x8DB3, 0x7403) },
        { "stair", U(0x697C, 0x68AF) },
        { "computer", U(0x7535, 0x8111) },
        { "pipe", U(0x7BA1, 0x9053) },
        { "spray", U(0x55F7, 0x5934) },
        { "switch", U(0x5F00, 0x5173) },
        { "trigger", U(0x50F1, 0x53D1) },
        { "lamp", U(0x706F) },
        { "light", U(0x706F) },
        { "chair", U(0x6905, 0x5B50) },
        { "table", U(0x684C, 0x5B50) },
        { "dumbwaiter", U(0x5347, 0x964D, 0x9910, 0x68AF) },
        { "cardreader", U(0x8BFB, 0x5361, 0x5668) },
        { "keyturn", U(0x8F6C, 0x94A5, 0x5319) },
        { "terminal", U(0x7EC8, 0x7AEF, 0x5F00, 0x5173) },
        { "stations", U(0x7AD9, 0x70B9, 0x9762, 0x677F) },
    }
    local zh = ""
    for _, kv in ipairs(ZH) do
        if low:find(kv[1], 1, true) and not zh:find(kv[1], 1, true) then
            
        end
    end
    
    local best = ""
    for _, kv in ipairs(ZH) do
        if low:find(kv[1], 1, true) and #kv[1] > #best then
            zh = kv[2]
            best = kv[1]
        end
    end
    if zh ~= "" then
        return zh .. " (" .. cls .. ")"
    end
    return cls
end

function J3SaveAllActors()
    local lines, n = {}, 0
    pcall(function()
        local all = FindAllOf("Actor")
        if not all then return end
        local seen = {}
        for _, a in pairs(all) do
            if JXAlive(a) then
                local cls = ActorClassToken(a)
                if cls ~= "" and not seen[cls] then
                    seen[cls] = true
                    local loc = nil
                    pcall(function() loc = a:K2_GetActorLocation() end)
                    lines[#lines + 1] = string.format("%s|%s|%.0f;%.0f;%.0f",
                        cls, J3ZH(cls), loc and loc.X or 0, loc and loc.Y or 0, loc and loc.Z or 0)
                    n = n + 1
                end
            end
        end
    end)
    table.sort(lines)
    local f = io.open(SaveDir .. "JXactor.sav", "w")
    if f then
        f:write("# JinxingLoader JXactor.sav - full scene actor classes (class|zh|x;y;z)\n")
        f:write(table.concat(lines, "\n") .. "\n")
        f:close()
        Log("jactor save: " .. n .. " unique actor classes -> Saved/SaveGames/JXactor.sav")
    else
        Log("jactor save: cannot write " .. SaveDir .. "JXactor.sav")
    end
    return n
end

local BLK = {
    U(0x6296, 0x97F3), U(0x5FEB, 0x624B), U(0x50BB, 0x903C),
    U(0x5C3C, 0x739B), U(0x5988, 0x7684), U(0x61C5, 0x7953),
}
local function J3ScanBlocked(force)
    local hits = {}
    pcall(function()
        local all = FindAllOf("PlayerState")
        if not all then return end
        for _, ps in pairs(all) do
            if JXAlive(ps) then
                local name = ""
                pcall(function() name = tostring(ps.PlayerName) end)
                if name and name ~= "" then
                    local bad = false
                    for _, tok in ipairs(BLK) do
                        if name:find(tok, 1, true) then bad = true end
                    end
                    for _, tok in ipairs({ "douyin", "bilibili", "kuaishou", "tiktok" }) do
                        if name:lower():find(tok, 1, true) then bad = true end
                    end
                    if bad then hits[#hits + 1] = name end
                end
            end
        end
    end)
    for _, hn in ipairs(hits) do Log("wordfilter: flagged nick '" .. hn .. "' (recorded; kick with jkick <name>)") end
    Log("wordfilter: " .. #hits .. " flagged nickname(s)" .. (force and " (full scan)" or ""))
    return #hits
end

local function JXResolveMapArg(arg, list)
    local num = tonumber(arg)
    if num and num >= 1 and num <= #list then return list[math.floor(num)] end
    local leaf = arg:match("/([^/]+)$") or arg
    for _, m in ipairs(list) do
        if m == arg then return m end
        local mleaf = m:match("/([^/]+)$")
        if mleaf == leaf and m:find(arg, 1, true) then return m end
    end
    for _, m in ipairs(list) do
        if m:find(arg, 1, true) then return m end
    end
    return nil
end

JXRegCmd("jmap", function(FullCommand, Parameters, Ar)
    ExecuteInGameThread(function()
        local arg = Parameters and Parameters[1]
        if not arg then Log("usage: jmap <number|name>  (safe host travel; players get a warning, see below)"); return end
        local target = JXResolveMapArg(arg, SEED_MAPS)
        if not target then Log("jmap: no such map: " .. tostring(arg)); return end
        
        Log("jmap: switching map -> " .. target .. " (what happens to the room is decided by who owns it - see the travel lines)")
        Log("jmap: " .. tostring(FullCommand))
        local ok, err = TravelTo(target)
        Log("jmap travel: " .. (ok and "started" or ("failed " .. tostring(err))))
    end)
    return true
end)

JXRegCmd("jactor", function(FullCommand, Parameters, Ar)
    ExecuteInGameThread(function()
        local sub = (Parameters and Parameters[1]) or "list"
        if sub == "on" then
            JxActor3.on = true
            J3Log("actor system ON (placement/link/enumeration enabled)")
            return
        end
        if sub == "off" then
            JxActor3.on = false
            J3Log("actor system OFF (enumeration and watch loops suspended)")
            return
        end
        if sub == "protect" then
            local on = (Parameters[2] == "on")
            if on then InstallDeleteGuard() end
            JxActor.protect = on
            JxActor.baseline = -1
            Log("jactor: delete guard " .. (on and "ARMED" or "DISARMED")
                .. (on and " - blueprint deletes of StaticMeshActor are now refused"
                       or " - self-disarms again on every map load"))
            if on then pcall(ActorWatchTick, 100) end
            return
        end
        if sub == "marker" then
            pcall(SpawnScaleMarker)
            return
        end
        if sub == "restore" then
            Log("jactor: " .. CountStaticMeshActors() .. " static mesh actors in scene; "
                .. "blocked deletes so far: " .. JxActor.blocked)
            return
        end
        if sub == "census" then
            ScanAllActors(true)
            return
        end
        if sub == "meshes" then
            RosterMeshes(true, 400)
            return
        end
        if sub == "all" then
            pcall(J3DumpAllActors, Parameters[2])
            return
        end
        if sub == "save" then
            pcall(J3SaveAllActors)
            return
        end
        if sub == "autosave" then
            JxActor3.autoSave = (Parameters[2] == "on")
            Log("autosave JXactor.sav: " .. (JxActor3.autoSave and "ON (per map change)" or "OFF (manual jactor save only)"))
            return
        end
        if sub == "list" then
            Log(string.format("jactor: guard=%s marker=%s meshes=%d blocked=%d",
                tostring(JxActor.protect), tostring(JxActor.marker),
                CountStaticMeshActors(), JxActor.blocked))
            return
        end
        Log("usage: jactor <on|off> | all [filter] | protect <on|off> | marker | restore | census | meshes | list")
    end)
    return true
end)

JXRegCmd("jbanlist", function()
    ExecuteInGameThread(function()
        if #BlacklistOrder == 0 then
            Log("blacklist is empty (add with: jban <name|steam64|netid>)")
            return
        end
        for i, e in ipairs(BlacklistOrder) do Log(string.format("  [%d] %s", i, e)) end
        Log("blacklist: " .. #BlacklistOrder .. " entries")
    end)
    return true
end)

JXRegCmd("jname", function()
    ExecuteInGameThread(function()
        local hits = ScanAdNames()
        JxSet.nameclean = not JxSet.nameclean
        Log("ad-name scan: found " .. hits .. " host and you exempt; "
            .. "cleaner flag=" .. tostring(JxSet.nameclean))
    end)
    return true
end)

JXRegCmd("jsave", function(FullCommand, Parameters, Ar)
    ExecuteInGameThread(function() RunGuarded("jsave", Slot.SaveMap, Parameters and Parameters[1]) end)
    return true
end)
JXRegCmd("jload", function(FullCommand, Parameters, Ar)
    ExecuteInGameThread(function() RunGuarded("jload", Slot.LoadMap, Parameters and Parameters[1]) end)
    return true
end)
JXRegCmd("jslots", function()
    ExecuteInGameThread(function() RunGuarded("jslots", Slot.ListMaps) end)
    return true
end)
JXRegCmd("jxdata", function(FullCommand, Parameters, Ar)
    local args = ""
    if Parameters then args = table.concat(Parameters, " ") end
    ExecuteInGameThread(function() RunGuarded("jxdata", Slot.DataCmd, args) end)
    return true
end)
JXRegCmd("jautoload", function(FullCommand, Parameters, Ar)
    ExecuteInGameThread(function()
        local n = (Parameters and Parameters[1]) or "off"
        if n == "off" then
            WriteAll(Slot.AutoFile, "off\n")
            AutoSlot = nil
            Log("auto-load off")
            return
        end
        WriteAll(Slot.AutoFile, "on\n")
        AutoSlot = true
        Log("auto-load: ON - each map's own JXAMS save is restored after it loads")
    end)
    return true
end)

JXRegCmd("jorder", function(FullCommand, Parameters, Ar)
    ExecuteInGameThread(function()
        local sub = Parameters and Parameters[1] or "show"
        if sub == "show" then
            for i, p in ipairs(MapList) do Log(string.format("  [%d] %s", i, p)) end
            Log("jorder: current order above; set with jorder set <idx,idx,...> (all "
                .. #MapList .. "), reset with jorder reset")
            return
        end
        if sub == "reset" then
            WriteAll(Slot.OrderFile, "")
            pcall(function() LoadMaps(); Slot.LoadOrder() end)
            Log("map order reset (alphabetical)")
            return
        end
        if sub == "set" then
            Slot.ApplyOrder(Parameters and Parameters[2] or "")
            return
        end
        Log("usage: jorder show | set <i1,i2,...> | reset")
    end)
    return true
end)

JXRegCmd("jbench", function()
    ExecuteInGameThread(function()
        if JxSet.bench then Log("jbench: already running"); return end
        JxSet.bench = true
        local PC = nil
        pcall(function() PC = UEHelpers.GetPlayerController() end)
        if JXAlive(PC) then pcall(function() JXExecCmd(PC, "stat unit") end) end
        Log("jbench: 10s sample started (stat unit on screen) - stand still")
        ExecuteWithDelay(10000, function()
            ExecuteInGameThread(function()
                local PC2 = nil
                pcall(function() PC2 = UEHelpers.GetPlayerController() end)
                if JXAlive(PC2) then pcall(function() JXExecCmd(PC2, "stat none") end) end
                JxSet.bench = false
                Log("jbench: sample finished. Read the on-screen numbers you saw:"
                    .. " Frame (ms) = total, Game / Draw / GPU = the split.")
            end)
        end)
    end)
    return true
end)

JXBinds = { order = {}, byId = {} }

function JxBindRecord(id, label, keyName, mods)
    if not id or not keyName then return nil end
    local e = JXBinds.byId[id]
    if not e then
        e = { id = id, mods = {} }
        JXBinds.byId[id] = e
        JXBinds.order[#JXBinds.order + 1] = e
    end
    e.label = label or e.label or id
    e.key = keyName
    if mods then e.mods = mods end
    return e
end

function JxBindModsText(mods)
    if not mods or #mods == 0 then return "" end
    local out = {}
    for i = 1, #mods do out[i] = tostring(mods[i]) end
    return table.concat(out, "+")
end

function JxBindApply(entry, fn)
    if not entry or not entry.key or entry.key == "" then return false, "no key recorded" end
    if type(fn) ~= "function" then return false, "no action for '" .. tostring(entry.id) .. "'" end
    local k, kn = FindKey({ entry.key })
    if not k then
        return false, "key '" .. tostring(entry.key) .. "' is not in this build's Key table"
    end
    local ok, err
    if #(entry.mods or {}) > 0 then ok, err = pcall(RegisterKeyBind, k, entry.mods, fn)
    else ok, err = pcall(RegisterKeyBind, k, fn) end
    if not ok then return false, tostring(err) end
    return true, kn
end

local function SafeBind(names, fn, id, label, mods)
    for _, n in ipairs(names) do
        local ok, k = pcall(function() return Key[n] end)
        if ok and k ~= nil and k ~= 0 then
            if id then JxBindRecord(id, label, n, mods) end
            pcall(RegisterKeyBind, k, fn)
            return true, n
        end
    end
    Log("keybind skipped, none of these exist: " .. table.concat(names, "/"))
    return false
end

local function OpenF6OrPak()
    
    if type(_G.JXPakToggle) == "function" then
        _G.JXPakToggle()
        return
    end
    -- r12: no legacy fallbacks - the canvas is the only interface
    Log("PNL| canvas host not loaded yet (r12 single-UI)")
end

if SafeBind({ "F4" }, function() ExecuteInGameThread(function() pcall(Fly.Toggle) end) end,
    "fly", "flight / noclip toggle") then
    Log("F4 bound: flight / noclip toggle")
end
if SafeBind({ "F6" }, OpenF6OrPak, "panel", "open the panel") then
    Log("F6 bound: panel")
end

function PanelVisibility()
    local core = nil
    pcall(function() core = AcquireLoaderCore() end)
    local f6 = nil
    pcall(function() f6 = AcquireF6Ui() end)

    local state = {
        pak = false, f6 = false, text = Panel.open and true or false,
        core = core, f6ui = f6, jui = nil,
    }

    if core then
        local jui = nil
        pcall(function() jui = core.JinxingUi end)
        state.jui = jui
        if jui ~= nil then
            local live = false
            pcall(function() live = (jui:IsValid() == true) end)
            if live then
                local invp = false
                pcall(function() invp = (jui:IsInViewport() == true) end)
                if invp then
                    local vis = -1
                    pcall(function() vis = tonumber(jui:GetVisibility()) end)
                    -- r29: 0 Visible / 3 HitTestInvisible / 4 SelfHitTestInvisible
                    -- all RENDER; the shell root normally sits at 4, so a
                    -- vis==0-only check made ESC blind to an on-screen panel
                    state.pak = (vis == 0 or vis == 3 or vis == 4)
                end
            end
        end
    end

    if state.jui == nil then
        local ui = nil
        pcall(function() ui = AcquirePakUIRoot() end)
        if ui ~= nil then
            local invp = false
            pcall(function() invp = (ui:IsInViewport() == true) end)
            if invp then
                local vis = -1
                pcall(function() vis = tonumber(ui:GetVisibility()) end)
                -- r29: renders = 0/3/4 (see PanelVisibility note above)
                state.pak = (vis == 0 or vis == 3 or vis == 4)
            end
        end
    end

    if f6 ~= nil then
        local invp = false
        pcall(function() invp = (f6:IsInViewport() == true) end)
        if invp then
            local vis = -1
            pcall(function() vis = tonumber(f6:GetVisibility()) end)
            -- r29: renders = 0/3/4
            state.f6 = (vis == 0 or vis == 3 or vis == 4)
        end
    end

    state.any = state.pak or state.f6 or state.text
    return state
end

local function CloseAllPanels()
    local closed = {}
    local st = PanelVisibility()
    -- r29: NEVER close via core:JinxingLoaderToggle() - live proof (21:16
    -- session) shows that UFUNCTION is ensure-open semantics; calling it to
    -- close just re-shows the shell. Collapse every live shell directly.
    -- The sweep runs regardless of st.pak so ESC also catches shells that
    -- PanelVisibility missed (core lost, odd visibility states, extras).
    do
        local collapsed = 0
        pcall(function()
            local all = FindAllOf("WBP_JinxingRoot_C")
            if type(all) == "table" then
                for _, s in pairs(all) do
                    if JXAlive(s) then
                        local invp = false
                        pcall(function() invp = (s:IsInViewport() == true) end)
                        local vis = -1
                        pcall(function() vis = tonumber(s:GetVisibility()) end)
                        local renders = invp and (vis == 0 or vis == 3 or vis == 4)
                        if renders then
                            pcall(function() s:SetVisibility(1) end)
                            collapsed = collapsed + 1
                        end
                    end
                end
            end
        end)
        if collapsed > 0 then closed[#closed + 1] = "pak:" .. collapsed end
    end
    if st.f6 then
        local ok = false
        pcall(function() ok = ToggleF6Ui() end)
        if ok then closed[#closed + 1] = "f6" end
    end
    if st.text then
        local ok = false
        pcall(function()
            Panel.open = false
            Panel.widget, Panel.text = nil, nil
            ok = true
        end)
        if ok then closed[#closed + 1] = "text" end
    end
    
    pcall(function()
        local jp = _G.JxPanels
        if type(jp) == "table" and jp.open and type(jp.ForceClose) == "function" then
            jp.ForceClose()
            closed[#closed + 1] = "canvas"
        end
    end)
    
    if #closed > 0 then
        SetPanelMouse(false)
        PakUIOpen = false
        F6UiOpen = false
    end
    return closed
end

local function ClosePanelIfOpen()
    ExecuteInGameThread(function()
        local ok, err = pcall(function()
            local closed = CloseAllPanels()
            if #closed > 0 then
                Log("ESC: closed " .. table.concat(closed, "+"))
            else
                Log("ESC: no mod panel was visible; left the key to the game")
            end
        end)
        if not ok then Log("ESC handler error: " .. tostring(err)) end
    end)
end

function JXSortedKeyNames()
    local names = {}
    pcall(function()
        for k, v in pairs(Key) do
            if type(k) == "string" and v ~= nil and v ~= 0 then
                names[#names + 1] = k
            end
        end
        table.sort(names)
    end)
    return names
end

function FindKey(patterns)
    local names = JXSortedKeyNames()
    if #names == 0 then return nil end
    for _, pat in ipairs(patterns) do
        local lp = string.lower(pat)
        for _, k in ipairs(names) do
            if string.lower(k) == lp then return Key[k], k end
        end
    end
    for _, pat in ipairs(patterns) do
        local lp = string.lower(pat)
        local hit = nil
        for _, k in ipairs(names) do
            if string.sub(string.lower(k), 1, #lp) == lp then
                if hit ~= nil then hit = nil; break end
                hit = k
            end
        end
        if hit ~= nil then return Key[hit], hit end
    end
    return nil
end

do
    local k, kn = FindKey({ "ESCAPE", "Escape", "Esc" })
    if k then
        pcall(RegisterKeyBind, k, ClosePanelIfOpen)
        JxBindRecord("escape", "close the mod panel when one is open, otherwise let the game handle it", kn)
        Log("v3.0 ESC bound (" .. tostring(kn) .. "): closes the panel")
    else
        Log("v3.0 ESC key constant not found in this UE4SS build")
    end
end
do
    local ctrl = nil
    pcall(function() ctrl = ModifierKey.CONTROL end)
    if ctrl ~= nil then
        local kl, kln = FindKey({ "LEFT_ARROW", "ArrowLeft" })
        local kr, krn = FindKey({ "RIGHT_ARROW", "ArrowRight" })
        if kl then
            pcall(RegisterKeyBind, kl, { ctrl }, function()
                
                ExecuteInGameThread(function() RunGuarded("jtab prev", JxTabGo, CurrentTabIndex() - 1, true) end)
            end)
            JxBindRecord("tabprev", "previous tab", kln, { ctrl })
        end
        if kr then
            pcall(RegisterKeyBind, kr, { ctrl }, function()
                ExecuteInGameThread(function() RunGuarded("jtab next", JxTabGo, CurrentTabIndex() + 1, true) end)
            end)
            JxBindRecord("tabnext", "next tab", krn, { ctrl })
        end
        if kl and kr then
            Log("v3.0 Ctrl+Left/Right bound (" .. tostring(kln) .. "+" .. tostring(krn) .. "): previous / next tab")
        else
            Log("v3.0 Ctrl+Left/Right NOT bound - left=" .. tostring(kln) .. " right=" .. tostring(krn))
        end
        
        local kz, kzn = FindKey({ "Z" })
        if kz then
            pcall(RegisterKeyBind, kz, { ctrl }, function()
                ExecuteInGameThread(function()
                    pcall(function()
                        local h = JX.TabHist
                        if type(h) ~= "table" or #h == 0 then
                            Log("Ctrl+Z back: nothing recorded yet (switch a page first)")
                            return
                        end
                        local to = tonumber(table.remove(h))
                        Log("Ctrl+Z back -> page " .. tostring(to))
                        JxTabGo(to or 0, false)
                    end)
                end)
            end)
            JxBindRecord("tabback", "return to the previous tab", kzn, { ctrl })
            Log("v3.9 Ctrl+Z bound (" .. tostring(kzn) .. "): return to the previous tab")
        else
            Log("v3.9 Ctrl+Z NOT bound - the Z key constant was not found in this UE4SS build")
        end
    end
end

local function CallCore(invoke, label)
    ExecuteInGameThread(function()
        pcall(function()
            local core = AcquireLoaderCore()
            if core and core:IsValid() then
                local ok, err = pcall(function() invoke(core) end)
                Log("hotkey Core " .. label .. ": " .. (ok and "ok" or ("FAIL " .. tostring(err))))
            else
                Log("hotkey " .. label .. ": Core not reachable (enter a level first)")
            end
        end)
    end)
end

do
    local ctrl = nil
    pcall(function() ctrl = ModifierKey.CONTROL end)
    if ctrl ~= nil then
        pcall(RegisterKeyBind, Key.O, { ctrl }, function() CallCore(function(c) c:JinxingModToggleAll() end, "ModToggleAll(Ctrl+O)") end)
        pcall(RegisterKeyBind, Key.P, { ctrl }, function() CallCore(function(c) c:JinxingAutoPerf()     end, "AutoPerf(Ctrl+P)")   end)
        pcall(RegisterKeyBind, Key.T, { ctrl }, function() CallCore(function(c) c:JinxingTeleportAll()  end, "TeleportAll(Ctrl+T)") end)
        Log("v2.8 Ctrl+O/P/T bound to Core callable events (mod-toggle / autoperf / teleport)")
    else
        Log("v2.8 ModifierKey.CONTROL unavailable in this UE4SS build; use the panel buttons instead")
    end
end

function JxBindActionFns()
    return {
        fly = function() ExecuteInGameThread(function() pcall(Fly.Toggle) end) end,
        panel = function() OpenF6OrPak() end,
        escape = function() ClosePanelIfOpen() end,
        tabprev = function()
            ExecuteInGameThread(function() RunGuarded("jtab prev", JxTabGo, CurrentTabIndex() - 1, true) end)
        end,
        tabnext = function()
            ExecuteInGameThread(function() RunGuarded("jtab next", JxTabGo, CurrentTabIndex() + 1, true) end)
        end,
        tabback = function()
            ExecuteInGameThread(function()
                pcall(function()
                    local h = JX.TabHist
                    if type(h) ~= "table" or #h == 0 then
                        Log("Ctrl+Z back: nothing recorded yet (switch a page first)")
                        return
                    end
                    local to = tonumber(table.remove(h))
                    Log("Ctrl+Z back -> page " .. tostring(to))
                    JxTabGo(to or 0, false)
                end)
            end)
        end,
    }
end

function JxBindLabelOf(id)
    local fns = { fly = "flight / noclip toggle", panel = "open the panel",
        escape = "close the panel", tabprev = "previous tab",
        tabnext = "next tab", tabback = "return to the previous tab" }
    return fns[id] or tostring(id)
end

local function BindAuto(patterns, fn, label)
    local k, kn = FindKey(patterns)
    if not k then
        Log("keydiag auto " .. label .. " NOT FOUND (tried " .. table.concat(patterns, "/") .. ")")
        return false
    end
    local ok = pcall(RegisterKeyBind, k, fn)
    
    Log("keydiag auto " .. label .. " bound=" .. tostring(ok) .. " as " .. tostring(kn))
    return ok
end

pcall(function()
    local names = {}
    for k, v in pairs(Key) do
        if type(k) == "string" and v ~= nil and v ~= 0 then names[#names + 1] = k end
    end
    table.sort(names)
    Log("keydiag available keys (" .. #names .. "): " .. table.concat(names, ","))
end)

BindAuto({ "UP_ARROW", "ArrowUp", "NUM_EIGHT" }, function() ExecuteInGameThread(function() pcall(function() if Panel.open then PanelNav(-1) end end) end) end, "Up")
BindAuto({ "DOWN_ARROW", "ArrowDown", "NUM_TWO" }, function() ExecuteInGameThread(function() pcall(function() if Panel.open then PanelNav(1) end end) end) end, "Down")
BindAuto({ "LEFT_ARROW", "ArrowLeft", "NUM_FOUR" }, function() ExecuteInGameThread(function() pcall(function()
    if not Panel.open then return end
    if Panel.page == 5 then PerfPanelAdjust(-1)
    elseif Panel.page == 3 and Panel.sel == 1 then PanelAdjustCap(-8)
    else PanelSwitch(-1) end
end) end) end, "Left")
BindAuto({ "RIGHT_ARROW", "ArrowRight", "NUM_SIX" }, function() ExecuteInGameThread(function() pcall(function()
    if not Panel.open then return end
    if Panel.page == 5 then PerfPanelAdjust(1)
    elseif Panel.page == 3 and Panel.sel == 1 then PanelAdjustCap(8)
    else PanelSwitch(1) end
end) end) end, "Right")

BindAuto({ "RETURN", "Enter" }, function() ExecuteInGameThread(function() pcall(function() if Panel.open then PanelAct() end end) end) end, "Enter")
BindAuto({ "PAGE_UP", "PageUp" }, function() ExecuteInGameThread(function() pcall(function() if Panel.open then PanelSwitch(-1) end end) end) end, "PageUp")
BindAuto({ "PAGE_DOWN", "PageDown" }, function() ExecuteInGameThread(function() pcall(function() if Panel.open then PanelSwitch(1) end end) end) end, "PageDown")

BootStep("LoadOrder", Slot.LoadOrder)
BootStep("LoadAuto", Slot.LoadAuto)

do
    local function FSay(s) Log("v4.8: " .. s) end

    function JXReadCVar(name)
        if type(name) ~= "string" or name == "" then return nil end
        local v = nil
        pcall(function()
            local KSL = StaticFindObject("/Script/Engine.Default__KismetSystemLibrary")
            if not JXAlive(KSL) then return end
            local r = KSL:GetConsoleVariableFloatValue(name)
            if r ~= nil then v = tonumber(r) end
        end)
        return v
    end

    function JXItemWants(i)
        local it = PerfItems[i]
        local names, wants = {}, {}
        if not it then return names, wants end
        if it.fan then
            local lines = it.fan[math.floor((it.cur or 0) + 0.5)] or it.fan[it.def] or {}
            for _, line in ipairs(lines) do
                local nm, val = tostring(line):match("^(%S+)%s+(%-?[%d%.]+)%s*$")
                local v = val and tonumber(val) or nil
                
                if nm and v then
                    names[#names + 1] = nm
                    wants[#names] = v
                end
            end
        elseif it.cvar then
            names[1] = it.cvar
            wants[1] = tonumber(it.cur)
        end
        return names, wants
    end

    function JXVerifyItem(i)
        local names, wants = JXItemWants(i)
        if #names == 0 then return "engine: untouched (this level sends no cvar)" end
        local function same(live, want)
            
            local lv, wv = tonumber(live), tonumber(want)
            if lv == nil or wv == nil then return nil end
            return math.abs(lv - wv) < 0.02
        end
        local function readAll()
            local out = {}
            for k, nm in ipairs(names) do out[k] = JXReadCVar(nm) end
            return out
        end
        local live = readAll()
        local bad = false
        for k = 1, #names do
            if same(live[k], wants[k]) == false then bad = true end
        end
        if bad then
            local PC = nil
            pcall(function() PC = UEHelpers.GetPlayerController() end)
            if JXAlive(PC) then
                for k = 1, #names do
                    if same(live[k], wants[k]) == false then
                        pcall(function()
                            JXExecCmd(PC, names[k] .. " " .. string.format("%g", wants[k]))
                        end)
                    end
                end
                live = readAll()
            end
        end
        local parts = {}
        local still = {}
        for k = 1, #names do
            local st = same(live[k], wants[k])
            parts[#parts + 1] = names[k] .. "="
                .. (live[k] ~= nil and string.format("%g", live[k]) or "unreadable")
                .. (st == true and "" or (st == nil and "?" or "!"))
            if st == false then still[#still + 1] = names[k] end
        end
        local tag = ""
        if #still > 0 then tag = "  <- STILL WRONG: " .. table.concat(still, ",") end
        return "engine: " .. table.concat(parts, " ") .. tag
    end

    local Burst = { n = 0, t = 0, muteUntil = 0, mutes = 0 }
    local function PerfBurstGate(tag)
        local t = (os and os.clock and os.clock()) or 0
        if t < Burst.muteUntil then return false end
        if t - Burst.t > 1.0 then Burst.t = t; Burst.n = 0 end
        Burst.n = Burst.n + 1
        if Burst.n > 40 then
            Burst.muteUntil = t + 5.0
            Burst.mutes = Burst.mutes + 1
            Log(string.format(
                "perf: interceptor burst on '%s' (%d in one second) -> muted 5 s to break a self-feed loop (mute #%d)",
                tostring(tag), Burst.n, Burst.mutes))
            return false
        end
        return true
    end

    local function InterceptCVar(cmdName, itemKey, scale)
        
        local ret = JXRegCmd(cmdName, function(FullCommand, Parameters)
            ExecuteInGameThread(function()
                
                if not PerfBurstGate(cmdName) then return end
                local i = PerfIdxFromKey(itemKey)
                if not i then return end
                local raw = Parameters and Parameters[1]
                local v = tonumber(raw)
                if v == nil then
                    Log(cmdName .. ": unparsed value '" .. tostring(raw) .. "' - ignored")
                    return
                end
                
                if type(PerfEcho) == "table" then
                    local seen = PerfEcho[cmdName]
                    PerfEcho[cmdName] = nil
                    if seen ~= nil and v == seen then return end
                end
                
                if type(scale) == "function" then v = scale(v)
                elseif scale then v = v * scale end
                
                if v ~= v or v == math.huge or v == -math.huge then return end
                local previous = PerfItems[i].cur or 0
                PerfClamp(i, v)
                if math.abs(previous - PerfItems[i].cur) < 0.005 then return end
                PerfSave()
                PerfApplyOne(i)
                
                FSay(cmdName .. " -> " .. itemKey .. "=" .. string.format("%g", PerfItems[i].cur)
                    .. " (persisted; survives map loads and restarts)")
                FSay("  " .. JXVerifyItem(i))
            end)
            return true
        end)
        local ok = (ret ~= false)
        FSay("slider interceptor '" .. cmdName .. "' " .. (ok and "armed" or "NOT armed"))
        return ok
    end
    InterceptCVar("r.StaticMeshLODDistanceScale", "slod", nil)
    InterceptCVar("r.ViewDistanceScale", "viewdist", nil)
    InterceptCVar("foliage.LODDistanceScale", "flod", nil)
    
    InterceptCVar("r.MotionBlurQuality", "motion", function(v)
        if v > 4 then return v / 15 end
        return v
    end)

    local WL = { on = true, list = {}, file = JXRootOr .. "config/whitelist.txt" }
    
    JX.WLRef = WL
    do
        local f = io.open(WL.file, "r")
        if f then
            for line in f:lines() do
                local name = line:match("^%s*([^;#%s][^;#]-)%s*$")
                if name and name ~= "" then WL.list[name:lower()] = true end
            end
            f:close()
        end
    end
    local function WLAllowed()
        if not WL.on then return true, "" end
        
        local auth = false
        pcall(function()
            local info = JXTravelInfo and JXTravelInfo() or nil
            auth = (info ~= nil and info.authority == true)
        end)
        if auth then return true, "(host)" end
        local me = ""
        pcall(function()
            if type(JXIdent) == "function" then me = (JXIdent()) or "" end
        end)
        if me == "" then
            pcall(function()
                local ps = nil
                pcall(function()
                    local pc = UEHelpers.GetPlayerController()
                    if pc and pc:IsValid() then ps = pc.PlayerState end
                end)
                if ps and ps:IsValid() then
                    pcall(function() me = JxStr(ps.PlayerName) end)
                end
            end)
        end
        if me == "" then return true, "" end
        local bare = me:match("^steam:(.+)$")
        local probes = { me, me:lower() }
        if bare then probes[#probes + 1] = bare end
        for _, k in ipairs(probes) do
            if WL.list[k] or WL.list[k:lower()] then return true, me end
        end
        
        local lvl = nil
        pcall(function()
            if type(JXWL) == "table" and JXWL.LevelOf then lvl = JXWL.LevelOf(me) end
        end)
        if type(lvl) == "number" and lvl >= 1 then return true, me end
        return false, me
    end
    local function WLCaptureSelf()
        pcall(function()
            local ps = nil
            pcall(function()
                local pc = UEHelpers.GetPlayerController()
                if pc and pc:IsValid() then ps = pc.PlayerState end
            end)
            if not (ps and ps:IsValid()) then return end
            local name, ids = "", {}
            pcall(function() name = JxStr(ps.PlayerName) end)
            pcall(function() ids[#ids + 1] = "PlayerId=" .. tostring(ps.PlayerId) end)
            pcall(function()
                local u = ps.UniqueId
                if u then ids[#ids + 1] = "UniqueId=" .. JxStr(u) end
            end)
            if name ~= "" then
                WL.list[name:lower()] = true
                AppendLine(WL.file, name .. "  ; " .. table.concat(ids, " "))
                FSay("whitelist: captured self '" .. name .. "' (" .. table.concat(ids, " ")
                    .. ") - the panel stays open for you")
            end
        end)
    end
    JXRegCmd("jwlist", function(FullCommand, Parameters)
        ExecuteInGameThread(function()
            local sub = Parameters and Parameters[1] or "status"
            if sub == "on" then
                WL.on = true
                WLCaptureSelf()
                FSay("whitelist gate ON - non-listed players get the panel closed on them ('jwlist off' restores)")
            elseif sub == "off" then
                WL.on = false
                FSay("whitelist gate OFF - the panel opens for everyone")
            elseif sub == "export" then
                ExecuteInGameThread(function()
                    pcall(function()
                        local out = ModDir .. "config/whitelist_export.txt"
                        local w = io.open(out, "w")
                        if not w then Log("WL| export: cannot write " .. out); return end
                        w:write("; JX whitelist export " .. os.date("%Y-%m-%d %H:%M:%S") .. "\r\n")
                        w:write("; --- panel gate list (whitelist.txt) ---\r\n")
                        for k in pairs(WL.list) do w:write(k .. "\r\n") end
                        w:write("; --- levels (whitelist.ini) ---\r\n")
                        local h = io.open(ModDir .. "config/whitelist.ini", "r")
                        if h then
                            for line in h:lines() do w:write(line .. "\r\n") end
                            h:close()
                        end
                        w:close()
                        Log("WL| exported gate list + levels to " .. out)
                    end)
                end)
                return true
            elseif sub == "add" then
                local name = Parameters and Parameters[2]
                if not name or name == "" then FSay("usage: jwlist add <player name>") return end
                WL.list[name:lower()] = true
                AppendLine(WL.file, name)
                FSay("whitelist: added '" .. name .. "'")
            else
                local n = 0
                for _ in pairs(WL.list) do n = n + 1 end
                FSay("whitelist gate = " .. tostring(WL.on) .. ", " .. tostring(n) .. " name(s) listed (file: " .. WL.file .. ")")
            end
        end)
        return true
    end)
    
    FSay("whitelist: panel gate moved to the canvas path (JXPanelGateAllowed, r9)")

    local AFK = { on = false, ms = 90000, seen = {}, tickOn = false }
    local function AFKScan()
        if not AFK.on then AFK.tickOn = false return end
        ExecuteInGameThread(function()
            if AFK.on and not JXBusy() and not JXTransferGuard() then
                pcall(function()
                    local PCs = FindAllOf("PlayerController")
                    if not PCs then return end
                    local now = JXClock()
                    for _, pc in pairs(PCs) do
                        if JXAlive(pc) then
                            local localPC = false
                            pcall(function() localPC = pc:IsLocalController() end)
                            if not localPC then
                                local pawn = nil
                                pcall(function() pawn = pc.Pawn end)
                                local pos = nil
                                if JXAlive(pawn) then
                                    pcall(function()
                                        local l = pawn:K2_GetActorLocation()
                                        pos = string.format("%.0f,%.0f,%.0f", l.X, l.Y, l.Z)
                                    end)
                                end
                                local key = JXName(pc)
                                local rec = AFK.seen[key]
                                if pos == nil then
                                    AFK.seen[key] = nil
                                elseif rec and rec.pos == pos then
                                    if now - rec.since > AFK.ms then
                                        local nm = ""
                                        pcall(function()
                                            if pc.PlayerState then nm = JxStr(pc.PlayerState.PlayerName) end
                                        end)
                                        AFK.seen[key] = nil
                                        JXKickToMenu(pc, "Removed by host: AFK "
                                            .. tostring(AFK.ms / 1000) .. "s (may rejoin)")
                                        FSay("AFK: kicked '" .. (nm ~= "" and nm or key) .. "' (idle "
                                            .. tostring(AFK.ms / 1000) .. "s, may rejoin)")
                                    end
                                else
                                    AFK.seen[key] = { pos = pos, since = now }
                                end
                            end
                        end
                    end
                end)
            end
            if AFK.on then
                ExecuteWithDelay(20000, function() ExecuteInGameThread(function() pcall(AFKScan) end) end)
            else
                AFK.tickOn = false
            end
        end)
    end
    JXRegCmd("jafk", function(FullCommand, Parameters)
        ExecuteInGameThread(function()
            local sub = Parameters and Parameters[1] or "status"
            if sub == "on" then
                AFK.on = true
                if not AFK.tickOn then
                    AFK.tickOn = true
                    ExecuteInGameThread(function() pcall(AFKScan) end)
                end
                FSay("AFK auto-clean ON - players idle over " .. tostring(AFK.ms / 1000) .. "s are kicked (may rejoin)")
            elseif sub == "off" then
                AFK.on = false
                AFK.tickOn = false
                FSay("AFK auto-clean OFF")
            elseif sub == "time" then
                local sec = tonumber(Parameters and Parameters[2])
                if sec and sec >= 30 then AFK.ms = sec * 1000 FSay("AFK threshold = " .. tostring(sec) .. "s") return end
                FSay("usage: jafk time <seconds 30+>")
            else
                FSay("AFK auto-clean = " .. tostring(AFK.on) .. ", threshold " .. tostring(AFK.ms / 1000) .. "s (jafk on|off|time <s>)")
            end
        end)
        return true
    end)

    local REV = { on = false }
    JXRegCmd("jrevive", function(FullCommand, Parameters)
        ExecuteInGameThread(function()
            local sub = Parameters and Parameters[1] or "status"
            if sub == "on" then
                REV.on = true
                FSay("auto-revive ON - a death in-game auto-restores the last save (jload) after 2s")
            elseif sub == "off" then
                REV.on = false
                FSay("auto-revive OFF")
            else
                FSay("auto-revive = " .. tostring(REV.on) .. " (jrevive on|off)")
            end
        end)
        return true
    end)

    local MeshShelf = { file = JXRootOr .. "config/meshes_cache.txt", n = 0 }
    local function MeshScan()
        pcall(function()
            local all = FindAllOf("StaticMeshActor")
            if not all then FSay("mesh scan: no StaticMeshActor found this world") return end
            local out, n = {}, 0
            for _, a in pairs(all) do
                if JXAlive(a) then
                    local label, path = "", ""
                    pcall(function() label = JXName(a) end)
                    pcall(function()
                        local sm = nil
                        pcall(function() sm = a.StaticMeshComponent end)
                        if not sm then pcall(function() sm = a:GetStaticMeshComponent() end) end
                        if sm and sm:IsValid() then
                            pcall(function()
                                local mesh = sm.StaticMesh
                                if mesh then path = JXName(mesh) end
                            end)
                        end
                    end)
                    n = n + 1
                    out[#out + 1] = label .. " | " .. path
                end
            end
            AppendLine(MeshShelf.file, "==== " .. Now() .. " ====")
            for _, l in ipairs(out) do AppendLine(MeshShelf.file, l) end
            MeshShelf.n = MeshShelf.n + n
            FSay("mesh shelf: " .. tostring(n) .. " static meshes stored to " .. MeshShelf.file
                .. " (jmesh find <text> to recall; jmesh count for totals)")
        end)
    end
    JXRegCmd("jmesh", function(FullCommand, Parameters)
        ExecuteInGameThread(function()
            local sub = Parameters and Parameters[1] or "scan"
            if sub == "scan" then
                MeshScan()
            elseif sub == "count" then
                FSay("mesh shelf: " .. tostring(MeshShelf.n) .. " line(s) stored this session (file: " .. MeshShelf.file .. ")")
            else
                local q = tostring(Parameters and Parameters[1] or "")
                local f = io.open(MeshShelf.file, "r")
                if not f then FSay("mesh shelf is empty - run jmesh scan first") return end
                local hits = 0
                for line in f:lines() do
                    if q ~= "" and line:find(q, 1, true) then
                        Log("  " .. line)
                        hits = hits + 1
                        if hits >= 40 then Log("  ...(truncated at 40)") break end
                    end
                end
                f:close()
                FSay("mesh shelf: " .. tostring(hits) .. " hit(s) for '" .. q .. "'")
            end
        end)
        return true
    end)

    local Cat = { file = JXRootOr .. "config/spawn_catalog.txt", map = nil, n = 0 }
    local function CatLoad(force)
        if Cat.map and not force then return Cat.map end
        local map = {}
        local f = io.open(Cat.file, "r")
        if f then
            for line in f:lines() do
                local sec, nm, p = line:match("^%[(%w+)%]%s*(.+)%s*=%s*(%S+)%s*$")
                if nm and p then
                    map[nm] = { sec = sec, path = p }
                end
            end
            f:close()
        end
        local n = 0
        for _ in pairs(map) do n = n + 1 end
        Cat.n = n
        Cat.map = map
        return map
    end
    local function CatSpawn(nm)
        local map = CatLoad()
        local e = map[nm]
        if not e then return nil, "not in catalog (jsp list <text> to search, jsp reload to rescan)" end
        local cls = nil
        if e.path:find("/Script/", 1, true) then
            pcall(function() cls = J3LoadObject(e.path) end)
        else
            local leaf = e.path:match("/([^/]+)$")
            pcall(function() cls = leaf and J3LoadObject(e.path .. "." .. leaf .. "_C") or nil end)
        end
        if not (cls and cls:IsValid()) then
            return nil, "class did not load: " .. e.path
        end
        
        local px, py, pz = 0, 0, 0
        local pyaw = 0
        
        JX = JX or {}
        local mode = JX.spawnAt or "feet"
        if mode == "cube" and type(MarkPos) == "function" then
            local mp = nil
            pcall(function() mp = MarkPos() end)
            if mp then px, py, pz = mp.X, mp.Y, mp.Z end
        end
        if px == 0 and py == 0 and pz == 0 and mode ~= "front" then
            pcall(function()
                local pc = UEHelpers.GetPlayerController()
                local pawn = pc and pc.Pawn
                if JXAlive(pawn) then
                    local l = pawn:K2_GetActorLocation()
                    local r = pawn:K2_GetActorRotation()
                    
                    px, py, pz = l.X, l.Y, l.Z + 60
                    pyaw = r and r.Yaw or 0
                end
            end)
        end
        local v = (px == 0 and py == 0 and pz == 0) and ViewPoint(160, 0) or nil
        if v then
            px, py, pz = v.x, v.y, v.z
            pyaw = v.yaw or 0
        elseif px == 0 and py == 0 and pz == 0 then
            
            pcall(function()
                local pc = UEHelpers.GetPlayerController()
                local pawn = pc and pc.Pawn
                if JXAlive(pawn) then
                    local l = pawn:K2_GetActorLocation()
                    local r = pawn:K2_GetActorRotation()
                    local yaw = math.rad(r and r.Yaw or 0)
                    px = l.X + math.cos(yaw) * 160
                    py = l.Y + math.sin(yaw) * 160
                    pz = l.Z
                    pyaw = r and r.Yaw or 0
                end
            end)
        end
        local a = nil
        if type(JxActor) == "table" and type(JxActor.spawn) == "function" then
            pcall(function() a = JxActor.spawn(cls, px, py, pz, pyaw) end)
        end
        if not JXAlive(a) then
            a = JXSpawnLikeLoader(cls)
        end
        if JXAlive(a) then
            return a
        end
        return nil, "spawn failed (class loaded but the actor did not come out)"
    end
    JXRegCmd("jsp", function(FullCommand, Parameters)
        ExecuteInGameThread(function()
            
            local rest = tostring(FullCommand or "")
            rest = rest:gsub("^%s*jsp%s*", "")
            rest = rest:match("^%s*(.-)%s*$")
            local sub = rest
            if sub == "" or sub == "help" then
                FSay("jsp <name|list|find|reload> - e.g. jsp <catalog name in Chinese>")
                return
            end
            if sub == "reload" then
                CatLoad(true)
                FSay("spawn catalog reloaded: " .. tostring(Cat.n) .. " entries")
            elseif sub == "list" or string.sub(sub, 1, 5) == "find " then
                local q = string.sub(sub, 6)
                q = q:match("^%s*(.-)%s*$") or ""
                local map = CatLoad()
                local hits = 0
                for nm, e in pairs(map) do
                    if q == "" or nm:find(q, 1, true) then
                        Log("  [" .. e.sec .. "] " .. nm)
                        hits = hits + 1
                        if hits >= 40 then Log("  ...(truncated at 40)") break end
                    end
                end
                FSay("catalog: " .. tostring(Cat.n) .. " entries, " .. tostring(hits) .. " shown for '" .. q .. "'")
            else
                local a, why = CatSpawn(sub)
                if JXAlive(a) then
                    FSay("spawned '" .. sub .. "' in front of you")
                else
                    FSay("spawn '" .. sub .. "' failed: " .. tostring(why))
                end
            end
        end)
        return true
    end)

    JXWordKickPublic = JXKickToMenu
    FSay("feature pack ready: slider interceptors + whitelist + AFK + revive + mesh shelf + spawn catalog (jwlist/jafk/jrevive/jmesh/jsp)")
    JXCatLoad = CatLoad  
end

do
    local function JXOwnerPackR314()
    local function FSay(s) Log("v4.9: " .. s) end

    local function JXResolveModDir()
        local src = nil
        pcall(function()
            local info = debug and debug.getinfo and debug.getinfo(1, "S")
            src = info and info.source or nil
        end)
        if type(src) ~= "string" or src == "" then return nil end
        src = src:gsub("^@", "")
        src = src:gsub("\\", "/")
        
        local root = src:match("^(.-)[Ss]cripts/[^/]*$")
        if not root or root == "" then return nil end
        if root:sub(-1) ~= "/" then root = root .. "/" end
        return root
    end

    do
        local resolved = JXResolveModDir()
        if resolved then
            
            ModDir = resolved
            Log("r3.17 paths: ModDir resolved to " .. tostring(ModDir) .. " (from the script location)")
        else
            Log("r3.17 paths: could not resolve the script directory; keeping the relative ModDir "
                .. tostring(ModDir) .. " - saves may not write if the working directory differs")
        end
    end

    local function EnsureDir(path)
        if path == nil then return false end
        local p = tostring(path):gsub("/", "\\")
        
        local probe = io.open(p .. "\\", "r")
        if probe then probe:close(); return true end
        if type(os.execute) ~= "function" then return false end
        local ok = false
        pcall(function()
            
            os.execute('if not exist "' .. p .. '" mkdir "' .. p .. '" >nul 2>nul')
            ok = true
        end)
        if not ok then return false end
        local check = io.open(p .. "\\", "r")
        if check then check:close(); return true end
        return false
    end

    local SavesDir = ModDir .. "saves/"
    local ExpDir   = ModDir .. "exports/"

    Slot.SavesDir = SavesDir
    Slot.ExportsDir = ExpDir

    local savesReady = EnsureDir(SavesDir)
    local expReady   = EnsureDir(ExpDir)
    Log("r3.17 paths: saves=" .. tostring(savesReady) .. " exports=" .. tostring(expReady)
        .. " (" .. tostring(SavesDir) .. ")")

    local function I32(n)
        n = math.floor(tonumber(n) or 0)
        if n > 2147483647 then n = 2147483647 elseif n < -2147483648 then n = -2147483648 end
        return string.pack("<i4", n)
    end
    local function I64(n)
        n = math.floor(tonumber(n) or 0)
        if n > 9223372036854775807 then n = 9223372036854775807
        elseif n < -9223372036854775808 then n = -9223372036854775808 end
        return string.pack("<i8", n)
    end
    local function F32(n) return string.pack("<f", tonumber(n) or 0) end
    local function FStr(s) s = tostring(s or ""); return I32(#s + 1) .. s .. "\0" end

    local function ReadAllBytes(path)
        local f = io.open(path, "rb"); if not f then return nil end
        local d = f:read("*a"); f:close(); return d
    end
    
    local function WriteAllBytes(path, d)
        if type(path) ~= "string" or path == "" then return false end
        if type(d) ~= "string" then return false end
        local parent = path:gsub("/", "\\"):match("^(.*)\\[^\\]+$")
        if parent and parent ~= "" then EnsureDir(parent .. "\\") end
        local f = io.open(path, "wb")
        if not f then return false end
        local ok = pcall(function() f:write(d) end)
        local closed = f:close()
        if not ok or closed == nil then return false end
        
        local back = ReadAllBytes(path)
        if back == nil or #back ~= #d then return false end
        return true
    end
    local function RdFStr(b, o)
        if o + 4 > #b then return nil, o end
        local len = string.unpack("<i4", b, o); o = o + 4
        if len <= 0 or o + len > #b then return nil, o + math.max(len, 0) end
        return b:sub(o, o + len - 2), o + len
    end

    local JXAMS_HEADER_HEX = "47564153020000000a02000004001b00020000000000130000002b2b5545342b52656c656173652d342e3237000300000037000000a7fbd240e54c484b755a38b09e494e8807000000fa7af5fc8342765058e6a9b9322da0ff44000000ed0a3111614d552ea39a67af2c08a1c511000000f37abb24834f4656c22d2f1fff96ad49050000002923a576b545230941d8ae98d86a2fcf050000000769bc5fae40c85584f1678e3ff1ff5e0100000012e426fb4d4b151f0a557293702f1d96030000004e7ce782a5432333c5136bb4f30d31970000000022d5549cbe4f26a846072194d082b4612b000000e432d8b00d4f891fb77ecfaca24afd360a0000002843c6e1534d2ca2868e6ca38cbd1764000000003cc15e37fb48e406f08400b57e712a2604000000ed68b0e4e94294f40bda31a241bb462e280000003f74fccf8044b043df14919373201d1725000000b5492bb0e94420bbb73204a36003e452030000005c10e4a4b549a159c440c5a7eedf7e5400000000c931c839dc47e65a179c449a7c8e1c3e00000000331bf078984feaebea84b4b9a25ab9cc0e0000000f383166e0434d2d27cf09805aa95669000000009f8bf812fc4a75880cd97ca629bd3a382d0000004ce75a7b104c70d2985758a95a2a210b0d000000186929d7dd4bd61da864e29d8438c13c030000007852a1c2fe4ae7bfff90176c55f71d5301000000d4a3ac6ec14cec40ed8b86b7c58f420903000000dd75e5292746a3e076d2109deadc2c23110000005da643af4749d37f8e3e739805bbc1d90f000000ec6c266b8f4bc71ed9e40ba307fc420901000000613df70dea473fa2e98927b79a49410c0100000086181d60844f64acded316aad6c7ea0d2f000000686308e7584c236b701b3984915e261601000000d6bcff9d58014f49821221e288a8923c0a000000acd0aef26f41fe9a7faa6486fcd626fa010000000b1f4f17a545c6b4e82e3fb17d91fbd00a000000834af9356c4058e2f50918a37c241096290000006ec18fb6e2421b8b5c2153b4fe448805010000000685e1b2c2cf7342bbf44ea507ba8b75010000003689f564ba421bfd897296ba4efad0d50100000027d80e6f954809a68d99919ca40e189002000000e79e7f713a49b0e93291b3880781381b0800000050326854af4899809698c88bb7f9adfb00000000194d0c4370495471699b6987e5b090df0f000000bd32feaa144c9553255e6ab6ddd13210010000008ee1af23584ee14c52c2618db7be53b90b000000eab762a43a4e99f41fecc199b2e1248204000000bdfdb52e104dac018ff33681daa59333050000004f359d502f49e6f6b28549a71c633c070000000040eb564adc11f5107e34d392e76ac9b202000000004a8ad7974658e8b519a8bab4467d481200000086f879551f4c3a937b08ba832fb961630200000052be2f610b4053da914f0d917c85b19f01000000367a23a4c941eacaf818a28ff31b685804000000753f4e80494b8870068cd6a4dcb67e3c05000000f20a68fba34bef59b519a8ba3d44c873020000000eb75099174e1ab40dfaccbbd67f815701000000965196abfc08d8458d22d7b79e56ad78010000002d0000002f47616d652f4d6f64732f426f782f426c75657072696e742f534c5f4163746f722e534c5f4163746f725f4300"
    local function HeaderBlob()
        return (JXAMS_HEADER_HEX:gsub("%x%x", function(cc)
            return string.char(tonumber(cc, 16))
        end))
    end

    local function SafeName(map) return (tostring(map):gsub("[^%w%-_]", "_")) end
    local function JxamsPath(map) return SavesDir .. "JXAMS-" .. SafeName(map) .. ".sav" end

    local function PathOnly(fn)
        if not fn then return nil end
        fn = tostring(fn)
        return fn:match("^%S+%s+(/.+)$") or fn
    end

    local function JxamsWrite(path, map, rows, player, stamp, mpath)
        local cls, msh, knd, flt, nms = {}, {}, {}, {}, {}
        for i, r in ipairs(rows) do
            cls[i] = FStr(r.cls or "")
            msh[i] = FStr(r.mesh or "")
            knd[i] = I32(r.kind or 0)
            nms[i] = FStr(r.name or "")
            flt[#flt + 1] = F32(r.x); flt[#flt + 1] = F32(r.y)
            flt[#flt + 1] = F32(r.z); flt[#flt + 1] = F32(r.yaw or 0)
        end
        local vM = FStr(map)
        local aC = FStr("ObjectProperty") .. I32(#rows) .. table.concat(cls)
        local aM = FStr("StrProperty") .. I32(#rows) .. table.concat(msh)
        local aK = FStr("IntProperty") .. I32(#rows) .. table.concat(knd)
        local aF = FStr("FloatProperty") .. I32(#rows * 4) .. table.concat(flt)
        local aN = FStr("StrProperty") .. I32(#rows) .. table.concat(nms)
        local vP, nP = "", 0
        if player and (player.x or player.y or player.z) then
            nP = 4
            vP = F32(player.x) .. F32(player.y) .. F32(player.z) .. F32(player.yaw or 0)
        end
        local aP = FStr("FloatProperty") .. I32(nP) .. vP
        local vS = FStr(tostring(stamp or "unknown") .. "|" .. tostring(mpath or "-"))
        local body = HeaderBlob()
            .. FStr("JXMap") .. FStr("StrProperty") .. I64(#vM) .. vM
            .. FStr("Classes") .. FStr("ArrayProperty") .. I64(#aC) .. aC
            .. FStr("Meshes") .. FStr("ArrayProperty") .. I64(#aM) .. aM
            .. FStr("Kinds") .. FStr("ArrayProperty") .. I64(#aK) .. aK
            .. FStr("Data") .. FStr("ArrayProperty") .. I64(#aF) .. aF
            .. FStr("Names") .. FStr("ArrayProperty") .. I64(#aN) .. aN
            .. FStr("Player") .. FStr("ArrayProperty") .. I64(#aP) .. aP
            .. FStr("Seen") .. FStr("StrProperty") .. I64(#vS) .. vS
            .. FStr("None")
        return WriteAllBytes(path, body)
    end

    local function JxamsRead(path)
        local b = ReadAllBytes(path)
        if not b then return nil, "cannot read " .. path end
        local at = b:find(FStr("JXMap"), 1, true)
        if not at then return nil, "not a JXAMS file" end
        local ok, result = pcall(function()
            local o = at
            local map, classes, meshes, kinds, floats, names = nil, {}, {}, {}, {}, {}
            local player, seen = {}, nil
            for _ = 1, 16 do
                local name, no = RdFStr(b, o); if not name then break end
                o = no
                if name == "None" then break end
                local typ, no2 = RdFStr(b, o); if not typ then break end
                o = no2
                local size = string.unpack("<i8", b, o); o = o + 8
                local vend = o + size
                if typ == "StrProperty" then
                    local v = RdFStr(b, o)
                    if name == "JXMap" then map = v
                    elseif name == "Seen" then seen = v end
                elseif typ == "ArrayProperty" then
                    local et, no3 = RdFStr(b, o)
                    if et then
                        o = no3
                        local n = string.unpack("<i4", b, o); o = o + 4
                        if et == "FloatProperty" then
                            
                            local dst = (name == "Player") and player or floats
                            for k = 1, n do
                                dst[k] = string.unpack("<f", b, o); o = o + 4
                            end
                        elseif et == "IntProperty" then
                            for k = 1, n do
                                kinds[k] = string.unpack("<i4", b, o); o = o + 4
                            end
                        elseif et == "ObjectProperty" or et == "StrProperty" then
                            for k = 1, n do
                                local s, no4 = RdFStr(b, o); o = no4
                                if et == "ObjectProperty" then classes[k] = s else
                                    if meshes[k] == nil and name == "Meshes" then meshes[k] = s
                                    elseif name == "Names" then names[k] = s end
                                end
                            end
                        end
                    end
                end
                o = vend
            end
            local rows = {}
            for i = 1, #classes do
                rows[i] = { cls = classes[i], mesh = meshes[i] or "", name = names[i] or "",
                            kind = kinds[i] or 0,
                            x = floats[(i - 1) * 4 + 1] or 0, y = floats[(i - 1) * 4 + 2] or 0,
                            z = floats[(i - 1) * 4 + 3] or 0, yaw = floats[(i - 1) * 4 + 4] or 0 }
            end
            return { map = map, rows = rows, seen = seen,
                     player = { x = player[1], y = player[2], z = player[3], yaw = player[4] } }
        end)
        if not ok then return nil, tostring(result) end
        return result
    end

    local Snap = { map = nil, rows = {} }

    local function SnapshotMap()
        local got = 0
        pcall(function()
            local all = FindAllOf("StaticMeshActor")
            if not all then return end
            local rows = {}
            for _, a in pairs(all) do
                if JXAlive(a) then
                    local loc, rot, mesh
                    pcall(function() loc = a:K2_GetActorLocation() end)
                    pcall(function() rot = a:K2_GetActorRotation() end)
                    pcall(function()
                        local sc = a.StaticMeshComponent
                        if sc and sc.StaticMesh then mesh = PathOnly(sc.StaticMesh:GetFullName()) end
                    end)
                    if loc then
                        rows[#rows + 1] = { cls = "/Script/Engine.StaticMeshActor",
                            name = JXName(a), mesh = mesh, kind = 1,
                            x = loc.X, y = loc.Y, z = loc.Z, yaw = rot and rot.Yaw or 0 }
                    end
                end
            end
            Snap.rows, Snap.map = rows, (MapIdentity())
            got = #rows
        end)
        return got
    end

    local AclLog = ModDir .. "logs/jx_acl.txt"
    local function AclClasses()
        local lad = os.getenv("LOCALAPPDATA") or ""
        local b = ReadAllBytes(lad .. "\\EscapeTheBackrooms\\Saved\\SaveGames\\ACL.sav")
        if not b then return nil, "ACL.sav not found under LOCALAPPDATA" end
        local seen, out = {}, {}
        for s in b:gmatch("[/%w%-%.%_:%(%)]+") do
            if #s >= 10 and s:sub(1, 1) == "/" and not seen[s] then
                seen[s] = true
                out[#out + 1] = s
            end
        end
        table.sort(out)
        return out
    end

    local SoftOff = {}

    local function KillByToken(token)
        local killed = 0
        pcall(function()
            local all = FindAllOf("Actor")
            if not all then return end
            local low = token:lower()
            for _, a in pairs(all) do
                if JXAlive(a) then
                    local tok = ActorClassToken(a)
                    if tok ~= "" and tok:lower():find(low, 1, true) then
                        pcall(function() a:DestroyActor() end)
                        killed = killed + 1
                    end
                end
            end
        end)
        return killed
    end

    local AC = { on = false, kicks = 0, fly = {}, spd = {}, lastDrops = -1,
                 dropsWanted = false }
    local WorkerArmed = false

    local DROP_SWEEP_MIN_TICKS = 5      
    local AC_dropTick = 0
    local AC_dropEvery = DROP_SWEEP_MIN_TICKS
    local AC_averageActors = 0
    local AC_dropScale = 1              

    local function WorkerTick()
        if next(SoftOff) ~= nil then
            for k in pairs(SoftOff) do KillByToken(k) end
        end
        if not AC.on then return end
        pcall(function()
            
            if AC.dropsWanted then
                AC_dropTick = AC_dropTick + 1
                if AC_dropTick >= AC_dropEvery then
                    AC_dropTick = 0
                    local drops = 0
                    local total = 0
                    local all = FindAllOf("Actor")
                    if all then
                        for _, a in pairs(all) do
                            if JXAlive(a) then
                                total = total + 1
                                local tok = ActorClassToken(a)
                                if tok:find("DroppedItem", 1, true) then drops = drops + 1 end
                            end
                        end
                    end
                    
                    AC_averageActors = total
                    if total > 20000 then AC_dropEvery = 40
                    elseif total > 8000 then AC_dropEvery = 20
                    elseif total > 3000 then AC_dropEvery = 10
                    else AC_dropEvery = DROP_SWEEP_MIN_TICKS end
                    AC_dropScale = AC_dropEvery
                    if AC.lastDrops >= 0 and drops - AC.lastDrops > 25 * AC_dropScale then
                        FSay("anticheat: dropped-item burst +" .. (drops - AC.lastDrops)
                            .. " in " .. (AC_dropScale * 2) .. "s (total " .. drops
                            .. ") - locate with: jfind DroppedItem")
                    end
                    AC.lastDrops = drops
                end
            end

            local states = UEHelpers.GetAllPlayerStates()
            for i = 1, #states do
                local PS = states[i]
                if PS and PS:IsValid() then
                    local isLocal = false
                    pcall(function()
                        local PC = UEHelpers.GetPlayerController()
                        if PC and PC:IsValid() and PS == PC.PlayerState then isLocal = true end
                    end)
                    if not isLocal then
                        local pawn = nil
                        pcall(function()
                            local own = PS.Owner
                            if own and own:IsValid() and own.Pawn and own.Pawn:IsValid() then
                                pawn = own.Pawn
                            end
                        end)
                        if JXAlive(pawn) then
                            local key = tostring(PlayerName(PS))
                            local mode
                            pcall(function() mode = pawn.CharacterMovement.MovementMode end)
                            if mode == 5 then AC.fly[key] = (AC.fly[key] or 0) + 1
                            else AC.fly[key] = nil end
                            local mag = 0
                            pcall(function()
                                local v = pawn:GetVelocity()
                                mag = math.sqrt(v.X * v.X + v.Y * v.Y + v.Z * v.Z)
                            end)
                            if mag > 3000 then AC.spd[key] = (AC.spd[key] or 0) + 1
                            else AC.spd[key] = nil end
                            if (AC.fly[key] or 0) >= 2 then
                                local pc
                                pcall(function() pc = pawn:GetController() or PS.Owner end)
                                if JXAlive(pc) and JXKickToMenu(pc, "Removed by host: flying (anticheat)") then
                                    AC.kicks = AC.kicks + 1
                                    FSay("anticheat: KICKED '" .. key .. "' (MovementMode=MOVE_Flying; flying is host-only)")
                                    AC.fly[key] = nil
                                end
                            elseif (AC.spd[key] or 0) >= 3 then
                                FSay("anticheat: '" .. key .. "' sustained speed "
                                    .. string.format("%.0f", mag) .. " over 3 checks - flagged (not kicked; lag can fake speed)")
                            end
                        end
                    end
                end
            end
        end)
    end

    local function ArmWorker()
        if WorkerArmed then return end
        WorkerArmed = true
        
        LoopAsync(6000, function()
            
            ExecuteInGameThread(function() pcall(WorkerTick) end)
        end)
    end

    -- r56: globals - Core_Ams jxload re-arms the cube via Mark.actor, and the
    -- forward use at the jmark command plus markergo/clear read these as globals
    Mark = { actor = nil }

    function MarkPos()
        if JXAlive(Mark.actor) then
            local p = nil
            pcall(function() p = Mark.actor:K2_GetActorLocation() end)
            if p then return p end
        end
        Mark.actor = nil
        return nil
    end

    local function MarkSpawnHere(atAim)
        local px, py, pz, pyaw = 0, 0, 0, 0
        local src = "feet"
        local okPawn = false
        pcall(function()
            local PC = UEHelpers.GetPlayerController()
            if PC and PC:IsValid() and PC.Pawn and PC.Pawn:IsValid() then
                local l = PC.Pawn:K2_GetActorLocation()
                local r = PC.Pawn:K2_GetActorRotation()
                px, py, pz = l.X, l.Y, l.Z
                pyaw = r and r.Yaw or 0
                okPawn = true
            end
        end)
        if atAim then
            local v = ViewPoint(180, 0)
            if v then
                px, py, pz, pyaw, src = v.x, v.y, v.z, v.yaw or 0, "aim"
                okPawn = true
            end
        end
        if not okPawn then FSay("jmark: no player pawn yet"); return false end
        if src == "feet" then
            
            local halfH = 88
            pcall(function()
                local PC = UEHelpers.GetPlayerController()
                if PC and PC:IsValid() and PC.Pawn and PC.Pawn:IsValid() then
                    local cap = PC.Pawn.CapsuleComponent
                    if cap and cap:IsValid() then
                        local r = cap:GetScaledCapsuleHalfHeight()
                        if type(r) == "number" and r > 4 and r < 400 then halfH = r end
                    end
                end
            end)
            pz = pz - halfH + 45
        end
        local pos = { X = px, Y = py, Z = pz }
        local a = J3SpawnAt("/Script/Engine.StaticMeshActor", pos.X, pos.Y, pos.Z, pyaw,
            "/Engine/BasicShapes/Cube.Cube")
        if not JXAlive(a) then FSay("jmark: cube spawn failed"); return false end
        pcall(function() a:SetActorScale3D({ X = 0.8, Y = 0.8, Z = 0.8 }) end)
        
        pcall(function() a:SetActorEnableCollision(false) end)
        pcall(function()
            local smc = a.StaticMeshComponent
            local mid = smc:CreateDynamicMaterialInstance(0)
            if mid then
                local cyan = { R = 0.0, G = 1.0, B = 1.0, A = 0.45 }
                local hit = false
                pcall(function() mid:SetVectorParameterValue("Color", cyan); hit = true end)
                if not hit then
                    pcall(function() mid:SetVectorParameterValue("BaseColor", cyan); hit = true end)
                end
                local semi = false
                pcall(function() mid:SetScalarParameterValue("Opacity", 0.45); semi = true end)
                FSay("jmark: cyan tint " .. (hit and "applied" or "n/a")
                    .. ", opacity " .. (semi and "requested (opaque base material may ignore it)" or "n/a"))
            end
        end)
        Mark.actor = a
        FSay(string.format("jmark: cube live at (%.0f, %.0f, %.0f) mode=%s walk-through - jsp/jplace spawn AT the cube",
            pos.X, pos.Y, pos.Z, src))
        return true
    end

    JXRegCmd("jmark", function(FullCommand, Parameters, Ar)
        local sub = (Parameters and Parameters[1]) or "status"
        if sub == "on" or sub == "here" or sub == "aim" then
            if JXAlive(Mark.actor) and (sub == "here" or sub == "aim") then
                
                pcall(function() Mark.actor:DestroyActor() end)
                Mark.actor = nil
            end
            if JXAlive(Mark.actor) then FSay("jmark: cube already live (jmark here to move it to your feet)"); return end
            local atAim = (sub == "aim")
            ExecuteInGameThread(function() pcall(MarkSpawnHere, atAim) end)
            return
        end
        if sub == "off" then
            if JXAlive(Mark.actor) then pcall(function() Mark.actor:DestroyActor() end) end
            Mark.actor = nil
            FSay("jmark: cube removed - spawn positions return to player-front")
            return
        end
        local p = MarkPos()
        if p then
            FSay(string.format("jmark: cube live at (%.0f, %.0f, %.0f) (jmark here | off)", p.X, p.Y, p.Z))
        else
            FSay("jmark: no cube (jmark on to place one at your body center)")
        end
    end)

    JxR319Install = function()
        
        local Grid = { tiles = {}, n = 5, gap = 130 }
        local function GridClear()
            for _, t in ipairs(Grid.tiles) do
                if JXAlive(t) then pcall(function() t:DestroyActor() end) end
            end
            Grid.tiles = {}
        end
        local function HalfHeight(pawn)
            local h = 88
            pcall(function()
                local c = pawn.CapsuleComponent
                if c and c:IsValid() then
                    local r = c:GetScaledCapsuleHalfHeight()
                    if type(r) == "number" and r > 4 and r < 400 then h = r end
                end
            end)
            return h
        end
        local function Tint(a, r, g, b)
            pcall(function()
                local smc = a.StaticMeshComponent
                local mid = smc:CreateDynamicMaterialInstance(0)
                if mid then
                    local col = { R = r, G = g, B = b, A = 1.0 }
                    local hit = false
                    pcall(function() mid:SetVectorParameterValue("Color", col); hit = true end)
                    if not hit then
                        pcall(function() mid:SetVectorParameterValue("BaseColor", col) end)
                    end
                end
            end)
        end
        local function GridBuild()
            GridClear()
            local PC = nil
            pcall(function() PC = UEHelpers.GetPlayerController() end)
            if not (PC and PC:IsValid() and PC.Pawn and PC.Pawn:IsValid()) then
                FSay("jgrid: no player pawn yet")
                return false
            end
            local p = nil
            pcall(function() p = PC.Pawn:K2_GetActorLocation() end)
            if not p then FSay("jgrid: pawn has no location"); return false end
            local yaw = 0
            pcall(function()
                local rot = PC.Pawn:K2_GetActorRotation()
                if rot then yaw = rot.Yaw or 0 end
            end)
            local z = p.Z - HalfHeight(PC.Pawn) + 6
            local n, gap = Grid.n, Grid.gap
            local half = (n - 1) / 2
            local made = 0
            for i = 0, n - 1 do
                for j = 0, n - 1 do
                    local a = J3SpawnAt("/Script/Engine.StaticMeshActor",
                        p.X + (i - half) * gap, p.Y + (j - half) * gap, z, yaw,
                        "/Engine/BasicShapes/Cube.Cube")
                    if JXAlive(a) then
                        pcall(function() a:SetActorScale3D({ X = 1.1, Y = 1.1, Z = 0.06 }) end)
                        Tint(a, 0.0, 1.0, 1.0)
                        Grid.tiles[#Grid.tiles + 1] = a
                        made = made + 1
                    end
                end
            end
            local b = J3SpawnAt("/Script/Engine.StaticMeshActor", p.X, p.Y, z + 300, yaw,
                "/Engine/BasicShapes/Cube.Cube")
            if JXAlive(b) then
                pcall(function() b:SetActorScale3D({ X = 0.35, Y = 0.35, Z = 6.0 }) end)
                Tint(b, 1.0, 1.0, 0.0)
                Grid.tiles[#Grid.tiles + 1] = b
            end
            FSay(string.format("jgrid: %dx%d squares at your feet (%.0f, %.0f, %.0f) + yellow pillar above",
                n, n, p.X, p.Y, z))
            Log(string.format("jgrid: %d tile(s) live, feet z=%.1f, yaw=%.0f, gap=%d",
                made, z, yaw, gap))
            return made > 0
        end
        JXRegCmd("jgrid", function(FullCommand, Parameters, Ar)
            ExecuteInGameThread(function()
                local sub = tostring((Parameters and Parameters[1]) or "on"):lower()
                if sub == "off" then
                    GridClear(); FSay("jgrid: cleared"); return
                end
                local num = tonumber(sub)
                if num then
                    num = math.floor(num)
                    if num < 2 then num = 2 elseif num > 11 then num = 11 end
                    Grid.n = num
                    pcall(GridBuild)
                    return
                end
                if sub == "gap" then
                    local g = tonumber(Parameters and Parameters[2])
                    if g and g >= 40 and g <= 500 then Grid.gap = math.floor(g) end
                    FSay("jgrid: gap = " .. tostring(Grid.gap) .. " (each square is 110 units wide)")
                    return
                end
                if sub == "status" then
                    FSay(string.format("jgrid: %s, %d tile(s), n=%d gap=%d",
                        (#Grid.tiles > 0 and "live" or "off"), #Grid.tiles, Grid.n, Grid.gap))
                    return
                end
                pcall(GridBuild)
            end)
        end)
        
        JXRegCmd("jloc", function()
            ExecuteInGameThread(function() pcall(GridBuild) end)
        end)

        local function AcquireSub(namePart)
            local all = FindAllOf("WidgetSwitcher")
            if not all then return nil end
            for _, w in pairs(all) do
                if JXAlive(w) then
                    local s = ""
                    pcall(function() s = tostring(w:GetFullName()) end)
                    if s:find(namePart, 1, true) then return w end
                end
            end
            return nil
        end
        JXRegCmd("jsub", function(FullCommand, Parameters, Ar)
            ExecuteInGameThread(function()
                local arg = tostring((Parameters and Parameters[1]) or "list"):lower()
                local sw = AcquireSub("ActorSubSwitcher")
                if arg == "list" then
                    local n = 0
                    if sw then pcall(function() n = sw:GetNumWidgets() end) end
                    Log("jsub: ActorSubSwitcher " .. (sw and ("pages=" .. tostring(n)) or "not found (open the panel first)"))
                    if sw then
                        for i = 0, math.max(n, 1) - 1 do
                            local nm = "?"
                            pcall(function()
                                local c = sw:GetChildAt(i)
                                if c and c:IsValid() then nm = tostring(c:GetFullName()):match("([^%.]+)$") or "?" end
                            end)
                            Log(string.format("jsub:   [%d] %s", i, nm))
                        end
                    end
                    FSay("jsub: " .. (sw and (tostring(n) .. " actor sub-page(s); jsub 0|1|2 to switch") or "panels closed - press B first"))
                    return
                end
                if not sw then FSay("jsub: actor sub-switcher not found - open the panel (B) first"); return end
                local idx = tonumber(arg)
                if not idx then FSay("usage: jsub list | jsub 0|1|2"); return end
                local n = 1
                pcall(function() n = sw:GetNumWidgets() end)
                idx = math.floor(idx)
                if idx < 0 or idx >= n then FSay("jsub: page " .. idx .. " is out of range (0.." .. (n - 1) .. ")"); return end
                local ok = pcall(function() sw:SetActiveWidgetIndex(idx) end)
                FSay("jsub: actor sub-page " .. idx .. " " .. (ok and "shown" or "refused"))
            end)
        end)

        JX.TabRoute = JX.TabRoute or {}
        local function SedetRoute()
            if type(JXSedet) == "function" then
                JXSedet("sedet", {}, "sedet")
            else
                Log("jxtabs: JXSedet is not in scope on this build")
            end
        end
        local ACTIONS = {
            
            plus   = function()
                Log("PLUS page: keys 1-9 run  sprint | jump | glide | night | luma | scan | shield | clear | stealth")
                Log("PLUS extras: jplus list | jplus dummyguard on | jplus move up|down|left|right|reset | jboost2 plus")
            end,
            pro    = function()
                Log("PRO page: keys 1-9 run  matrix | slow | fast | god | radar | build | clone | freeze | purge")
                Log("PRO extras: jpro list | jpro ssaa | jpro net | jpro guard | jpro vault | jpro ultimate | jfog off | jload")
            end,
            sedet  = SedetRoute,
            jent   = function() Log("jxtabs: the entity-list page is filled by 'jent list'; 'jent list <n|text>' filters") end,
            jsmesh = function() Log("jxtabs: the static-mesh page is filled by 'jsmesh census' then 'jsmesh spawn <n>'") end,
            jmesh  = function() Log("jxtabs: the object page is filled by 'jmesh'; 'jmesh next' walks it") end,
        }
        JX.TabAction = JX.TabAction or ACTIONS
        
        JX.TabRoute[3] = JX.TabRoute[3] or "sedet"
        
        -- r43: the 854D2A38 pak reordered the switcher - 12=EntPageV184,
        -- 13=AiPageV46, 18=PlusPageV48, 19=ProPageV48. The route keys follow
        -- the LIVE page indices, not the rail button numbers.
        JX.TabRoute[12] = nil
        JX.TabRoute[13] = nil
        JX.TabRoute[18] = JX.TabRoute[18] or "plus"
        JX.TabRoute[19] = JX.TabRoute[19] or "pro"
        local function RunRoute(idx)
            local what = JX.TabRoute[idx]
            if what == nil then return false end
            local fn = type(what) == "function" and what or (JX.TabAction and JX.TabAction[what])
            if type(fn) ~= "function" then
                Log("jxtabs: page " .. tostring(idx) .. " is bound to '" .. tostring(what) .. "', which is not an action")
                return false
            end
            local ok, e = pcall(fn)
            if not ok then Log("jxtabs: action for page " .. tostring(idx) .. " raised: " .. tostring(e)) end
            return ok
        end
        JX.TabRunRoute = RunRoute
        JXRegCmd("jxtabs", function(FullCommand, Parameters, Ar)
            ExecuteInGameThread(function()
                local sub = tostring((Parameters and Parameters[1]) or "list"):lower()
                if sub == "bind" then
                    local idx = tonumber(Parameters and Parameters[2])
                    local what = tostring((Parameters and Parameters[3]) or "none"):lower()
                    if not idx then FSay("usage: jxtabs bind <index> sedet|jent|jsmesh|jmesh|none"); return end
                    idx = math.floor(idx)
                    if what == "none" or what == "off" then
                        JX.TabRoute[idx] = nil
                    elseif JX.TabAction[what] then
                        JX.TabRoute[idx] = what
                    else
                        FSay("jxtabs bind: unknown action '" .. what .. "' (sedet|jent|jsmesh|jmesh|none)")
                        return
                    end
                    FSay("jxtabs: page " .. idx .. " -> " .. what)
                    return
                end
                if sub == "run" then
                    local idx = CurrentTabIndex()
                    if RunRoute(idx) then
                        FSay("jxtabs: ran the action for page " .. tostring(idx))
                    else
                        FSay("jxtabs: nothing bound to page " .. tostring(idx) .. " (see jxtabs)")
                    end
                    return
                end
                local sw = AcquireTabSwitcher()
                local n = 0
                if sw then pcall(function() n = sw:GetNumWidgets() end) end
                local live = CurrentTabIndex()
                Log(string.format("jxtabs: %s, pages=%d, showing=%d", sw and "switcher live" or "switcher not found (press B once)", n, live))
                for i = 0, math.max(n, 1) - 1 do
                    local nm = "?"
                    pcall(function()
                        local c = sw:GetChildAt(i)
                        if c and c:IsValid() then nm = tostring(c:GetFullName()):match("([^%.]+)$") or "?" end
                    end)
                    Log(string.format("jxtabs:   [%d] %s%s", i, nm, JX.TabRoute[i] and ("  <- " .. tostring(JX.TabRoute[i])) or ""))
                end
                FSay(string.format("jxtabs: pages=%d showing=%d; 'jxtabs run' runs this page's action", n, live))
            end)
        end)
    end
    pcall(JxR319Install)

    local OrigJ3Spawn = JxActor.spawn
    JxActor.spawn = function(cls, x, y, z, yaw)
        local p = MarkPos()
        if p then return OrigJ3Spawn(cls, p.X, p.Y, p.Z, yaw) end
        return OrigJ3Spawn(cls, x, y, z, yaw)
    end

    JXRegCmd("jxacl", function(FullCommand, Parameters, Ar)
        local sub = (Parameters and Parameters[1]) or "list"
        local classes, why = AclClasses()
        if not classes then FSay("jxacl: " .. tostring(why)); return end
        if sub == "list" then
            for i, s in ipairs(classes) do Log(string.format("  [%d] %s", i, s)) end
            pcall(function()
                local f = io.open(AclLog, "w")
                if f then
                    for _, s in ipairs(classes) do f:write(s .. "\n") end
                    f:close()
                end
            end)
            FSay("ACL.sav holds " .. #classes .. " actor class path(s) (also written to logs/jx_acl.txt)")
            return
        end
        if sub == "spawn" then
            local which = tonumber(Parameters[2])
            ExecuteInGameThread(function()
                local done, failed = 0, 0
                for i, s in ipairs(classes) do
                    if which == nil or which == i then
                        local a
                        pcall(function()
                            local PC = UEHelpers.GetPlayerController()
                            if PC and PC:IsValid() and PC.Pawn and PC.Pawn:IsValid() then
                                local p = PC.Pawn:K2_GetActorLocation()
                                a = J3SpawnAt(s, p.X + 200, p.Y + (i % 9) * 120 - 480, p.Z, 0, nil)
                            end
                        end)
                        if JXAlive(a) then done = done + 1 else failed = failed + 1 end
                    end
                end
                FSay(string.format("jxacl spawn: %d created, %d failed (of %d class(es))",
                    done, failed, which and 1 or #classes))
            end)
            return
        end
        FSay("usage: jxacl list | spawn [n]")
    end)

    JXRegCmd("jxams", function(FullCommand, Parameters, Ar)
        local sub = (Parameters and Parameters[1]) or "info"
        local key, disp, mpath = MapIdentity()

        if sub == "info" or sub == "list" then
            FSay("this level's save key: " .. key .. "  (" .. disp .. ")")
            Log("jxams info: key=" .. key .. " name=" .. disp .. " path=" .. mpath)
            Slot.P_ListMaps()
            return
        end

        if sub == "snap" then
            local n = SnapshotMap()
            FSay(string.format("snapshot: %d static mesh actor(s) on %s (this is the baseline jxams save records)",
                n, disp))
            return
        end

        if sub == "save" then
            ExecuteInGameThread(function() RunGuarded("jxams save", Slot.P_SaveMap, Parameters and Parameters[2]) end)
            return
        end

        if sub == "load" then
            ExecuteInGameThread(function() RunGuarded("jxams load", Slot.P_LoadMap, Parameters and Parameters[2]) end)
            return
        end

        if sub == "peek" then
            local p = Slot.P_PeekMap(Parameters and Parameters[2])
            if not p then FSay("jxams peek: nothing matches that (jslots)"); return end
            FSay(string.format("%s: %d row(s), saved %s", p.name, p.rows, tostring(p.stamp or "-")))
            return
        end

        if sub == "export" then
            local b = ReadAllBytes(JxamsPath(key))
            if not b then FSay("jxams export: no save for " .. disp .. " yet (jxams save first)"); return end
            EnsureDir(ExpDir)
            local out = ExpDir .. "JXAMS-" .. SafeName(key) .. ".sav"
            if not WriteAllBytes(out, b) then FSay("jxams export: cannot write " .. out); return end
            FSay("exported " .. disp .. " -> " .. out)
            return
        end

        if sub == "import" then
            local nm = Parameters[2]
            if not nm then FSay("usage: jxams import <file name or path>"); return end
            local cands = { nm, ExpDir .. nm, ExpDir .. "JXAMS-" .. SafeName(nm) .. ".sav" }
            for _, c in ipairs(cands) do
                local b = ReadAllBytes(c)
                if b then
                    EnsureDir(SavesDir)
                    if not b:find(FStr("JXMap"), 1, true) then
                        FSay("jxams import: " .. c .. " is not a JXAMS file"); return
                    end
                    pcall(function()
                        local old = ReadAllBytes(JxamsPath(key))
                        if old then WriteAllBytes(JxamsPath(key) .. ".prev", old) end
                    end)
                    if not WriteAllBytes(JxamsPath(key), b) then
                        FSay("jxams import: cannot write " .. JxamsPath(key)); return
                    end
                    FSay("imported " .. c .. " as the save for " .. disp .. " (key " .. key .. ") - jload to restore")
                    return
                end
            end
            FSay("jxams import: not found: " .. nm)
            return
        end

        FSay("usage: jxams info | snap | save | load [key] | peek <key> | export | import <f>   (see also jsave / jload / jslots / jxdata)")
    end)

    JXRegCmd("jfind", function(FullCommand, Parameters, Ar)
        local pat = (Parameters and Parameters[1]) or ""
        if pat == "" then FSay("usage: jfind <name substring>"); return end
        ExecuteInGameThread(function()
            local hits, total = {}, 0
            pcall(function()
                local all = FindAllOf("Actor")
                if not all then return end
                local low = pat:lower()
                for _, a in pairs(all) do
                    if JXAlive(a) then
                        total = total + 1
                        local nm = ""
                        local tok = ActorClassToken(a)
                        pcall(function() nm = JXName(a) end)
                        if (tok ~= "" and tok:lower():find(low, 1, true))
                            or (nm ~= "" and nm:lower():find(low, 1, true)) then
                            hits[#hits + 1] = tok .. "  '" .. nm .. "'"
                        end
                    end
                end
            end)
            for i = 1, math.min(#hits, 40) do Log("  " .. hits[i]) end
            pcall(function()
                local f = io.open(ModDir .. "logs/actor_search.txt", "w")
                if f then
                    f:write("map=" .. tostring(CurrentMapName()) .. " find=" .. pat
                        .. " live_actors=" .. total .. "\n")
                    for _, s in ipairs(hits) do f:write(s .. "\n") end
                    f:close()
                end
            end)
            FSay(string.format("jfind '%s': %d hit(s) of %d live actor(s) (logs/actor_search.txt)",
                pat, #hits, total))
        end)
    end)

    JXRegCmd("jmodoff", function(FullCommand, Parameters, Ar)
        local nm = Parameters and Parameters[1]
        if not nm or nm == "" then
            local n = 0
            for _ in pairs(SoftOff) do n = n + 1 end
            if n == 0 then FSay("usage: jmodoff <mod-token>  (nothing soft-off right now)"); return end
            for k in pairs(SoftOff) do Log("  off: " .. k) end
            FSay(n .. " mod(s) soft-off (jmodon <token> re-allows)")
            return
        end
        SoftOff[nm:lower()] = true
        local killed = KillByToken(nm)
        FSay(string.format("'%s' soft-off: %d live actor(s) destroyed; the 2s worker keeps it dead", nm, killed))
    end)

    JXRegCmd("jmodon", function(FullCommand, Parameters, Ar)
        local nm = Parameters and Parameters[1]
        if not nm or nm == "" then FSay("usage: jmodon <mod-token>"); return end
        SoftOff[nm:lower()] = nil
        FSay("'" .. nm .. "' re-allowed (a map switch or the replay brings it back)")
    end)

    JXRegCmd("jantic", function(FullCommand, Parameters, Ar)
        local sub = (Parameters and Parameters[1]) or "status"
        if sub == "on" then
            AC.on = true
            AC.dropsWanted = true
            pcall(ArmWorker)
            FSay("anticheat watch ON (fly=kick after 2 checks, speed=flag after 3, item burst=report; host exempt)")
            Log("anticheat: drops sweep armed (adaptive interval, see WorkerTick note)")
            return
        end
        if sub == "off" then AC.on = false; FSay("anticheat watch OFF"); return end
        
        if sub == "drops" then
            local v = (Parameters and Parameters[2]) or "on"
            if v == "off" then
                AC.dropsWanted = false
                FSay("anticheat: dropped-item sweep OFF (fly/speed checks unaffected)")
            else
                AC.dropsWanted = true
                pcall(ArmWorker)
                FSay("anticheat: dropped-item sweep ON (adaptive: every "
                    .. (AC_dropEvery * 2) .. "s at last measured "
                    .. AC_averageActors .. " actors)")
            end
            return
        end
        local nf, ns = 0, 0
        for _ in pairs(AC.fly) do nf = nf + 1 end
        for _ in pairs(AC.spd) do ns = ns + 1 end
        Log(string.format("anticheat: on=%s kicks=%d tracked-fly=%d tracked-speed=%d",
            tostring(AC.on), AC.kicks, nf, ns))
        FSay(string.format("anticheat: drops=%s every=%ds actors=%d kicks=%d",
            tostring(AC.dropsWanted), AC_dropEvery * 2, AC_averageActors, AC.kicks))
        FSay("usage: jantic on | off | status | drops on|off")
    end)

    pcall(ArmWorker)

    local Ent = { list = {}, n = 0 }
    do
        local f = io.open(ModDir .. "config/spawn_catalog.txt", "r")
        if f then
            for line in f:lines() do
                line = line:gsub("^\239\187\191", "")
                local kind, rest = line:match("^%[(%w+)%]%s*(.+)$")
                if kind == "entity" and rest then
                    local name, path = rest:match("^(.-)%s*=%s*(%S+)%s*$")
                    if name and path then
                        Ent.n = Ent.n + 1
                        Ent.list[Ent.n] = { name = name, path = path }
                    end
                end
            end
            f:close()
        end
    end

    local function ResolveCatalogClass(path)
        if path:sub(1, 8) == "/Script/" then return path end
        local leaf = path:match("([%w_%-]+)$")
        return path .. "." .. leaf .. "_C"
    end

    local function SpawnAtMarkOrMe(cls)
        local a = nil
        pcall(function()
            JX = JX or {}
            local mode = JX.spawnAt or "feet"
            local pos = (mode == "cube") and MarkPos() or nil
            if not pos then
                local PC = UEHelpers.GetPlayerController()
                if PC and PC:IsValid() and PC.Pawn and PC.Pawn:IsValid() then
                    local base = PC.Pawn:K2_GetActorLocation()
                    
                    local off = (mode == "front") and 150 or 0
                    local lift = (mode == "front") and 0 or 60
                    pos = { X = base.X + off, Y = base.Y, Z = base.Z + lift }
                end
            end
            if pos then a = J3SpawnAt(cls, pos.X, pos.Y, pos.Z, 0, nil) end
        end)
        return a
    end

    local function EntFind(key)
        local n = tonumber(key)
        if n and Ent.list[n] then return Ent.list[n], n end
        local low = tostring(key):lower()
        for i, e in ipairs(Ent.list) do
            if e.name:lower():find(low, 1, true) then return e, i end
        end
        return nil, nil
    end

    JXRegCmd("jent", function(FullCommand, Parameters, Ar)
        local sub = (Parameters and Parameters[1]) or "list"
        if sub == "list" then
            for i, e in ipairs(Ent.list) do
                Log(string.format("  [%d] %s = %s", i, e.name, e.path))
            end
            FSay("entity catalog: " .. Ent.n .. " entries (jent <n> or jent <name part>)")
            pcall(function()
                local f = io.open(ModDir .. "logs/entity_list.txt", "w")
                if f then
                    for i, e in ipairs(Ent.list) do
                        f:write(string.format("[%d] %s = %s\n", i, e.name, e.path))
                    end
                    f:close()
                end
            end)
            return
        end
        local e, idx = EntFind(sub)
        if not e then FSay("jent: no entity matches '" .. sub .. "' (jent list)"); return end
        local cls = ResolveCatalogClass(e.path)
        ExecuteInGameThread(function()
            local a = SpawnAtMarkOrMe(cls)
            FSay(string.format("jent [%d] %s -> %s", idx, e.name,
                JXAlive(a) and ("spawned" .. (MarkPos() and " at the cube" or "")) or "spawn FAILED"))
        end)
    end)

    local MeshList = { rows = {}, n = 0 }

    local function MeshIdx(key)
        local n = tonumber(key)
        if n and MeshList.rows[n] then return MeshList.rows[n], n end
        local low = tostring(key):lower()
        for i, r in ipairs(MeshList.rows) do
            if r.path:lower():find(low, 1, true) then return r, i end
        end
        return nil, nil
    end

    JXRegCmd("jsmesh", function(FullCommand, Parameters, Ar)
        local sub = (Parameters and Parameters[1]) or "census"
        if sub == "census" then
            ExecuteInGameThread(function()
                local meshes, actors = {}, 0
                pcall(function()
                    local all = FindAllOf("StaticMeshActor")
                    if not all then return end
                    for _, a in pairs(all) do
                        if JXAlive(a) then
                            actors = actors + 1
                            pcall(function()
                                local sc = a.StaticMeshComponent
                                if sc and sc.StaticMesh then
                                    local fn = PathOnly(sc.StaticMesh:GetFullName())
                                    meshes[fn] = (meshes[fn] or 0) + 1
                                end
                            end)
                        end
                    end
                end)
                MeshList.rows, MeshList.n = {}, 0
                for m in pairs(meshes) do
                    MeshList.n = MeshList.n + 1
                    MeshList.rows[MeshList.n] = { path = m, count = meshes[m] }
                end
                table.sort(MeshList.rows, function(x, y) return x.path < y.path end)
                for i = 1, math.min(MeshList.n, 30) do
                    Log(string.format("  [%d] %s x%d", i, MeshList.rows[i].path, MeshList.rows[i].count))
                end
                pcall(function()
                    local f = io.open(ModDir .. "logs/static_meshes.txt", "w")
                    if f then
                        f:write("map=" .. tostring(CurrentMapName()) .. " actors=" .. actors
                            .. " unique=" .. MeshList.n .. "\n")
                        for i, r in ipairs(MeshList.rows) do
                            f:write(string.format("[%d] %s x%d\n", i, r.path, r.count))
                        end
                        f:close()
                    end
                end)
                FSay(string.format("mesh census: %d actor(s), %d unique asset(s) (jsmesh spawn <n|part>)",
                    actors, MeshList.n))
            end)
            return
        end
        if sub == "spawn" or sub == "next" then
            if MeshList.n == 0 then FSay("jsmesh: run jsmesh census first"); return end
            local key = sub == "next" and tostring((tonumber(Parameters[2]) or 0) + 1) or Parameters[2]
            local r, idx = MeshIdx(key or "1")
            if not r then FSay("jsmesh: no mesh matches '" .. tostring(key) .. "'"); return end
            ExecuteInGameThread(function()
                local a = SpawnAtMarkOrMe("/Script/Engine.StaticMeshActor")
                if JXAlive(a) then
                    pcall(function()
                        local mesh = J3LoadObject(r.path)
                        if mesh and mesh:IsValid() then
                            a.StaticMeshComponent:SetStaticMesh(mesh)
                        end
                    end)
                end
                FSay(string.format("jsmesh [%d] %s -> %s", idx, r.path,
                    JXAlive(a) and "placed" or "place FAILED"))
            end)
            return
        end
        FSay("usage: jsmesh census | spawn <n|part> | next")
    end)

    do

    local function SaveStamp()
        local t = os.date("*t")
        if not t then return "unknown time" end
        return string.format("%04d-%02d-%02d %02d:%02d:%02d",
            t.year, t.month, t.day, t.hour, t.min, t.sec)
    end

    local function CollectRows()
        local rows = {}
        for _, p in pairs(JxActor3.placed) do
            rows[#rows + 1] = { cls = p.cls or "/Script/Engine.StaticMeshActor",
                mesh = p.mesh or "", name = "placed", kind = 0,
                x = p.x or 0, y = p.y or 0, z = p.z or 0, yaw = p.yaw or 0 }
        end
        local placedN = #rows
        local live = {}
        pcall(function()
            local all = FindAllOf("StaticMeshActor")
            if all then
                for _, a in pairs(all) do
                    if JXAlive(a) then live[JXName(a)] = true end
                end
            end
        end)
        local gone = 0
        for _, r in ipairs(Snap.rows) do
            if not live[r.name] then gone = gone + 1 end
            rows[#rows + 1] = r
        end
        return rows, placedN, gone
    end

    local IndexFile = SavesDir .. "jxams_index.txt"

    local function IndexRead()
        local out = {}
        for _, line in ipairs(FileLines(IndexFile)) do
            local k, d, p = line:match("^(%S+)%s*|%s*([^|]-)%s*|%s*([^|]-)%s*|")
            if k then out[#out + 1] = { key = k, name = d, path = p, line = line } end
        end
        return out
    end

    local function ResolveMapKey(what)
        if not what or what == "" then return nil end
        local idx = IndexRead()
        local n = tonumber(what)
        if n and idx[n] then return idx[n] end
        local low = tostring(what):lower()
        for _, e in ipairs(idx) do
            if e.key:lower() == low or e.name:lower() == low then return e end
        end
        for _, e in ipairs(idx) do
            if e.key:lower():find(low, 1, true) or e.name:lower():find(low, 1, true) then return e end
        end
        return nil
    end

    local function RestoreRows(data)
        local live = {}
        pcall(function()
            local all = FindAllOf("StaticMeshActor")
            if all then
                for _, a in pairs(all) do
                    if JXAlive(a) then live[JXName(a)] = true end
                end
            end
        end)
        local made, failed, skipped = 0, 0, 0
        for _, r in ipairs(data.rows) do
            if r.kind == 1 and live[r.name] then
                skipped = skipped + 1
            else
                local a = nil
                pcall(function()
                    if r.cls and r.cls ~= "" then
                        a = J3SpawnAt(r.cls, r.x, r.y, r.z, r.yaw, (r.mesh ~= "" and r.mesh) or nil)
                    end
                end)
                if JXAlive(a) then made = made + 1 else failed = failed + 1 end
            end
        end
        return made, failed, skipped
    end

    local function ApplyMapFile(path, key, disp)
        local data, why = JxamsRead(path)
        if not data then
            Log("jload: " .. tostring(why))
            FSay("load failed: " .. tostring(why))
            return false
        end
        ExecuteInGameThread(function()
            local made, failed, skipped = RestoreRows(data)
            local p = data.player or {}
            local moved = false
            if p.x or p.y or p.z then moved = TeleportTo(p.x, p.y, p.z, p.yaw) end
            Slot.AutoDone[key] = true
            Log(string.format("jload %s: %d back, %d failed, %d baseline object(s) still standing; position %s; %d row(s); saved %s",
                tostring(disp or key), made, failed, skipped,
                moved and "restored" or (p.x and "restore FAILED" or "not recorded"),
                #data.rows, tostring(data.seen or "no stamp")))
            FSay(string.format("load %s: %d object(s) back, %d failed (%d rows)",
                tostring(disp or key), made, failed, #data.rows))
        end)
        return true
    end

    Slot.AutoDone = Slot.AutoDone or {}

    function Slot.P_SaveMap(note)
        local key, disp, mpath = MapIdentity()
        EnsureDir(SavesDir)
        if not Snap.map or Snap.map ~= key then SnapshotMap() end
        local rows, placedN, gone = CollectRows()
        local path = JxamsPath(key)
        
        local hadPrev = false
        pcall(function()
            local old = ReadAllBytes(path)
            if old then hadPrev = WriteAllBytes(path .. ".prev", old) end
        end)
        local player = nil
        pcall(function() player = Slot.PlayerXform() end)
        local stamp = SaveStamp()
        local ok = JxamsWrite(path, key, rows, player, stamp, mpath)
        if ok then
            pcall(function()
                local keep = {}
                for _, l in ipairs(FileLines(IndexFile)) do
                    if l:match("^%S+") ~= key then keep[#keep + 1] = l end
                end
                keep[#keep + 1] = string.format("%s | %s | %s | rows=%d placed=%d baseline=%d missing=%d | %s",
                    key, disp, mpath, #rows, placedN, #Snap.rows, gone, stamp)
                WriteAll(IndexFile, table.concat(keep, "\n") .. "\n")
            end)
        end
        Slot.AutoDone[key] = true
        if key:sub(1, 5) == "world" and mpath == "-" then
            Log("jsave: this world's map path is not readable, so the file is keyed '"
                .. key .. "' - loading it works inside THIS session only")
        end
        Log(string.format("jsave %s: %s (%s) -> %s  rows=%d (placed=%d baseline=%d missing=%d) player=%s backup=%s",
            ok and "ok" or "FAILED", tostring(note or disp), tostring(key), path,
            #rows, placedN, #Snap.rows, gone,
            player and "recorded" or "NOT recorded", hadPrev and "kept" or "none"))
        FSay(ok and string.format("saved %s: %d object(s) + %d baseline", disp, placedN, #Snap.rows)
            or ("save FAILED - cannot write " .. path))
        return ok
    end

    function Slot.P_LoadMap(which)
        local key, disp, mpath = MapIdentity()
        local useKey, useDisp, usePath = key, disp, JxamsPath(key)

        if which and which ~= "" and which ~= key then
            local e = ResolveMapKey(which)
            if not e then
                Log("jload: nothing matches '" .. tostring(which)
                    .. "' -- jslots lists the saved maps, and it takes a key, a name or an index")
                FSay("jload: unknown map '" .. tostring(which) .. "'")
                return false
            end
            if e.key ~= key then
                if not e.path or e.path == "-" then
                    Log("jload: " .. e.key .. " has no readable map path on file - travel there yourself, then jload again")
                    FSay("jload: " .. e.name .. " has no travel path - go there first")
                    return false
                end
                if not ReadAllBytes(JxamsPath(e.key)) then
                    Log("jload: the index lists " .. e.key .. " but the file is gone (" .. JxamsPath(e.key) .. ")")
                    FSay("jload: " .. e.name .. "'s save file is missing")
                    return false
                end
                
                local ok, err = TravelTo(e.path)
                if not ok then
                    Log("jload: travel to " .. e.path .. " failed - " .. tostring(err))
                    FSay("jload: could not travel to " .. e.name)
                    return false
                end
                local tKey, tDisp, tPath = e.key, e.name, JxamsPath(e.key)
                JXAfterLoad("jload", "the save of " .. tDisp, function()
                    ApplyMapFile(tPath, tKey, tDisp)
                end)
                Log("jload: travelling to " .. e.path .. " (" .. tDisp .. "); its save is applied once the level is up")
                FSay("jload: travelling to " .. tDisp)
                return true
            end
            useKey, useDisp, usePath = e.key, e.name, JxamsPath(e.key)
        end

        if not ReadAllBytes(usePath) then
            Log("jload: no save for " .. useDisp .. " (" .. usePath .. ") -- jsave writes one, jslots lists them")
            FSay("jload: no save for " .. useDisp .. " yet")
            return false
        end
        Slot.AutoDone[useKey] = true
        return ApplyMapFile(usePath, useKey, useDisp)
    end

    function Slot.P_ListMaps()
        local idx = IndexRead()
        if #idx == 0 then
            Log("no map saves yet -- jsave files one for whatever map you stand on")
            return 0
        end
        local here = MapIdentity()
        for i, e in ipairs(idx) do
            Log(string.format("  [%d]%s %s", i, (e.key == here) and " *" or "  ", e.line))
        end
        Log(#idx .. " map save(s) in " .. SavesDir .. "  (* = the map you are on)")
        return #idx
    end

    function Slot.P_PeekMap(what)
        local e = ResolveMapKey(what)
        if not e then return nil end
        local data = JxamsRead(JxamsPath(e.key))
        if not data then return nil end
        return { key = e.key, name = e.name, path = e.path, rows = #data.rows,
                 stamp = data.seen, player = data.player }
    end

    function Slot.P_AutoRestore()
        local key, disp = MapIdentity()
        if Slot.AutoDone[key] then return end
        local path = JxamsPath(key)
        if not ReadAllBytes(path) then return end
        Slot.AutoDone[key] = true
        Log("auto-load: " .. disp .. " has its own save - restoring it (jautoload off stops this)")
        ApplyMapFile(path, key, disp)
    end

    local DataSections = { "binds", "actors", "meshes", "entities" }
    local function DataPath(section) return SavesDir .. "Jxdata-" .. section .. ".sav" end

    local function DataRows(section)
        local rows = {}
        if section == "binds" then
            for _, e in ipairs(JXBinds.order) do
                rows[#rows + 1] = { cls = tostring(e.label or e.id), mesh = tostring(e.key or ""),
                    name = tostring(e.id), kind = 10, x = #(e.mods or {}), y = 0, z = 0, yaw = 0 }
            end
        elseif section == "actors" then
            local seen = {}
            pcall(function()
                local all = FindAllOf("Actor")
                if not all then return end
                for _, a in pairs(all) do
                    if JXAlive(a) then
                        local tok = ActorClassToken(a)
                        if tok ~= "" and not seen[tok] then
                            seen[tok] = true
                            rows[#rows + 1] = { cls = tok, mesh = "", name = "actor", kind = 20,
                                x = 0, y = 0, z = 0, yaw = 0 }
                        end
                    end
                end
            end)
            table.sort(rows, function(p, q) return p.cls < q.cls end)
        elseif section == "meshes" then
            for i, r in ipairs(MeshList.rows) do
                rows[i] = { cls = "/Script/Engine.StaticMeshActor", mesh = tostring(r.path),
                    name = "mesh", kind = 21, x = tonumber(r.count) or 0, y = 0, z = 0, yaw = 0 }
            end
        elseif section == "entities" then
            for i, e in ipairs(Ent.list) do
                rows[i] = { cls = tostring(e.path), mesh = "", name = tostring(e.name), kind = 22,
                    x = 0, y = 0, z = 0, yaw = 0 }
            end
        end
        return rows
    end

    local function SaveData(section)
        EnsureDir(SavesDir)
        local rows = DataRows(section)
        local ok = JxamsWrite(DataPath(section), "Jxdata/" .. section, rows, nil, SaveStamp(), "-")
        Log(string.format("jxdata save %s: %s, %d row(s) -> %s",
            section, tostring(ok), #rows, DataPath(section)))
        return ok, #rows
    end

    local function LoadData(section)
        local data, why = JxamsRead(DataPath(section))
        if not data then
            Log("jxdata load " .. section .. ": " .. tostring(why))
            return false
        end
        if section == "binds" then
            local fns = JxBindActionFns()
            local applied, failed = 0, 0
            for _, r in ipairs(data.rows) do
                local e = JXBinds.byId[r.name]
                if e then
                    e.key = r.mesh
                    local n = tonumber(r.x) or 0
                    if n > 0 and #(e.mods or {}) ~= n then
                        Log("jxdata load binds: " .. tostring(r.name)
                            .. " was saved with " .. n .. " modifier(s); this build has "
                            .. #(e.mods or {}) .. " - re-applying without them")
                    end
                    local ok, kn = JxBindApply(e, fns[r.name])
                    if ok then applied = applied + 1
                    else failed = failed + 1; Log("jxdata load binds: " .. tostring(r.name) .. " - " .. tostring(kn)) end
                end
            end
            Log(string.format("jxdata load binds: %d re-applied, %d failed (%d row(s) on file)",
                applied, failed, #data.rows))
            return true
        end
        if section == "meshes" then
            MeshList.rows, MeshList.n = {}, 0
            for _, r in ipairs(data.rows) do
                MeshList.n = MeshList.n + 1
                MeshList.rows[MeshList.n] = { path = r.mesh, count = tonumber(r.x) or 0 }
            end
            Log("jxdata load meshes: roster refilled with " .. MeshList.n
                .. " asset(s) - jsmesh spawn <n> works without a new census")
            return true
        end
        if section == "entities" then
            Ent.list, Ent.n = {}, 0
            for _, r in ipairs(data.rows) do
                Ent.n = Ent.n + 1
                Ent.list[Ent.n] = { name = r.name, path = r.cls }
            end
            Log("jxdata load entities: catalog refilled with " .. Ent.n .. " entr(ies)")
            return true
        end
        Log(string.format("jxdata load %s: %d row(s) read (saved %s) - a census is a record of what was live, there is nothing to install from it",
            section, #data.rows, tostring(data.seen or "-")))
        return true
    end

    function Slot.P_DataCmd(parameters)
        local args = tostring(parameters or "")
        local sub, rest = args:match("^(%S+)%s*(.*)$")
        sub = sub or "list"
        rest = rest or ""

        if sub == "list" or sub == "status" then
            local key, disp = MapIdentity()
            Log("Jxdata store: " .. SavesDir .. "  (GLOBAL - not a map slot)")
            for _, s in ipairs(DataSections) do
                local b = ReadAllBytes(DataPath(s))
                Log(string.format("  %-9s %s", s, b and (tostring(#b) .. " bytes") or "not written yet"))
            end
            Log("map saves are separate: jslots lists them, jsave/jload use them. This map's key is '" .. key .. "' (" .. disp .. ")")
            if sub == "status" then
                for _, e in ipairs(JXBinds.order) do
                    local mt = JxBindModsText(e.mods)
                    Log(string.format("  bind %-8s %-16s %s%s", tostring(e.id), tostring(e.key or "?"),
                        tostring(e.label or ""), (mt ~= "") and (" [" .. mt .. "]") or ""))
                end
                Log(#JXBinds.order .. " hotkey(s) owned by this script (another mod's keys are not visible to Lua, so they are not listed)")
            end
            return true
        end

        if sub == "save" then
            local one = (rest ~= "" and rest ~= "all") and rest or nil
            local n, c = 0, 0
            for _, s in ipairs(one and { one } or DataSections) do
                local ok, rows = SaveData(s)
                c = c + 1
                if ok then n = n + (rows or 0) end
            end
            Log("jxdata save: " .. n .. " row(s) across " .. c .. " section(s) - map saves are untouched by this")
            return true
        end

        if sub == "load" then
            local one = (rest ~= "" and rest ~= "all") and rest or nil
            for _, s in ipairs(one and { one } or DataSections) do LoadData(s) end
            return true
        end

        if sub == "show" then
            local sec, n = rest:match("^(%S+)%s*(%d*)$")
            if not sec then
                Log("usage: jxdata show <binds|actors|meshes|entities> [n]")
                return false
            end
            local rows = DataRows(sec)
            if #rows == 0 then Log("jxdata show " .. sec .. ": nothing live to show (or unknown section)"); return false end
            local limit = math.min(tonumber(n) or 40, #rows)
            for i = 1, limit do
                local r = rows[i]
                Log(string.format("  [%d] %s = %s", i, tostring(r.name), tostring(r.cls ~= "" and r.cls or r.mesh)))
            end
            Log("jxdata show " .. sec .. ": " .. #rows .. " row(s), " .. limit .. " shown")
            return true
        end

        if sub == "del" then
            if rest == "" then Log("usage: jxdata del <section>"); return false end
            local gone = os.remove(DataPath(rest))
            Log("jxdata del " .. rest .. ": " .. (gone and "removed " or "nothing to remove at ") .. DataPath(rest))
            return true
        end

        if sub == "maps" then
            Slot.P_ListMaps()
            return true
        end

        if sub == "bind" then
            local id, key = rest:match("^(%S+)%s*(%S*)$")
            if not id or key == "" then
                Log("usage: jxdata bind <id> <key name>      ids: fly / panel / escape / tabprev / tabnext / tabback")
                Log("  e.g. jxdata bind fly F7   (applies live and is stored in Jxdata-binds; jxdata load binds re-applies it)")
                return false
            end
            local e = JXBinds.byId[id]
            if not e then
                Log("jxdata bind: '" .. tostring(id) .. "' is not a hotkey this script owns - 'jxdata status' lists them")
                return false
            end
            local k, kn = FindKey({ key })
            if not k then
                Log("jxdata bind: this build's Key table has no '" .. tostring(key) .. "'")
                return false
            end
            e.key = kn
            local okSave = pcall(SaveData, "binds")
            local ok, msg = JxBindApply(e, JxBindActionFns()[id])
            Log("jxdata bind " .. tostring(id) .. " = " .. tostring(kn) .. ": "
                .. (ok and "live now" or ("re-applying FAILED - " .. tostring(msg)))
                .. ", " .. (okSave and "stored in Jxdata-binds.sav" or "NOT stored (write failed)"))
            return ok
        end

        Log("usage: jxdata list|status | save [section] | load [section] | show <section> [n] | del <section> | bind <id> <key> | maps")
        Log("  sections: binds (hotkeys) / actors (live class census) / meshes (static mesh roster) / entities (catalog)")
        Log("  this is the GLOBAL store; map saves live in jslots/jsave/jload")
        return false
    end

    end   

    FSay("owner pack ready: jsave/jload/jslots (JXAMS, one file per map) / jxdata list|status|save|load|show|del|bind|maps / jxams info|snap|save|load|peek|export|import / jxacl / jfind / jsmesh census|spawn|next / jent list|spawn / jmodoff|jmodon / jantic on|off / jmark")
    end   
          
    pcall(JXOwnerPackR314)
end

Log("JinxingLoaderRT v1.3.1 (r3.16) loaded. JXAMS = one save file PER MAP (jsave/jload/jslots, jautoload on|off); Jxdata = the GLOBAL data store (jxdata); actor placement/link live; map order matches the panel; JXactor.sav autosave off by default (jactor autosave on).")
Log("  Map saves r3.16: jsave [note] (this map), jload [key|name|n], jslots, jautoload on|off, jxdata list|status|save|load|show|del|bind|maps, jorder (run order), jactor protect (real K2 block).")
Log("  Console: sedet/jgrid/jloc/jsub/jxtabs/jmods/jtab/jactor/jbanlist/jchat/jword/jname/jbench/jlist/jfly/jmax/jcap/jban/jpardon/jreload/jmaps/jtravel/jperf/jboost/jguard.")
Log("  Wiring: jwiring prints the live object graph + which console tokens actually registered.")
Log("  engine boost level: " .. BoostLevel .. "  (change with: jboost off|balanced|max)")
Log("  Perf: jboost off|balanced|max, jguard (guard/caches/pump), jperf.")

;

BootStep("chat+wordfilter", function()
    local ChatIniFile  = ModDir .. "config/jinxing.ini"
    local WordListDir  = ModDir .. "config/"
    local WordListFile = ModDir .. "config/banned_words.txt"
    local WordOffFile  = ModDir .. "config/banned_off.txt"
    local ChatLogFile  = ModDir .. "logs/chat_records.txt"
    local GameIniLeaf  = "Saved\\Config\\WindowsNoEditor\\Engine.ini"
    local GameIniLeaf2 = "Saved/Config/WindowsNoEditor/Engine.ini"

    local C = {
        booted  = false,
        mode    = "censor",   
        applied = true,       
        names   = false,      
        mirror  = true,       
        chatOn  = false,
        
        wordOn  = true,
        words   = {},         
        strict  = {},         
        userWords = {},       
        nGame   = 0,
        nUser   = 0,
        nShort  = 0,
        nBuiltin = 0,
        hits    = 0,
        seen    = {},
        seenN   = 0,
        last    = {},         
        tickOn  = false,
        tickN   = 0,
        srcNote = "",
        iniNote = "",
        
        kick    = true,
        kickN   = 0,
        kickLast = {},
        chatProp = nil,       
        chatKey  = nil,       
        chatProbeN = nil,     
        chatSeen = {},
        chatSeenN = 0,
        apiNote = "",
    }

    function JxStr(v)
        if v == nil then return "" end
        if type(v) == "string" then return v end
        local ok, s = pcall(function() return v:ToString() end)
        if ok and type(s) == "string" then return s end
        return ""
    end

    local function ErrMsg(e)
        return (tostring(e):gsub('^%[string "[^"]*"%]:%d+:%s*', ""))
    end
    
    local function FileExists(path)
        local f = io.open(path, "r")
        if f then f:close() return true end
        return false
    end

    local function ReadIni(path)
        local f = io.open(path, "r")
        if not f then return nil end
        local out, sec = {}, ""
        for line in f:lines() do
            local t = line:gsub("^%s+", ""):gsub("%s+$", "")
            if t ~= "" and t:sub(1, 1) ~= ";" and t:sub(1, 1) ~= "#" then
                local s = t:match("^%[([^%]]+)%]$")
                if s then
                    sec = s:lower():gsub("[%s_%-]", "")
                else
                    local k, v = t:match("^([%w%._%-]+)%s*=%s*(.-)%s*$")
                    if k then out[sec .. "." .. k:lower()] = v end
                end
            end
        end
        f:close()
        return out
    end

    local function IniGet(kv, prefixes, key)
        if not kv then return nil, nil end
        for _, p in ipairs(prefixes) do
            local v = kv[p .. key]
            if v ~= nil and v ~= "" then return v, p .. key end
        end
        return nil, nil
    end

    local PFX_W = { "wordfilter.", "jinxingloader.wordfilter.", "jinxing.wordfilter.", "words." }
    local PFX_C = { "chat.", "jinxingloader.chat.", "jinxing.chat." }

    local function Truthy(v, dflt)
        if v == nil then return dflt end
        v = tostring(v):lower()
        if v == "on" or v == "1" or v == "true" or v == "yes" then return true end
        if v == "off" or v == "0" or v == "false" or v == "no" then return false end
        return dflt
    end

    local function WriteDefaultIni()
        WriteAll(ChatIniFile,
            "; JinxingLoader chat + word filter. Read at boot and by 'jword reload'.\n"
            .. "; The same keys work in the game's own Engine.ini under\n"
            .. "; [JinxingLoader.WordFilter] and [JinxingLoader.Chat].\n"
            .. "\n[Chat]\n"
            .. "; enabled = on lets the mod drive the game's chat box (jchat)\n"
            .. "enabled = on\n"
            .. "; mirror = on copies incoming chat lines into logs/chat_records.txt\n"
            .. "mirror = on\n"
            .. "\n[WordFilter]\n"
            .. "; enabled = on is the same as typing jword once\n"
            .. "; r3.82: this template used to ship 'off', which contradicted the\n"
            .. "; code's own default (wordOn = true, 2026-09-12: a filter that ships\n"
            .. "; switched off is a filter nobody has) and silently disabled every\n"
            .. "; word the owner added. The ini wins over the default, so the two\n"
            .. "; had to agree; the boot line now prints which file decided it.\n"
            .. "enabled = on\n"
            .. "; mode = censor replaces the word with *, mode = block empties the line\n"
            .. "mode = censor\n"
            .. "; apply_chat filters typed and incoming text, apply_names filters nicks\n"
            .. "apply_chat = on\n"
            .. "apply_names = off\n"
            .. "; kick = on removes a non-host player as soon as a banned word is found\n"
            .. "; on them (nickname, or a chat line once a readable source is found)\n"
            .. "kick = on\n"
            .. "; list = a second word file, one word per line, beside this file\n"
            .. "list = banned_words.txt\n"
            .. "; extra = more words, comma separated\n"
            .. "extra = \n")
    end

    local function AddWord(w, from)
        w = tostring(w):lower()
        w = w:gsub("^%s+", ""):gsub("%s+$", "")
        if w == "" or C.words[w] then return false end
        
        local mode = "s"
        if #w <= 4 and w:find("^[%w_]+$") then mode = "b" end
        C.words[w] = mode
        C.nAll = (C.nAll or 0) + 1
        if mode == "b" then C.nShort = C.nShort + 1 end
        if from == "game" then
            C.nGame = C.nGame + 1
        else
            C.userWords[w] = mode
            if from == "file" then C.fileWords[w] = mode end
            
            if from == "file" or from == "extra" then C.nUser = C.nUser + 1 end
        end
        
        if from ~= "game" then C.strict[w] = mode end
        return true
    end

    local BAD_CN = {
        "e588b6e8a381,e6adbbe4baba,e9b8a1e590a7,e9b8a1e88aad,e9b8a138,e6938de4bda0e59097,e88d89e4bda0e59097,e88d89e4bda0",   
        "e582bbe980bc,e7859ee7ac94,e6b299e6af94,e582bbe689b9,e582bb42,e69292e6af94,e7859ee980bc",   
        "e6938de4bda0e5a688,e88d89e6b3a5e9a9ac,e69bb9e5b0bce78e9b,e889b9e4bda0e5a688,e889b9e5b0bce78e9b,e6938de4bda0e5a898,e88d89e6b3a5e9a6ac,e6a7bde4bda0e5a688",   
        "e7959ce7949f,e7959ce789b2",   
        "e5a688e79a84,e9a9ace79a84,e59097e79a84",   
        "e5b0bce78e9b,e6b3a5e9a9ac,e4bda0e5a688,e5b0bce9a6ac",   
        "e58da7e6a7bd,e68891e6938d,e68891e88d89,e68fa1e88d89,e58da7e88d89,e68891e889b9,e6b283e6a7bd,e58da743",   
        "e8b4b1e4baba,e8b4b1e8b4a7,e8b4b1e5a9a2",   
        "e5a98ae5ad90,e8a1a8e5ad90,e5a98a",   
        "e78b97e4b89ce8a5bf,e78b97e69d82e7a78d,e78b97e697a5e79a84,e78b97e5a898e585bbe79a84,e5ba9fe78b97,e88894e78b97",   
        "e69d82e7a78d,e5b08fe69d82e7a78d",   
        "e697a5e4bda0,e697a5e4bda0e5a688,e5b9b2e4bda0e5a898,e5b9b2e4bda0e5a688",   
        "e5a688e58d96e689b9,e9a9ace58d96e689b9,e5a688e79a84e689b9,e5a688e689b9",   
        "e58ebbe4bda0e5a688e79a84,e58ebbe6adbbe590a7,e4bda0e58ebbe6adbb,e6bb9ae4bda0e5a688",   
        "e6adbbe585a8e5aeb6,e6adbbe5a688,e4bda0e5a688e6adbbe4ba86,e4bda0e585a8e5aeb6",   
        "e88491e6ae8b,e88491e798ab,e5bcb1e699ba,e699bae99a9c",   
        "e9b8a1e5b7b4,e587a0e68a8a,e9b8a1e585ab,e5b18ce4bda0,e58fbce4bda0",   
        "e4ba8ce980bc,e4ba8c42,e8a385e980bc,e8a38542",   
        "e9aa9ae8b4a7,e9aa9ae980bc,e78382e8b4a7,e78382e980bc",   
        "e6938de4bda0e7a596e5ae97,e6938de4bda0e585a8e5aeb6",   
        "e78e8be585abe89b8b,e9be9fe584bfe5ad90,e4babae6b8a3",   
        "e582bbe58db5,e582bbe5908a,e6adbbe980bc,e980bce6a0b7,e980bce884b8",   
        "e4bb96e5a688,e4bb96e5a688e79a84,e4bda0e4bb96e5a688,e789b9e5a688e79a84,e5a194e78e9be79a84",   
        "e5a688e79a84e4b8aae980bc,e5a688e4ba86e4b8aae980bc,e9a9ace58b92e68888e5a381",   
        "e88d89e4bda0,e889b9e4bda0",   
        "e5a98ae5ad90e585bbe79a84,e78b97e69d82e7a28e",   
        "e582bbe78b97,e582bbe58f89,e582bbe7bcba,e582bbe58692,e582bbe89b8b,e582bbe5b18c",   
        "e8b4b1e980bc,e78b97e980bc,e980bce5b4bde5ad90,e980bce8b4a7",   
        "e5b181e79cbc,e78b97e5b181,e694bee5b181,e5b181e8af9d,e78b97e5b18e",   
        "e4bda0e5a4a7e788b7,e4bb96e5a4a7e788b7,e4bda0e5a898,e5a898e79a84,e4bda0e5a5b6e5a5b6,e4bda0e7a596e5ae97",   
        "e5bc84e6adbbe4bda0,e68993e6adbbe4bda0,e5b9b2e6adbbe4bda0,e5bc84e4bda0e5a688,e5b9b2e4bda0",   
        "e59e83e59cbe,e5ba9fe789a9,e8a0a2e8b4a7,e8a0a2e78caa,e8a0a2e9a9b4,e799bde797b4,e8b4a5e7b1bb,e78382e4baba",   
        "e796afe78b97,e78b97e5b4bde5ad90,e9be9fe5ad99e5ad90,e78e8be585ab",   
        "e4bda0e5a688e980bc,e5a688e980bc,e582bbe980bce78ea9e6848f,e980bce78ea9e6848f,e582bbe980bce4b89ce8a5bf",   
        "e6bb9ae89b8b,e6bb9ae5bc80,e6bb9ae78a8ae5ad90,e7bb99e68891e6bb9a,e6bb9ae8bf9ce782b9",   
        "e58ebbe6adbb,e8afa5e6adbb,e689bee6adbb,e6adbbe58ebbe590a7",   
        "e6938de4bda0,e697a5e4bda0e58588e4baba,e697a5e4bda0e7a596e5ae97,e6938de4bda0e5a4a7e788b7",   
        "e6adbbe4b89ce8a5bf,e6adbbe5a688e4b89ce8a5bf,e5b08fe7959ce7949f,e88081e7959ce7949f,e7959ce7949fe4b89ce8a5bf",   
        "e5b0bce78e9be79a84,e4bda0e5a688e79a84,e5a688e79a84e4b8aa42,e4bda0e5a688e4ba86e4b8aae980bc",   
        "e9babbe8bea3e99a94e5a381,e9a9ace58b92e99a94e5a381,e9babbe58b92e68888e5a381,e9a9ace68b89e99a94e5a381",   
        "e585a8e5aeb6e6adbbe58589,e6adbbe4b880e688b7e58fa3e69cac,e6adbbe58589e58589",   
        "e8828fe4bda0,e8828fe4bda0e5a688,e5b9b2e6adbbe4bda0e5a688,e6938de6adbbe4bda0",   
        "e7959ce7949fe585bbe79a84,e78b97e980bce585bbe79a84,e8b4b1e7a78d,e69d82e7a78de4b89ce8a5bf",   
    }
    local BAD_ASCII = {
        "cs,j8,jb,csb,sbq,nmslq",   
        "sb",   
        "shabi,sabi",   
        "caonima,cnm,cnmb,cao",   
        "nmsl,nimasile",   
        "tmd",   
        "rnm,rnmd,rinima",   
        "mmp,mamaipi",   
        "mlgb,malegebi",   
        "wcnm,wcnmd,wocaonima",   
        "mdzz",   
        "nmd,nmb,nimabi",   
        "qnmd,qunimade",   
        "jiba",   
        "fuck,fck,fuk",   
        "shit,sh1t",   
        "bitch,b1tch",   
        "asshole,a55hole",   
        "cunt,dick,pussy",   
        "nigger,n1gger,nigga",   
        "faggot,f4ggot",   
        "whore,slut,bastard",   
        "motherfucker,mofo",   
        "retard,retarded",   
        "s13,sha13,shab,shb",   
        "2b,213,erb",   
        "nc,nt,rz,zz",   
        "lj,fw,laji,feiwu,naocan,ruozhi,zhizhang",   
        "cnmlgb,wnmlgb,cnmlg,cnmdsb,cnmsb",   
        "wsnd,nmslwsnd,nmslwsndle",   
        "gundan,gunduzi,gunkai",   
        "nnd,nnnd",   
        "wanker,twat,bugger,prick,bollocks",   
        "kys,kms",   
        "sob,sonofabitch,jackass,dumbass",   
        "moron,idiot,imbecile,cretin",   
        "ribi,rigou,caoniquanjia,caonizu",   
        "sbb,sbbb,sbwanyi",   
    }

    local function JxHexDecode(hex)
        local out = {}
        for i = 1, #hex - 1, 2 do
            local b = tonumber(hex:sub(i, i + 1), 16)
            if b then out[#out + 1] = string.char(b) end
        end
        return table.concat(out)
    end

    local function LoadBuiltinWords()
        local n = 0
        local function expand(line, asciiMode)
            for tok in tostring(line):gmatch("[^,]+") do
                local w = asciiMode and tok or JxHexDecode(tok)
                if w ~= "" and AddWord(w, "builtin") then n = n + 1 end
            end
        end
        for _, line in ipairs(BAD_CN) do expand(line, false) end
        for _, line in ipairs(BAD_ASCII) do expand(line, true) end
        return n
    end

    local FW_MAP = {}
    do
        for i = 0, 9 do FW_MAP[string.char(0xEF, 0xBC, 0x90 + i)] = string.char(48 + i) end
        for i = 0, 25 do
            FW_MAP[string.char(0xEF, 0xBC, 0xA1 + i)] = string.char(65 + i)
            FW_MAP[string.char(0xEF, 0xBD, 0x81 + i)] = string.char(97 + i)
        end
        FW_MAP[string.char(0xE3, 0x80, 0x80)] = " "
    end

    local LEET_MAP = {
        ["0"] = "o", ["1"] = "i", ["3"] = "e", ["4"] = "a", ["5"] = "s",
        ["7"] = "t", ["8"] = "b", ["9"] = "g", ["@"] = "a", ["$"] = "s",
        ["!"] = "i", ["+"] = "t", ["|"] = "l",
    }

    local SEP_RE = "[%s%.%-_%*~%,/\\'\"%(%)%[%]{}<>%%=%^`?#&;:]"

    local function JxCollapse(s)
        local out, i, n = {}, 1, #s
        while i <= n do
            local b = s:byte(i)
            local len = 1
            if b >= 0xF0 then len = 4
            elseif b >= 0xE0 then len = 3
            elseif b >= 0xC0 then len = 2 end
            if i + len - 1 > n then len = 1 end
            local ch = s:sub(i, i + len - 1)
            local j, run = i + len, 1
            while j + len - 1 <= n and s:sub(j, j + len - 1) == ch do
                run = run + 1
                j = j + len
            end
            if run >= (len > 1 and 2 or 3) then
                out[#out + 1] = ch
            else
                out[#out + 1] = s:sub(i, j - 1)
            end
            i = j
        end
        return table.concat(out)
    end

    local function JxNorm(text)
        local s = tostring(text)
        for k, v in pairs(FW_MAP) do
            if s:find(k, 1, true) then s = s:gsub(k, v) end
        end
        s = s:lower()
        for k, v in pairs(LEET_MAP) do
            if s:find(k, 1, true) then s = s:gsub(k, v) end
        end
        s = s:gsub(SEP_RE, "")
        return JxCollapse(s)
    end

    local function JxDetect(text, set)
        set = set or C.strict
        local hits, what = 0, {}
        if text == nil or text == "" or next(set) == nil then return 0, what end
        local low = tostring(text):lower()
        local norm = JxNorm(low)
        local normDiffers = (norm ~= low)
        for w, mode in pairs(set) do
            local m = false
            if mode == "b" then
                local esc = w:gsub("%p", "%%%0")
                m = (low:find("%f[%w]" .. esc .. "%f[%W]") ~= nil)
                
                if not m and #w >= 4 then m = (low:find(w, 1, true) ~= nil) end
                if not m and normDiffers then
                    m = (norm:find("%f[%w]" .. esc .. "%f[%W]") ~= nil)
                    if not m and #w >= 4 then m = (norm:find(w, 1, true) ~= nil) end
                end
            else
                m = (low:find(w, 1, true) ~= nil)
                if not m and normDiffers then
                    m = (norm:find(w, 1, true) ~= nil)
                end
            end
            if m then
                hits = hits + 1
                if #what < 8 then what[#what + 1] = w end
            end
        end
        return hits, what
    end

    local function LoadGameWords()
        local keys, note = nil, "string table not found"
        pcall(function()
            local KSTL = J3LoadObject("/Script/Engine.Default__KismetStringTableLibrary")
            local ST   = J3LoadObject("/Game/Multiplayer/Chat/ProfanityFilterList.ProfanityFilterList")
            if not (ST and ST:IsValid()) then
                ST = J3LoadObject("ProfanityFilterList")
            end
            if not (KSTL and KSTL:IsValid()) then note = "KismetStringTableLibrary not found" return end
            if not (ST and ST:IsValid()) then note = "ProfanityFilterList asset not found" return end
            keys = KSTL:GetKeysFromStringTable(ST)
            note = "read " .. tostring(ST:GetFullName())
        end)
        local n = 0
        if type(keys) == "table" then
            for _, k in pairs(keys) do
                if AddWord(JxStr(k), "game") then n = n + 1 end
            end
            note = note .. " -> " .. n .. " keys"
        elseif keys ~= nil then
            note = note .. " (GetKeysFromStringTable returned " .. type(keys) .. ")"
        end
        C.srcNote = note
        return n
    end

    local function LoadUserWords(listFile)
        local n = 0
        for _, w in ipairs(FileLines(listFile)) do
            local head = w:sub(1, 1)
            if head ~= "[" and head ~= ";" and not w:find(" ", 1, true) then
                if AddWord(w, "file") then n = n + 1 end
            end
        end
        return n
    end

    local function LoadOffWords()
        if not FileExists(WordOffFile) then return 0 end
        local n = 0
        for _, w in ipairs(FileLines(WordOffFile)) do
            w = tostring(w):lower():gsub("^%s+", ""):gsub("%s+$", "")
            if w ~= "" and w:sub(1, 1) ~= ";" and w:sub(1, 1) ~= "[" then
                C.off[w] = true
                C.words[w], C.strict[w], C.userWords[w], C.fileWords[w] = nil, nil, nil, nil
                C.nAll = (C.nAll or 0) - 1
                n = n + 1
            end
        end
        return n
    end

    local function SaveOffWords()
        local ws = {}
        for w in pairs(C.off or {}) do ws[#ws + 1] = w end
        table.sort(ws)
        local out = "; Words switched off in the mod's built-in list - one per line.\n"
            .. "; Written by 'jword del' and cleared again by 'jword add'.\n"
        for _, w in ipairs(ws) do out = out .. w .. "\n" end
        WriteAll(WordOffFile, out)
        return #ws
    end

    local function JxMask(text, set)
        set = set or C.words
        if text == "" or next(set) == nil then return text, 0 end
        local low, hits = text:lower(), 0
        for w, mode in pairs(set) do
            local from = 1
            while true do
                local s, e
                if mode == "b" then
                    s, e = low:find("%f[%w]" .. w:gsub("%p", "%%%0") .. "%f[%W]", from)
                else
                    s, e = low:find(w, from, true)
                end
                if not s then break end
                local stars = string.rep("*", e - s + 1)
                text = text:sub(1, s - 1) .. stars .. text:sub(e + 1)
                low  = low:sub(1, s - 1) .. stars .. low:sub(e + 1)
                hits = hits + 1
                from = e + 1
            end
        end
        return text, hits
    end

    local function JxMaskLine(text)
        if not C.applied or not C.wordOn then return text, 0 end
        return JxMask(text)
    end
    
    _G.JXWordMaskLine = function(s)
        if not (C.applied and C.wordOn) then return tostring(s), 0 end
        return JxMaskLine(tostring(s))
    end
    _G.JXWordEnabled = function() return (C.applied and C.wordOn) end
    
    local function LocalPC()
        local pc = nil
        pcall(function() pc = UEHelpers.GetPlayerController() end)
        if JXAlive(pc) then return pc end
        return nil
    end

    local function ChatComp()
        local pc = LocalPC()
        if pc then
            for _, prop in ipairs({ "Chat_Component", "ChatComponent" }) do
                local c = nil
                pcall(function() c = pc[prop] end)
                if JXAlive(c) then return c end
            end
        end
        local hit = nil
        pcall(function()
            local all = FindAllOf("ChatComponent_C")
            if not all then return end
            local pcName = pc and JXName(pc) or ""
            for _, c in pairs(all) do
                if JXAlive(c) then
                    hit = hit or c
                    local owner = nil
                    pcall(function() owner = c:GetOwner() end)
                    if pcName ~= "" and JXAlive(owner) and JXName(owner) == pcName then
                        hit = c
                        break
                    end
                end
            end
        end)
        return hit
    end

    local function ChatWidget(comp)
        local w = nil
        if comp then
            for _, prop in ipairs({ "Chat_Widget", "ChatWidget", "WB_Chat", "Chat_Box" }) do
                pcall(function() w = comp[prop] end)
                if JXAlive(w) then return w end
            end
        end
        pcall(function()
            local all = FindAllOf("WB_Chat_C")
            if not all then return end
            for _, x in pairs(all) do
                if JXAlive(x) then w = x break end
            end
        end)
        return w
    end

    local function ChatInputBox(comp)
        local box = nil
        if comp then
            for _, prop in ipairs({ "ChatMessage_InputBox", "Chat_InputBox" }) do
                pcall(function() box = comp[prop] end)
                if JXAlive(box) then return box end
            end
        end
        local w = ChatWidget(comp)
        if w then
            for _, prop in ipairs({ "Chat_InputBox", "ChatMessage_InputBox" }) do
                pcall(function() box = w[prop] end)
                if JXAlive(box) then return box end
            end
        end
        return nil
    end

    local ChatCands = {
        "ChatComponent_C", "Chat_Component_C", "WB_Chat_C", "WB_ChatMessage_C",
        "ChatWidget_C", "Chat_Box_C", "ChatBox_C", "Chat_C",
    }

    local function PropTypeName(p)
        local full = ""
        pcall(function() full = tostring(p:GetFullName()) end)
        return (full:match("^(%a+)") or ""), full
    end

    local function PropList(obj)
        local out = {}
        if not JXAlive(obj) then return out end
        pcall(function()
            if not obj.ForEachProperty then return end
            obj:ForEachProperty(function(p)
                local cls, full = PropTypeName(p)
                local nm = full:match(":([^:]+)$") or full:match("([^/\\]+)$") or full
                local inner = ""
                if cls == "ArrayProperty" then
                    pcall(function()
                        local ip = p:GetInner()
                        inner = (PropTypeName(ip))
                    end)
                end
                out[#out + 1] = { name = nm, cls = cls, inner = inner }
            end)
        end)
        return out
    end

    local function ApiProbe()
        local lines = 0
        Log("chat api probe: enumerating properties of the live chat classes")
        for _, cls in ipairs(ChatCands) do
            local objs = nil
            pcall(function() objs = FindAllOf(cls) end)
            local n = 0
            if type(objs) == "table" then n = #objs end
            if n > 0 then
                local obj = objs[1]
                Log(string.format("chat api: class %s -> %d live object(s), sample %s", cls, n, JXName(obj)))
                local props = PropList(obj)
                for i, p in ipairs(props) do
                    if i > 40 then Log("chat api:   ... " .. (#props - 40) .. " more properties"); break end
                    Log(string.format("chat api:   prop %s : %s%s", p.name, p.cls,
                        p.inner ~= "" and ("<" .. p.inner .. ">") or ""))
                end
                if #props == 0 then Log("chat api:   no properties enumerated (ForEachProperty unavailable or empty)") end
                lines = lines + 1
            end
        end
        if lines == 0 then
            Log("chat api: none of the chat classes are live right now - open the chat in game, then run 'jchat api' again")
        end
        return true
    end

    local function ChatStoreObj()
        local c = ChatComp()
        if JXAlive(c) then return c end
        local w = ChatWidget(nil)
        if JXAlive(w) then return w end
        return nil
    end

    local function FindChatList(obj)
        local cands = PropList(obj)
        local best = nil
        for _, p in ipairs(cands) do
            local ln = p.name:lower()
            local looks = ln:find("chat", 1, true) or ln:find("messag", 1, true)
                or ln:find("msg", 1, true) or ln:find("log", 1, true)
                or ln:find("histor", 1, true)
            if looks and p.cls == "ArrayProperty" and p.inner == "StrProperty" then
                best = p.name
                break
            end
        end
        if best then
            Log("wordfilter: chat store found: " .. best .. " (array of FString) on " .. JXName(obj))
            C.chatProp = best
        else
            local kinds = {}
            for _, p in ipairs(cands) do
                local ln = p.name:lower()
                if ln:find("chat", 1, true) or ln:find("messag", 1, true) then
                    kinds[#kinds + 1] = p.name .. ":" .. p.cls .. (p.inner ~= "" and ("<" .. p.inner .. ">") or "")
                end
            end
            Log("wordfilter: no readable (array of FString) chat store on " .. JXName(obj)
                .. ( #kinds > 0 and ("; chat-ish properties: " .. table.concat(kinds, ", ")) or "; no chat-ish properties" ))
            C.chatProp = false                   
        end
        return best
    end

    local JX_COLON = ":\239\188\154"
    local function SenderOf(line)
        local body = tostring(line):gsub("^%s*%[[^%]]*%]%s*", "")
        local who = body:match("^([^" .. JX_COLON .. "]+)[" .. JX_COLON .. "]")
        if not who then return nil end
        who = who:gsub("^%s+", ""):gsub("%s+$", "")
        if who == "" then return nil end
        local pc = nil
        pcall(function()
            local all = FindAllOf("PlayerState")
            if not all then return end
            for _, ps in pairs(all) do
                if JXAlive(ps) and JxStr(ps.PlayerName) == who then
                    pc = PCOfState(ps)
                    return
                end
            end
        end)
        return pc, who
    end

    local function ChatStoreProp(obj)
        local key = JXName(obj)
        if key == "" then return nil end
        if C.chatProp ~= nil and C.chatKey == key then return C.chatProp end
        if C.tickN - (C.chatProbeN or -1000) < 25 then return nil end   
        C.chatProbeN = C.tickN
        C.chatKey = key
        return FindChatList(obj)
    end

    local function ChatCapture()
        local obj = ChatStoreObj()
        if not JXAlive(obj) then return 0 end
        local prop = ChatStoreProp(obj)
        if not prop then return 0 end
        local list = nil
        pcall(function() list = obj[prop] end)
        if type(list) ~= "table" then return 0 end
        local n = 0
        for _, line in ipairs(list) do
            local s = JxStr(line)
            if s ~= "" and not C.chatSeen[s] then
                C.chatSeen[s] = true
                C.chatSeenN = C.chatSeenN + 1
                if C.chatSeenN > 300 then
                    C.chatSeen, C.chatSeenN = {}, 0
                    C.chatSeen[s] = true
                    C.chatSeenN = 1
                end
                n = n + 1
                if C.mirror then AppendLine(ChatLogFile, "[" .. Now() .. "] " .. s) end
                if C.wordOn then
                    local hits, what = JxDetect(s, C.strict)
                    if hits > 0 then
                        C.hits = C.hits + hits
                        local pc, who = SenderOf(s)
                        local why = "banned word in chat (" .. table.concat(what, ",") .. ")"
                        AppendLine(JoinLogFile, string.format("%s  WORD-CHAT  %s  %s", Now(), tostring(who or "?"), why))
                        if C.kick and pc then
                            JXWordKick(pc, who, why)
                        elseif C.kick then
                            Log("wordfilter: " .. why .. " but the sender could not be identified; not kicked")
                        else
                            Log("wordfilter: " .. why .. " (kick is off)")
                        end
                    end
                end
            end
        end
        return n
    end

    _G.JXChatLines = function()
        local out = {}
        pcall(function()
            local obj = ChatStoreObj()
            if not JXAlive(obj) then return end
            local prop = ChatStoreProp(obj)
            if not prop then return end
            local list = nil
            pcall(function() list = obj[prop] end)
            if type(list) ~= "table" then return end
            for _, line in ipairs(list) do
                local s = JxStr(line)
                if s ~= "" then
                    local m = JxMaskLine(s)
                    out[#out + 1] = m
                end
            end
        end)
        return out
    end

    local function GuardInput()
        if not (C.applied and C.wordOn) then return 0 end
        if not C.ioNote then
            C.ioNote = true
            Log("wordfilter: input-box filtering is unavailable on this build (needs FText GetText + SetText; both end the process here)")
        end
        return 0
    end

    local function RecordLine(text)
        if not C.mirror then return end
        if C.seen[text] then return end
        C.seen[text] = true
        C.seenN = C.seenN + 1
        if C.seenN > 400 then
            C.seen, C.seenN = {}, 0
            C.seen[text] = true
            C.seenN = 1
        end
        AppendLine(ChatLogFile, "[" .. Now() .. "] " .. text)
    end

    local function ScanLines()
        if not C.scanNote then
            C.scanNote = true
            Log("wordfilter: on-screen chat censor/mirror is unavailable on this build (needs FText widget read + write)")
        end
        return 0
    end

    function PCOfState(ps)
        local found = nil
        pcall(function()
            local psFull = JXName(ps)
            if psFull == "" then return end
            local PCs = FindAllOf("PlayerController")
            if not PCs then return end
            for i = 1, #PCs do
                local pc = PCs[i]
                if JXAlive(pc) then
                    local st = nil
                    pcall(function() st = pc.PlayerState end)
                    if JXAlive(st) and JXName(st) == psFull then found = pc return end
                end
            end
        end)
        return found
    end

    function JXWordKick(pc, name, reason)
        if not C.kick then return false end
        
        if JXTransferGuard() then
            Log("wordfilter: '" .. tostring(name) .. "' flagged (" .. reason
                .. ") while the map is changing - not kicked, the window is closed")
            return false
        end
        if not JXAlive(pc) then return false end
        local isLocal = true
        pcall(function() isLocal = pc:IsLocalController() end)
        if isLocal then
            Log("wordfilter: '" .. tostring(name) .. "' is the local player (" .. reason .. "), not kicked")
            return false
        end
        C.kickN = C.kickN + 1
        C.kickLast[name or "?"] = Now()
        AppendLine(JoinLogFile, string.format("%s  WORD-KICK  %s  (%s)", Now(), tostring(name), reason))
        local ok = JXKickToMenu(pc, "Removed by host: " .. reason)
        Log(string.format("wordfilter: kicking '%s' (%s) -> %s", tostring(name), reason,
            ok and "removal issued" or "removal FAILED"))
        return ok
    end

    local function ScanNames()
        local hits = 0
        pcall(function()
            local all = FindAllOf("PlayerState")
            if not all then return end
            for _, ps in pairs(all) do
                if JXAlive(ps) then
                    local name = ""
                    pcall(function() name = JxStr(ps.PlayerName) end)
                    if name ~= "" then
                        
                        local n, what = JxDetect(name, C.strict)
                        local ad = false
                        for _, tok in ipairs(AD_WORDS) do
                            if name:find(tok, 1, true) then ad = true end
                        end
                        if n > 0 or ad then
                            hits = hits + 1
                            local why = ad and "banned advert in name"
                                or ("banned word in name (" .. table.concat(what, ",") .. ")")
                            AppendLine(JoinLogFile, string.format("%s  WORD-NAME  %s  %s", Now(), name, why))
                            if C.kick then
                                local pc = PCOfState(ps)
                                if pc then
                                    JXWordKick(pc, name, why)
                                else
                                    Log("wordfilter: flagged nick '" .. name .. "' but no controller owns it (kick with jkick <name>)")
                                end
                            else
                                Log("wordfilter: flagged nick '" .. name .. "' (kick is off; use jkick <name>)")
                            end
                        end
                    end
                end
            end
        end)
        return hits
    end

    local function Tick()
        if not (C.chatOn or C.wordOn) then C.tickOn = false return end
        C.tickN = C.tickN + 1
        
        if not (C.wordOn or C.mirror) then
            ExecuteWithDelay(1000, Tick)
            return
        end
        if not JXBusy() then
            ExecuteInGameThread(function()
                pcall(function()
                    if C.wordOn then GuardInput() end
                    
                    if C.wordOn or C.mirror then ChatCapture() end
                    if C.wordOn and (C.names or C.kick) and C.tickN % 25 == 0 then ScanNames() end
                end)
            end)
        end
        ExecuteWithDelay(1200, Tick)
    end

    local function TickStart()
        if C.tickOn then return end
        C.tickOn = true
        ExecuteWithDelay(1200, Tick)
    end

    local function GameIni()
        local cands = {
            "..\\..\\Saved\\Config\\WindowsNoEditor\\Engine.ini",
            "../../Saved/Config/WindowsNoEditor/Engine.ini",
            GameIniLeaf,
            GameIniLeaf2,
        }
        for _, p in ipairs(cands) do
            if FileExists(p) then return p end
        end
        return nil
    end

    local function ReadSettings()
        local kv  = ReadIni(ChatIniFile) or {}
        local gip = GameIni()
        local gkv = gip and ReadIni(gip) or {}
        local S = {
            ini = ChatIniFile, engine = gip, src = {},
            extra = "", list = "banned_words.txt",
        }
        local function Get(prefixes, key, label)
            local v = IniGet(gkv, prefixes, key)
            if v ~= nil then S.src[label or key] = "engine"; return v end
            v = IniGet(kv, prefixes, key)
            if v ~= nil then S.src[label or key] = "mod-ini"; return v end
            return nil
        end

        S.chatOn  = Truthy(Get(PFX_C, "enabled", "chat.enabled"), nil)
        S.mirror  = Truthy(Get(PFX_C, "mirror", "chat.mirror"), nil)
        S.wordOn  = Truthy(Get(PFX_W, "enabled", "word.enabled"), nil)
        S.applied = Truthy(Get(PFX_W, "apply_chat"), nil)
        S.names   = Truthy(Get(PFX_W, "apply_names"), nil)
        S.kick    = Truthy(Get(PFX_W, "kick", "word.kick"), nil)

        local mode = Get(PFX_W, "mode")
        if mode ~= nil then
            S.mode = (tostring(mode):lower() == "block") and "block" or "censor"
        end

        local extra = Get(PFX_W, "extra")
        if extra ~= nil then S.extra = extra end
        local list = Get(PFX_W, "list")
        if list ~= nil and list ~= "" then S.list = list end

        return S
    end

    local function ApplySettings()
        local S = ReadSettings()
        if S.chatOn  ~= nil then C.chatOn  = S.chatOn end
        if S.wordOn  ~= nil then C.wordOn  = S.wordOn end
        if S.applied ~= nil then C.applied = S.applied end
        if S.names   ~= nil then C.names   = S.names end
        if S.mirror  ~= nil then C.mirror  = S.mirror end
        if S.mode    ~= nil then C.mode    = S.mode end
        if S.kick    ~= nil then C.kick    = S.kick end
        
        JxSet.chat, JxSet.word = C.chatOn, C.wordOn
        C.settings = S
        return S
    end

    local function ReloadWords()
        local S = ReadSettings()
        C.words, C.userWords, C.fileWords, C.strict = {}, {}, {}, {}
        C.nGame, C.nUser, C.nShort, C.nAll = 0, 0, 0, 0
        C.off = {}

        LoadGameWords()
        C.nBuiltin = LoadBuiltinWords()
        local nFile = LoadUserWords(WordListDir .. S.list)
        if nFile == 0 and S.list ~= "banned_words.txt" then
            nFile = LoadUserWords(WordListFile)
        end
        local nExtra = 0
        for w in tostring(S.extra):gmatch("[^,]+") do
            if AddWord(w, "extra") then nExtra = nExtra + 1 end
        end
        local nOff = LoadOffWords()

        C.listNote = string.format("%s=%d, extra=%d, builtin=%d, off=%d",
            S.list, nFile, nExtra, C.nBuiltin or 0, nOff)
        return C.nAll
    end

    local function SaveWordFile()
        local ws = {}
        for w in pairs(C.fileWords) do ws[#ws + 1] = w end
        table.sort(ws)
        local out = "; JinxingLoader word filter list - one word per line.\n"
            .. "; ';' and '[' start a comment; edited by 'jword add' / 'jword del'.\n"
        for _, w in ipairs(ws) do out = out .. w .. "\n" end
        WriteAll(WordListFile, out)
        return #ws
    end

    local ChatFnUsed = {}

    local function HasFn(obj, name)
        if not JXAlive(obj) then return false end
        local f = nil
        pcall(function() f = obj[name] end)
        if f == nil then return false end
        local ok = pcall(function() return f.IsValid == nil or f:IsValid() end)
        return ok
    end

    local function TryFn(obj, names, tag, ...)
        if not JXAlive(obj) then return false, nil end
        local Args = { ... }
        for _, n in ipairs(names) do
            if HasFn(obj, n) then
                local ok = pcall(function() return obj[n](obj, table.unpack(Args)) end)
                if not ok then pcall(function() return obj[n](table.unpack(Args)) end) end
                ChatFnUsed[tag] = n
                Log("wordfilter: " .. tag .. " -> " .. n)
                return true, n
            end
        end
        return false, nil
    end

    local function ChatReport()
        local S = C.settings or {}
        local comp = ChatComp()
        local box  = ChatInputBox(comp)
        local wid  = ChatWidget(comp)
        local used = {}
        for k, v in pairs(ChatFnUsed) do used[#used + 1] = k .. "=" .. v end
        table.sort(used)
        local nStrict = 0
        for _ in pairs(C.strict) do nStrict = nStrict + 1 end
        local nOff = 0
        for _ in pairs(C.off or {}) do nOff = nOff + 1 end
        return table.concat({
            string.format("chat state: chat=%s words=%s mode=%s apply_chat=%s names=%s mirror=%s kick=%s",
                tostring(C.chatOn), tostring(C.wordOn), C.mode, tostring(C.applied),
                tostring(C.names), tostring(C.mirror), tostring(C.kick)),
            string.format("  words: %d total (%d from the game, %d from files, %d built-in, %d short/word-boundary) %s",
                C.nAll or 0, C.nGame, C.nUser, C.nBuiltin or 0, C.nShort, tostring(C.listNote)),
            string.format("  kickable set: %d word(s) (the game's own English list is excluded); switched off by hand: %d",
                nStrict, nOff),
            string.format("  game list: %s", tostring(C.srcNote)),
            string.format("  ini: %s (exists=%s)  engine.ini: %s", ChatIniFile, tostring(FileExists(ChatIniFile)), tostring(S.engine)),
            string.format("  hits so far: %d   kicks issued: %d   mirrored lines: %d   tick: %s/%d",
                C.hits, C.kickN or 0, C.seenN, tostring(C.tickOn), C.tickN),
            string.format("  chat store: %s", C.chatProp and tostring(C.chatProp)
                or (C.chatProp == false and "none readable found (see 'jchat api')" or "not looked for yet")),
            string.format("  chat probe: key=%s tick=%s (a resolved store is read every tick; an unresolved one is re-asked at most every 10s)",
                tostring(C.chatKey or "-"), tostring(C.chatProbeN or "-")),
            string.format("  chat component: %s", comp and JXName(comp) or "NOT FOUND"),
            string.format("  chat widget: %s", wid and JXName(wid) or "NOT FOUND"),
            string.format("  input box: %s", box and JXName(box) or "NOT FOUND"),
            string.format("  functions used: %s", #used > 0 and table.concat(used, ", ") or "(none yet)"),
        }, "\n")
    end

    local function ChatCommand(P)
        local sub = tostring(P[1] or ""):lower()

        if sub == "diag" or sub == "status" then
            Log("\n" .. ChatReport())
            return
        end
        if sub == "clear" then
            local comp = ChatComp()
            local ok = TryFn(comp, { "Clear_Chat", "ClearChat", "Clear" }, "chat.clear")
            if not ok then
                
                Log("jchat clear: the chat component has no Clear function, and blanking the line widgets is not possible on this build (SetText needs an FText)")
            end
            return
        end
        if sub == "focus" then
            local box = ChatInputBox(ChatComp())
            if not box then Log("jchat focus: no input box found"); return end
            local ok = TryFn(box, { "SetKeyboardFocus", "SetUserFocus", "SetFocus" }, "chat.focus")
            Log("jchat focus: " .. (ok and ("focused " .. JXName(box)) or "no focus function on the box"))
            return
        end
        if sub == "say" then
            local text = table.concat(P, " ", 2)
            if text == "" then Log("usage: jchat say <text>"); return end
            
            Log("jchat say: not possible on this build (writing the input box needs an FText); text was: " .. text)
            return
        end
        if sub == "log" then
            local lines = FileLines(ChatLogFile)
            local from = #lines - 11
            if from < 1 then from = 1 end
            Log("chat log (" .. #lines .. " line(s) in " .. ChatLogFile .. "):")
            for i = from, #lines do Log("  " .. lines[i]) end
            return
        end
        if sub == "hook" then
            
            local v = tostring(P[2] or ""):lower()
            if v == "on" or v == "off" then
                ChatHook.on = (v == "on")
            else
                ChatHook.on = not ChatHook.on
            end
            Log(string.format("chat firewall: %s (armed=%s, caught=%d, censored=%d, unreadable=%d)",
                ChatHook.on and "ON" or "OFF", tostring(ChatHook.armed),
                ChatHook.n, ChatHook.wrote, ChatHook.unread))
            if not ChatHook.armed then
                Log("  the hook is not armed on this build; 'jchat api' reports what the chat classes expose")
            end
            return
        end
        if sub == "on" or sub == "off" or sub == "" then
            if sub == "" then C.chatOn = not C.chatOn else C.chatOn = (sub == "on") end
            JxSet.chat = C.chatOn
            if C.chatOn then
                TickStart()
                local ok, n = TryFn(ChatComp(), { "ToggleChatBox", "Toggle_ChatBox", "ToggleChat" }, "chat.toggle")
                Log("chat box: ON" .. (ok and (" (" .. n .. ")") or " (no toggle function found on the component)"))
            else
                TryFn(ChatComp(), { "ToggleChatBox", "Toggle_ChatBox", "ToggleChat" }, "chat.toggle")
                Log("chat box: OFF")
            end
            return
        end
        if sub == "show" or sub == "hide" then
            
            local want = (sub == "show")
            local ok, msg = pcall(function()
                local GS = UEHelpers.GetGameplayStatics()
                if not (GS and GS:IsValid()) then error("no GameplayStatics") end
                
                local SlotName = "GameSettings_SaveSlot"
                local sv = GS:LoadGameFromSlot(SlotName, 0)
                if not (sv and sv:IsValid()) then
                    local sv2 = GS:LoadGameFromSlot(SlotName, -1)
                    if sv2 and sv2:IsValid() then sv = sv2 end
                end
                if not (sv and sv:IsValid()) then error("slot '" .. SlotName .. "' did not load") end
                local cur = sv.ShowChat
                if cur == nil then error("loaded slot has no ShowChat member; left untouched") end
                sv.ShowChat = want
                local saved = GS:SaveGameToSlot(sv, SlotName, 0)
                return "ShowChat was " .. tostring(cur) .. ", set to " .. tostring(want) .. ", save returned " .. tostring(saved)
            end)
            Log("jchat " .. sub .. ": " .. (ok and msg or ("not written - " .. ErrMsg(msg))))
            return
        end
        if sub == "api" then
            pcall(function() ApiProbe() end)
            return
        end
        if sub == "capture" then
            local n = ChatCapture()
            Log(string.format("jchat capture: %d new line(s) read from the store; mirrored %d line(s) so far",
                n, C.chatSeenN))
            if not C.chatProp then
                Log("jchat capture: no readable store was found - run 'jchat api' and check the log for what the chat classes actually carry")
            end
            return
        end
        Log("usage: jchat [on|off|hook on|off|focus|clear|show|hide|say <text>|log|diag|api|capture]")
    end

    local JxCases = {
        { "sb", true }, { "SB", true }, { "s b", true }, { "s.b", true }, { "sbb", true },
        { "sxyb", false },
        { "shabi", true }, { "caonima", true }, { "cao ni ma", true }, { "cnm", true },
        { "nmsl", true }, { "tmd", true },
        { "fuck", true }, { "f u c k", true }, { "f*ck", true }, { "fuckyou", true },
        { "sh1t", true }, { "b1tch", true }, { "asshole", true }, { "a55hole", true },
        { "2b", true }, { "213", true }, { "s13", true }, { "kys", true },
        { "Steve", false }, { "classic lesson", false }, { "grass", false },
        { "Casino Royale", false }, { "Nightingale", false },
        { "#e6938de4bda0e5a688", true },       
        { "#e88d89e6b3a5e9a9ac", true },       
        { "#e7959ce7949f", true },             
        { "#e582bbe980bc", true },             
        { "#e7859ee7ac94", true },             
        { "#e5a688e79a84", true },             
        { "#e58da7e6a7bd", true },             
        { "#e4bda0e4bb96e5a688", true },       
        { "#e78b97e4b89ce8a5bf", true },       
        { "#e6adbbe585a8e5aeb6", true },       
        { "#e4ba8ce980bc", true },             
        { "#e8b4b1e4baba", true },             
        { "#e88491e6ae8b", true },             
        { "#e59e83e59cbe", true },             
        { "#e6938d20e4bda020e5a688", true },   
        { "#e6938de6938de6938de4bda0e5a688", true },   
        { "#e582bbe980bce980bc", true },       
        { "#e4bda0e5a5bde5958a", false },      
        { "#e8b0a2e8b0a2", false },            
    }

    local function JxSelfTest()
        local ok, bad, misses, falseHits = 0, 0, {}, {}
        for _, c in ipairs(JxCases) do
            local text = c[1]
            if text:sub(1, 1) == "#" then text = JxHexDecode(text:sub(2)) end
            local n, what = JxDetect(text, C.strict)
            local got = (n > 0)
            if got == c[2] then
                ok = ok + 1
            else
                bad = bad + 1
                if c[2] then misses[#misses + 1] = text
                else falseHits[#falseHits + 1] = text end
            end
            if got and #what > 0 then
                Log(string.format("  %-6s %s  <- %s", c[2] and "hit" or "HIT?!", text, table.concat(what, ",")))
            else
                Log(string.format("  %-6s %s", got and "hit" or (c[2] and "MISS" or "clean"), text))
            end
        end
        Log(string.format("jword selftest: %d/%d as expected, %d wrong (%d missed, %d false)",
            ok, #JxCases, bad, #misses, #falseHits))
        for _, t in ipairs(misses) do Log("  missed    : " .. t) end
        for _, t in ipairs(falseHits) do Log("  false hit : " .. t) end
        Log(string.format("  list in play: %d word(s), %d of them kickable (%s); mode=%s kick=%s",
            C.nAll or 0, (function() local n = 0 for _ in pairs(C.strict) do n = n + 1 end return n end)(),
            tostring(C.listNote), C.mode, tostring(C.kick)))
        return bad == 0
    end

    local function WordCommand(P)
        local sub = tostring(P[1] or ""):lower()

        if sub == "diag" or sub == "status" then
            Log("\n" .. ChatReport())
            return
        end
        if sub == "test" then
            local text = table.concat(P, " ", 2)
            if text == "" then text = "you are an ass and an idiot, classy" end
            local masked, hits = JxMask(text)
            
            local out = masked
            if C.mode == "block" and hits > 0 then out = "(the line would be sent empty)" end
            
            local dn, dw = JxDetect(text, C.strict)
            
            local note = ""
            if hits == 0 and dn > 0 then
                note = "\n  note: the mask stars out a span of the raw text, and this spelling"
                    .. "\n  has none to star (a separator or a repeated letter splits the word)."
                    .. "\n  Masking follows the raw text on purpose; the kick above still fires."
            end
            Log(string.format("jword test: %d hit(s) [mode=%s]\n  in : %s\n  out: %s\n  normalised: %s\n  kick set: %d hit(s) %s%s",
                hits, C.mode, text, out, JxNorm(text), dn,
                dn > 0 and ("<- " .. table.concat(dw, ",")) or "(clean)", note))
            return
        end
        if sub == "selftest" or sub == "self" then
            JxSelfTest()
            return
        end
        if sub == "kick" then
            local v = tostring(P[2] or ""):lower()
            if v == "on" or v == "1" or v == "true" then C.kick = true
            elseif v == "off" or v == "0" or v == "false" then C.kick = false
            else C.kick = not C.kick end
            Log("host kick on a banned word: " .. (C.kick and "ON" or "OFF")
                .. string.format(" (%d kick(s) issued so far)", C.kickN or 0)
                .. "  [set word.kick in the ini to make it stick]")
            return
        end
        if sub == "list" then
            local ws = {}
            for w, mode in pairs(C.words) do ws[#ws + 1] = w .. (mode == "b" and " (b)" or "") end
            table.sort(ws)
            Log(string.format("word list: %d word(s) %s\n  game table: %s", #ws, tostring(C.listNote), tostring(C.srcNote)))
            local shown = 0
            for _, w in ipairs(ws) do
                if shown >= 40 then Log("  ... " .. (#ws - shown) .. " more"); break end
                shown = shown + 1
                Log("  " .. w)
            end
            return
        end
        if sub == "add" or sub == "del" then
            local w = P[2]
            if w == nil or w == "" then Log("usage: jword " .. sub .. " <word>"); return end
            w = tostring(w):lower()
            if sub == "add" then
                C.fileWords[w] = nil
                if not AddWord(w, "file") then
                    C.fileWords[w] = C.words[w] or "s"
                end
            else
                if not C.fileWords[w] then
                    Log("jword del: '" .. w .. "' is not in " .. WordListFile .. " (ini words are not editable here)")
                    return
                end
                C.fileWords[w] = nil
                C.words[w] = nil
            end
            local n = SaveWordFile()
            local total = ReloadWords()
            ApplySettings()
            Log(string.format("jword %s '%s': file now holds %d word(s), %d active in total", sub, w, n, total))
            return
        end
        if sub == "mode" then
            local m = tostring(P[2] or ""):lower()
            if m ~= "censor" and m ~= "block" then Log("usage: jword mode censor|block"); return end
            C.mode = m
            Log("wordfilter mode: " .. m .. " (censor masks the word, block empties the line)")
            return
        end
        if sub == "names" then
            local v = tostring(P[2] or ""):lower()
            C.names = (v == "on" or v == "1" or v == "true") and true or (v == "off" and false or not C.names)
            Log("nickname filtering: " .. (C.names and "ON" or "OFF"))
            return
        end
        if sub == "mirror" then
            local v = tostring(P[2] or ""):lower()
            C.mirror = (v == "on" or v == "1" or v == "true") and true or (v == "off" and false or not C.mirror)
            
            Log("chat mirror to " .. ChatLogFile .. ": "
                .. (C.mirror and "ON (unavailable on this build: needs an FText widget read)" or "OFF"))
            if C.mirror then RecordLine("(mirror requested " .. Now() .. " - not deliverable on this build)") end
            return
        end
        if sub == "reload" then
            local total = ReloadWords()
            local S = ApplySettings()
            
            local parts = {}
            for _, k in ipairs({ "chat.enabled", "chat.mirror", "word.enabled", "mode",
                                 "apply_chat", "apply_names" }) do
                parts[#parts + 1] = k .. "=" .. tostring(S.src[k] or "default")
            end
            S.src.extra = S.src.extra or "default"
            parts[#parts + 1] = "extra=" .. tostring(S.src.extra)
            Log(string.format("reloaded: %d word(s) %s; mode=%s apply_chat=%s names=%s",
                total, tostring(C.listNote), C.mode, tostring(C.applied), tostring(C.names)))
            Log("  where each key came from: " .. table.concat(parts, " "))
            Log("  mod ini " .. ChatIniFile .. "  engine ini " .. tostring(S.engine))
            Log("  game's own list: " .. tostring(C.srcNote))
            if C.chatOn or C.wordOn then TickStart() end
            return
        end
        if sub == "on" or sub == "off" or sub == "" then
            if sub == "" then C.wordOn = not C.wordOn else C.wordOn = (sub == "on") end
            JxSet.word = C.wordOn
            if C.wordOn then
                TickStart()
                if C.names then pcall(function() J3ScanBlocked(true) end) end  
            end
            Log("word filter: " .. (C.wordOn and "ON" or "OFF")
                .. string.format(" (mode=%s, %d word(s), apply_chat=%s, names=%s)",
                    C.mode, C.nAll or 0, tostring(C.applied), tostring(C.names)))
            return
        end
        Log("usage: jword [on|off|mode censor|block|list|add W|del W|reload|names on|off|kick on|off|mirror on|off|test [text]|selftest|diag]")
    end

    -- r56: global - the jchat "hook" handler above is defined before this
    -- line and read ChatHook as a nil global; arming/state was unreachable
    ChatHook = { armed = false, on = true, n = 0, unread = 0, wrote = 0, noted = false,
        feed = {}, feedN = 0 }

    local function JxChatFilter(s)
        if not C.wordOn then return nil end
        local masked, hits = JxMask(s, C.strict)
        if hits == 0 then return nil end
        if C.mode == "block" then return "", hits end
        return masked, hits
    end

    local function ArmChatFirewall()
        if ChatHook.armed then return true end
        local ok, ret = pcall(RegisterHook, "/Script/Engine.PlayerController:ClientMessage",
            function(self, S, Type, MsgLifeTime)
                
                local good, err = pcall(function()
                    if not ChatHook.on or not C.wordOn then return end
                    
                    local line = nil
                    if type(S) == "string" then
                        line = S
                    elseif S ~= nil then
                        local getter = nil
                        pcall(function() getter = S.get end)
                        if type(getter) == "function" then
                            pcall(function() line = S:get() end)
                        end
                    end
                    if type(line) ~= "string" or line == "" then
                        ChatHook.unread = ChatHook.unread + 1
                        if not ChatHook.noted then
                            ChatHook.noted = true
                            Log("chat firewall: the outgoing line is not readable from the hook on this build;"
                                .. " detection stays on the polled chat store (jchat api reports the shape)")
                        end
                        return
                    end
                    
                    local hudLine = JxMaskLine(line)
                    ChatHook.feedN = ChatHook.feedN + 1
                    ChatHook.feed[ChatHook.feedN] = hudLine
                    if ChatHook.feedN > 8 then ChatHook.feedN = 1 end
                    local out, hits = JxChatFilter(line)
                    if not out then return end
                    ChatHook.n = ChatHook.n + 1
                    local _, dw = JxDetect(line, C.strict)
                    AppendLine(JoinLogFile, string.format("%s  WORD-SEND  %s  (%d hit(s))",
                        Now(), tostring(line), hits))
                    local setter = nil
                    pcall(function() setter = S.set end)
                    if type(setter) == "function" then
                        pcall(function() S:set(out) end)
                        ChatHook.wrote = ChatHook.wrote + 1
                        Log(string.format("chat firewall: outgoing line censored (%d hit(s): %s)%s",
                            hits, table.concat(dw, ","),
                            C.mode == "block" and " - line sent empty (mode=block)" or ""))
                    else
                        Log("chat firewall: line caught (" .. table.concat(dw, ",")
                            .. ") but the parameter is read-only on this build; reported, not rewritten")
                    end
                end)
                if not good then Log("HOOK| ClientMessage guarded: " .. tostring(err)) end
            end)
        ChatHook.armed = ok and (ret ~= false)
        Log("chat firewall: /Script/Engine.PlayerController:ClientMessage "
            .. (ChatHook.armed and "armed (FString-only channel, no FText)" or
                ("NOT armed (" .. tostring(ok and ret or "threw") .. ")")))
        return ChatHook.armed
    end

    _G.JXChatLines = function()
        local out = {}
        for i = 1, 8 do
            local v = ChatHook.feed[i]
            if v then out[#out + 1] = v end
        end
        return out
    end

    if not FileExists(ChatIniFile) then
        WriteDefaultIni()
        Log("chat: wrote a default " .. ChatIniFile)
    end
    local nWords = ReloadWords()
    ApplySettings()
    if C.chatOn or C.wordOn then TickStart() end
    
    pcall(ArmChatFirewall)
    
    local S = C.settings or {}
    Log(string.format("chat/wordfilter ready: chat=%s[%s] word=%s[%s] (%d word(s): %s; game list: %s)",
        tostring(C.chatOn), tostring(S.src and S.src["chat.enabled"] or "default"),
        tostring(C.wordOn), tostring(S.src and S.src["word.enabled"] or "default"),
        nWords, tostring(C.listNote), tostring(C.srcNote)))
    if not C.wordOn then
        Log("wordfilter: THE GATE IS OFF, so no added word can take effect. decided by "
            .. tostring(S.src and S.src["word.enabled"] or "default")
            .. " -> 'jword on' for this session, or set [WordFilter] enabled = on in "
            .. tostring(ChatIniFile))
    end

    JXRegCmd("jchat", function(FullCommand, Parameters)
        local P = {}
        if type(Parameters) == "table" then for i, v in ipairs(Parameters) do P[i] = tostring(v) end end
        pcall(function() ChatCommand(P) end)
        return true
    end)

    JXRegCmd("jword", function(FullCommand, Parameters)
        local P = {}
        if type(Parameters) == "table" then for i, v in ipairs(Parameters) do P[i] = tostring(v) end end
        pcall(function() WordCommand(P) end)
        return true
    end)

function JXSedet(FullCommand, Parameters, Ar)
    ExecuteInGameThread(function()
        local L = {}
        local flagged = {}
        local function P(s)
            L[#L + 1] = s
            if type(s) == "string" and (s:find("MISSING", 1, true)
                or s:find("unreadable", 1, true) or s:find("STILL WRONG", 1, true)
                or s:find("pick=/Game", 1, true) or s:find("section absent", 1, true)
                or s:find("no plain mount", 1, true)) then
                flagged[#flagged + 1] = s
            end
        end
        P("== SEDET r3.18 ==")
        P("time: " .. tostring(os.date and os.date("%Y-%m-%d %H:%M:%S") or "?"))

        P("")
        P("-- 1. load channels (a pack with no channel never runs at all) --")
        local function probe(rel, label)
            local h = io.open(rel, "rb")
            if not h then
                P(string.format("  %-16s MISSING   %s", label, rel))
                return
            end
            local data = h:read(400) or ""
            h:close()
            local head = (data:gsub("%s+", " ")):sub(1, 90)
            P(string.format("  %-16s present   %s  head: %s", label, rel, head))
        end
        probe(ModDir .. "enabled.txt", "enabled.txt")
        probe(JXUe4ssMods .. "mods.txt", "mods.txt")
        probe("Mods/BPModLoaderMod/Scripts/loaded_mods.txt", "loaded_mods.txt")

        P("")
        P("-- 2. runtime pak discovery (LogicMods) --")
        local okScan, scanErr = pcall(JXRawPakScan)
        if not okScan then P("  scan FAILED: " .. tostring(scanErr)) end
        local rep = JX.pakScanReport or {}
        P("  listing: " .. tostring(rep.cleared) .. ", " .. tostring(rep.count) .. " pak(s)")
        for _, r in ipairs(rep) do
            if type(r) == "table" and r.name then
                P(string.format("  %-26s mount=%-32s assets=%-5s pick=%s", r.name,
                    tostring(r.mount), tostring(r.assets), tostring(r.pick)))
                if not r.pick then P("      why: " .. tostring(r.why)) end
            end
        end

        P("")
        P("-- 3. sliders: stored value vs the value the engine holds --")
        for i = 1, #PerfItems do
            local it = PerfItems[i]
            P(string.format("  [%d] %-14s = %-6s (%s..%s)", i, tostring(it.key),
                string.format("%g", it.cur or 0), string.format("%g", it.min or 0),
                string.format("%g", it.max or 0)))
            P("      " .. JXVerifyItem(i))
        end

        P("")
        P("-- 4. motion blur chain --")
        local want = PerfItems[PerfIdxFromKey("motion") or 0]
        if want then
            local lines = want.fan and want.fan[math.floor((want.cur or 0) + 0.5)] or {}
            P(string.format("  slider: cur=%g def=%s min=%s max=%s",
                want.cur or 0, tostring(want.def), tostring(want.min), tostring(want.max)))
            P("  fan sends: [" .. table.concat(lines, " | ") .. "] (empty = leaves the engine alone)")
        end
        for _, nm in ipairs({ "r.DefaultFeature.MotionBlur", "r.MotionBlurQuality",
                              "r.DefaultFeature.DepthOfField", "r.DepthOfFieldQuality",
                              "r.ScreenPercentage", "sg.PostProcessQuality" }) do
            local v = JXReadCVar(nm)
            P(string.format("  engine  %-30s = %s", nm,
                v ~= nil and string.format("%g", v) or "unreadable"))
        end
        
        local la = nil
        
        pcall(function()
            local s = os.getenv and os.getenv("LOCALAPPDATA") or nil
            if s and s ~= "" and not s:find("%%") then la = s end
        end)
        if not la then
            pcall(function()
                local ph = io.popen('echo %LOCALAPPDATA%')
                if ph then
                    local s = ph:read("*l")
                    ph:close()
                    if s and s ~= "" and not s:find("%%") then la = s end
                end
            end)
        end
        local dirs = {}
        if la then
            dirs[#dirs + 1] = la .. "\\EscapeTheBackrooms\\Saved\\Config\\WindowsNoEditor\\"
        end
        dirs[#dirs + 1] = "..\\..\\Saved\\Config\\WindowsNoEditor\\"
        dirs[#dirs + 1] = "..\\..\\EscapeTheBackrooms\\Saved\\Config\\WindowsNoEditor\\"
        for _, d in ipairs(dirs) do
            for _, fn in ipairs({ "Engine.ini", "GameUserSettings.ini" }) do
                local p = d .. fn
                local h = io.open(p, "rb")
                if not h then
                    P("  ini MISSING      " .. p)
                else
                    local data = h:read("*a") or ""
                    h:close()
                    P(string.format("  ini %s  %s  (%d bytes)", fn, p, #data))
                    for _, sec in ipairs({ "SystemSettings", "ScalabilityGroups" }) do
                        local s = data:find("[" .. sec .. "]", 1, true)
                        if s then
                            local e = data:find("\n[", s, true)
                            local chunk = e and data:sub(s, e - 1) or data:sub(s)
                            local hits = {}
                            for line in chunk:gmatch("[^\r\n]+") do
                                if line:find("MotionBlur", 1, true)
                                    or line:find("DepthOfField", 1, true)
                                    or line:find("ScreenPercentage", 1, true)
                                    or line:find("sg.", 1, true)
                                    or line:find("Scalability", 1, true) then
                                    hits[#hits + 1] = "      " .. line
                                end
                            end
                            P(string.format("    [%s] %d relevant line(s)", sec, #hits))
                            for _, hl in ipairs(hits) do P(hl) end
                        else
                            P(string.format("    [%s] section absent", sec))
                        end
                    end
                end
            end
        end

        P("")
        local dir = (ModDir .. "config"):gsub("/", "\\")
        pcall(function()
            os.execute('if not exist "' .. dir .. '" mkdir "' .. dir .. '" >nul 2>nul')
        end)
        local outPath = ModDir .. "config/sedet.txt"
        local h = io.open(outPath, "w")
        if h then
            h:write(table.concat(L, "\r\n"))
            h:write("\r\n")
            h:close()
            P("written to " .. outPath)
            Log("SEDET: " .. #L .. " line(s) written to " .. outPath)
        else
            Log("SEDET: could not write " .. outPath)
        end
        if #flagged == 0 then
            Log("SEDET: nothing flagged - see config/sedet.txt for the full reading")
        else
            Log("SEDET: " .. #flagged .. " line(s) worth a look:")
            for _, s in ipairs(flagged) do Log("SEDET| " .. s) end
        end
    end)
    return true
end
JXRegCmd("SEDET", JXSedet)

JXRegCmd("sedet", JXSedet)

function JXMemberPack()
    local function Say(s) Log("[MEMBER] " .. tostring(s)) end

    local function KSL()
        local k = nil
        pcall(function() k = StaticFindObject("/Script/Engine.Default__KismetSystemLibrary") end)
        return k
    end

    local function CVar(name, value)
        JXQueue({ name .. " " .. tostring(value) })
        Say(string.format("cvar %s = %s", name, tostring(value)))
    end

    local function ReadCVar(name)
        local out = nil
        local k = KSL()
        if JXAlive(k) then pcall(function() out = k:GetConsoleVariableFloatValue(name) end) end
        return out
    end

    local function Spot(dist, lift)
        local v = ViewPoint(dist or 160, lift or 0)
        if not v then return nil end
        return v
    end

    local function Cube(x, y, z, yaw, scale)
        local a = J3SpawnAt("/Script/Engine.StaticMeshActor", x, y, z, yaw or 0,
            "/Engine/BasicShapes/Cube.Cube")
        if JXAlive(a) and scale then
            pcall(function() a:SetActorScale3D({ X = scale, Y = scale, Z = scale }) end)
        end
        return a
    end

    local function Dash(distance, lift)
        local p = PlayerXform()
        if not p then Say("no pawn yet"); return end
        local ok = TeleportTo(p.x + math.sin(p.yaw or 0) * distance, p.y + math.cos(p.yaw or 0) * distance,
            p.z + (lift or 0), p.yaw)
        Say(string.format("displaced %.0f units (lift %.0f) -> %s", distance, lift or 0,
            ok and "moved" or "blocked"))
    end

    local function Census(what)
        ScanAllActors(true)
        Say(what .. ": full census written to the log/config; see the scanner output above")
    end

    local Actions = {}

    Actions["sprint"] = function() Dash(900, 0) end
    Actions["jump"] = function() Dash(120, 340) end
    Actions["glide"] = function()
        local p = PlayerXform()
        if not p then return end
        for i = 1, 4 do
            TeleportTo(p.x, p.y, p.z - i * 90, p.yaw)
        end
        Say("feather fall: descended 360 units in four steps")
    end
    Actions["night"] = function()
        CVar("r.EyeAdaptationQuality", 2)
        CVar("r.TonemapperGamma", 1.8)
        CVar("r.DefaultFeature.AutoExposure", 0)
        Say(string.format("night vision armed (gamma reads %s)", tostring(ReadCVar("r.TonemapperGamma"))))
    end
    Actions["luma"] = function()
        CVar("r.Tonemapper.Sharpen", 1.5)
        CVar("r.Tonemapper.Quality", 5)
        CVar("r.Color.Mid", 0.45)
        Say("luma pass armed")
    end
    Actions["scan"] = function() Census("sweep") end
    Actions["shield"] = function()
        CVar("s.AsyncLoadingUseFullTimeLimit", 0)
        CVar("gc.TimeBetweenPurgingPendingKillObjects", 60)
        CVar("r.Streaming.MaxTempMemoryAllowed", 96)
        JX.shieldOn = true
        Say("frame shield on (streaming + GC pacing rewritten)")
    end
    Actions["clear"] = function()
        CVar("r.ScreenPercentage", 100)
        CVar("r.Tonemapper.Sharpen", 1.0)
        JXQueue({ "obj gc" })
        if JXAlive(Mark and Mark.actor) then pcall(function() Mark.actor:DestroyActor() end); Mark.actor = nil end
        Say("screen reset to 100%, template cube removed, gc requested")
    end
    Actions["stealth"] = function()
        CVar("r.EyeAdaptationQuality", 0)
        CVar("r.TonemapperGamma", 0.85)
        CVar("r.MotionBlurQuality", 0)
        Say("stealth grade armed (low exposure, no motion blur)")
    end
    Actions["gift"] = function()
        local v = Spot(220, 0)
        if not v then Say("no pawn yet"); return end
        for i = -2, 2 do
            Cube(v.x + i * 130, v.y + i * 60, v.z, v.yaw, 0.6)
        end
        Say("gift line deployed: five cubes, one per PLUS tier")
    end

    Actions["matrix"] = function(parameters)
        LoadMaps()
        Say(string.format("travel matrix: %d level(s) staged", #MapList))
        local want = parameters and parameters[2]
        if want then
            local path = JXResolveMapArg(want, MapList)
            if path then
                TravelTo(path)
                Say("matrix jump -> " .. tostring(path))
            else
                Say("matrix: unknown level " .. tostring(want))
            end
        else
            Say("usage: jpro matrix <name|index>")
        end
    end
    Actions["slow"] = function() CVar("slomo", 0.5) end
    Actions["fast"] = function() CVar("slomo", 2) end
    Actions["god"] = function()
        
        local p = nil
        pcall(function() p = Slot.PlayerXform() end)
        if not p then Say("no pawn yet"); return end
        TeleportTo(p.x, p.y, p.z + 1500, p.yaw)
        Say("observer lift: 1500 units up (look down, then jplus glide to come back)")
    end
    Actions["radar"] = function()
        local n = CountStaticMeshActors()
        Say(string.format("radar: %s static-mesh actor(s) in this world", tostring(n)))
        J3DumpAllActors("radar")
    end
    Actions["build"] = function()
        local v = Spot(240, 0)
        if not v then return end
        Cube(v.x, v.y, v.z, v.yaw, 3.0)
        Say("instant build: 3x cube placed on the crosshair")
    end
    Actions["clone"] = function()
        local v = Spot(240, 0)
        if not v then return end
        Cube(v.x - 130, v.y, v.z, v.yaw, 1.0)
        Cube(v.x + 130, v.y, v.z, v.yaw, 1.0)
        Say("clone pair deployed")
    end
    Actions["freeze"] = function() CVar("slomo", 0.05) end
    Actions["purge"] = function()
        CVar("slomo", 1)
        CVar("r.ScreenPercentage", 100)
        JXQueue({ "obj gc" })
        Say("world released: time back to 1x, gc requested")
    end
    Actions["ssaa"] = function()
        CVar("r.ScreenPercentage", 150)
        CVar("r.TemporalAA.Upsampling", 1)
        Say("super-sampling armed at 150%")
    end
    Actions["net"] = function()
        CVar("p.NetEnableMoveCombining", 1)
        CVar("net.UseAdaptiveNetUpdateFrequency", 1)
        Say("net smooth pass armed")
    end
    Actions["guard"] = function()
        JX.guardOn = true
        CVar("t.MaxFPS", 0)
        Say("crash guard flag set (same pacing the guard command uses)")
    end
    Actions["vault"] = function()
        local ok = pcall(function() Slot.SaveMap("member vault") end)
        Say("vault: map snapshot " .. (ok and "written" or "refused"))
    end
    Actions["ultimate"] = function()
        Actions["ssaa"]()
        Actions["luma"]()
        Actions["night"]()
        Actions["shield"]()
        Say("PRO ultimate: super-sampling + luma + night + frame shield, all four applied")
    end

    local function Run(tag, parameters)
        local what = parameters and parameters[1]
        if not what or what == "list" then
            local names = {}
            for k in pairs(Actions) do names[#names + 1] = k end
            table.sort(names)
            Say(tag .. " actions: " .. table.concat(names, " "))
            return
        end
        local fn = Actions[what]
        if not fn then
            Say(tag .. ": unknown action '" .. tostring(what) .. "' (try " .. tag .. " list)")
            return
        end
        local ok, err = pcall(fn, parameters)
        if not ok then Say(tag .. " " .. what .. " failed: " .. tostring(err)) end
    end

    local Off = { x = 0, y = 0 }

    Actions["move"] = function(parameters)
        local dir = (parameters and parameters[2]) or "reset"
        local step = tonumber((parameters and parameters[3])) or 60
        if dir == "up" then Off.y = Off.y - step
        elseif dir == "down" then Off.y = Off.y + step
        elseif dir == "left" then Off.x = Off.x - step
        elseif dir == "right" then Off.x = Off.x + step
        elseif dir == "reset" then Off.x, Off.y = 0, 0
        else
            Say("usage: jmove up|down|left|right|reset [px]  (or jplus move ...)")
            return
        end
        local w = nil
        pcall(function() w = AcquirePakUIRoot() end)
        if not JXAlive(w) then Say("mover: panel widget not found (open it with B first)"); return end
        local ok = pcall(function() w:SetRenderTranslation({ X = Off.x, Y = Off.y }) end)
        Say(string.format("mover: panel offset (%d, %d) - %s", Off.x, Off.y,
            ok and "applied" or "the widget refused SetRenderTranslation"))
        if ok then Log(string.format("MOVER| offset x=%d y=%d", Off.x, Off.y)) end
    end

    JXMemberRun = Run   
    
    local function MoveComp()
        local m = nil
        pcall(function()
            local PC = UEHelpers.GetPlayerController()
            m = PC and PC.Pawn and PC.Pawn.CharacterMovement or nil
        end)
        return m
    end
    local function SetSpeed(v)
        local m = MoveComp()
        if JXAlive(m) then m.MaxWalkSpeed = v; Say("walk speed -> " .. v) else Say("no movement component") end
    end
    Actions["movereset"] = function() Dash(0, 0) Say("position reset") end
    Actions["moveup"] = function() Dash(0, 200) Say("moved up 200") end
    Actions["movedown"] = function() Dash(0, -200) Say("moved down 200") end
    Actions["moveleft"] = function() Dash(-300, 0) Say("moved left 300") end
    Actions["moveright"] = function() Dash(300, 0) Say("moved right 300") end
    Actions["dummyon"] = function() if InstallDeleteGuard then InstallDeleteGuard() end Say("dummy guard ON") end
    Actions["dummyoff"] = function() JxActor.protect = false Say("dummy guard OFF") end
    Actions["matrix1"] = function() Say("matrix 1 - use jmap 1") TravelTo(MapList[1]) end
    Actions["matrix2"] = function() Say("matrix 2 - use jmap 2") TravelTo(MapList[2]) end
    Actions["scale1"] = function() local pc=UEHelpers.GetPlayerController() if pc and pc:IsValid() and pc.Pawn and pc.Pawn:IsValid() then pc.Pawn:SetActorScale3D({X=1,Y=1,Z=1}) Say("scale reset to 1") end end
    Actions["scale2"] = function() local pc=UEHelpers.GetPlayerController() if pc and pc:IsValid() and pc.Pawn and pc.Pawn:IsValid() then pc.Pawn:SetActorScale3D({X=2,Y=2,Z=2}) Say("scale set to 2") end end
    Actions["noclip"] = function() if Fly and Fly.Set then Fly.Set(true) Say("noclip ON") end end
    Actions["walk1"] = function() SetSpeed(600) end
    Actions["walk2"] = function() SetSpeed(1200) end
    Actions["walk3"] = function() SetSpeed(2400) end
    
    Actions["noclip"] = function()
        local ok = false
        if type(Fly) == "table" and type(Fly.Set) == "function" then
            ok = Fly.Set(true)
        end
        Say(ok and "noclip: fly ON (level flight; Space climbs, Ctrl descends)"
            or "noclip: fly refused (no pawn / mode did not stick - see log)")
    end
    Actions["gravity"] = function()
        pcall(function()
            local m = MoveComp()
            if JXAlive(m) then
                m.GravityScale = ((m.GravityScale or 1) > 0.5) and 0.15 or 1
                Say("gravity scale -> " .. tostring(m.GravityScale))
            end
        end)
    end
    Actions["jumpx"] = function()
        pcall(function()
            local m = MoveComp()
            if JXAlive(m) then m.JumpZVelocity = 1400; Say("jump velocity -> 1400") end
        end)
    end
    Actions["tpxyz"] = function(p)
        local x = tonumber(p and p[2]) or 0
        local y = tonumber(p and p[3]) or 0
        local z = tonumber(p and p[4]) or 0
        pcall(function() TeleportTo(x, y, z, nil) end)
        Say(string.format("teleported to %.0f %.0f %.0f", x, y, z))
    end
    Actions["revive"] = function()
        local n = 0
        pcall(function()
            local l = FindAllOf("PlayerController")
            if l then for _, c in pairs(l) do if JXAlive(c) then c:ClientRestart(); n = n + 1 end end end
        end)
        Say(string.format("restart pushed to %d controller(s)", n))
    end
    Actions["scale"] = function(p)
        local v = tonumber(p and p[2]) or 2
        local v2 = Spot(240, 0)
        if v2 then Cube(v2.x, v2.y, v2.z, v2.yaw, v); Say("cube " .. v .. "x spawned") end
    end
    Actions["brightness"] = function()
        CVar("r.EyeAdaptationQuality", 0)
        CVar("r.TonemapperGamma", 1.4)
        Say("brightness: gamma 1.4, auto-exposure off")
    end
    Actions["antiafk"] = function()
        JX.antiafk = not JX.antiafk
        Say("anti-afk " .. (JX.antiafk and "on (micro-move each 4 min)" or "off"))
        if JX.antiafk then
            ExecuteWithDelay(240000, function()
                ExecuteInGameThread(function()
                    pcall(function()
                        local pv = PlayerXform()
                        if pv then TeleportTo(pv.x, pv.y, pv.z + 2, pv.yaw) end
                        if JX.antiafk then Actions["antiafk"]() end
                    end)
                end)
            end)
        end
    end
    Actions["killai"] = function()
        local n = 0
        pcall(function()
            local me = nil
            pcall(function() me = UEHelpers.GetPlayerController().Pawn end)
            local all = FindAllOf("Character")
            if not all then return end
            for _, a in pairs(all) do
                if JXAlive(a) and a ~= me then
                    local nm = JXName(a:GetClass()) or ""
                    if nm:find("AI", 1, true) or nm:find("Enemy", 1, true) or nm:find("Entity", 1, true) then
                        pcall(function() a:DestroyActor() end)
                        n = n + 1
                    end
                end
            end
        end)
        Say(string.format("killed %d AI/entity character(s)", n))
    end
    Actions["whereami"] = function()
        local pv = PlayerXform()
        if pv then Say(string.format("position %.0f %.0f %.0f yaw %.0f", pv.x, pv.y, pv.z, pv.yaw or 0)) end
    end
    Actions["markergo"] = function()
        local p2 = MarkPos()
        if p2 then
            pcall(function() TeleportTo(p2.X, p2.Y, p2.Z + 80, nil) end)
            Say("teleported onto the marker cube")
        else
            Say("no marker (jmark on first)")
        end
    end
    Actions["fps60"] = function()
        CVar("t.MaxFPS", 60)
        Say("fps cap -> 60")
    end
    Actions["fpsunlock"] = function()
        CVar("t.MaxFPS", 0)
        Say("fps cap removed")
    end
    
    local ExpandedSettings = {
        ["ui_gamma"] = { "r.TonemapperGamma", 0.8, 2.4, false },
        ["ui_sharpen"] = { "r.Tonemapper.Sharpen", 0, 3, false },
        ["ui_resolution"] = { "r.ScreenPercentage", 50, 150, true },
        ["ui_fpscap"] = { "t.MaxFPS", 0, 240, true },
        ["ui_viewdistance"] = { "r.ViewDistanceScale", 0.5, 2, false },
        ["ui_foliage"] = { "foliage.DensityScale", 0, 1, false },
        ["ui_grass"] = { "grass.DensityScale", 0, 1, false },
        ["ui_texture"] = { "sg.TextureQuality", 0, 3, true },
        ["ui_shadow"] = { "sg.ShadowQuality", 0, 3, true },
        ["ui_aa"] = { "sg.AntiAliasingQuality", 0, 3, true },
        ["ui_postprocess"] = { "sg.PostProcessQuality", 0, 3, true },
        ["ui_effects"] = { "sg.EffectsQuality", 0, 3, true },
        ["ui_bloom"] = { "r.BloomQuality", 0, 5, true },
        ["ui_motionblur"] = { "r.MotionBlurQuality", 0, 4, true },
        ["ui_tonemapper"] = { "r.Tonemapper.Quality", 0, 5, true },
        ["ui_eyeadaptation"] = { "r.EyeAdaptationQuality", 0, 2, true },
        ["ui_dof"] = { "r.DepthOfFieldQuality", 0, 2, true },
        ["ui_lensflare"] = { "r.LensFlareQuality", 0, 3, true },
        ["ui_refraction"] = { "r.RefractionQuality", 0, 2, true },
        ["ui_ssr"] = { "r.SSR.Quality", 0, 4, true },
        ["ui_ssrroughness"] = { "r.SSR.MaxRoughness", 0.1, 1, false },
        ["ui_aolevels"] = { "r.AmbientOcclusionLevels", -1, 3, true },
        ["ui_aoradius"] = { "r.AmbientOcclusionRadiusScale", 0.5, 2, false },
        ["ui_shadowresolution"] = { "r.Shadow.MaxResolution", 256, 2048, true },
        ["ui_shadowdistance"] = { "r.Shadow.DistanceScale", 0.5, 2, false },
        ["ui_mipbias"] = { "r.Streaming.MipBias", 0, 4, false },
        ["ui_anisotropy"] = { "r.MaxAnisotropy", 1, 16, true },
    }
    for name, spec in pairs(ExpandedSettings) do
        local setting = spec
        Actions[name] = function(p)
            local value = tonumber(p and p[2])
            if not value or value ~= value or value == math.huge or value == -math.huge then
                Say("setting rejected: finite numeric argument required"); return
            end
            value = math.max(setting[2], math.min(setting[3], value))
            if setting[4] then value = math.floor(value + 0.5) end
            CVar(setting[1], value)
            Say("setting queued (not verified): " .. setting[1])
        end
    end

    local function Say(s) Log("[PERF] " .. tostring(s)) end

    local function IniLines()
        local out = {}
        local h = io.open(ModDir .. "config/boost_pack.ini", "r")
        if not h then return out end
        for line in h:lines() do
            local k, v = line:match("^([%w_%.]+)%s*=%s*(.-)%s*$")
            if k and v and #v > 0 then out[#out + 1] = { k = k, v = v } end
        end
        h:close()
        return out
    end

    local RHICache = nil
    local function RHIName()
        if RHICache then return RHICache end
        local s = nil
        pcall(function()
            local KSL = StaticFindObject("/Script/Engine.Default__KismetSystemLibrary")
            if JXAlive(KSL) then
                pcall(function() s = KSL:GetConsoleVariableStringValue("r.RHI.Name") end)
                if not s then pcall(function() s = KSL:GetConsoleVariableStringValue("r.RHI.Name") end) end
            end
        end)
        RHICache = s or "unknown"
        return RHICache
    end

    local function RHISafe(cmd)
        local low = cmd:lower()
        local is12 = low:find("d3d12", 1, true) or low:find("raytracing", 1, true)
            or low:find("r.ngx", 1, true) or low:find("dlss", 1, true) or low:find("gpulightmass", 1, true)
        if not is12 then return true end
        local r = RHIName():lower()
        return r:find("d3d12", 1, true) ~= nil
    end

    local function ApplyGroup(prefix, label)
        local n = 0
        for _, e in ipairs(IniLines()) do
            if e.k:sub(1, #prefix) == prefix then
                if RHISafe(e.v) then JXQueue({ e.v }); n = n + 1
                else Log("PERF| skipped on this renderer: " .. e.v) end
            end
        end
        Say(string.format("%s applied: %d command(s)", label, n))
        return n
    end

    local function FogActors(off)
        local n = 0
        pcall(function()
            local fogs = FindAllOf("ExponentialHeightFog")
            if not fogs then return end
            for _, f in pairs(fogs) do
                if JXAlive(f) then
                    pcall(function() f:SetActorHiddenInGame(off and true or false) end)
                    pcall(function() f.bEnableVolumetricFog = not off end)
                    if off then pcall(function() f:SetActorTickEnabled(false) end)
                    else pcall(function() f:SetActorTickEnabled(true) end) end
                    n = n + 1
                end
            end
        end)
        return n
    end

    JXRegCmd("jboost2", function(FullCommand, Parameters, Ar)
        local tier = (Parameters and Parameters[1]) or "ultra_fps"
        if tier == "list" then
            Say("tiers: ultra_fps balanced quality  (jboost2 <tier>)")
            return
        end
        ExecuteInGameThread(function()
            pcall(function() ApplyGroup("tier." .. tier .. ".", "tier " .. tier) end)
        end)
    end)

    local function AutoBoostTier()
        local t = "balanced"
        local h = io.open(ModDir .. "config/auto_boost.txt", "r")
        if h then
            local v = (h:read("*l") or ""):match("^%s*(%S+)%s*$")
            h:close()
            if v and #v > 0 then t = v:lower() end
        end
        return t
    end
    
    _G.JXAutoBoostApply = function()
        local tier = AutoBoostTier()
        if tier == "off" then
            Say("auto-boost disabled (auto_boost.txt = off)")
        else
            ApplyGroup("tier." .. tier .. ".", "auto-boost " .. tier)
        end
    end
    ExecuteWithDelay(35000, function()
        ExecuteInGameThread(function() pcall(_G.JXAutoBoostApply) end)
    end)

    JXRegCmd("jfog", function(FullCommand, Parameters, Ar)
        local mode = (Parameters and Parameters[1]) or "status"
        ExecuteInGameThread(function()
            pcall(function()
                if mode == "off" then
                    ApplyGroup("off.", "fog-off")
                    local n = FogActors(true)
                    Say(string.format("fog off: volumetric+shafts cleared, %d fog actor(s) hidden and unticked", n))
                elseif mode == "on" then
                    ApplyGroup("on.", "fog-on")
                    local n = FogActors(false)
                    Say(string.format("fog on: %d fog actor(s) restored", n))
                else
                    local v = nil
                    pcall(function()
                        local KSL = StaticFindObject("/Script/Engine.Default__KismetSystemLibrary")
                        if JXAlive(KSL) then v = KSL:GetConsoleVariableFloatValue("r.VolumetricFog") end
                    end)
                    Say(string.format("fog status: r.VolumetricFog=%s (jfog off | on)", tostring(v)))
                end
            end)
        end)
    end)

    ExecuteWithDelay(25000, function()
        ExecuteInGameThread(function() pcall(function() ApplyGroup("a0", "boot load pacing") end) end)
    end)
    Log("perf pack ready: jboost2 ultra_fps|balanced|quality, jfog off|on")
end
-- r25: JXPerfPack symbol never existed anywhere (dead call, logged "definition
-- missing" every boot). Real arming happens in Core_WL.lua:290 pcall(JXMemberPack).
Log('perf pack: armed via Core_WL.lua -> pcall(JXMemberPack) (r25 dead-call cleanup)')

function JXUIFix()
    local function Say(s) Log("[UI] " .. tostring(s)) end

    local function Root()
        local w = nil
        pcall(function() w = AcquirePakUIRoot() end)
        return w
    end

    local function Prop(w, getter, setter, value)
        local ok = pcall(function() w[setter](w, value) end)
        local now = nil
        pcall(function() now = w[getter](w) end)
        return ok, now
    end

    local function Force(w)
        local parts = {}
        local ok, vis = Prop(w, "GetVisibility", "SetVisibility", 0)          
        parts[#parts + 1] = "vis" .. (ok and "=ok(" or "=FAIL(") .. tostring(vis) .. ")"
        local ok2 = pcall(function() w:SetRenderOpacity(1.0) end)
        parts[#parts + 1] = "opacity" .. (ok2 and "=ok" or "=FAIL")
        local ok3 = pcall(function() w:SetRenderTranslation({ X = 0, Y = 0 }) end)
        parts[#parts + 1] = "translate" .. (ok3 and "=ok" or "=FAIL")
        local ok4 = pcall(function() w:SetIsEnabled(true) end)
        parts[#parts + 1] = "enabled" .. (ok4 and "=ok" or "=FAIL")
        local inv = nil
        pcall(function() inv = w:IsInViewport() end)
        if inv == false or inv == nil then
            -- r58: ZOrder 0 put the panel UNDER the game HUD - every other
            -- AddToViewport in this tree uses 10000. One odd call out of seven
            -- is what made the repaired panel come back behind the HUD.
            local ok5 = pcall(function() w:AddToViewport(10000) end)
            parts[#parts + 1] = "AddToViewport" .. (ok5 and "=ok" or "=FAIL")
        else
            parts[#parts + 1] = "inViewport=yes"
        end
        
        pcall(function() if MovOff then MovOff.x, MovOff.y = 0, 0 end end)
        return table.concat(parts, " ")
    end

    JXRegCmd("jui", function(FullCommand, Parameters, Ar)
        ExecuteInGameThread(function()
            local jp = _G.JxPanels
            if type(jp) == "table" and type(jp.Toggle) == "function" then
                jp.Toggle()
                Say("jui -> canvas toggle (pak panel retired r7.0)")
            else
                Say("jui: pak panel retired; canvas not loaded - use B / F8 / jpanel")
            end
        end)
        return true
    end)
    Log("ui fix ready: jui routes to the canvas (r9)")
end
JXUIFix()

function JXGuardPack()
    local function Say(s) Log("[GUARD] " .. tostring(s)) end

    local GuardTier, GuardNames = "basic", {}

    local function ReadGuardIni()
        local tier, wl = nil, {}
        local h = io.open(ModDir .. "config/crashguard.ini", "r")
        if not h then return "basic", {} end
        local section = ""
        for line in h:lines() do
            local s = line:match("^%s*%[([%w_%.]+)%]")
            if s then section = s:lower()
            else
                local k, v = line:match("^%s*([%w_%.]+)%s*=%s*(.-)%s*$")
                if k then
                    if section == "tier" then
                        if k:lower() == "default" then tier = v end
                    elseif section == "whitelist" then
                        if #v > 0 then wl[#wl + 1] = v end
                    end
                end
            end
        end
        h:close()
        return tier or "basic", wl
    end

    local function IsWhitelisted(me)
        if type(me) ~= "string" or me == "" then return false end
        for _, n in ipairs(GuardNames) do
            if n == me then return true end
        end
        return false
    end

    local FullOn = false
    local function ApplyTierFull(why)
        if FullOn then return end
        FullOn = true
        JXQueue({ "t.MaxFPS 0", "r.MotionBlurQuality 0", "r.MotionBlur.Max 0", "r.MotionBlur.Amount 0" })
        Log("GUARD| FULL guard on (" .. tostring(why) .. "): dll guard + tick/heap guards + 30 s sweep")
        
        local function Sweep()
            if not FullOn then return end
            pcall(function()
                local n = 0
                local all = FindAllOf("Actor")
                if all then
                    for _, a in pairs(all) do
                        if JXAlive(a) then
                            local nm = JXName(a) or ""
                            if nm:find("Default__", 1, true) then n = n + 1 end
                        end
                    end
                end
                if n > 0 then Log("GUARD| sweep: " .. n .. " class-default object(s) alive (informational)") end
            end)
            ExecuteWithDelay(30000, function() ExecuteInGameThread(function() pcall(Sweep) end) end)
        end
        ExecuteWithDelay(30000, function() ExecuteInGameThread(function() pcall(Sweep) end) end)
    end

    JXRegCmd("jguardfeed", function(FullCommand, Parameters, Ar)
        ExecuteInGameThread(function()
            pcall(function()
                local logfile = (Parameters and Parameters[1]) or (ModDir .. "crashlog.txt")
                local h = io.open(logfile, "r")
                if not h then Log("JGUARD| crash log not found: " .. logfile); return end
                local patterns = {}
                local total = 0
                for line in h:lines() do
                    total = total + 1
                    
                    local code, mod, off = line:match("exception (0x%x+) at ([%w%.]+)%+(%d+)")
                    if code and mod and off then
                        local key = mod .. "+" .. off
                        patterns[key] = (patterns[key] or 0) + 1
                    end
                    
                    local skmod, skoff = line:match("SKIPPED.*at ([%w%.]+)%+(%d+)")
                    if skmod and skoff then
                        local key = skmod .. "+SK" .. skoff
                        patterns[key] = (patterns[key] or 0) + 1
                    end
                end
                h:close()
                
                local sorted = {}
                for k, v in pairs(patterns) do sorted[#sorted + 1] = { addr = k, count = v } end
                table.sort(sorted, function(a, b) return a.count > b.count end)
                
                local outpath = ModDir .. "config/crash_analysis.txt"
                local prearm = ModDir .. "config/crash_prearm.txt"
                local w = io.open(outpath, "w")
                local pw = io.open(prearm, "w")
                if w then
                    w:write("; JX crash analysis " .. os.date() .. "\r\n")
                    w:write("; total lines: " .. total .. " | unique patterns: " .. #sorted .. "\r\n")
                    for i, e in ipairs(sorted) do
                        if i > 50 then break end
                        w:write(string.format("%s  count=%d\r\n", e.addr, e.count))
                    end
                    w:close()
                end
                if pw then
                    for i, e in ipairs(sorted) do
                        if i > 20 then break end
                        if e.count >= 5 then
                            pw:write(e.addr .. "\r\n")
                        end
                    end
                    pw:close()
                end
                Log("JGUARD| parsed " .. total .. " lines, " .. #sorted .. " unique patterns")
                Log("JGUARD| top crash sites written to config/crash_analysis.txt")
                Log("JGUARD| prearm file: config/crash_prearm.txt (" ..
                    math.min(#sorted, 20) .. " sites with count>=5)")
                
                for i = 1, math.min(5, #sorted) do
                    JXSay("JGUARD| #" .. i .. " " .. sorted[i].addr .. " x" .. sorted[i].count)
                end
            end)
        end)
        return true
    end)

    JXRegCmd("jguard2", function(FullCommand, Parameters, Ar)
        local sub = (Parameters and Parameters[1]) or "status"
        if sub == "reload" then
            GuardTier, GuardNames = ReadGuardIni()
            Say(string.format("policy reloaded: default=%s whitelist=%d name(s)", GuardTier, #GuardNames))
            return
        end
        if sub == "list" then
            Say(string.format("tier=%s full=%s whitelist=%d: %s", GuardTier, tostring(FullOn),
                #GuardNames, table.concat(GuardNames, ", ")))
            return
        end
        if sub == "full" then ApplyTierFull("manual"); return end
        if sub == "wl" then
            local act = Parameters and Parameters[2]
            local who = Parameters and Parameters[3]
            if act == "add" and who then
                GuardNames[#GuardNames + 1] = who
                local h = io.open(ModDir .. "config/crashguard.ini", "a")
                if h then h:write("name." .. string.format("%02d", #GuardNames) .. "  = " .. who .. "\r\n"); h:close() end
                if who == PlayerName(UEHelpers.GetPlayerController() and UEHelpers.GetPlayerController().PlayerState) then
                    ApplyTierFull("whitelisted")
                end
                Say("whitelist += " .. who)
                return
            end
            if act == "del" and who then
                for i, n in ipairs(GuardNames) do if n == who then table.remove(GuardNames, i) break end end
                Say("whitelist -= " .. who)
                return
            end
            Say("usage: jguard2 wl add|del <name>")
            return
        end
        Say(string.format("guard: tier=%s full=%s whitelist=%d (jguard2 full|list|reload|wl add <name>)",
            GuardTier, tostring(FullOn), #GuardNames))
    end)

    GuardTier, GuardNames = ReadGuardIni()
    ExecuteWithDelay(15000, function()
        ExecuteInGameThread(function()
            pcall(function()
                local PC = UEHelpers.GetPlayerController()
                local me = PC and PlayerName(PC.PlayerState) or ""
                local tier = GuardTier
                if IsWhitelisted(me) then tier = "full" end
                if me == "" then tier = "basic" end
                Log(string.format("GUARD| policy: default=%s  me=%s  -> %s",
                    GuardTier, me == "" and "(unknown)" or me, tier))
                if tier == "full" then ApplyTierFull("policy:" .. tostring(me)) end
            end)
        end)
    end)
    Log("guard pack ready: jui auto on|off / jui diag, jguard2 status|full|list|reload|wl add <name>")
end
JXGuardPack()

function JXUICreate()
    local Tried = { "/Game/Mods/JinxingLoader_P/WBP_JinxingRoot.WBP_JinxingRoot_C",
                    "/Game/Mods/JinxingLoader_P/WBP_JinxingRoot.WBP_JinxingRoot",
                    "WBP_JinxingRoot_C" }
    local Made = nil
    local MadeRoute = "none"

    local function PC()
        local p = nil
        pcall(function() p = UEHelpers.GetPlayerController() end)
        return p
    end

    local function Make()
        if JXAlive(Made) then return Made end
        local pc = PC()
        if not pc or not pc:IsValid() then Log("UICREATE| no player controller yet"); return nil end
        
        local function ResolveClass(asset)
            if asset == nil then return nil end
            local c = nil
            local okg = pcall(function()
                c = asset.GeneratedClass
            end)
            if okg and c ~= nil then return c end
            pcall(function() c = StaticFindObject("WidgetBlueprintGeneratedClass", nil, "WBP_JinxingRoot_C", true) end)
            return c
        end
        local cls = nil
        
        pcall(function() cls = StaticFindObject("WidgetBlueprintGeneratedClass", nil, "WBP_JinxingRoot_C", true) end)
        if not JXAlive(cls) then
            pcall(function() cls = StaticFindObject("BlueprintGeneratedClass", nil, "WBP_JinxingRoot_C", true) end)
        end
        if not JXAlive(cls) then
            
            local okL, rL = pcall(function() return LoadAsset("/Game/Mods/JinxingLoader_P/WBP_JinxingRoot.WBP_JinxingRoot_C") end)
            Log("UICREATE| r5.11 class-path LoadAsset ok=" .. tostring(okL) .. " rL=" .. tostring(rL ~= nil))
            if not (okL and rL) then
                pcall(function() rL = LoadAsset("/Game/Mods/JinxingLoader_P/WBP_JinxingRoot") end)
            end
            Log(string.format("UICREATE| LoadAsset ok=%s type=%s",
                tostring(okL), type(rL)))
            if rL ~= nil then
                local className = ""
                local fullName = ""
                pcall(function() className = tostring(rL:GetClass()) end)
                pcall(function() fullName = rL:GetFullName() end)
                Log("UICREATE| loaded asset class=" .. className .. " full=" .. fullName)
                
                local inner = nil
                pcall(function() inner = StaticFindObject("WidgetBlueprintGeneratedClass", rL, "WBP_JinxingRoot_C", true) end)
                if not inner then pcall(function() inner = StaticFindObject("WidgetBlueprintGeneratedClass", rL, "WBP_JinxingRoot_C") end) end
                if inner and inner:IsValid() then
                    cls = inner
                    Log("UICREATE| inner class resolved via rL outer: " .. tostring(inner))
                else
                    pcall(function()
                        local gc = rL.GeneratedClass
                        if gc and gc:IsValid() then cls = gc; Log("UICREATE| GeneratedClass resolved") end
                    end)
                end
                
                if className:find("UClass", 1, true) then
                    cls = rL
                    Log("UICREATE| using LoadAsset result directly as UClass: " .. tostring(cls))
                else
                    
                    cls = ResolveClass(rL)
                    if cls ~= nil then
                        Log("UICREATE| resolved UClass via GeneratedClass: " .. tostring(cls))
                    end
                end
            end
            if cls == nil then
                pcall(function() cls = StaticFindObject("WidgetBlueprintGeneratedClass", nil, "WBP_JinxingRoot_C", true) end)
            end
            if cls == nil then
                pcall(function() cls = StaticFindObject("Class", nil, "WBP_JinxingRoot_C", true) end)
            end
        end
        if cls == nil then
            
            pcall(function()
                local n, hit = 0, nil
                local all = FindAllOf("WidgetBlueprintGeneratedClass")
                for _, u in pairs(all or {}) do
                    n = n + 1
                    local nm = ""
                    pcall(function() nm = JXName(u) or "" end)
                    if nm:find("JinxingRoot", 1, true) then hit = nm end
                end
                Log("UICREATE| diag: " .. tostring(n) .. " WidgetBlueprintGeneratedClass(es) resident, jinxing hit=" .. tostring(hit))
            end)
            Log("UICREATE| class not loadable; see diag above")
            return nil
        end
        Log("UICREATE| class resolved: " .. tostring(cls ~= nil))
        
        pcall(function()
            if cls and cls.AddToRoot then cls:AddToRoot() end
        end)
        
        local clsU = nil
        pcall(function()
            
            if cls and cls.IsChildOf and cls:IsChildOf(StaticFindObject("/Script/UMG.UserWidget")) then
                clsU = cls
            end
        end)
        if not clsU then
            
            pcall(function() clsU = StaticFindObject("WidgetBlueprintGeneratedClass", nil, "WBP_JinxingRoot_C", true) end)
        end
        if not clsU then pcall(function() clsU = StaticFindObject("WidgetBlueprintGeneratedClass", nil, "WBP_JinxingRoot_C") end) end
        if not clsU and cls then clsU = cls end
        Log("UICREATE| class object for CreateWidget: " .. tostring(clsU ~= nil) .. " (" .. tostring(clsU) .. ")")
        local w = nil
        local werr = nil
        local route = "shell"
        local WBL = nil
        pcall(function() WBL = StaticFindObject("/Script/UMG.Default__WidgetBlueprintLibrary") end)
        
        if not JXAlive(w) then
            local core = nil
            pcall(function() core = AcquireLoaderCore() end)
            if core and core:IsValid() then
                local ui = nil
                pcall(function() ui = core.JinxingUi end)
                if ui ~= nil then
                    local uv = nil
                    pcall(function() uv = ui:IsValid() end)
                    if uv == true then
                        w = ui
                        Log("UICREATE| Core route: live JinxingUi adopted")
                    else
                        pcall(function() core.JinxingUi = nil end)
                        Log("UICREATE| Core route: cleared a dead JinxingUi reference")
                    end
                end
                if not JXAlive(w) then
                    local okc, eC = pcall(function() core:JinxingLoaderToggle() end)
                    Log("UICREATE| Core route: JinxingLoaderToggle ok=" .. tostring(okc)
                        .. (okc and "" or (" err=" .. tostring(eC):sub(1, 120))))
                    pcall(function() ui = core.JinxingUi end)
                    if ui ~= nil then
                        local uv = nil
                        pcall(function() uv = ui:IsValid() end)
                        if uv == true then w = ui end
                    end
                end
                if JXAlive(w) then
                    Log("UICREATE| Core BP route produced the widget")
                    route = "core"
                end
            else
                Log("UICREATE| Core route skipped: no loader core actor in this world")
            end
        end
        
        if not JXAlive(w) then
            local WBC = nil
            pcall(function() WBC = StaticFindObject("/Script/UMG.WidgetBlueprintLibrary") end)
            if WBC and WBC:IsValid() then
                local okc, e0 = pcall(function() w = WBC:CreateWidget(pc, clsU, pc) end)
                if not okc then werr = tostring(e0) end
            end
        end
        
        if JXAlive(w) then route = "wbc" end
        if not JXAlive(w) then
            local okc, e1 = pcall(function() w = WBL:CreateWidget(pc, clsU, pc) end)
            if not okc then werr = (werr and (werr .. " | ") or "") .. tostring(e1) end
        end
        
        if not JXAlive(w) then
            local world = nil
            pcall(function() world = pc:GetWorld() end)
            local okc, e2 = pcall(function() w = WBL:CreateWidget(world, clsU, pc) end)
            if not okc then werr = (werr and (werr .. " | ") or "") .. tostring(e2) end
        end
        
        if not JXAlive(w) then
            local okc, e3 = pcall(function() w = WBL:CreateWidget(pc, clsU) end)
            if not okc then werr = (werr and (werr .. " | ") or "") .. tostring(e3) end
        end
        
        if not JXAlive(w) then
            Log("UICREATE| all CreateWidget paths failed - shell route disabled (heap-corruption source); the keepalive will retry via Core")
        end
        if not JXAlive(w) and werr then
            Log("UICREATE| CreateWidget errors: " .. tostring(werr):sub(1, 300))
        end
        if JXAlive(w) then
            
            pcall(function() w:AddToViewport(10000) end)
            pcall(function() w:SetVisibility(0) end)   
            pcall(function() w:SetRenderOpacity(0.72) end)   
            pcall(function() w:SetPositionInViewport({ X = 60, Y = 60 }, false) end)
            pcall(function()
                local ivp = nil
                pcall(function() ivp = w:IsInViewport() end)
                Log("UICREATE| viewport state: in=" .. tostring(ivp))
            end)
            pcall(function()
                local wt, rw = nil, nil
                pcall(function() wt = w.WidgetTree end)
                if wt then pcall(function() rw = wt.RootWidget end) end
                Log("UICREATE| tree probe: WidgetTree=" .. tostring(wt ~= nil)
                    .. " RootWidget=" .. tostring(rw ~= nil) .. " route=" .. route)
            end)
            MadeRoute = route
            Made = w
            _G.JXPakPanel = w
            Log("UICREATE| pak panel created from Lua (V62 widget live)")
            return w
        end
        Log("UICREATE| Create failed on all paths (class=" .. tostring(cls) .. ")")
        return nil
    end

    _G.JXPakToggle = function()
        ExecuteInGameThread(function()
            pcall(function()
                if JXBusy() then Log('B: UI locked during map load') return end
                -- r29: JxNewUI v4.6 owns the toggle (Lua-authoritative; the
                -- Core UFUNCTION is ensure-open and stacked shells). B / F6 /
                -- bare jpanel all route through it; log-only stub stays as
                -- the fallback when JxNewUI failed to load.
                local nu = _G.JxNewUI
                if type(nu) == "table" and type(nu.ToggleB) == "function" then
                    local okR = pcall(nu.ToggleB)
                    Log("PNL| toggle routed to JxNewUI ok=" .. tostring(okR))
                    return
                end
                Log("PNL| B -> pak shell panel (JxNewUI absent, no toggle)")
            end)
        end)
    end

    JXRegCmd("juicreate", function()
        ExecuteInGameThread(function()
            pcall(function() Log("UICREATE| legacy pak panel retired (r7.0) - use B / the 16-tab canvas") end)
        end)
    end)

    JXRegCmd("jxuiinit", function()
        ExecuteInGameThread(function()
            pcall(function() Log("UICREATE| legacy pak panel retired (r7.0) - use B / the 16-tab canvas") end)
            pcall(function()
                local jp = _G.JxPanels
                if type(jp) == "table" and type(jp.AutoOpen) == "function" then
                    jp.AutoOpen()
                    JXSay("JX UI INIT: canvas opened (pak panel retired r7.0)")
                else
                    JXSay("JX UI INIT: canvas not loaded - B toggles when ready")
                end
            end)
        end)
        return true
    end)

    local ui_try = 0
    local function BootCreate()
        ui_try = ui_try + 1
        if ui_try > 18 then                      
            Log("UICREATE| boot retries exhausted - HUD text menu stays (B works)")
            return
        end
        ExecuteInGameThread(function()
            Log("UICREATE| legacy pak panel retired (r7.0) - the 16-tab glass canvas is the UI (B toggles)")
        end)
    end
    ExecuteWithDelay(15000, BootCreate)
    
    local kaGen = 0
    local kaShellTries = 0
    local kaProbe = 0
    local function PanelKeepaliveStart()
        kaGen = kaGen + 1
        local gen = kaGen
        local function tick()
            ExecuteInGameThread(function()
                pcall(function()
                    if gen ~= kaGen then return end
                    if _G.JXCanvasReopenPending then
                        _G.JXCanvasReopenPending = false
                        local jp = _G.JxPanels
                        if jp and type(jp.AutoOpen) == "function" and not jp.open then
                            jp.AutoOpen()
                            Log("PNL| canvas re-opened after world change")
                        end
                    end
                end)
            end)
            if gen == kaGen then ExecuteWithDelay(15000, tick) end
        end
        ExecuteWithDelay(2000, tick)
    end
    ExecuteWithDelay(20000, PanelKeepaliveStart)
    _G.JXPanelKeepaliveReseed = PanelKeepaliveStart
    Log("ui create ready: juicreate, panel auto-created with 5 s retries from 15 s after boot")
end
JXUICreate()

function JXUIToggleFix()
    local function Say(s) Log("[UITOG] " .. tostring(s)) end

    local function ClearDeadAndToggle(tag)
        local core = nil
        pcall(function() core = AcquireLoaderCore() end)
        if not core or not core:IsValid() then
            Say(tag .. ": loader core not found")
            return false
        end
        local ui, wasValid = nil, nil
        pcall(function() ui = core.JinxingUi end)
        if ui ~= nil then
            pcall(function() wasValid = ui:IsValid() end)
            if wasValid ~= true then
                local cleared = pcall(function() core.JinxingUi = nil end)
                Say(tag .. ": cleared a dead JinxingUi reference (" .. tostring(cleared) .. ")")
            else
                Say(tag .. ": JinxingUi is a live widget already")
            end
        else
            Say(tag .. ": JinxingUi was empty")
        end
        local ok = pcall(function() core:JinxingLoaderToggle() end)
        local after, alive = nil, nil
        pcall(function() after = core.JinxingUi end)
        if after ~= nil then pcall(function() alive = after:IsValid() end) end
        Say(string.format("%s: toggle called ok=%s -> JinxingUi %s", tag,
            tostring(ok), after == nil and "still empty" or ("present, valid=" .. tostring(alive))))
        if alive == true then
            pcall(function() after:AddToViewport(10000) end)
            pcall(function() after:SetVisibility(0) end)
            pcall(function() after:SetRenderOpacity(0.72) end)
            Say(tag .. ": widget added to the viewport and forced visible")
            return true
        end
        return false
    end

    JXRegCmd("juitoggle", function()
        ExecuteInGameThread(function()
            pcall(function() Log("UICREATE| legacy pak panel retired (r7.0) - use B / the 16-tab canvas") end)
        end)
    end)

    Log("ui toggle fix ready: juitoggle retired (r7.0); boot auto-toggle disabled")
end
JXUIToggleFix()

function JXUIProbe()
    local Cands = {
        { tag = "game", path = "/Game/NebulaLobbyUI/UI/UI_ModeSelection/UI_Menu_ModeSelection.UI_Menu_ModeSelection_C" },
        { tag = "game2", path = "/Game/Multiplayer/Chat/WB_Chat.WB_Chat_C" },
        { tag = "ours", path = "/Game/Mods/JinxingLoader_P/WBP_JinxingRoot.WBP_JinxingRoot_C" },
    }
    local function Probe()
        local pc = nil
        pcall(function() pc = UEHelpers.GetPlayerController() end)
        local pcOk = (pc ~= nil and pc:IsValid())
        Log(string.format("UIPROBE| start: pc=%s", tostring(pcOk)))
        local WBL = nil
        pcall(function() WBL = StaticFindObject("/Script/UMG.Default__WidgetBlueprintLibrary") end)
        Log(string.format("UIPROBE| WidgetBlueprintLibrary=%s valid=%s",
            tostring(WBL ~= nil), tostring(WBL ~= nil and WBL:IsValid() or false)))
        for _, c in ipairs(Cands) do
            local cls, found = nil, false
            pcall(function() cls = StaticFindObject(c.path); found = (cls ~= nil) end)
            local valid, path, cdo = false, "?", false
            if found then
                pcall(function() valid = cls:IsValid() end)
                pcall(function() path = cls:GetPathName() end)
                pcall(function() cdo = (cls:GetDefaultObject() ~= nil) end)
            end
            local made, madeValid = nil, nil
            if found and valid and pcOk and WBL ~= nil then
                pcall(function() made = WBL:Create(pc, cls, pc) end)
                if made ~= nil then pcall(function() madeValid = made:IsValid() end) end
            end
            Log(string.format("UIPROBE| %-5s found=%s valid=%s cdo=%s create=%s madeValid=%s path=%s",
                c.tag, tostring(found), tostring(valid), tostring(cdo),
                made == nil and "nil" or "object", tostring(madeValid), tostring(path)))
        end
    end

    JXRegCmd("juiprobe", function()
        ExecuteInGameThread(function() pcall(Probe) end)
    end)
    ExecuteWithDelay(25000, function()
        ExecuteInGameThread(function() pcall(Probe) end)
    end)
    Log("ui probe ready: juiprobe, plus a pass at 25 s")
end
JXUIProbe()

function JXProbe3()
    local Cands = {
        { tag = "base  ", path = "/Game/NebulaLobbyUI/UI/UI_ModeSelection/UI_Menu_ModeSelection.UI_Menu_ModeSelection_C" },
        { tag = "manboM", path = "/Game/Mods/Z_manbo_P/Widget/menu.menu_C" },
        { tag = "manboH", path = "/Game/Mods/Z_manbo_P/Widget/HUD.HUD_C" },
        { tag = "yumaoA", path = "/Game/Mods/yumao_P/ModActor.ModActor_C" },
        { tag = "mahiro", path = "/Game/Mods/Box/Main_ModActor.Main_ModActor_C" },
        { tag = "ours  ", path = "/Game/Mods/JinxingLoader_P/WBP_JinxingRoot.WBP_JinxingRoot_C" },
        { tag = "ourtog", path = "/Game/JinxingLoader/Core/BP_JinxingLoaderCore.BP_JinxingLoaderCore_C" },
    }
    local function Run()
        for _, c in ipairs(Cands) do
            local cls, found = nil, false
            pcall(function() cls = StaticFindObject(c.path); found = (cls ~= nil) end)
            local valid = false
            if found then pcall(function() valid = cls:IsValid() end) end
            Log(string.format("PROBE3| %s found=%-5s valid=%-5s  %s",
                c.tag, tostring(found), tostring(valid), c.path:match("[^/]+$")))
        end
    end
    JXRegCmd("jprobe3", function() ExecuteInGameThread(function() pcall(Run) end) end)
    ExecuteWithDelay(30000, function() ExecuteInGameThread(function() pcall(Run) end) end)
    Log("probe3 ready (30 s pass): base game vs other mod paks vs ours")
end
JXProbe3()

do -- r16 split: shared env bridge for Core_* sidecars
    _G.JXEnv = {
        Log = Log,
        UEHelpers = UEHelpers,
        ModDir = ModDir,
        JXAlive = JXAlive,
        JXName = JXName,
        JXQueue = JXQueue,
        JXSay = JXSay,
    }
end
do
    local sd = _G.JXSidecarDir or ""
    local mc = loadfile(sd .. "Core_Perf.lua")
    if mc then
        local okm, merr = pcall(mc)
        if not okm then Log("Core_Perf.lua load error: " .. tostring(merr)) end
    else
        Log("Core_Perf.lua not found (non-fatal)")
    end
end

do -- r16 split: env bridge for Core_WL.lua
    _G.JXEnv.Log = Log
    _G.JXEnv.UEHelpers = UEHelpers
    _G.JXEnv.ModDir = ModDir
    _G.JXEnv.JXQueue = JXQueue
    _G.JXEnv.JXRootOr = JXRootOr
end
do
    local sd = _G.JXSidecarDir or ""
    local mc = loadfile(sd .. "Core_WL.lua")
    if mc then
        local okm, merr = pcall(mc)
        if not okm then Log("Core_WL.lua load error: " .. tostring(merr)) end
    else
        Log("Core_WL.lua not found (non-fatal)")
    end
end

function JXPanelHost()
    local GateList = {}
    do
        local f = io.open(JXRootOr .. "config/whitelist.txt", "r")
        if f then
            for line in f:lines() do
                local name = line:match("^%s*([^;#%s][^;#]-)%s*$")
                if name and name ~= "" then GateList[name:lower()] = true end
            end
            f:close()
        end
    end
    local function GateAllowed()
        local auth = false
        pcall(function()
            local info = JXTravelInfo and JXTravelInfo() or nil
            auth = (info ~= nil and info.authority == true)
        end)
        if auth then return true end
        local me = ""
        pcall(function() if type(JXIdent) == "function" then me = (JXIdent()) or "" end end)
        if me == "" then return true end
        local bare = me:match("^steam:(.+)$")
        if GateList[me:lower()] or (bare and GateList[bare:lower()]) then return true end
        
        local lvl = nil
        pcall(function() if type(JXWL) == "table" and JXWL.LevelOf then lvl = JXWL.LevelOf(bare or me) end end)
        if lvl == "pro" or lvl == "plus" or (type(lvl) == "number" and lvl >= 1) then return true end
        
        local anyRule = false
        pcall(function()
            local JW = _G.JxWhitelist
            if type(JW) == "table" and type(JW.rules) == "table" then
                for _ in pairs(JW.rules) do anyRule = true break end
            end
        end)
        if next(GateList) ~= nil then anyRule = true end
        pcall(function()
            local h = io.open(JXRootOr .. "config/whitelist.ini", "r")
            if h then
                for ln in h:lines() do
                    local s = ln:match("^%s*(.-)%s*$") or ""
                    if s ~= "" and s:sub(1, 1) ~= "#" and s:sub(1, 1) ~= ";" then anyRule = true break end
                end
                h:close()
            end
        end)
        if not anyRule then
            Log("WL| no whitelist configured - panel gate opened (fail-open)")
            return true
        end
        
        pcall(function()
            local w = io.open(JXRootOr .. "config/whitelist_blocks.log", "a")
            if w then
                w:write(os.date("%Y-%m-%d %H:%M:%S") .. "  PANEL-BLOCK  " .. me .. "\r\n")
                w:close()
            end
        end)
        return false
    end
    local function FindPanel()
        local found = nil
        pcall(function()
            local all = FindAllOf("UserWidget")
            for _, u in pairs(all or {}) do
                if JXAlive(u) then
                    local cn = ""
                    pcall(function() cn = JXName(u:GetClass()) or "" end)
                    if cn == "WBP_JinxingRoot_C" then found = u return end
                end
            end
        end)
        return found
    end
    local function PanelMouse(show)
        pcall(function()
            local PC = UEHelpers.GetPlayerController()
            if not PC or not PC:IsValid() then return end
            pcall(function() PC.bShowMouseCursor = show and true or false end)
            local WBL = StaticFindObject("/Script/UMG.Default__WidgetBlueprintLibrary")
            if WBL and WBL:IsValid() then
                if show then
                    pcall(function() WBL:SetInputMode_GameAndUIEx(PC, nil, 0, false) end)
                else
                    pcall(function() WBL:SetInputMode_GameOnly(PC) end)
                end
            end
        end)
    end
    local PanelShown = false
    local function ShowPanel()
        local w = FindPanel()
        if w then
            w:SetVisibility(0)
            PanelShown = true
            PanelMouse(true)
            Log("PNL| shown existing panel")
            return true
        end
        
        Log("PNL| no pak panel instance; the HUD panel is the UI (B key)")
        return false
    end
    local function HidePanel()
        local w = FindPanel()
        if w then pcall(function() w:SetVisibility(1) end) end
        PanelShown = false
        PanelMouse(false)
        Log("PNL| panel hidden")
    end
    _G.JXPanelGateAllowed = GateAllowed
    _G.JXPanelMouse = PanelMouse
    
    local okb, kb = pcall(function() return Key.B end)
    if okb and kb then
        pcall(function()
            RegisterKeyBind(kb, function()
                
                ExecuteInGameThread(function()
                    pcall(function()
                        if type(_G.JXPakToggle) == "function" then
                            _G.JXPakToggle()
                        else
                            Log("PNL| panel host not loaded yet")
                        end
                    end)
                end)
            end)
        end)
        Log("PNL| B-key -> HUD panel host armed (jpanel status|hide)")
    else
        Log("PNL| Key.B unavailable - use jpanel show|hide")
    end
end
JXPanelHost()

function JXNameFix()
    local LastLogged = nil

    local function Try(what, fn)
        local ok, v = pcall(fn)
        if ok and type(v) == "string" and #v > 0 and not v:find("TrivialObject", 1, true) then
            return v, what
        end
        return nil, what
    end

    function JXIdent()
        local PS = nil
        pcall(function()
            local PC = UEHelpers.GetPlayerController()
            if PC and PC:IsValid() then PS = PC.PlayerState end
        end)
        local v, src = Try("PlayerState:GetPlayerName", function() return PS:GetPlayerName() end)
        if v then return v, src end
        v, src = Try("PlayerState.PlayerName", function() return PS.PlayerName end)
        if v then return v, src end
        v, src = Try("mod PlayerName", function() return PlayerName(PS) end)
        if v then return v, src end
        local id = nil
        pcall(function() id = GetSteam64() end)
        if type(id) == "string" and #id > 0 then return "steam:" .. id, "steam64" end
        return "", "none"
    end

    JXRegCmd("jme", function()
        ExecuteInGameThread(function()
            local name, src = JXIdent()
            local lvl = 0
            pcall(function() lvl = (JXWL and JXWL.Level()) or 0 end)
            Log(string.format("ME| name=%s (via %s)  level=%s", tostring(name), tostring(src), tostring(lvl)))
        end)
    end)

    local Step = 42          
    local function FlyVerticalTick()
        pcall(function()
            if not FlyOn then return end
            local pawn = FlyAcquirePawn and FlyAcquirePawn() or nil
            if not (pawn and pawn:IsValid()) then return end
            local crouch, jump = false, false
            pcall(function() crouch = pawn.bIsCrouched == true end)
            pcall(function() jump = pawn.bPressedJump == true end)
            if not (JX and JX.flyVertical) then return end
            if not crouch and not jump then return end
            local loc = nil
            pcall(function() loc = pawn:K2_GetActorLocation() end)
            if not loc then return end
            local z = loc.Z + (jump and Step or -Step)
            local name, _ = JXIdent()
            TeleportTo(loc.X, loc.Y, z, nil)
            if name ~= LastLogged then
                LastLogged = name
                Log(string.format("FLYV| vertical via %s (%s)", jump and "jump" or "crouch", tostring(name)))
            end
        end)
        
        local cadence = 2000
        pcall(function() if FlyOn == true then cadence = 100 end end)
        ExecuteWithDelay(cadence, function()
            ExecuteInGameThread(function() pcall(FlyVerticalTick) end)
        end)
    end
    
    JX = JX or {}
    JX.flyVertical = true   
    ExecuteWithDelay(5000, function() ExecuteInGameThread(function() pcall(FlyVerticalTick) end) end)
    Log("r3.34 ready: jme (name/id/level), fly vertical = crouch down / jump up")
end
JXNameFix()

function JXPageKeys()
    local Plus = { "sprint", "jump", "glide", "night", "luma", "scan", "shield", "clear", "stealth" }
    local Pro = { "matrix", "slow", "fast", "god", "radar", "build", "clone", "freeze", "purge" }
    local Names = { "ONE", "TWO", "THREE", "FOUR", "FIVE", "SIX", "SEVEN", "EIGHT", "NINE" }
    local function Fire(n)
        ExecuteInGameThread(function()
            pcall(function()
                if not PakPanelMouseOn then return end
                local idx = CurrentTabIndex()
                local list, tag
                if idx == 12 then list, tag = Plus, "jplus"
                elseif idx == 13 then list, tag = Pro, "jpro"
                else return end
                local what = list[n]
                if not what or type(JXMemberRun) ~= "function" then return end
                JXMemberRun(tag, { what })
                Log(string.format("PAGEKEY| %s %s (page %d key %d)", tag, what, idx, n))
            end)
        end)
    end
    
    local Armed = false
    JXRegCmd("jpagekeys", function(FullCommand, Parameters, Ar)
        local what = tostring((Parameters and Parameters[1]) or "status"):lower()
        if what == "on" then
            if Armed then Log("page keys: already armed"); return end
            local ok = 0
            for i, kn in ipairs(Names) do
                local k = Key and Key[kn] or nil
                if k then
                    local n = i
                    local good = pcall(RegisterKeyBind, k, function() Fire(n) end)
                    if good then ok = ok + 1 end
                end
            end
            Armed = true
            Log(string.format("page keys armed: %d/9 (PLUS page 1-9 = jplus, PRO page 1-9 = jpro)", ok))
        elseif what == "off" then
            Armed = false
            Log("page keys disarmed (the binds stay registered until the game restarts, but the handler no longer fires)")
        else
            Log(string.format("page keys: %s (jpagekeys on|off)", Armed and "ARMED" or "not armed - the panel tabs still work)"))
        end
    end)

    ExecuteWithDelay(25000, function()
        ExecuteInGameThread(function()
            pcall(function()
                local ok = 0
                for i, kn in ipairs(Names) do
                    local k = Key and Key[kn] or nil
                    if k then
                        local n = i
                        if pcall(RegisterKeyBind, k, function() Fire(n) end) then ok = ok + 1 end
                    end
                end
                Armed = true
                Log(string.format("page keys auto-armed: %d/9 (jpagekeys off to disable)", ok))
            end)
        end)
    end)
    
end
JXPageKeys()

function JXPagesAndCode()
    local Verified, VerifiedFor = false, ""

    local function NameOf(obj)
        local n = nil
        pcall(function() n = obj:GetName() end)
        return tostring(n)
    end

    local function DumpPages(tag)
        ExecuteInGameThread(function()
            pcall(function()
                local sw = AcquireTabSwitcher and AcquireTabSwitcher() or nil
                if not JXAlive(sw) then
                    Log("PAGES| panel switcher not reachable (open the panel first)")
                    return
                end
                local n = 0
                pcall(function() n = sw:GetChildrenCount() end)
                Log(string.format("PAGES(%s)| switcher %s has %d page(s)", tostring(tag), NameOf(sw), n))
                for i = 0, n - 1 do
                    local ch = nil
                    pcall(function() ch = sw:GetChildAt(i) end)
                    if ch then
                        local vis, kids = nil, nil
                        pcall(function() vis = ch:GetVisibility() end)
                        pcall(function() kids = ch:GetChildrenCount() end)
                        Log(string.format("PAGES|   [%2d] %-22s vis=%s children=%s",
                            i, NameOf(ch), tostring(vis), tostring(kids)))
                    end
                end
            end)
        end)
    end
    JXRegCmd("jpages", function() DumpPages("cmd") end)
    
    ExecuteWithDelay(45000, function() pcall(DumpPages, "boot") end)

    local function Checksum(s)
        local h = 7
        for i = 1, #s do
            h = (h * 31 + s:byte(i)) % 1000003
        end
        return h
    end

    local function CodeFor(who, day)
        local salt = "JXL"
        return string.format("%06d", Checksum(who .. "|" .. day .. "|" .. salt))
    end

    JXRegCmd("jcode", function(FullCommand, Parameters, Ar)
        local sub = (Parameters and Parameters[1]) or "status"
        local day = os.date and os.date("%Y-%m-%d") or "?"
        if sub == "gen" then
            local who = (Parameters and Parameters[2]) or ""
            if who == "" then
                pcall(function()
                    local PC = UEHelpers.GetPlayerController()
                    who = (PC and PlayerName(PC.PlayerState)) or ""
                end)
            end
            if who == "" then Log("CODE| usage: jcode gen <player name>"); return end
            Log(string.format("CODE| verification code for %s (%s): %s", who, day, CodeFor(who, day)))
            return
        end
        if sub == "status" then
            Log(string.format("CODE| verified=%s for=%s", tostring(Verified), tostring(VerifiedFor)))
            return
        end
        
        local code = sub
        local me = ""
        pcall(function()
            local PC = UEHelpers.GetPlayerController()
            me = (PC and PlayerName(PC.PlayerState)) or ""
        end)
        if me == "" or me:find("TrivialObject", 1, true) then
            pcall(function() me = (JXIdent and JXIdent()) or "" end)
        end
        local want = CodeFor(me, day)
        if code == want then
            Verified, VerifiedFor = true, me
            Log(string.format("CODE| verified OK for %s - member tier unlocked for this session", tostring(me)))
            pcall(function()
                if type(JXWL) == "table" and JXWL.SetLevel then JXWL.SetLevel(5.5) end
            end)
        else
            Log(string.format("CODE| refused: %s is not the code for %s on %s (host runs: jcode gen %s)",
                tostring(code), tostring(me), day, tostring(me)))
        end
    end)

    Log("pages+code ready: jpages (page map), jcode gen <name> | jcode <code> | jcode status")
end
JXPagesAndCode()

function JXLateReplay()
    local done = false
    ExecuteWithDelay(30000, function()
        ExecuteInGameThread(function()
            if done then return end
            done = true
            pcall(function()
                local wid = JXWorldId and JXWorldId() or nil
                
                if false and type(JXReplayLoader) == "function" then
                    JXReplayLoader("late30", wid)
                    Log("LATE| replay pass at 30 s issued")
                end
                if type(JXReplaySweep) == "function" then
                    JXReplaySweep("late30", wid)
                end
            end)
        end)
    end)
    Log("late replay armed (30 s)")
end
JXLateReplay()

function JXFinishPack()
    local function Say(s) Log("[JX] " .. tostring(s)) end

    JXRegCmd("jspat", function(FullCommand, Parameters, Ar)
        JX = JX or {}
        local m = (Parameters and Parameters[1]) or "status"
        if m == "feet" or m == "front" or m == "cube" then
            JX.spawnAt = m
            Say("spawn placement = " .. m .. "  (feet = under you, front = aim ray, cube = jmark cube)")
        else
            Say("spawn placement = " .. tostring(JX.spawnAt or "feet") .. "  (jspat feet|front|cube)")
        end
    end)

    JXRegCmd("jinspect", function(FullCommand, Parameters, Ar)
        local q = (Parameters and Parameters[1]) or ""
        ExecuteInGameThread(function()
            pcall(function()
                local states = UEHelpers.GetAllPlayerStates and UEHelpers.GetAllPlayerStates() or nil
                if not states then Say("no player states readable yet"); return end
                for i = 1, #states do
                    local PS = states[i]
                    if PS and PS:IsValid() then
                        local nm = ""
                        pcall(function() nm = PS:GetPlayerName() or "" end)
                        if nm == "" then pcall(function() nm = PlayerName(PS) or "" end) end
                        if q == "" or nm:lower():find(q:lower(), 1, true) then
                            local id, lvl, ban = "?", "?", "no"
                            pcall(function() id = PlayerId(PS) or "?" end)
                            pcall(function() lvl = (JXWL and JXWL.LevelOf and JXWL.LevelOf(nm)) or "?" end)
                            pcall(function() ban = IsBlacklisted(nm, id) and "yes" or "no" end)
                            Say(string.format("PLAYER| %-20s id=%-22s whitelist=%-5s blacklisted=%s",
                                nm, tostring(id), tostring(lvl), tostring(ban)))
                        end
                    end
                end
            end)
        end)
    end)

    JXRegCmd("jams", function()
        ExecuteInGameThread(function()
            pcall(function()
                local map = CurrentMapName and CurrentMapName() or "?"
                Say("JXAMS (per-map saves) - current map: " .. tostring(map))
                local dir = ModDir .. "saves/"
                local n = 0
                local f = io.open(dir .. "index.txt", "r")
                if f then
                    for line in f:lines() do
                        if line:match("%S") then
                            Say("   " .. line)
                            n = n + 1
                        end
                        if n >= 20 then break end
                    end
                    f:close()
                end
                if n == 0 then Say("   (no index yet - jsave writes one; jsave [note] to snapshot this map)") end
                Say("   jsave [note] | jload [key] | jslots | jxdata list|status|save|load")
            end)
        end)
    end)

    Log("finish pack ready: jspat feet|front|cube, jinspect <player>, jams")
end
JXFinishPack()

function JXAllActors()
    local Last = { rows = {}, total = 0 }

    local function Census(filter)
        local counts, names = {}, {}
        pcall(function()
            local all = FindAllOf("Actor")
            if not all then return end
            for _, a in pairs(all) do
                if JXAlive(a) then
                    local cn = nil
                    pcall(function() cn = JXName(a:GetClass()) end)
                    if cn and cn ~= "" then
                        if not filter or cn:lower():find(filter:lower(), 1, true) then
                            counts[cn] = (counts[cn] or 0) + 1
                        end
                    end
                end
            end
        end)
        for cn in pairs(counts) do names[#names + 1] = cn end
        table.sort(names, function(x, y)
            if counts[x] ~= counts[y] then return counts[x] > counts[y] end
            return x < y
        end)
        local rows, total = {}, 0
        for _, cn in ipairs(names) do
            rows[#rows + 1] = { name = cn, count = counts[cn] }
            total = total + counts[cn]
        end
        return rows, total
    end

    local function Write(rows, total, what)
        pcall(function()
            local f = io.open(ModDir .. "logs/all_actors.txt", "w")
            if f then
                f:write("actor census - " .. tostring(what) .. " - total " .. tostring(total) .. "\r\n")
                for _, r in ipairs(rows) do
                    f:write(string.format("%6d  %s\r\n", r.count, r.name))
                end
                f:close()
            end
        end)
    end

    JXRegCmd("jall", function(FullCommand, Parameters, Ar)
        local sub = tostring((Parameters and Parameters[1]) or ""):lower()
        -- r56: local chat-echo - FSay is a nested local elsewhere in this
        -- file and was nil inside this handler (jall replies never showed)
        local FSay = function(s) Log(s) end
        ExecuteInGameThread(function()
            pcall(function()
                if sub == "spawn" then
                    local n = tonumber((Parameters and Parameters[2]) or "") or 0
                    local r = Last.rows[n]
                    if not r then FSay("jall spawn: run 'jall' first, then 'jall spawn <n>' with 1.." .. #Last.rows); return end
                    local leaf = r.name:match("([%w_%-]+)_C$") or r.name:match("([%w_%-]+)$")
                    if not leaf then FSay("jall spawn: cannot derive a class leaf from " .. r.name); return end
                    local ok, a = pcall(function() return J3SpawnAt(leaf, 0, 0, 0, 0, nil) end)
                    FSay("jall spawn " .. n .. " (" .. r.name .. "): " .. (JXAlive(a) and "spawned at your feet" or "refused (not instantiable from Lua)"))
                    return
                end
                local filter = (sub ~= "" and sub ~= "all") and sub or nil
                local rows, total = Census(filter)
                Last.rows, Last.total = rows, total
                Write(rows, total, filter or "all classes")
                Log(string.format("JALL| %s: %d class(es), %d actor(s) - full list in logs/all_actors.txt",
                    filter and ("filter '" .. filter .. "'") or "full census", #rows, total))
                local top = math.min(#rows, 40)
                for i = 1, top do
                    Log(string.format("JALL| %4d x %s", rows[i].count, rows[i].name))
                end
                if #rows > top then Log(string.format("JALL| ... %d more class(es) in the file", #rows - top)) end
                FSay(string.format("jall: %d actor(s) in %d class(es)%s - top list in the log, file saved",
                    total, #rows, filter and ("  filter=" .. filter) or ""))
            end)
        end)
    end)

    Log("all-actors census ready: jall | jall <filter> | jall spawn <n>")
end
JXAllActors()

do
    local sd = _G.JXSidecarDir or ""
    local mc = loadfile(sd .. "Core_Popup.lua")
    if mc then
        local okm, merr = pcall(mc)
        if not okm then Log("Core_Popup.lua load error: " .. tostring(merr)) end
    else
        Log("Core_Popup.lua not found (non-fatal)")
    end
end

do -- r17: native companion (C++ sampler -> logs/NativeStats.json)
    local sd0 = _G.JXSidecarDir or ""
    local exe = sd0 .. "JxNative.exe"
    local okf = false
    pcall(function()
        local h = io.open(exe, "rb")
        if h then okf = true; h:close() end
    end)
    local stopped = false
    pcall(function()
        local h = io.open(sd0 .. "../config/jxnative.stop", "r")
        if h then stopped = true; h:close() end
    end)
    if okf and not stopped then
        ExecuteWithDelay(30000, function()
            pcall(function()
                os.execute('start "" /b "' .. exe .. '" "' .. sd0 .. '../"')
            end)
        end)
        Log("JxNative launcher armed: C++ sampler starts at +30 s (config/jxnative.stop disables)")
    elseif stopped then
        Log("JxNative disabled by jxnative.stop")
    end
end

do -- r16 split: env bridge for Core_Crash.lua
    _G.JXEnv.ModDir = ModDir
end
do
    local sd = _G.JXSidecarDir or ""
    local mc = loadfile(sd .. "Core_Crash.lua")
    if mc then
        local okm, merr = pcall(mc)
        if not okm then Log("Core_Crash.lua load error: " .. tostring(merr)) end
    else
        Log("Core_Crash.lua not found (non-fatal)")
    end
end

do -- r16 split: env bridge for Core_Reliab.lua
    _G.JXEnv.JXAlive = JXAlive
    -- r56: live accessors - AssertPage read PakPanelMouseOn/TabIndex/
    -- AcquireTabSwitcher as nil globals inside the sidecar and never ran
    _G.JXEnv.AcquireTabSwitcher = AcquireTabSwitcher
    _G.JXEnv.IsPanelMouseOn = function() return PakPanelMouseOn end
    _G.JXEnv.GetTabIndex = function() return TabIndex end
end
do
    local sd = _G.JXSidecarDir or ""
    local mc = loadfile(sd .. "Core_Reliab.lua")
    if mc then
        local okm, merr = pcall(mc)
        if not okm then Log("Core_Reliab.lua load error: " .. tostring(merr)) end
    else
        Log("Core_Reliab.lua not found (non-fatal)")
    end
end

do -- r46 split: tiered blacklist + server sync + spread (Core_Black.lua)
    _G.JXEnv.ModDir = ModDir
    do
        local sd = _G.JXSidecarDir or ""
        local mc = loadfile(sd .. "Core_Black.lua")
        if mc then
            local okm, merr = pcall(mc)
            if not okm then Log("Core_Black.lua load error: " .. tostring(merr)) end
        else
            Log("Core_Black.lua not found (non-fatal)")
        end
    end
end

do -- r16 split: env bridge for Core_Ams.lua
    _G.JXEnv.ModDir = ModDir
    _G.JXEnv.JXAlive = JXAlive
    _G.JXEnv.JXName = JXName
end
do
    local sd = _G.JXSidecarDir or ""
    local mc = loadfile(sd .. "Core_Ams.lua")
    if mc then
        local okm, merr = pcall(mc)
        if not okm then Log("Core_Ams.lua load error: " .. tostring(merr)) end
    else
        Log("Core_Ams.lua not found (non-fatal)")
    end
end

function JXCatVerify()
    local function TestOne(path)
        local cls = nil
        pcall(function()
            local leaf = path:match("/([^/]+)$")
            if path:find("/Script/", 1, true) then
                cls = J3LoadObject(path)
            else
                cls = leaf and J3LoadObject(path .. "." .. leaf .. "_C") or nil
            end
        end)
        if cls and cls:IsValid() then
            return true
        end
        return false
    end

    local function Run(tag)
        local map = {}
        pcall(function() if JXCatLoad then map = JXCatLoad() or {} end end)
        local total, good = 0, 0
        local out = {}
        pcall(function()
            for name, e in pairs(map) do
                total = total + 1
                if TestOne(e.path) then
                    good = good + 1
                    out[#out + 1] = name .. " = " .. e.path
                end
            end
        end)
        Log(string.format("CATVERIFY(%s)| %d/%d catalog path(s) load in this game version", tostring(tag), good, total))
        if total == 0 then Log("CATVERIFY(" .. tostring(tag) .. ")| catalog EMPTY - load failed, check the r3.70 early-root patch") end
        local h = io.open(ModDir .. "config/spawn_catalog_working.txt", "w")
        if h then
            
            h:write(os.date("%Y-%m-%d") .. "\r\n")
            for _, l in ipairs(out) do h:write(l .. "\r\n") end
            h:close()
            Log(string.format("catalog verified: %d working path(s) written", good))
        end
    end

    JXRegCmd("jcatverify", function()
        ExecuteInGameThread(function() pcall(function() Run("cmd") end) end)
    end)

    local cache = ModDir .. "config/spawn_catalog_working.txt"
    local stale = true
    pcall(function()
        local fi = io.open(cache, "r")
        if fi then
            local first = fi:read("*l")
            local n = 0
            for _ in fi:lines() do n = n + 1 end
            fi:close()
            if first and n > 50 then
                local y, mo, d = first:match("^(%d%d%d%d)%-(%d%d)%-(%d%d)")
                if y then
                    local age = os.time() - os.time({ year = y, month = mo, day = d, hour = 12 })
                    
                    if age < 0 then age = 0 end
                    if age < 7 * 86400 then stale = false end
                end
            end
        end
    end)
    if stale then
        ExecuteWithDelay(40000, function()
            ExecuteInGameThread(function() pcall(function() Run("boot") end) end)
        end)
        Log("catalog verify ready: boot pass at 40 s (jcatverify to rerun)")
    else
        
        pcall(function()
            local fi = io.open(cache, "r")
            if fi then
                local body = fi:read("*a")
                fi:close()
                body = body:gsub("^%S*\r?\n", os.date("%Y-%m-%d") .. "\r\n", 1)
                local fo = io.open(cache, "w")
                if fo then fo:write(body); fo:close() end
            end
        end)
        Log("catalog verify ready: cached list is fresh - boot pass SKIPPED (boot-speed r9.3; jcatverify to force)")
    end
end
JXCatVerify()

JXExecutor = function(cmd)
    local done = false
    pcall(function()
        local pc = UEHelpers.GetPlayerController()
        if JXAlive(pc) then done = JXExecCmd(pc, cmd) end
    end)
    return done
end

JXSpawnClassOf = function(cls)
    local made = nil
    pcall(function()
        if not JXAlive(cls) then return end
        local px, py, pz, yaw = 0, 0, 0, 0
        pcall(function()
            local pc = UEHelpers.GetPlayerController()
            local pawn = pc and pc.Pawn
            if JXAlive(pawn) then
                local l = pawn:K2_GetActorLocation()
                local r = pawn:K2_GetActorRotation()
                px, py, pz, yaw = l.X, l.Y, l.Z + 60, (r and r.Yaw or 0)
                local dir = math.rad(yaw)
                px = px + math.sin(dir) * 220
                py = py + math.cos(dir) * 220
            end
        end)
        if px == 0 and py == 0 and pz == 0 then return end
        if type(JxActor) == "table" and type(JxActor.spawn) == "function" then
            pcall(function() made = JxActor.spawn(cls, px, py, pz, yaw) end)
        end
    end)
    return made
end

do
    local ok, panels = false, "retired r14: HUD canvas has no dispatch on native AHUD (pak shell is the display path)"
    if ok and type(panels) == "table" and type(panels.Install) == "function" then
        pcall(panels.Install, JXExecutor, { UEHelpers = UEHelpers })
        _G.JxPanels = panels   
        
        local function bindKey(name, fn)
            local k = nil
            pcall(function() k = Key[name] end)
            if k == nil or k == 0 then return false end
            return pcall(RegisterKeyBind, k, fn)
        end
        local toggle = function() ExecuteInGameThread(function() pcall(panels.Toggle) end) end
        local bound = bindKey("F8", toggle)
        bindKey("F7", toggle)
        Log("member panel ready: F8 or F7 toggles the Lua-drawn PLUS/PRO/ACTORS panel (key bound="
            .. tostring(bound) .. ")")
    else
        Log("member panel NOT loaded: require('JxPanels') -> " .. tostring(panels))
    end
end

end)

do
    do -- r16 Core_* sidecar loader (JXEnv bridge + deferred load)
    _G.JXEnv = _G.JXEnv or {}
    _G.JXEnv.Log = Log
    _G.JXEnv.UEHelpers = UEHelpers
    _G.JXEnv.ModDir = ModDir
    _G.JXEnv.JXAlive = JXAlive
    _G.JXEnv.JXName = JXName
    _G.JXEnv.JXQueue = JXQueue
    _G.JXEnv.JXSay = JXSay
    _G.JXEnv.JXSidecarDir = _G.JXSidecarDir
    local coreMods = { "Core_Perf.lua", "Core_Popup.lua", "Core_WL.lua", "Core_Crash.lua", "Core_Reliab.lua", "Core_Ams.lua" }
    for _, cn in ipairs(coreMods) do
        local mc = loadfile((_G.JXSidecarDir or "") .. cn)
        if mc then
            local okm, merr = pcall(mc)
            if okm then Log(cn .. " loaded (Core sidecar)")
            else Log(cn .. " load error: " .. tostring(merr)) end
        else
            Log(cn .. " not found (non-fatal)")
        end
    end
end

do -- r19: new UI from Lua (JxNewUI)
    local okn, nui = pcall(require, "JxNewUI")
    if okn and type(nui) == "table" and type(nui.Install) == "function" then
        pcall(nui.Install, JXExecutor, { UEHelpers = UEHelpers })
        _G.JxNewUI = nui
        Log("JxNewUI ready: jnewui toggle (new UI from Lua)")
    else
        Log("JxNewUI NOT loaded: " .. tostring(nui))
    end
end

do -- r35: actor generator wiring (定位/搜索/生成 on the 实体 page)
    local oka, aui = pcall(require, "JxActorUI")
    if oka and type(aui) == "table" and type(aui.Install) == "function" then
        pcall(aui.Install)
        Log("JxActorUI ready: pin/search/spawn wiring")
    else
        Log("JxActorUI NOT loaded: " .. tostring(aui))
    end
end


local okai, ai = pcall(require, "JxAI")
    if okai and type(ai) == "table" and type(ai.Install) == "function" then
        pcall(ai.Install, JXExecutor, { UEHelpers = UEHelpers })
        _G.JxAI = ai
        Log("JxAI ready: chat jai <anything in Chinese> + PRO-only AI tab on canvas")
    else
        Log("JxAI NOT loaded: require('JxAI') -> " .. tostring(ai))
    end
end

Log("boot probe: chat/JxPanels section done")

;pcall(function()
    local names = {"jxsearch", "jxsearchprev", "jxsearchnext", "jxsearchfilter"}
    for _, name in ipairs(names) do
        if JX.Cmd and JX.Cmd[name] ~= nil then
            Log("actor search registration refused: " .. name)
            return
        end
    end
    local root, fields = nil, nil
    local function alive(o)
        if o == nil then return false end
        local ok, value = pcall(function() return o:IsValid() end)
        return ok and value == true
    end
    local function acquire()
        if alive(root) and fields then
            local valid = true
            for i = 1, 11 do valid = valid and alive(fields[i]) end
            if valid then return root end
        end
        root, fields = nil, nil
        
        local w = FindFirstOf("WBP_JinxingRoot_C")
        if not alive(w) then return nil end
        local refs = {}
        for i = 0, 10 do
            refs[i+1] = w[i == 10 and "JxSearchStatus" or ("JxSearchRow" .. i)]
            if not alive(refs[i+1]) then return nil end
        end
        root, fields = w, refs
        return root
    end
    local pending, queued = nil, false
    local function render(view)
        pending = view
        if queued then return end
        queued = true
        local ok, err = pcall(ExecuteInGameThread, function()
            queued = false
            local latest = pending; pending = nil
            local good, failure = pcall(function()
                local w = acquire()
                if not w then Log("actor search: compiled search widget unavailable"); return end
                for i = 0, 9 do
                    if not alive(w) or not alive(fields[i+1]) then root, fields = nil, nil; return end
                    
                    w["JxSearchSet" .. i](w, latest.rows[i+1])
                end
                if alive(w) and alive(fields[11]) then w:JxSearchSet10(latest.status) end
            end)
            if not good then root, fields = nil, nil; Log("actor search UI update failed: " .. tostring(failure)) end
        end)
        if not ok then queued = false; Log("actor search dispatch failed: " .. tostring(err)) end
    end
    
    local search, searchErr = nil, nil
    local function ensureSearch()
        if search then return search end
        if searchErr then return nil end
        local ok, built = pcall(function()
            local directory
            if debug and debug.getinfo then
                local info = debug.getinfo(1, "S")
                local src = info and info.source
                if type(src) == "string" and src:sub(1,1) == "@" then
                    directory = src:sub(2):gsub("\\", "/"):match("^(.*[/])[^/]+$")
                end
            end
            directory = directory or (tostring(ModDir):gsub("\\", "/"):gsub("/?$", "/") .. "Scripts/")
            local factory = assert(loadfile(directory .. "JxActorSearch.lua"))()
            local data = assert(loadfile(directory .. "JxActorSearchData.lua"))()
            return factory.new(data, {render = render})
        end)
        if not ok then
            searchErr = tostring(built)
            Log("actor search unavailable: " .. searchErr)
            return nil
        end
        search = built
        Log("actor search: catalog loaded on first use (lazy, 8.8 MB held out of boot)")
        return search
    end
    
    JXRegCmd("jxsearch", function(full)
        local s = ensureSearch(); if s then return s.command(full) end return true
    end)
    JXRegCmd("jxsearchprev", function()
        local s = ensureSearch(); if s then s.prev() end return true
    end)
    JXRegCmd("jxsearchnext", function()
        local s = ensureSearch(); if s then s.next() end return true
    end)
    JXRegCmd("jxsearchfilter", function()
        local s = ensureSearch(); if s then s.filter() end return true
    end)
end)

Log("boot probe: actor search section done (lazy)")

;

do
    local function SSay(s) Log("[jxserver] " .. tostring(s)) end
    Log("[jxserver] boot: block entered")
    local CfgFile   = ModDir .. "config/jxserver.txt"
    local CacheFile = ModDir .. "config/whitelist_remote.txt"
    local Srv = { url = "", names = {}, n = 0, lastSync = "never", watch = 0 }

    local function ReadUrl()
        local f = io.open(CfgFile, "r")
        if not f then return "" end
        for line in f:lines() do
            local t = line:gsub("^%s+", ""):gsub("%s+$", "")
            if t:sub(1, 4) == "http" then f:close() return t end
        end
        f:close()
        return ""
    end

    local function ParseList(path)
        local out = {}
        local f = io.open(path, "r")
        if not f then return out end
        for line in f:lines() do
            local t = line:gsub("^%s+", ""):gsub("%s+$", "")
            if t ~= "" and t:sub(1, 1) ~= ";" and t:sub(1, 1) ~= "#" then
                out[t:lower()] = t
            end
        end
        f:close()
        return out
    end

    local function CountKeys(t)
        local n = 0
        for _ in pairs(t) do n = n + 1 end
        return n
    end

    local function UrlSafe(u)
        if type(u) ~= "string" then return false end
        local scheme, rest = u:match("^(%a[%w+.-]*)://(.+)$")
        if not scheme then return false end
        scheme = scheme:lower()
        if scheme ~= "http" and scheme ~= "https" then return false end
        local host = rest:match("^([^/:?#]+)")
        if not host then return false end
        host = host:lower()
        
        if host:find("[:%[%]]") then return false end
        if host:find("@") then return false end
        if host:match("^[%d%.]+$") or host:find("^0[xX]") then return false end
        if host == "localhost" or host:sub(1, 4) == "127." then return false end
        if host:sub(1, 8) == "169.254." then return false end
        if host:sub(1, 3) == "10." then return false end
        if host:sub(1, 8) == "192.168." then return false end
        local a, b = host:match("^172%.(%d+)%.(%d+)")
        if a and tonumber(a) >= 16 and tonumber(a) <= 31 then return false end
        if host == "0.0.0.0" then return false end
        if host:find("%.local$") or host:find("%.internal$") then return false end
        if host:sub(1, 3) == "::1" or host:sub(1, 5) == "fe80:" then return false end
        return true
    end

    local function Sync()
        Srv.url = ReadUrl()
        if Srv.url == "" then
            SSay("no URL - run: jxserver url https://raw.githubusercontent.com/<user>/<repo>/main/whitelist.txt")
            return false
        end
        if not UrlSafe(Srv.url) then
            SSay("configured URL rejected by the safety check (http/https only, no localhost/private hosts)")
            return false
        end
        local curl = "C:\\Windows\\System32\\curl.exe"
        local probe = io.open(curl, "rb")
        if probe then probe:close() else curl = "curl" end
        
        local function Fetch(url)
            pcall(function()
                -- r46: --connect-timeout 3 - a BLOCKED host (github direct
                -- from CN) used to eat the whole -m 10 on every channel;
                -- -f so a 404 page body never lands in the cache as names
                os.execute(string.format('%s -4 -s -f --connect-timeout 3 -m 8 -L "%s" -o "%s"',
                    curl, url, CacheFile:gsub("/", "\\")))
            end)
            return CountKeys(ParseList(CacheFile))
        end
        local got = Fetch(Srv.url)
        local via = "direct"
        if got == 0 and Srv.url:find("githubusercontent.com", 1, true) then
            
            via = "ghproxy.net fallback"
            got = Fetch("https://ghproxy.net/" .. Srv.url)
        end
        Srv.names = ParseList(CacheFile)
        if type(JX) == "table" and type(JX.CleanNames) == "function" then
            Srv.names = JX.CleanNames(Srv.names)
        end
        Srv.n = CountKeys(Srv.names)
        Srv.lastSync = os.date("%Y-%m-%d %H:%M:%S") .. " via " .. via
        SSay("server whitelist synced: " .. tostring(Srv.n) .. " rule(s) via " .. via)
        Log("SRV| sync ok: " .. tostring(Srv.n) .. " rule(s) via " .. via)
        if Srv.n == 0 then
            SSay("sync failed on both the direct URL and the mirror (" .. CacheFile .. ")")
            return false
        end
        
        local merged = 0
        pcall(function()
            local wl = JX.WLRef
            if wl and wl.list then
                for k in pairs(Srv.names) do
                    if not wl.list[k] then wl.list[k] = true; merged = merged + 1 end
                end
            end
        end)
        pcall(function()
            local wlFile = (JX.WLRef and JX.WLRef.file) or (JXRootOr .. "config/whitelist.txt")
            
            local have = {}
            local rf = io.open(wlFile, "r")
            if rf then
                for line in rf:lines() do
                    local t = line:gsub("^%s+", ""):gsub("%s+$", "")
                    if t ~= "" then have[t:lower()] = true end
                end
                rf:close()
            end
            local fresh = {}
            for k in pairs(Srv.names) do
                if not have[k] then fresh[#fresh + 1] = Srv.names[k] end
            end
            if #fresh > 0 then
                local f = io.open(wlFile, "a")
                if f then
                    for _, nm in ipairs(fresh) do f:write(nm .. "\n") end
                    f:close()
                end
            end
        end)
        SSay(string.format("synced %d name(s) from GitHub (%d newly merged into the live gate); %s",
            Srv.n, merged, Srv.lastSync))
        return true
    end

    _G.JXServerSync = Sync -- r17.4: exposed for map-change auto refresh

    local function RoomLines()
        local lines, total = {}, 0
        pcall(function()
            local states = UEHelpers.GetAllPlayerStates()
            if not states then return end
            local myName = ""
            pcall(function()
                local pc = UEHelpers.GetPlayerController()
                if pc and pc:IsValid() and pc.PlayerState and pc.PlayerState:IsValid() then
                    myName = PlayerName(pc.PlayerState)
                end
            end)
            for i = 1, #states do
                local PS = states[i]
                if PS and PS:IsValid() then
                    total = total + 1
                    local nm = PlayerName(PS)
                    local ping = nil
                    pcall(function() ping = tonumber(PS.ExactPing) end)
                    if ping == nil then pcall(function() ping = tonumber(PS.Ping) end) end
                    local wl = "gate-off"
                    if JX.WLRef and JX.WLRef.on then
                        wl = (JX.WLRef.list[nm:lower()] ~= nil) and "listed" or "NOT-listed"
                    end
                    lines[#lines + 1] = string.format("  %-20s ping=%-6s wl=%s%s",
                        nm, ping ~= nil and string.format("%.0f", ping) or "?",
                        wl, (nm == myName) and " [you]" or "")
                end
            end
        end)
        return lines, total
    end

    local function Status()
        local info = (type(JXTravelInfo) == "function") and JXTravelInfo() or {}
        if Srv.url == "" then Srv.url = ReadUrl() end
        SSay(string.format("server whitelist: %d remote name(s), synced %s", Srv.n, Srv.lastSync))
        SSay("url: " .. (Srv.url ~= "" and Srv.url or "(not set - jxserver url <raw-url>)"))
        SSay("gate: " .. ((JX.WLRef and JX.WLRef.on) and "ON (jwlist off opens for everyone)"
            or "OFF (list loaded but not enforced; jwlist on)"))
        SSay(string.format("room: netmode=%s authority=%s players=%d remotes=%d",
            tostring(info.netMode), tostring(info.authority),
            tonumber(info.players) or 0, tonumber(info.remotes) or 0))
        local lines, total = RoomLines()
        for _, l in ipairs(lines) do Log(l) end
        SSay(total .. " player(s); ping column is the engine's own ExactPing/Ping property")
    end

    local function Watch(left)
        if Srv.watch <= 0 then return end
        if left <= 0 or JXBusy() then
            SSay("watch ended")
            return
        end
        local lines, total = RoomLines()
        SSay("watch " .. (Srv.watch - left + 1) .. "/" .. Srv.watch .. " - " .. total .. " player(s)")
        for _, l in ipairs(lines) do Log(l) end
        ExecuteWithDelay(3000, function()
            ExecuteInGameThread(function() pcall(function() Watch(left - 1) end) end)
        end)
    end

    JXRegCmd("jxserver", function(FullCommand, Parameters)
        local sub = (Parameters and Parameters[1]) or "status"
        if sub == "url" then
            local u = (Parameters and Parameters[2]) or ""
            if not UrlSafe(u) then
                SSay("url rejected: http/https only, and not localhost/private/loopback hosts")
                SSay("usage: jxserver url https://raw.githubusercontent.com/<user>/<repo>/main/whitelist.txt")
                return true
            end
            pcall(function()
                local f = io.open(CfgFile, "w")
                if f then f:write(u .. "\n"); f:close() end
            end)
            SSay("url saved: " .. u .. " (jxserver sync fetches it)")
            return true
        end
        if sub == "sync" then
            -- r17.4: fetch runs on the UE4SS worker thread (os.execute would
            -- otherwise block the game thread for ~3.7 s on every sync)
            ExecuteWithDelay(0, function() pcall(Sync) end)
            SSay("sync running in background - game stays smooth; jxserver status for the result")
            return true
        end
        if sub == "watch" then
            local n = tonumber(Parameters and Parameters[2]) or 10
            if n <= 0 then Srv.watch = 0; SSay("watch stopped"); return true end
            if n > 20 then n = 20 end
            Srv.watch = n
            SSay("watch: " .. n .. " read(s), one every 3 s - jxserver watch 0 stops")
            ExecuteInGameThread(function() pcall(function() Watch(n) end) end)
            return true
        end
        if sub == "status" then
            ExecuteInGameThread(function() pcall(Status) end)
            return true
        end
        SSay("usage: jxserver status | sync | url <raw-url> | watch [0-20]")
        return true
    end)

    Srv.url = ReadUrl()
    if Srv.url == "" then
        SSay("no whitelist URL configured - the boot sync is SKIPPED.")
        SSay("  fix: put the raw url on its own line in " .. CfgFile)
        SSay("  or run: jxserver url https://raw.githubusercontent.com/<user>/<repo>/main/whitelist.txt")
    end
    JX = JX or {}
    JX.CleanNames = function(names)
        local clean = {}
        for k, v in pairs(names) do
            v = tostring(v or k)
            if #v > 0 and #v <= 64
                and not v:find("[%c<>]")
                and not v:find("&", 1, true)
                and not v:find('"', 1, true)
                and not v:find("'", 1, true)
                and not v:find("://", 1, true) then
                clean[v:lower()] = v
            end
        end
        return clean
    end
    if Srv.url ~= "" then
        Srv.names = ParseList(CacheFile)
        if type(JX) == "table" and type(JX.CleanNames) == "function" then
            Srv.names = JX.CleanNames(Srv.names)
        end
        Srv.n = CountKeys(Srv.names)
        if Srv.n > 0 then
            Srv.lastSync = "cached at boot"
            SSay(Srv.n .. " cached whitelist name(s); 'jxserver sync' refreshes from GitHub")
        end
        
        ExecuteWithDelay(8000, function()
            pcall(function()
                SSay("auto-sync starting (jxserver sync runs by itself at boot)")
                Sync()
            end)
        end)
    end
end

Log("boot probe: main.lua chunk complete (EOF)")

pcall(function()
    local f = io.open(ModDir .. "config/autoverify.txt", "r")
    if not f then return end
    f:close()
    pcall(function() os.remove(ModDir .. "config/autoverify.txt") end)
    Log("AUTOVERIFY| armed (Level0 run in 40s)")
    ExecuteWithDelay(40000, function()
        ExecuteInGameThread(function()
            pcall(function()
                Log("AUTOVERIFY| travel -> /Game/Maps/Level0")
                local ok, err = TravelTo("/Game/Maps/Level0")
                Log("AUTOVERIFY| travel ok=" .. tostring(ok) .. " err=" .. tostring(err))
            end)
        end)
        ExecuteWithDelay(15000, function()
            ExecuteInGameThread(function()
                pcall(function()
                    local jp = _G.JxPanels
                    Log("AUTOVERIFY| world=" .. tostring(CurrentMapName())
                        .. " canvas=" .. tostring(jp and jp.open))
                    if jp and not jp.open and type(jp.Open) == "function" then
                        jp.Open()
                    end
                    Log("AUTOVERIFY| SHOWN open=" .. tostring(jp and jp.open))
                end)
            end)
            ExecuteWithDelay(10000, function()
                ExecuteInGameThread(function()
                    local jp = _G.JxPanels
                    Log("AUTOVERIFY| CHECK open=" .. tostring(jp and jp.open)
                        .. " frames=" .. tostring(jp and jp.frames)
                        .. " hookFrames=" .. tostring(jp and jp.hookFrames))
                end)
            end)
        end)
    end)
end)
