
local HS = {
    state = "idle",        
    hunters = {},          
    hiders = {},           
    caught = {},           
    spectator = {},        
    hideMin = 1,
    huntMin = 5,
    maxHunters = 2,
    catchDist = 200,
    tickOn = false,
    tickN = 0,
    minuteMark = 0,
    startLoc = nil,        
    worldRuns = 0,         
}

local function Say(s) print("[HideSeek] " .. tostring(s) .. "\n") end

local function Popup(msg, dur)
    
    pcall(function()
        local KSL = StaticFindObject("/Script/Engine.Default__KismetSystemLibrary")
        if KSL and KSL:IsValid() then
            KSL:PrintString(nil, tostring(msg), true, true,
                { R = 1, G = 0.3, B = 0, A = 1 }, dur or 5.0)
        end
    end)
    local sent = 0
    pcall(function()
        local pcs = FindAllOf("PlayerController")
        if not pcs then return end
        for _, pc in pairs(pcs) do
            if pc and pc:IsValid() then
                if pcall(function() pc:ClientMessage("[躲猫猫] " .. tostring(msg)) end) then
                    sent = sent + 1
                end
            end
        end
    end)
    if sent > 0 then
        Say(msg .. "  (已广播给 " .. sent .. " 名玩家)")
    else
        Say(msg)
    end
end

local function GetPlayers()
    local list = {}
    pcall(function()
        local pcs = FindAllOf("PlayerController")
        if pcs then
            for _, pc in pairs(pcs) do
                if pc and pc:IsValid() then
                    local nm = "?"
                    pcall(function()
                        if pc.PlayerState and pc.PlayerState:IsValid() then
                            nm = tostring(pc.PlayerState.PlayerName)
                        end
                    end)
                    local isLocal = false
                    pcall(function() isLocal = pc:IsLocalController() end)
                    list[#list + 1] = { name = nm, pc = pc, isLocal = isLocal }
                end
            end
        end
    end)
    return list
end

local function GetName(pc)
    local nm = "?"
    pcall(function()
        if pc.PlayerState and pc.PlayerState:IsValid() then
            nm = tostring(pc.PlayerState.PlayerName)
        end
    end)
    return nm
end

local function GetLoc(pawn)
    local loc = nil
    pcall(function() loc = pawn:K2_GetActorLocation() end)
    return loc
end

local function TeleportTo(pc, x, y, z)
    pcall(function()
        if pc.Pawn and pc.Pawn:IsValid() then
            pc.Pawn:K2_SetActorLocation({ X = x, Y = y, Z = z }, false, true)
        end
    end)
end

local function Dist3(a, b)
    local dx, dy, dz = a.X - b.X, a.Y - b.Y, a.Z - b.Z
    return math.sqrt(dx * dx + dy * dy + dz * dz)
end

function HS.Start()
    if HS.state ~= "idle" then
        Say("game already running (state=" .. HS.state .. "). jxhide stop first")
        return false
    end
    local players = GetPlayers()
    if #players < 2 then
        Say("need at least 2 players to start (have " .. #players .. ")")
        return false
    end

    pcall(function()
        local pc = nil
        pcall(function() pc = UEHelpers.GetPlayerController() end)
        if not pc then pcall(function() pc = FindFirstOf("PlayerController") end) end
        if pc and pc:IsValid() and pc.Pawn and pc.Pawn:IsValid() then
            HS.startLoc = pc.Pawn:K2_GetActorLocation()
        end
    end)

    HS.hunters = {}
    HS.hiders = {}
    HS.caught = {}
    HS.spectator = {}
    local indices = {}
    for i = 1, #players do indices[i] = i end
    
    for i = #indices, 2, -1 do
        local j = math.random(i)
        indices[i], indices[j] = indices[j], indices[i]
    end
    local nHunters = math.min(HS.maxHunters, #players - 1)
    if nHunters < 1 then nHunters = 1 end
    for i = 1, nHunters do
        local p = players[indices[i]]
        HS.hunters[p.name:lower()] = true
    end
    for i = nHunters + 1, #players do
        local p = players[indices[i]]
        HS.hiders[p.name:lower()] = true
    end

    HS.gen = (HS.gen or 0) + 1
    HS.state = "hiding"
    HS.tickN = 0
    HS.minuteMark = 0
    HS.worldRuns = (type(JX) == "table" and JX.worldRuns) or 0
    Popup("=== 躲猫猫开始! ===", 5)
    Popup("躲藏时间: " .. HS.hideMin .. " 分钟 | 追捕时间: " .. HS.huntMin .. " 分钟", 5)
    Popup("抓捕者: " .. nHunters .. " 人 | 其他玩家快躲起来!", 5)
    for hn, _ in pairs(HS.hunters) do
        Popup("抓捕者: " .. hn, 5)
    end
    Say("game started: " .. nHunters .. " hunter(s), " .. (#players - nHunters) .. " hider(s)")
    Say("hiding phase: " .. HS.hideMin .. " minute(s)")

    if not HS.tickOn then
        HS.tickOn = true
        ExecuteWithDelay(1000, function()
            ExecuteInGameThread(function() pcall(HS.Tick, 0) end)
        end)
    end
    return true
end

function HS.Stop(reason)
    if HS.state == "idle" then return end
    HS.state = "ended"
    HS.tickOn = false

    Popup("=== 躲猫猫结束 ===", 10)
    if reason then Popup(reason, 10) end

    local caughtN, freeN = 0, 0
    for hn, _ in pairs(HS.hiders) do
        if HS.caught[hn] then caughtN = caughtN + 1
        else freeN = freeN + 1 end
    end
    if freeN > 0 then
        Popup("躲藏成功! " .. freeN .. " 人存活 | 被抓: " .. caughtN .. " 人", 10)
        Say("result: hiders win! " .. freeN .. " survived, " .. caughtN .. " caught")
    else
        Popup("抓捕者胜利! 所有人都被抓到了!", 10)
        Say("result: hunters win! everyone caught")
    end

    local gen = (HS.gen or 0)
    HS.gen = gen
    ExecuteWithDelay(10000, function()
        ExecuteInGameThread(function()
            pcall(function()
                if (HS.gen or -1) ~= gen or HS.state ~= "ended" then
                    Say("cleanup skipped (superseded)")
                    return
                end
                Popup("所有玩家回到出生点", 5)
                local players = GetPlayers()
                for _, p in ipairs(players) do
                    if HS.startLoc then
                        TeleportTo(p.pc, HS.startLoc.X, HS.startLoc.Y, HS.startLoc.Z + 100)
                    end
                end
                
                HS.state = "idle"
                HS.hunters = {}
                HS.hiders = {}
                HS.caught = {}
                HS.spectator = {}
                HS.tickOn = false
                HS.startLoc = nil
                Say("game cleaned up, all players returned to spawn")
            end)
        end)
    end)
end

function HS.Tick(elapsedSec)
    if not HS.tickOn or HS.state == "idle" then return end
    HS.tickN = HS.tickN + 1
    elapsedSec = elapsedSec + 1

    if ((type(JX) == "table" and JX.worldRuns) or 0) ~= HS.worldRuns then
        Say("map changed - game cancelled")
        HS.state = "idle"
        HS.tickOn = false
        return
    end

    local players = GetPlayers()
    for _, p in ipairs(players) do
        local key = p.name:lower()
        if not HS.hunters[key] and not HS.hiders[key] and not HS.spectator[key] then
            HS.spectator[key] = true
            Popup(p.name .. " 中途加入 -> 观战模式", 3)
            Say("new joiner -> spectator: " .. p.name)
        end
    end

    if HS.state == "hiding" then
        
        local totalHide = HS.hideMin * 60
        local remaining = totalHide - elapsedSec
        if remaining <= 0 then
            HS.state = "hunting"
            HS.tickN = 0
            elapsedSec = 0
            HS.minuteMark = 0
            Popup("=== 躲藏结束! 追捕开始! ===", 5)
            Popup("追捕时间: " .. HS.huntMin .. " 分钟", 5)
            Say("hiding phase over, hunting phase started (" .. HS.huntMin .. " min)")
        elseif remaining % 30 < 1 and remaining > 0 then
            Popup("还有 " .. math.ceil(remaining / 1) .. " 秒开始追捕...", 3)
        end
    elseif HS.state == "hunting" then
        
        local totalHunt = HS.huntMin * 60
        local remaining = totalHunt - elapsedSec

        local elapsedMin = math.floor(elapsedSec / 60)
        if elapsedMin > HS.minuteMark then
            HS.minuteMark = elapsedMin
            local minLeft = HS.huntMin - elapsedMin
            if minLeft > 0 then
                Popup("追捕倒计时: " .. minLeft .. " 分钟", 5)
            end
        end

        if remaining <= 60 and remaining > 55 then
            Popup("最后 1 分钟! 抓捕者加速!", 5)
        end

        local hunterLocs = {}
        for _, p in ipairs(players) do
            if HS.hunters[p.name:lower()] and p.pc.Pawn and p.pc.Pawn:IsValid() then
                hunterLocs[#hunterLocs + 1] = { name = p.name, loc = GetLoc(p.pc.Pawn) }
            end
        end
        for _, p in ipairs(players) do
            local key = p.name:lower()
            if HS.hiders[key] and not HS.caught[key] and p.pc.Pawn and p.pc.Pawn:IsValid() then
                local hiderLoc = GetLoc(p.pc.Pawn)
                if hiderLoc then
                    for _, h in ipairs(hunterLocs) do
                        if h.loc and Dist3(hiderLoc, h.loc) < HS.catchDist then
                            HS.caught[key] = true
                            Popup(p.name .. " 被抓到了! (by " .. h.name .. ")", 5)
                            Say("caught: " .. p.name .. " by " .. h.name)
                            
                            if h.loc then
                                TeleportTo(p.pc, h.loc.X, h.loc.Y, h.loc.Z + 50)
                            end
                            break
                        end
                    end
                end
            end
        end

        local freeLeft = 0
        for hn, _ in pairs(HS.hiders) do
            if not HS.caught[hn] then freeLeft = freeLeft + 1 end
        end
        if freeLeft == 0 then
            Popup("抓捕者胜利! 全员落网!", 10)
            HS.Stop("所有人都被抓到了")
            return
        end
        if remaining <= 0 then
            Popup("时间到! 躲藏者胜利!", 10)
            HS.Stop("五分钟到了, 抓捕者失败!")
            return
        end
    end

    ExecuteWithDelay(1000, function()
        ExecuteInGameThread(function() pcall(HS.Tick, elapsedSec) end)
    end)
end

function HS.Status()
    Say("state=" .. HS.state .. " hide=" .. HS.hideMin .. "min hunt=" .. HS.huntMin
        .. "min maxHunters=" .. HS.maxHunters)
    local h, hid, c, s = 0, 0, 0, 0
    for _ in pairs(HS.hunters) do h = h + 1 end
    for _ in pairs(HS.hiders) do hid = hid + 1 end
    for _ in pairs(HS.caught) do c = c + 1 end
    for _ in pairs(HS.spectator) do s = s + 1 end
    Say("hunters=" .. h .. " hiders=" .. hid .. " caught=" .. c .. " spectators=" .. s)
end

JXRegCmd("jxhide", function(FullCommand, Parameters)
    local sub = (Parameters and Parameters[1]) or "status"
    if sub == "start" then
        
        local nh = tonumber(Parameters[2])
        local hm = tonumber(Parameters[3])
        local tm = tonumber(Parameters[4])
        if nh and nh >= 1 and nh <= 4 then HS.maxHunters = math.floor(nh) end
        if hm and hm >= 1 and hm <= 10 then HS.hideMin = math.floor(hm) end
        if tm and tm >= 1 and tm <= 30 then HS.huntMin = math.floor(tm) end
        ExecuteInGameThread(function() pcall(HS.Start) end)
        return true
    end
    if sub == "stop" then
        ExecuteInGameThread(function() pcall(HS.Stop, "手动结束") end)
        return true
    end
    if sub == "status" then
        ExecuteInGameThread(function() pcall(HS.Status) end)
        return true
    end
    Say("usage: jxhide start [hunters 1-4] [hideMin] [huntMin] | stop | status")
    return true
end)

local origWorldReady = JXWorldReady
if origWorldReady then
    JXWorldReady = function(tag, epoch, wid)
        local r = origWorldReady(tag, epoch, wid)
        if HS.state ~= "idle" then
            Say("map changed - game cancelled")
            HS.state = "idle"
            HS.tickOn = false
        end
        return r
    end
end

print("[HideSeek] ready: jxhide start [1-4 hunters] [hideMin] [huntMin] | stop | status\n")

return HS
