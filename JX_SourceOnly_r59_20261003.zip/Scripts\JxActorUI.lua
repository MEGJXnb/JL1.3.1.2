-- JxActorUI.lua r2 (r59) - input + display bridge for the 实体 tab.
--
-- WHY THE REWRITE (all of this is measured, not assumed):
--   r1 waited for widgets named JxActSearch / JxActRes_0..7 / JxActPin /
--   JxActSpawn / JxActStatus. The installed pak (E19AE6B3) contains NONE of
--   them - config/newui_tree.txt, the 535-widget dump of the live shell, has
--   zero JxAct* names. So r1's Wire() could never succeed, and its Poll()
--   re-walked up to 2500 widget nodes every 2 s, 600 times per session, with
--   no IsValid gate anywhere. Those unguarded native touches are exactly what
--   crashlog.txt records as thousands of stepped-over reads inside UE4SS.dll.
--   r1 also bound UMG delegates (OnClicked:Add / OnTextChanged:Add), the
--   pattern this project abandoned in r51 because UE4SS garbage-collects the
--   callback refs ("Ref was not function" / "Freed invalid callbacks").
--
-- WHAT THE PAK ACTUALLY GIVES US (ActorPageV43, verified in the dump):
--   JxSearchHelp, JxSearchInput (the only EditableTextBox in the pak),
--   JxSearchGo / JxSearchPrev / JxSearchNext / JxSearchFilter, JxSearchStatus,
--   JxSearchRow0..9, ActorSubBtn_0..2 -> ActorSubSwitcherV48 with
--   ActorListPageV48 (ActorLst_0..4 + ActorLstTxt_0..4 + ActorLstBox_Info) and
--   ActorPlacePageV48 (ActorPlc_0..5 + ActorPlcTxt_0..5 + ActorCoordBox_Info +
--   ActorPlaceInfoV48). ActorSpawnPageV66 is an empty ScrollBox.
--
-- ARCHITECTURE
--   * no widget construction, no delegates, no tree walk. Widgets come from
--     property access on the shell root (w.JxSearchInput), which is what
--     main.lua's search renderer already proved works, and rows go through the
--     pak's compiled setters w:JxSearchSet0..10(text).
--   * clicks ride JxNewUI's native-state poll: append to JxNewUI.cbsOrder and
--     publish the handler in _G.JXUICBS. ResetWiring() clears both on every
--     world change, so Tick() re-registers whenever our key disappears - that
--     is also what drops every stale widget handle from the previous map.
--   * zero new spawn/placement logic. Every button dispatches a command that
--     already exists and is already gated: jsp (curated catalog spawn), jmark,
--     jkill, jlistplaced, jbox, jsub, jxsearch/prev/next/filter.
--   * J3PaintBox in main.lua is a `return false` stub, so ActorLstBox_Info and
--     ActorCoordBox_Info have never displayed anything. We paint them here.
local M = { name = "JxActorUI", ver = 2 }

local Log = Log or function(s) print("[JxActorUI] " .. tostring(s) .. "\n") end

local S = {
    mode = "cat",          -- cat = curated spawn catalog, idx = big read-only index
    q = "",                -- active query
    hits = {},             -- cat mode: { {name=, sec=, path=, fold=} }
    page = 1,
    sel = nil,             -- selected cat row
    lastBox = "",          -- last text seen in JxSearchInput
    lastType = 0,          -- os.clock of the last text change (debounce)
    pending = false,
    shell = nil,
    cat = nil,             -- pre-folded curated catalog
    catN = 0,
    wired = 0,
    wcache = {},           -- name -> widget, re-validated on every read
}

local PER_PAGE = 10

-- ============ primitives ====================================================
local function Alive(o)
    if o == nil then return false end
    local ok, v = pcall(function() return o:IsValid() end)
    return ok and v == true
end

-- JxNewUI already acquires the RAIL shell (it prefers the rendered instance
-- when several are alive). Borrow its handle instead of running our own
-- FindAllOf; fall back to FindFirstOf only when JxNewUI is not up yet.
local function Shell()
    if Alive(S.shell) then return S.shell end
    -- the shell we had is gone: every widget handle taken from it is now a
    -- dead pointer, so the cache goes with it (this is the r58 lesson).
    S.shell = nil
    S.wcache = {}
    local nu = _G.JxNewUI
    if type(nu) == "table" and Alive(nu.shell) then
        S.shell = nu.shell
        return S.shell
    end
    local ok, w = pcall(function() return FindFirstOf("WBP_JinxingRoot_C") end)
    if ok and Alive(w) then S.shell = w end
    return S.shell
end

-- Two ways in, no third. 1) BindWidget property on the shell root - proven for
-- JxSearchRow*/JxSearchStatus, but a WBP child is only a property when it was
-- marked as a variable, so it cannot be assumed for every button. 2) the tree
-- JxNewUI already walked this pass (JxNewUI.flat). We never walk ourselves.
local function Prop(name)
    -- cache, but never trust it: every hand-out is re-validated, and Wire()
    -- empties the cache on each re-arm so nothing survives a world change.
    local hit = S.wcache[name]
    if hit ~= nil then
        if Alive(hit) then return hit end
        S.wcache[name] = nil
    end
    local w = Shell()
    if w then
        local ok, child = pcall(function() return w[name] end)
        if ok and Alive(child) then S.wcache[name] = child return child end
    end
    local nu = _G.JxNewUI
    if type(nu) == "table" and type(nu.flat) == "table" then
        for i = 1, #nu.flat do
            local e = nu.flat[i]
            if e and e.name == name then
                if Alive(e.w) then S.wcache[name] = e.w return e.w end
                return nil
            end
        end
    end
    return nil
end

local KTL = nil
local function FT(s)
    if KTL == nil then
        pcall(function() KTL = StaticFindObject("/Script/Engine.Default__KismetTextLibrary") end)
    end
    if not KTL then return nil end
    local ok, t = pcall(function() return KTL:Conv_StringToText(tostring(s)) end)
    if ok then return t end
    return nil
end

local function SetTextOn(widget, s)
    if not Alive(widget) then return false end
    local t = FT(s)
    if not t then return false end
    return (pcall(function() widget:SetText(t) end))
end

-- Rows and status prefer the pak's own compiled setters (same primitive
-- main.lua's catalog renderer uses); property+SetText is the fallback.
local function SetRow(i, s)
    local w = Shell()
    if w then
        local ok = pcall(function() w["JxSearchSet" .. i](w, tostring(s)) end)
        if ok then return true end
    end
    return SetTextOn(Prop("JxSearchRow" .. i), s)
end

local function SetStatus(s)
    local w = Shell()
    if w then
        local ok = pcall(function() w:JxSearchSet10(tostring(s)) end)
        if ok then return true end
    end
    return SetTextOn(Prop("JxSearchStatus"), s)
end

local function PaintBox(name, s)
    return SetTextOn(Prop(name), s)
end

-- Dispatch an existing command through main's registry (JXRegCmd stores the
-- raw handler in JX.CmdFn and invokes it as fn(FullCommand, Parameters)).
local function Cmd(name, arg)
    local full = arg and (name .. " " .. tostring(arg)) or name
    local params = {}
    if arg ~= nil and tostring(arg) ~= "" then
        for tok in tostring(arg):gmatch("%S+") do params[#params + 1] = tok end
    end
    local done = false
    pcall(function()
        local JXT = _G.JX
        local fn = (type(JXT) == "table" and type(JXT.CmdFn) == "table") and JXT.CmdFn[name] or nil
        if type(fn) == "function" then
            fn(full, params, nil)
            done = true
        end
    end)
    if not done then
        pcall(function()
            if type(_G.JXExecCmd) == "function" then done = _G.JXExecCmd(full) and true or false end
        end)
    end
    if not done then Log("dispatch FAILED: " .. full) end
    return done
end

-- ============ curated catalog (spawnable) ===================================
local function Fold(s)
    return (tostring(s or ""):lower())
end

-- JXCatLoad is main.lua's loader for config/spawn_catalog.txt
-- ("[section] <name> = /Game/path"). Folding once at build time keeps every
-- later keystroke free of per-row lower() churn.
local function CatBuild(force)
    if S.cat and not force then return S.cat end
    local rows = {}
    pcall(function()
        if type(_G.JXCatLoad) ~= "function" then return end
        local map = _G.JXCatLoad(force and true or false)
        if type(map) ~= "table" then return end
        for nm, e in pairs(map) do
            if type(e) == "table" and type(e.path) == "string" then
                rows[#rows + 1] = {
                    name = tostring(nm),
                    sec = tostring(e.sec or "?"),
                    path = e.path,
                    fold = Fold(nm) .. "\n" .. Fold(e.sec) .. "\n" .. Fold(e.path),
                }
            end
        end
    end)
    table.sort(rows, function(a, b)
        if a.sec ~= b.sec then return a.sec < b.sec end
        return a.name < b.name
    end)
    S.cat = rows
    S.catN = #rows
    Log("curated catalog: " .. #rows .. " spawnable entries (config/spawn_catalog.txt)")
    return rows
end

local function Pages()
    return math.max(1, math.ceil(#S.hits / PER_PAGE))
end

local function CatSearch(q)
    local rows = CatBuild(false)
    local key = Fold(q)
    S.q = tostring(q or "")
    S.hits = {}
    S.page = 1
    for i = 1, #rows do
        local r = rows[i]
        if key == "" or r.fold:find(key, 1, true) then
            S.hits[#S.hits + 1] = r
        end
    end
end

local function PlaceMode()
    local jx = _G.JX
    local m = (type(jx) == "table" and type(jx.spawnAt) == "string") and jx.spawnAt or "feet"
    if m ~= "feet" and m ~= "cube" and m ~= "front" then m = "feet" end
    return m
end

local MODE_ZH = { feet = "脚下", cube = "方块", front = "面前" }

-- ============ render ========================================================
local function StatusLine()
    if S.mode == "idx" then
        return "实体 | 模式=大目录(只读) | 用「生成」请切回策展目录 | 搜索框回车或点搜索"
    end
    local sel = S.sel and S.sel.name or "无"
    return string.format("实体 | 模式=策展目录 | 关键词\"%s\" | 命中 %d/%d | 第 %d/%d 页 | 选中=%s | 落点=%s",
        S.q, #S.hits, S.catN, S.page, Pages(), sel, MODE_ZH[PlaceMode()] or PlaceMode())
end

local function Render()
    if S.mode ~= "cat" then
        -- idx mode belongs to main.lua's jxsearch renderer; only the status
        -- line is ours, and only to say which mode is live.
        SetStatus(StatusLine())
        return
    end
    local base = (S.page - 1) * PER_PAGE
    for i = 0, PER_PAGE - 1 do
        local r = S.hits[base + i + 1]
        if r then
            SetRow(i, string.format("%d. %s  [%s]\n   %s", base + i + 1, r.name, r.sec, r.path))
        else
            SetRow(i, "")
        end
    end
    SetStatus(StatusLine())

    -- ActorListPageV48: the five click slots mirror the top of this page.
    for i = 0, 4 do
        local r = S.hits[base + i + 1]
        SetTextOn(Prop("ActorLstTxt_" .. i), r and (r.name .. "  [" .. r.sec .. "]") or "-")
    end
    if S.sel then
        PaintBox("ActorLstBox_Info", string.format("选中：%s\n分区：%s\n路径：%s\n落点：%s（ActorPlc_4 切换）\n点 ②生成 用 jsp 下发（沿用既有授权门）",
            S.sel.name, S.sel.sec, S.sel.path, MODE_ZH[PlaceMode()] or PlaceMode()))
    else
        PaintBox("ActorLstBox_Info", "还没选中条目。先在搜索框输入关键词，然后点列表里的一行。")
    end

    -- ActorPlacePageV48 labels: say exactly which command each button sends.
    local col = "开"
    pcall(function()
        local a3 = _G.JxActor3
        if type(a3) == "table" and a3.box == false then col = "关" end
    end)
    local plc = {
        "① 定位方块 (jmark)",
        "② 生成选中 (jsp)",
        "删除最后 (jkill last)",
        "已放置列表 (jlistplaced)",
        "落点：" .. (MODE_ZH[PlaceMode()] or PlaceMode()),
        "碰撞：" .. col .. " (jbox)",
    }
    for i = 0, 5 do
        SetTextOn(Prop("ActorPlcTxt_" .. i), plc[i + 1] or "-")
    end
    PaintBox("ActorPlaceInfoV48", string.format("落点模式=%s | 碰撞=%s | 策展库=%d 条\n生成一律走 jsp，保留 Bind/授权规则；坐标框由本页写入（main 的 J3PaintBox 是空桩）",
        MODE_ZH[PlaceMode()] or PlaceMode(), col, S.catN))
end

-- ============ actions =======================================================
local function Select(n)
    local r = S.hits[(S.page - 1) * PER_PAGE + n]
    if not r then
        SetStatus("第 " .. tostring(n) .. " 槽是空的：先搜索或翻页")
        return false
    end
    S.sel = r
    Render()
    Log("selected: " .. r.name .. " -> " .. r.path)
    return true
end

local function SpawnSelected()
    if S.mode ~= "cat" then
        SetStatus("大目录是只读证据库，不能生成；点「过滤」切回策展目录")
        return
    end
    if not S.sel then
        SetStatus("先点一行选中，再点 ②生成")
        return
    end
    Cmd("jsp", S.sel.name)
    SetStatus("已下发 jsp " .. S.sel.name .. "（落点=" .. (MODE_ZH[PlaceMode()] or PlaceMode()) .. "），结果看聊天/日志")
end

local function CyclePlace()
    local order = { feet = "cube", cube = "front", front = "feet" }
    _G.JX = _G.JX or {}
    _G.JX.spawnAt = order[PlaceMode()] or "feet"
    Render()
    Log("spawnAt -> " .. tostring(_G.JX.spawnAt))
end

local function ToggleCollision()
    local on = true
    pcall(function()
        local a3 = _G.JxActor3
        if type(a3) == "table" and a3.box == false then on = false end
    end)
    Cmd("jbox", on and "off" or "on")
    ExecuteWithDelay(250, function() ExecuteInGameThread(function() pcall(Render) end) end)
end

local function DoSearch(q)
    if S.mode == "cat" then
        CatSearch(q)
        Render()
    else
        S.q = tostring(q or "")
        Cmd("jxsearch", S.q)
        SetStatus(StatusLine())
    end
end

local function CycleMode()
    S.mode = (S.mode == "cat") and "idx" or "cat"
    if S.mode == "cat" then
        CatSearch(S.q)
        Render()
        Log("mode -> curated catalog (spawnable)")
    else
        Cmd("jxsearchfilter")
        SetStatus(StatusLine())
        Log("mode -> big read-only index (jxsearch engine owns the rows)")
    end
end

local function PageStep(d)
    if S.mode == "idx" then
        Cmd(d > 0 and "jxsearchnext" or "jxsearchprev")
        return
    end
    local p = S.page + d
    if p < 1 then p = 1 end
    if p > Pages() then p = Pages() end
    S.page = p
    Render()
end

-- ============ wiring (JxNewUI native-state poll, zero delegates) ============
local HANDLERS = {
    JxSearchGo = function()
        local box = Prop("JxSearchInput")
        local txt = ""
        if box then
            pcall(function()
                local t = box:GetText()
                txt = tostring(t and t:ToString() or "")
            end)
        end
        S.lastBox = txt
        DoSearch(txt)
    end,
    JxSearchPrev = function() PageStep(-1) end,
    JxSearchNext = function() PageStep(1) end,
    JxSearchFilter = function() CycleMode() end,
    ActorSubBtn_0 = function() Cmd("jsub", "0") end,
    ActorSubBtn_1 = function() Cmd("jsub", "1") end,
    ActorSubBtn_2 = function() Cmd("jsub", "2") end,
    ActorPlc_0 = function() Cmd("jmark") end,
    ActorPlc_1 = function() SpawnSelected() end,
    ActorPlc_2 = function() Cmd("jkill", "last") end,
    ActorPlc_3 = function() Cmd("jlistplaced") end,
    ActorPlc_4 = function() CyclePlace() end,
    ActorPlc_5 = function() ToggleCollision() end,
}
for i = 0, 4 do
    HANDLERS["ActorLst_" .. i] = function() Select(i + 1) end
end

local function Wire()
    local nu = _G.JxNewUI
    if type(nu) ~= "table" or type(nu.cbsOrder) ~= "table" then return false end
    local w = Shell()
    if not w then return false end
    _G.JXUICBS = _G.JXUICBS or {}
    S.wcache = {}
    local n = 0
    for nm, fn in pairs(HANDLERS) do
        local widget = Prop(nm)
        if widget then
            -- No page gate: InputItemVisible() only polls IsValid when `action`
            -- is absent, and a click still needs IsHovered, so a hidden page
            -- can never fire. Page gating would need pgIdx["ActorPageV43"] to
            -- exist at wire time, which is not guaranteed this early.
            nu.cbsOrder[#nu.cbsOrder + 1] = { nm = nm, e = { w = widget } }
            _G.JXUICBS[nm] = fn
            n = n + 1
        end
    end
    if n == 0 then return false end
    S.wired = n
    SetTextOn(Prop("JxSearchHelp"),
        "搜索框打字即搜（策展目录）→ 点一行选中 → ②生成；◀▶翻页，「过滤」切策展/大目录")
    CatBuild(false)
    CatSearch(S.q)
    Render()
    Log("wired " .. n .. " Actor-page buttons into the JxNewUI poll (no delegates)")
    return true
end

-- ============ tick: re-wire after a rearm + poll the text box ===============
local function Tick()
    local w = Shell()
    if not w then return end
    if type(_G.JXUICBS) ~= "table" or _G.JXUICBS.JxSearchGo == nil then
        pcall(Wire)
        return
    end
    if S.mode ~= "cat" then return end
    local box = Prop("JxSearchInput")
    if not box then return end
    local txt = nil
    pcall(function()
        local t = box:GetText()
        txt = tostring(t and t:ToString() or "")
    end)
    if type(txt) ~= "string" then return end
    if txt ~= S.lastBox then
        S.lastBox = txt
        S.lastType = os.clock()
        S.pending = true
        return
    end
    -- settle for ~0.4 s after the last keystroke, then search once
    if S.pending and (os.clock() - S.lastType) >= 0.4 then
        S.pending = false
        DoSearch(txt)
    end
end

local function StartPoll()
    local function tick()
        ExecuteInGameThread(function() pcall(Tick) end)
        ExecuteWithDelay(300, tick)
    end
    ExecuteWithDelay(6000, tick)
end

-- ============ commands ======================================================
local function Install_Commands()
    if type(JXRegCmd) ~= "function" then
        Log("JXRegCmd unavailable - Actor page commands not registered")
        return
    end
    JXRegCmd("jact", function()
        ExecuteInGameThread(function()
            CatBuild(false)
            Log("[jact] " .. StatusLine())
            Log("[jact] jactfind <kw> | jactsel <1-10> | jactspawn | jactmode | jactpage next|prev|<n> | jactreload")
            Log("[jact] wired=" .. tostring(S.wired) .. " shell=" .. tostring(Alive(S.shell)))
            SetStatus(StatusLine())
        end)
        return true
    end)
    JXRegCmd("jactfind", function(FullCommand, Parameters)
        ExecuteInGameThread(function()
            local rest = tostring(FullCommand or ""):gsub("^%s*jactfind%s*", ""):match("^%s*(.-)%s*$")
            DoSearch(rest or "")
            Log("[jact] find \"" .. tostring(rest) .. "\" -> " .. #S.hits .. " hit(s)")
        end)
        return true
    end)
    JXRegCmd("jactsel", function(FullCommand, Parameters)
        ExecuteInGameThread(function()
            local n = tonumber((Parameters and Parameters[1]) or "")
            if not n then Log("[jact] usage: jactsel <1-10>") return end
            Select(math.floor(n))
        end)
        return true
    end)
    JXRegCmd("jactspawn", function()
        ExecuteInGameThread(function() SpawnSelected() end)
        return true
    end)
    JXRegCmd("jactmode", function()
        ExecuteInGameThread(function() CycleMode() end)
        return true
    end)
    JXRegCmd("jactpage", function(FullCommand, Parameters)
        ExecuteInGameThread(function()
            local a = tostring((Parameters and Parameters[1]) or "next"):lower()
            if a == "next" then PageStep(1)
            elseif a == "prev" then PageStep(-1)
            else
                local n = tonumber(a)
                if n then S.page = math.max(1, math.min(Pages(), math.floor(n))); Render() end
            end
        end)
        return true
    end)
    JXRegCmd("jactreload", function()
        ExecuteInGameThread(function()
            CatBuild(true)
            CatSearch(S.q)
            Render()
            Log("[jact] curated catalog reloaded: " .. S.catN .. " entries")
        end)
        return true
    end)
end

function M.Install()
    Install_Commands()
    StartPoll()
    Log("r2 installed: ActorPageV43 bridge (18 buttons, property access, no walk, no delegates)")
    return M
end

M.State = S
M.Render = function() pcall(Render) end
M.Search = function(q) pcall(DoSearch, q) end

Log("JxActorUI r2 loaded")
return M
