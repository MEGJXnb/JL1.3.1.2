
local Guard = { armed = false, blocked = 0, logged = {}, hooks = 0 }

local function Log(msg)
    print("[JxCrashGuard] " .. tostring(msg) .. "\n")
end

local function NoteOnce(kind, detail)
    Guard.blocked = Guard.blocked + 1
    if (Guard.logged[kind] or 0) < 10 then
        Guard.logged[kind] = (Guard.logged[kind] or 0) + 1
        Log("BLOCKED " .. kind .. " #" .. Guard.blocked .. ": " .. tostring(detail):sub(1, 120))
    end
end

local function ArgIsSafe(a)
    if a == nil then return false end
    local t = type(a)
    if t == "number" or t == "boolean" or t == "string" then return true end
    if t == "table" then return true end
    if t == "userdata" then
        local ok, valid = pcall(function() return a:IsValid() end)
        if ok and valid == false then return false end
        
        return true
    end
    return false
end

local function ParamsSafe(args, nmax)
    for i = 1, math.min(#args, nmax or 4) do
        if not ArgIsSafe(args[i]) then
            return false, ("arg%d=%s"):format(i, tostring(args[i]))
        end
    end
    return true
end

local function HookEverywhere(fnName, pathFragment, handler, label)
    local count = 0
    pcall(function()
        local seen = {}
        local ok, list = pcall(function() return FindAllOf("Class") end)
        if ok and list then
            for _, c in pairs(list) do
                pcall(function()
                    if c and c:IsValid() and not seen[c] then
                        seen[c] = true
                        local path = ""
                        pcall(function() path = c:GetFullPath() end)
                        if path:find(pathFragment, 1, true) then
                            local has = false
                            pcall(function() has = (StaticFindObject(c:GetFullPath() .. ":" .. fnName) ~= nil) end)
                            if has then
                                local okh = pcall(function()
                                    RegisterHook(path .. ":" .. fnName, handler)
                                end)
                                if okh then count = count + 1 end
                            end
                        end
                    end
                end)
            end
        end
    end)
    return count
end

function Guard.Install()
    if Guard.armed then return true end

    local PML = function(self, ...)
        local args = { ... }
        local safe, why = ParamsSafe(args, 4)
        if not safe then
            NoteOnce("PrintToModLoader", why)
            
        end
        return true
    end
    pcall(function()
        
        RegisterHook("/Game/Mods/BPML_GenericFunctions.BPML_GenericFunctions_C:PrintToModLoader", PML)
        Guard.hooks = Guard.hooks + 1
        Log("PrintToModLoader guard armed (BPML_GenericFunctions_C)")
    end)
    pcall(function()
        local n = HookEverywhere("PrintToModLoader", "BPML_GenericFunctions", PML, "pml")
        Guard.hooks = Guard.hooks + n
        Log("PrintToModLoader extra carriers hooked: " .. tostring(n))
    end)

    pcall(function()
        local tries = 0
        local function retry()
            tries = tries + 1
            if Guard.hooks >= 2 or tries > 12 then return end
            pcall(function()
                local n = HookEverywhere("PrintToModLoader", "BPML_GenericFunctions", PML, "pml")
                Guard.hooks = Guard.hooks + n
                if n > 0 then
                    Log("PrintToModLoader late carriers hooked: " .. tostring(n)
                        .. " (total " .. tostring(Guard.hooks) .. ")")
                end
            end)
            ExecuteWithDelay(20000, retry)
        end
        ExecuteWithDelay(20000, retry)
        Log("late-carrier timer retry armed (20s x12 until hooks>=2)")
    end)

    Guard.armed = true
    Log(("crash guard v2.1 installed (hooks=%d, blocked=%d)"):format(Guard.hooks, Guard.blocked))
    return true
end

function Guard.Status()
    return {
        armed = Guard.armed,
        hooks = Guard.hooks,
        blocked = Guard.blocked,
        unique_errors = (function()
            local n = 0
            for _ in pairs(Guard.logged) do n = n + 1 end
            return n
        end)()
    }
end

Guard.Install()

return Guard
