
local PG = { _VERSION = "1.0.0" }

local B = (type(_G) == "table" and _G.JXPerfBridge) or nil

local function Say(s)
    local msg = "[PERFGUARD] " .. tostring(s)
    if B and type(B.Log) == "function" then
        if not pcall(B.Log, msg) then pcall(print, msg) end
    else
        pcall(print, msg)
    end
end

local function Bridged() return B ~= nil end

local function Exec(cmd)
    if type(cmd) ~= "string" or cmd == "" then return false end
    local ok = false
    pcall(function()
        local PC = nil
        pcall(function() PC = UEHelpers.GetPlayerController() end)
        if B and type(B.Exec) == "function" then
            
            ok = B.Exec(PC, cmd) and true or false
        elseif type(ExecuteConsoleCommand) == "function" then
            ok = ExecuteConsoleCommand(cmd) and true or false
        end
    end)
    return ok
end

local function ReadNum(name)
    if B and type(B.ReadNum) == "function" then
        local v = nil
        pcall(function() v = B.ReadNum(name) end)
        return v
    end
    local v = nil
    pcall(function()
        local KSL = StaticFindObject("/Script/Engine.Default__KismetSystemLibrary")
        if KSL and KSL:IsValid() then v = KSL:GetConsoleVariableFloatValue(name) end
    end)
    return v
end

local function Root()
    
    if B then
        local d = nil
        pcall(function() if B.SidecarDir then d = B.SidecarDir() end end)
        if type(d) == "string" and d ~= "" then return d end
        pcall(function() if B.ModDir then d = B.ModDir() end end)
        if type(d) == "string" and d ~= "" then return d end
    end
    if type(_G) == "table" and type(_G.JXSidecarDir) == "string" then return _G.JXSidecarDir end
    if type(ModDir) == "string" then return ModDir end
    return ""
end

local function Queue(cmds)
    if B and type(B.Queue) == "function" then
        local ok = pcall(B.Queue, cmds)
        if ok then return #cmds end
        return 0
    end
    local n = 0
    for _, c in ipairs(cmds) do if Exec(c) then n = n + 1 end end
    return n
end

local LEVERS = {
    
    { n = "r.MotionBlurQuality",            want = 0,   cost = "high", scalability = true,
      why = "full-screen velocity pass; quality 4 = 4 blur samples every frame" },
    { n = "r.MaxAnisotropy",                want = 1,   cost = "high", scalability = true,
      why = "16x anisotropic is 16 taps per sample; the desktop INI asks for 16" },
    { n = "r.BloomQuality",                 want = 0,   cost = "high",
      why = "multi-pass downsample/upsample chain; the desktop INI asks for 4" },
    { n = "r.ShadowQuality",                want = 0,   cost = "high",
      why = "shadow depth rendering per light; the desktop INI asks for 3" },
    { n = "r.Tonemapper.Quality",           want = 0,   cost = "high",
      why = "tonemap + colour grading chain; the desktop INI asks for 5" },
    { n = "r.AmbientOcclusionLevels",       want = 0,   cost = "high",
      why = "SSAO is a full-screen gather per level" },
    { n = "r.VolumetricFog",                want = 0,   cost = "high",
      why = "3D fog volume marched per pixel; the heaviest single pass in a foggy map" },

    { n = "r.PostProcessAAQuality",         want = 2,   cost = "med",  scalability = true,
      why = "TAA cost scales with the quality level; 2 keeps edges without 4's cost" },
    { n = "r.DepthOfFieldQuality",          want = 0,   cost = "med" },
    { n = "r.LensFlareQuality",             want = 0,   cost = "med" },
    { n = "r.LightShaftQuality",            want = 0,   cost = "med" },
    { n = "r.SceneColorFringeQuality",      want = 0,   cost = "med" },
    { n = "r.Tonemapper.Sharpen",           want = 0,   cost = "med" },
    { n = "r.Shadow.CSM.MaxCascades",       want = 1,   cost = "med" },
    { n = "r.Shadow.MaxResolution",         want = 512, cost = "med" },
    { n = "r.SkyLight.RealTimeReflectionCapture", want = 0, cost = "med" },
    { n = "r.TranslucencyLightingVolume",   want = 0,   cost = "med" },

    { n = "gc.TimeBetweenPurgingPendingKillObjects", want = 60, cost = "med",
      why = "longer gaps = fewer, larger GC hitches instead of many small ones" },
    { n = "s.LevelStreamingActorsUpdateTimeLimit",   want = 2.0, cost = "med",
      why = "per-frame budget for streaming actor updates; 5ms is a visible spike" },
    { n = "s.UnregisterComponentsTimeLimit",         want = 2.0, cost = "low" },
    { n = "gc.AllowParallelGC",                      want = 1,   cost = "low" },
    { n = "gc.NumRetriesBeforeForcingGC",            want = 20,  cost = "low" },
    { n = "s.AsyncLoadingThreadEnabled",             want = 1,   cost = "low" },
    { n = "s.AsyncLoadingUseFullTimeLimit",          want = 0,   cost = "low" },
    { n = "s.ForceGCAfterLevelStreamedOut",          want = 0,   cost = "low" },
    { n = "r.Streaming.DefragDynamicBounds",         want = 1,   cost = "low" },
    { n = "r.Streaming.MaxTempMemoryAllowed",        want = 64,  cost = "low" },
    { n = "r.Streaming.MipBias",                     want = 0.6, cost = "low",
      why = "positive bias streams smaller mips; saves VRAM and bandwidth" },
}

local function ReassertList()
    local out = {}
    for _, L in ipairs(LEVERS) do
        if L.scalability then out[#out + 1] = L end
    end
    return out
end

local PRIORITY = { global = 1, tier = 2, boost = 3, slider = 4 }

local function Resolve()
    local best = {}   

    local function Offer(cvar, val, src)
        if type(cvar) ~= "string" or cvar == "" then return end
        if val == nil then return end
        local pri = PRIORITY[src]
        if not pri then return end
        local cur = best[cvar]
        if not cur or pri > cur.pri then
            best[cvar] = { v = val, src = src, pri = pri }
        end
    end

    for _, L in ipairs(LEVERS) do Offer(L.n, L.want, "tier") end

    local tierName = PG.tier or "pro"
    local root = Root()
    local iniPath = root .. "config/boost_pack.ini"
    pcall(function()
        local h = io.open(iniPath, "r")
        if not h then return end
        for line in h:lines() do
            local k, v = line:match("^([%w_%.]+)%s*=%s*(.-)%s*$")
            if k and v and k:sub(1, 7) == "global." then
                local cname, cval = v:match("^(%S+)%s+(.+)$")
                if cname and cval then Offer(cname, cval, "global") end
            end
        end
        h:close()
    end)
    pcall(function()
        local h = io.open(iniPath, "r")
        if not h then return end
        local prefix = "tier." .. tierName .. "."
        for line in h:lines() do
            local k, v = line:match("^([%w_%.]+)%s*=%s*(.-)%s*$")
            if k and v and k:sub(1, #prefix) == prefix then
                local cname, cval = v:match("^(%S+)%s+(.+)$")
                if cname and cval then Offer(cname, cval, "tier") end
            end
        end
        h:close()
    end)

    pcall(function()
        local lvl = "balanced"
        pcall(function()
            local bf = root .. "config/boost.txt"
            local h = io.open(bf, "r")
            if h then
                local lv = (h:read("*l") or ""):gsub("%s+", "")
                h:close()
                if lv == "off" or lv == "balanced" or lv == "max" then lvl = lv end
            end
        end)
        
        local BOOST = {
            off      = { ["gc.TimeBetweenPurgingPendingKillObjects"] = 60,
                         ["r.MaxAnisotropy"] = 16, ["r.Streaming.FramesForFullUpdate"] = 1 },
            balanced = { ["gc.TimeBetweenPurgingPendingKillObjects"] = 120,
                         ["r.MaxAnisotropy"] = 4,  ["r.Streaming.FramesForFullUpdate"] = 5 },
            max      = { ["gc.TimeBetweenPurgingPendingKillObjects"] = 300,
                         ["r.MaxAnisotropy"] = 1,  ["r.Streaming.FramesForFullUpdate"] = 10 },
        }
        local t = BOOST[lvl]
        if t then
            for cvar, val in pairs(t) do Offer(cvar, val, "boost") end
            PG.boostLevel = lvl
        end
    end)

    pcall(function()
        local items = nil
        if B and type(B.PerfItems) == "function" then
            pcall(function() items = B.PerfItems() end)
        elseif type(PerfItems) == "table" then
            items = PerfItems
        end
        if type(items) ~= "table" then return end
        for _, it in ipairs(items) do
            if it and type(it.cvar) == "string" and it.cur ~= nil then
                Offer(it.cvar, it.cur, "slider")
            end
        end
    end)

    return best
end

local function ApplyAll(reason)
    local resolved = Resolve()
    local names, written, skipped = {}, 0, 0
    for n in pairs(resolved) do names[#names + 1] = n end
    table.sort(names)

    local cmds = {}
    for _, n in ipairs(names) do
        local e = resolved[n]
        cmds[#cmds + 1] = string.format("%s %s", n, tostring(e.v))
        written = written + 1
    end
    local queued = Queue(cmds)
    Say(string.format("applied %d/%d lever(s) via %s (%s)%s", queued, written,
        Bridged() and "pump" or "direct", tostring(reason or "-"),
        (not Bridged()) and "  [WARNING: bridge missing - synchronous writes]" or ""))
    PG.last = { at = os.date("%H:%M:%S"), count = queued, reason = reason }
    return queued
end

local function Reassert(reason)
    local resolved = Resolve()
    local cmds = {}
    for _, L in ipairs(ReassertList()) do
        local e = resolved[L.n]
        if e then cmds[#cmds + 1] = string.format("%s %s", L.n, tostring(e.v)) end
    end
    if #cmds == 0 then return 0 end
    local n = Queue(cmds)
    if n > 0 then
        Say("re-asserted " .. n .. " scalability-owned lever(s) (" .. tostring(reason or "-") .. ")")
    end
    return n
end

local ORDER = { high = 1, med = 2, low = 3 }

local function Scan(writeReport)
    local resolved = Resolve()
    local rows = {}
    for _, L in ipairs(LEVERS) do
        local e = resolved[L.n]
        local want = e and tonumber(e.v) or L.want
        local got = ReadNum(L.n)
        local good = (got ~= nil and want ~= nil) and (math.abs(got - want) < 0.51) or false
        rows[#rows + 1] = {
            name = L.n, want = want, got = got, good = good,
            cost = L.cost or "low", src = e and e.src or "tier",
            scalability = L.scalability and true or false,
            why = L.why or "",
        }
    end
    table.sort(rows, function(a, b)
        if a.good ~= b.good then return not a.good end           
        return (ORDER[a.cost] or 9) < (ORDER[b.cost] or 9)       
    end)

    local bad = 0
    for _, r in ipairs(rows) do if not r.good then bad = bad + 1 end end
    Say(string.format("scan: %d/%d lever(s) in effect, %d not", #rows - bad, #rows, bad))
    for _, r in ipairs(rows) do
        if not r.good then
            Say(string.format("  [%s] %-42s want=%-6s got=%-8s (%s)%s",
                string.upper(r.cost), r.name, tostring(r.want), tostring(r.got),
                r.src, r.scalability and "  <- scalability re-applies this" or ""))
        end
    end

    if writeReport then
        local root = Root()
        pcall(function()
            local h = io.open(root .. "config/perf_guard_report.txt", "w")
            if not h then return end
            h:write("perf guard scan - tier " .. tostring(PG.tier or "pro")
                .. "  boost " .. tostring(PG.boostLevel or "?")
                .. "  " .. os.date("%Y-%m-%d %H:%M:%S") .. "\r\n")
            h:write(string.format("%d/%d in effect, %d not\r\n\r\n", #rows - bad, #rows, bad))
            h:write(string.format("%-6s %-42s %-8s %-8s %-9s %s\r\n",
                "COST", "CVAR", "WANT", "GOT", "SOURCE", "STATUS"))
            for _, r in ipairs(rows) do
                h:write(string.format("%-6s %-42s %-8s %-8s %-9s %s\r\n",
                    string.upper(r.cost), r.name, tostring(r.want), tostring(r.got),
                    r.src, r.good and "ok" or "NOT-APPLIED"))
                if not r.good and r.why ~= "" then
                    h:write(string.format("       why: %s%s\r\n", r.why,
                        r.scalability and " (scalability-owned: re-asserted after map load)" or ""))
                end
            end
            h:close()
        end)
    end
    return rows, bad
end

local Sample = { running = false, ticks = 0, t0 = nil, result = nil }

local function Tick()
    if not Sample.running then return end
    Sample.ticks = Sample.ticks + 1
    local t = os.clock()
    if Sample.t0 == nil then Sample.t0 = t end
    local elapsed = t - (Sample.t0 or t)
    if elapsed >= (Sample.seconds or 3) then
        Sample.running = false
        local fps = (elapsed > 0) and (Sample.ticks / elapsed) or 0
        Sample.result = { fps = fps, ticks = Sample.ticks, seconds = elapsed }
        if type(Sample.done) == "function" then pcall(Sample.done, Sample.result) end
        return
    end
    if type(ExecuteWithDelay) == "function" then
        pcall(ExecuteWithDelay, 0, Tick)
    end
end

local function Measure(seconds, cb)
    if Sample.running then return false end
    Sample.seconds = seconds or 3
    Sample.done = cb
    Sample.ticks = 0
    Sample.t0 = nil
    Sample.result = nil
    Sample.running = true
    if type(ExecuteWithDelay) == "function" then
        pcall(ExecuteWithDelay, 0, Tick)
        return true
    end
    Sample.running = false
    return false
end

local function AB(seconds)
    Say("A/B: measuring with the guard in force ...")
    ApplyAll("ab-a")
    pcall(function()
        if type(ExecuteWithDelay) == "function" then
            ExecuteWithDelay(1500, function()
                Measure(seconds or 3, function(a)
                    Say(string.format("  A (guarded): %.1f fps over %.1fs", a.fps, a.seconds))
                    
                    local release = {
                        "r.MotionBlurQuality 4", "r.MaxAnisotropy 16",
                        "r.BloomQuality 4", "r.ShadowQuality 3", "r.Tonemapper.Quality 5",
                    }
                    Queue(release)
                    ExecuteWithDelay(1500, function()
                        Measure(seconds or 3, function(b)
                            Say(string.format("  B (released): %.1f fps over %.1fs", b.fps, b.seconds))
                            local d = a.fps - b.fps
                            Say(string.format("  delta: %+.1f fps (%s)", d,
                                d > 0.5 and "the guard helps" or (d < -0.5 and "the guard hurts" or "no measurable change")))
                            
                            ApplyAll("ab-restore")
                        end)
                    end)
                end)
            end)
        end
    end)
end

local function Register()
    if type(JXRegCmd) ~= "function" then
        Say("JXRegCmd not available yet; commands not registered")
        return false
    end
    JXRegCmd("jperfguard", function(FullCommand, Parameters)
        local a = tostring(Parameters or ""):match("%S+") or "status"
        if a == "apply" then
            ApplyAll("manual"); return true
        elseif a == "scan" then
            Scan(true); return true
        elseif a == "ab" then
            AB(3); return true
        elseif a == "fps" then
            Measure(3, function(r)
                Say(string.format("%.1f fps (%d ticks / %.1fs)", r.fps, r.ticks, r.seconds))
            end)
            return true
        elseif a == "why" then
            Say("frame-cost table (what the WRONG value costs, highest first):")
            local sorted = {}
            for _, L in ipairs(LEVERS) do sorted[#sorted + 1] = L end
            table.sort(sorted, function(x, y) return (ORDER[x.cost] or 9) < (ORDER[y.cost] or 9) end)
            for _, L in ipairs(sorted) do
                Say(string.format("  [%-4s] %-42s want=%-6s%s%s", L.cost or "low", L.n,
                    tostring(L.want), L.scalability and " (scalability-owned)" or "",
                    (L.why and L.why ~= "") and ("  " .. L.why) or ""))
            end
            return true
        end
        Say("version " .. PG._VERSION .. " | tier=" .. tostring(PG.tier or "pro")
            .. " boost=" .. tostring(PG.boostLevel or "?")
            .. " | last=" .. tostring(PG.last and PG.last.at or "none"))
        Say("  jperfguard apply|scan|why|fps|ab")
        return true
    end)
    return true
end

local function Boot()
    if type(ExecuteWithDelay) ~= "function" then
        pcall(ApplyAll, "boot-immediate")
        return
    end
    
    pcall(ExecuteWithDelay, 30000, function()
        pcall(ApplyAll, "boot")
        
        pcall(ExecuteWithDelay, 3000, function()
            pcall(Reassert, "boot-settled")
            pcall(ExecuteWithDelay, 2000, function() pcall(Scan, true) end)
        end)
    end)
    
    if type(JXTransferBegin) == "function" then
        
    end
    pcall(ExecuteWithDelay, 45000, function()
        pcall(Reassert, "late")
    end)
end

PG.ApplyAll = ApplyAll
PG.Reassert = Reassert
PG.Scan = Scan
PG.Measure = Measure
PG.AB = AB
PG.Resolve = Resolve
PG.LEVERS = LEVERS
PG.ReadNum = ReadNum

pcall(function() Register() end)
pcall(function() Boot() end)
Say("ready (jperfguard apply|scan|why|fps|ab)")

return PG
