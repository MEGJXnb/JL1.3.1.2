
local ULC = { version = "1.0", reportPath = nil }

local function Log(s) print("[JxUiLinkCheck] " .. tostring(s)) end

do
    local base = _G.JXSidecarDir
    if type(base) ~= "string" or base == "" then base = "" end
    ULC.reportPath = base .. "jx_uilink.txt"
end

local function writeReport(text)
    pcall(function()
        local f = io.open(ULC.reportPath, "w")
        if f then f:write(text, "\n"); f:close() end
    end)
end

local function linkKeyTable(r)
    
    local B = _G.JXBinds or _G.JxBinds
    if type(B) ~= "table" or type(B.byId) ~= "table" then
        r[#r + 1] = { "L1 key table", "WARN",
            "host bind registry not published (JXBinds) -- cannot audit; main.lua older than r3.63?" }
        return
    end
    local want = { "panel", "fly" }
    local missing = {}
    for _, w in ipairs(want) do
        if not B.byId[w] then missing[#missing + 1] = w end
    end
    if #missing == 0 then
        r[#r + 1] = { "L1 key table", "PASS",
            ("%d binds registered (F4 fly / F6 panel present)"):format(#want) }
    else
        r[#r + 1] = { "L1 key table", "FAIL",
            "missing binds: " .. table.concat(missing, ", ") .. " -- keys rebind after map change via SafeBind; if this persists, check the boot log for 'FAILED to bind'" }
    end
end

local function linkLock(r)
    
    if type(_G.JXForceUnlock) ~= "function" then
        r[#r + 1] = { "L2 ui lock", "WARN",
            "JXForceUnlock not exposed -- r4.3 main.lua not deployed; a wedged clock can still lock every panel key ('junlock' would fix it)" }
        return
    end
    local busy = false
    pcall(function() busy = _G.JXBusy and _G.JXBusy() end)
    r[#r + 1] = { "L2 ui lock", "PASS",
        busy and "transition window OPEN (normal during a map change; 'junlock' releases it early)"
               or "idle - every panel key is live" }
end

local function linkRunner(r)
    
    if type(_G.JXMemberRun) ~= "function" then
        r[#r + 1] = { "L3 member runner", "FAIL",
            "JXMemberRun not exposed -- jplus/jpro/jmove are dead and the panel buttons that route through them no-op. r4.3 main.lua calls JXMemberPack() before JXWhitelist(); if you see this, that fix is not deployed" }
    else
        r[#r + 1] = { "L3 member runner", "PASS",
            "jplus/jpro alive behind the whitelist gate" }
    end
end

local function linkGate(r)
    
    local JW = _G.JxWhitelist
    if type(JW) ~= "table" then
        r[#r + 1] = { "L4 wl gate", "WARN", "JxWhitelist sidecar not loaded -- name gate only (no Steam64 precision)" }
        return
    end
    local n = 0
    pcall(function()
        if type(JW.rules) == "table" then
            for _ in pairs(JW.rules) do n = n + 1 end
        end
    end)
    local mode = tostring(JW.mode or "strict")
    if n == 0 then
        r[#r + 1] = { "L4 wl gate", "WARN",
            ("mode=%s, 0 Steam64 rules loaded -- 'jwlsteam add <id> [plus|pro]' to fill; name gate still active"):format(mode) }
    else
        r[#r + 1] = { "L4 wl gate", "PASS",
            ("mode=%s, %d Steam64 rule(s) loaded"):format(mode, n) }
    end
end

local function linkPanelObjects(r)
    
    local core, root, f6 = false, false, false
    pcall(function()
        local probe = _G.JxUiProbe
        if type(probe) == "function" then
            local pr = probe()
            core = (pr and pr.coreState == "ALIVE")
            root = (pr and pr.uirootState == "ALIVE")
            f6 = (pr and pr.f6State == "ALIVE")
        else
            r[#r + 1] = { "L5 panel objects", "WARN",
                "JxUiProbe not published (r4.3 main.lua not deployed) -- census unavailable" }
            return
        end
    end)
    if #r > 0 and r[#r][1] == "L5 panel objects" then return end
    if core or root or f6 then
        r[#r + 1] = { "L5 panel objects", "PASS",
            ("Core %s / Root %s / F6 %s"):format(core and "ALIVE" or "-",
                root and "ALIVE" or "-", f6 and "ALIVE" or "-") }
    else
        r[#r + 1] = { "L5 panel objects", "FAIL",
            "no pak panel object alive (Core/Root/F6 all absent) -- expected since r7.0 retired the pak panel; the canvas (B/F8) does not depend on this chain" }
    end
end

local function linkCanvasImGui(r)
    
    local canvas = false
    pcall(function()
        local JP = _G.JxPanels
        canvas = (type(JP) == "table" and type(JP.hookFrames) == "number" and JP.hookFrames > 0)
    end)
    local imgui = false
    pcall(function() imgui = (type(_G.JXImgUiUp) == "function" and _G.JXImgUiUp()) or false end)
    if canvas or imgui then
        r[#r + 1] = { "L6 canvas/imgui", "PASS",
            ("canvas %s / imgui %s"):format(canvas and "rendering" or "-", imgui and "up" or "-") }
    else
        r[#r + 1] = { "L6 canvas/imgui", "WARN",
            "canvas hook idle and imgui layer down -- press B (canvas toggle) and re-run; if nothing shows, F8 then F6" }
    end
end

local function linkInput(r)
    
    local open, cursor = false, false
    pcall(function()
        
        local PC = FindFirstOf("PlayerController")
        if PC and PC:IsValid() then
            cursor = (PC.bShowMouseCursor == true)
        end
    end)
    pcall(function()
        local JP = _G.JxPanels
        open = (type(JP) == "table" and JP.open == true)
    end)
    if open and not cursor then
        r[#r + 1] = { "L7 input mode", "FAIL",
            "canvas panel reports OPEN but the mouse cursor is hidden -- SetPanelMouse(false) path missed a close; 'junlock' + reopen, or juix fix (JxUiRescue427)" }
    else
        r[#r + 1] = { "L7 input mode", "PASS",
            open and "panel open with cursor -- correct" or "panel closed, cursor hidden -- correct" }
    end
end

local function run()
    local rows = {}
    local okAll = pcall(function()
        linkKeyTable(rows)   
        linkLock(rows)       
        linkRunner(rows)     
        linkGate(rows)       
        linkCanvasImGui(rows)
        linkInput(rows)      
    end)
    if not okAll then rows[#rows + 1] = { "audit", "WARN", "a link threw during audit (see console above)" } end
    
    pcall(linkPanelObjects, rows)

    local order = { "L1", "L2", "L3", "L4", "L5", "L6", "L7" }
    local byId = {}
    for _, row in ipairs(rows) do byId[row[1]:sub(1, 2)] = byId[row[1]:sub(1, 2)] or {}; byId[row[1]:sub(1, 2)][#(byId[row[1]:sub(1, 2)]) + 1] = row end

    local lines = { "=== JxUiLinkCheck " .. ULC.version .. " @ " .. os.date("%Y-%m-%d %H:%M:%S") .. " ===" }
    local fails = 0
    for _, id in ipairs(order) do
        for _, row in ipairs(byId[id] or {}) do
            local name, verdict, detail = row[1], row[2], row[3]
            if verdict == "FAIL" then fails = fails + 1 end
            lines[#lines + 1] = string.format("  %-18s %-4s  %s", name, verdict, detail)
        end
    end
    lines[#lines + 1] = ""
    if fails == 0 then
        lines[#lines + 1] = "  circuit verdict: every audited link PASS/WARN -- nothing here blocks the panel."
    else
        lines[#lines + 1] = ("  circuit verdict: %d FAIL link(s) above -- fix them top-down, they are ordered by the signal path"):format(fails)
    end
    local text = table.concat(lines, "\n")
    print("[JxUiLinkCheck]\n" .. text)
    writeReport(text)
    return text
end

if type(JXRegCmd) == "function" then
    JXRegCmd("juilink", function(FullCommand, Parameters, Ar)
        pcall(function()
            if type(ExecuteInGameThread) == "function" then
                ExecuteInGameThread(function() pcall(run) end)
            else
                run()
            end
        end)
        return true
    end)
else
    pcall(run)
end

ULC.report = run          
Log("v" .. ULC.version .. " loaded -- 'juilink' audits the 7-link UI circuit, report -> " .. tostring(ULC.reportPath))

return ULC
