JPSNET = {}
local JN = JPSNET
JN.version = "1.1.1"

local JxRoot
do
    local sc = (_G.JXSidecarDir or "")
    if sc ~= "" then
        JxRoot = tostring(sc):gsub("\\", "/"):gsub("[^/]+/$", "")
    else
        JxRoot = ""
    end
end
JN.config = {
    pingWarn = 120,
    pingKick = 180,
    pingBadSamples = 4,
    autoSwitch = false,
    rejoinOnDrop = true,
    failoverOnDrop = true,
    pollMs = 5000,
    cacheFile = JxRoot .. "config/servers.json",
    altCache = JxRoot .. "tools/servers_cache.json",
    iniFile = JxRoot .. "config/jps_net.ini",
    travelDelayMs = 3000,
    maxFailoverTries = 3,
}
JN.status = {
    servers = {},
    lastPing = 0,
    pingSamples = {},
    state = "online",
    drops = 0,
    rejoins = 0,
    failovers = 0,
    lastServerIdx = 0,
    currentTarget = nil,
    netErr = 0,
    cfgSource = "none",
    initDone = false,
    rejoinCheck = 0,
}
JN.world = nil
JN.pc = nil

local function NLog(msg)
    print("[JinxingNetSuite] " .. tostring(msg))
end

local function NPanel(msg, dur)
    print("[JN] " .. tostring(msg))
    pcall(function()
        local KSL = StaticFindObject("/Script/Engine.Default__KismetSystemLibrary")
        if KSL then
            KSL:PrintString(nil, true, "[JN] " .. tostring(msg), false, nil, dur or 5.0, "Cyan")
        end
    end)
end

local function Trim(s)
    return (s:gsub("^%s+", ""):gsub("%s+$", ""))
end

local function JsonDecode(text)
    local pos = 1
    local function skipWs()
        while pos <= #text do
            local c = text:sub(pos, pos)
            if c == " " or c == "\t" or c == "\r" or c == "\n" then
                pos = pos + 1
            else
                break
            end
        end
    end
    local function parseString()
        pos = pos + 1
        local out = {}
        while pos <= #text do
            local c = text:sub(pos, pos)
            if c == '"' then
                pos = pos + 1
                return table.concat(out)
            elseif c == "\\" then
                local nc = text:sub(pos + 1, pos + 1)
                local esc = { n = "\n", t = "\t", r = "\r", b = "\b", f = "\f", ['"'] = '"', ["\\"] = "\\", ["/"] = "/" }
                if nc == "u" then
                    local hex = text:sub(pos + 2, pos + 5)
                    local code = tonumber(hex, 16)
                    if code then
                        
                        if code < 0x80 then
                            table.insert(out, string.char(code))
                        elseif code < 0x800 then
                            table.insert(out, string.char(
                                0xC0 + math.floor(code / 64),
                                0x80 + code % 64))
                        elseif code >= 0xD800 and code <= 0xDFFF then
                            table.insert(out, string.char(0xEF, 0xBF, 0xBD))
                        else
                            table.insert(out, string.char(
                                0xE0 + math.floor(code / 4096),
                                0x80 + math.floor(code / 64) % 64,
                                0x80 + code % 64))
                        end
                    end
                    pos = pos + 6
                else
                    table.insert(out, esc[nc] or nc)
                    pos = pos + 2
                end
            else
                table.insert(out, c)
                pos = pos + 1
            end
        end
        error("unterminated string")
    end
    local parseValue
    local function parseObject()
        local obj = {}
        pos = pos + 1
        skipWs()
        if text:sub(pos, pos) == "}" then
            pos = pos + 1
            return obj
        end
        while true do
            skipWs()
            if text:sub(pos, pos) ~= '"' then error("expected key at " .. pos) end
            local key = parseString()
            skipWs()
            if text:sub(pos, pos) ~= ":" then error("expected colon at " .. pos) end
            pos = pos + 1
            skipWs()
            obj[key] = parseValue()
            skipWs()
            local c = text:sub(pos, pos)
            if c == "," then
                pos = pos + 1
            elseif c == "}" then
                pos = pos + 1
                return obj
            else
                error("expected , or } at " .. pos)
            end
        end
    end
    local function parseArray()
        local arr = {}
        pos = pos + 1
        skipWs()
        if text:sub(pos, pos) == "]" then
            pos = pos + 1
            return arr
        end
        while true do
            skipWs()
            table.insert(arr, parseValue())
            skipWs()
            local c = text:sub(pos, pos)
            if c == "," then
                pos = pos + 1
            elseif c == "]" then
                pos = pos + 1
                return arr
            else
                error("expected , or ] at " .. pos)
            end
        end
    end
    parseValue = function()
        skipWs()
        local c = text:sub(pos, pos)
        if c == "{" then return parseObject() end
        if c == "[" then return parseArray() end
        if c == '"' then return parseString() end
        
        if text:sub(pos, pos + 3) == "true" then
            pos = pos + 4
            return true
        end
        if text:sub(pos, pos + 4) == "false" then
            pos = pos + 5
            return false
        end
        if text:sub(pos, pos + 3) == "null" then
            pos = pos + 4
            return nil
        end
        local numStart, numEnd = text:find("^%-?%d+%.?%d*[eE][-+]?%d*", pos)
        if not numStart then
            numStart, numEnd = text:find("^%-?%d+%.?%d*", pos)
        end
        if numStart then
            local numStr = text:sub(numStart, numEnd)
            
            local n = tonumber(numStr)
            if n then
                pos = numEnd + 1
                return n
            end
        end
        error("unexpected char at " .. pos)
    end
    skipWs()
    return parseValue()
end

local function ReadTextFile(path)
    local ok, out = pcall(function()
        local f = io.open(path, "r")
        if not f then return nil end
        local content = f:read("*a")
        f:close()
        return content
    end)
    if ok then return out end
    return nil
end

local function ReadIniInt(path, key, default)
    local content = ReadTextFile(path)
    if not content then return default end
    local v = content:match(key .. "%s*=%s*(%-?%w+)")
    if v then return tonumber(v) or default end
    return default
end

local function ReadIniBool(path, key, default)
    local content = ReadTextFile(path)
    if not content then return default end
    local v = content:match(key .. "%s*=%s*(%w+)")
    if v then
        v = v:lower()
        if v == "on" or v == "true" or v == "1" then return true end
        if v == "off" or v == "false" or v == "0" then return false end
    end
    return default
end

local function LoadServerConfig()
    -- r45: an EXISTING but EMPTY servers.json used to shadow the GitHub sync
    -- cache forever - the network page then showed 0 servers (fake offline)
    -- even though the sync had fetched a fresh list. Walk both sources in
    -- order and take the first one that yields at least one valid entry.
    local sources = {
        { path = JN.config.cacheFile, tag = "config/servers.json (local)" },
        { path = JN.config.altCache,  tag = "tools/servers_cache.json (github sync)" },
    }
    for _, src in ipairs(sources) do
        local raw = ReadTextFile(src.path)
        if raw and Trim(raw) ~= "" then
            local ok, data = pcall(JsonDecode, raw)
            if not ok or type(data) ~= "table" then
                NLog("server config parse failed: " .. tostring(data) .. " (" .. src.tag .. ")")
            else
                local list = data.servers
                if type(list) == "table" then
                    local result = {}
                    for _, s in ipairs(list) do
                        if type(s) == "table" and type(s.host) == "string" and s.host ~= "" then

                            local h = tostring(s.host)
                            local hOk = h:find("^[%w%.%-]+$") ~= nil
                                or h:find("^%d+%.%d+%.%d+%.%d+$") ~= nil
                                or (h:find("^%[?[%x:]+%]?$") ~= nil and h:find(":") ~= nil)
                            local pOk = true
                            local prt = tonumber(s.port)
                            if s.port ~= nil and prt == nil then
                                pOk = false
                            elseif prt ~= nil and (prt < 1 or prt > 65535) then
                                pOk = false
                            end
                            if not hOk or not pOk then
                                NLog("server entry dropped (unsafe host/port): host="
                                    .. tostring(s.host) .. " port=" .. tostring(s.port))
                            else
                                table.insert(result, {
                                    name = s.name or s.host,
                                    host = h,
                                    port = prt or 7777,
                                    region = s.region or "?",
                                    priority = tonumber(s.priority) or 100,
                                    enabled = (s.enabled ~= false),
                                    note = s.note or "",
                                    latency = tonumber(s.latency_ms) or nil,
                                })
                            end
                        end
                    end
                    table.sort(result, function(a, b) return (a.priority) < (b.priority) end)
                    if #result > 0 then
                        JN.status.cfgSource = src.tag
                        return result
                    end
                end
            end
        end
    end
    JN.status.cfgSource = "none"
    return {}
end

local function GetWorld()
    local ok, w = pcall(function() return FindFirstOf("World") end)
    if ok and w and w:IsValid() then return w end
    return nil
end

local function GetPlayerController()
    local ok, pc = pcall(function() return FindFirstOf("PlayerController") end)
    if ok and pc and pc:IsValid() then return pc end
    return nil
end

local function CurrentPing()
    local world = JN.world or GetWorld()
    if not world then return nil end
    local ok, ping = pcall(function()
        local gs = world:GetGameState()
        if not gs or not gs:IsValid() then return nil end
        local players = gs.PlayerArray
        if not players then return nil end
        local total, count = 0, 0
        for i = 0, players:Num() - 1 do
            local ps = players:Get(i)
            if ps and ps:IsValid() then
                local okP, p = pcall(function() return ps.Ping end)
                if okP and type(p) == "number" then
                    total = total + p
                    count = count + 1
                end
            end
        end
        if count == 0 then return nil end
        return math.floor(total / count)
    end)
    if ok and type(ping) == "number" then return ping end
    return nil
end

local function IsSessionAlive()
    local pc = JN.pc or GetPlayerController()
    if not pc then return true end
    local ok, conn = pcall(function() return pc.NetConnection end)
    if ok and conn == nil then
        local okAuth, auth = pcall(function() return pc:HasAuthority() end)
        if okAuth and auth == true then return true end
        return false
    end
    return true
end

local function Exec(cmd)
    pcall(function()
        local KSL = StaticFindObject("/Script/Engine.Default__KismetSystemLibrary")
        local pc = JN.pc or GetPlayerController()
        if KSL and pc then
            KSL:ExecuteConsoleCommand(pc, cmd, pc)
        end
    end)
end

local function GetAddressURL()
    local world = JN.world or GetWorld()
    if not world then return nil end
    local ok, url = pcall(function() return world:GetAddressURL() end)
    if ok and type(url) == "string" and url ~= "" then return url end
    return nil
end

local function ScoreServer(s)
    
    local lat = s.latency
    local latScore
    if lat == nil then
        latScore = 9999
    elseif lat < 0 then
        latScore = 10000
    else
        latScore = lat
    end
    return latScore * 10 + (s.priority or 100)
end

local function CurrentServerKey()
    local url = GetAddressURL()
    if not url then return nil end
    return tostring(url):lower():gsub("^%s+", ""):gsub("%s+$", "")
end

local function IsCurrentServer(s)
    local cur = CurrentServerKey()
    if not cur or cur == "" then return false end
    local hostport = tostring(s.host or ""):lower() .. ":" .. tostring(s.port or "")
    
    if cur == hostport then return true end
    local curHost = cur:match("^([^:]+)")
    if curHost and curHost ~= "" and s.host and curHost == tostring(s.host):lower() then
        return true
    end
    return false
end

local function PickBestServer(exclude)
    local best, bestScore = nil, nil
    for _, s in ipairs(JN.status.servers) do
        if s.enabled and s ~= exclude then
            local sc = ScoreServer(s)
            if bestScore == nil or sc < bestScore then
                bestScore = sc
                best = s
            end
        end
    end
    return best
end

local function TravelTo(s, reason)
    JN.status.failovers = JN.status.failovers + 1
    JN.status.currentTarget = s.name
    local latStr = s.latency and (s.latency < 0 and "DOWN" or (s.latency .. "ms")) or "n/a"
    NPanel(reason .. " -> [" .. s.name .. "] " .. s.host .. ":" .. s.port .. " " .. latStr, 8)
    ExecuteWithDelay(JN.config.travelDelayMs, function()
        pcall(Exec, "open " .. s.host .. ":" .. tostring(s.port))
    end)
    return true
end

local function TryRejoin()
    local url = GetAddressURL()
    JN.status.rejoins = JN.status.rejoins + 1
    if url and url ~= "" then
        NPanel("dropped, rejoining last session " .. url, 5)
        Exec("open " .. url)
        return true
    end
    NPanel("dropped, no address to rejoin, trying failover", 5)
    return false
end

local function TryFailover(reason)
    local cur = CurrentServerKey()
    local tried = JN.status.failoverTried
    if type(tried) ~= "table" then tried = {}; JN.status.failoverTried = tried end
    local sorted = {}
    for _, s in ipairs(JN.status.servers) do
        if s.enabled and not IsCurrentServer(s) and not tried[s.name] then
            table.insert(sorted, s)
        end
    end
    table.sort(sorted, function(a, b) return ScoreServer(a) < ScoreServer(b) end)
    local s = sorted[1]
    if s then
        tried[s.name] = true
        local n = 0
        for _ in pairs(tried) do n = n + 1 end
        NLog("failover: trying [" .. s.name .. "] (attempt " .. n
            .. "/" .. JN.config.maxFailoverTries .. " this generation)")
        if n >= (JN.config.maxFailoverTries or 3) then
            
            JN.status.failoverTried = nil
        end
        return TravelTo(s, reason)
    end
    NLog("failover: no usable standby (current=" .. tostring(cur)
        .. ", all candidates tried or none configured)")
    return false
end

local function SwitchToBest(reason)
    local cur = CurrentServerKey()
    local excluded = nil
    for _, s in ipairs(JN.status.servers) do
        if IsCurrentServer(s) then excluded = s; break end
    end
    local best = PickBestServer(excluded)
    if best then
        return TravelTo(best, reason)
    end
    if excluded then
        NPanel("already on the best/most suitable server, staying", 5)
    else
        NPanel("no standby server in config, staying", 5)
    end
    if cur then NLog("switch: no better target than " .. cur) end
    return false
end

local function OfflineSafeMode()
    JN.status.state = "offline-guard"
    Exec("slomo 1")
    local pc = JN.pc or GetPlayerController()
    pcall(function()
        if pc and pc:IsValid() then
            pc.bShowMouseCursor = true
            pc.bEnableClickEvents = true
        end
    end)
end

local function NetLoop()
    local ping = CurrentPing()
    if ping then
        JN.status.lastPing = ping
        table.insert(JN.status.pingSamples, ping)
        if #JN.status.pingSamples > 12 then
            table.remove(JN.status.pingSamples, 1)
        end
    end
    if not IsSessionAlive() then
        if JN.status.state == "online" then
            JN.status.state = "dropped"
            JN.status.drops = JN.status.drops + 1
            NLog("session drop detected")
            if JN.config.rejoinOnDrop and TryRejoin() then
                JN.status.state = "rejoining"
            elseif JN.config.failoverOnDrop and TryFailover("dropped") then
                JN.status.state = "failover"
            else
                OfflineSafeMode()
            end
        end
    else
        if JN.status.state == "rejoining" or JN.status.state == "failover" then
            JN.status.rejoinCheck = JN.status.rejoinCheck + 1
            if JN.status.rejoinCheck >= 3 then
                NPanel("back online" .. (JN.status.currentTarget and (" via " .. JN.status.currentTarget) or ""), 5)
                JN.status.state = "online"
                JN.status.currentTarget = nil
                JN.status.rejoinCheck = 0
                
                JN.status.failoverTried = nil
            end
        elseif JN.status.state ~= "online" then
            JN.status.state = "online"
            JN.status.currentTarget = nil
            
            pcall(function()
                local pc = JN.pc or GetPlayerController()
                if pc and pc:IsValid() then pc.bShowMouseCursor = false end
            end)
        end
        if JN.config.autoSwitch and ping and #JN.status.pingSamples >= JN.config.pingBadSamples then
            local bad = 0
            for i = #JN.status.pingSamples - JN.config.pingBadSamples + 1, #JN.status.pingSamples do
                if JN.status.pingSamples[i] >= JN.config.pingKick then bad = bad + 1 end
            end
            if bad >= JN.config.pingBadSamples then
                if SwitchToBest("ping " .. ping .. "ms too high") then
                    JN.status.pingSamples = {}
                    JN.status.state = "failover"
                end
            end
        end
    end
    if JN.status.initDone and ping and ping >= JN.config.pingWarn and #JN.status.pingSamples == 12 then
        local worst = 0
        for _, p in ipairs(JN.status.pingSamples) do
            if p > worst then worst = p end
        end
        
        if worst >= JN.config.pingWarn and (os.time() - (JN.status.lastPingWarn or 0)) > 30 then
            JN.status.lastPingWarn = os.time()
            local best = PickBestServer()
            if best then
                local latStr = best.latency and (best.latency .. "ms") or "n/a"
                NPanel("ping " .. ping .. "ms high, standby [" .. best.name .. "] " .. latStr .. " (Ctrl+F6 to switch)", 6)
            end
        end
    end
    pcall(function()
        ExecuteWithDelay(JN.config.pollMs, function() pcall(NetLoop) end)
    end)
end

local function Report()
    NLog("=== JinxingNetSuite v" .. JN.version .. " ===")
    NLog("cfg: " .. JN.status.cfgSource .. " | servers: " .. #JN.status.servers)
    for i, s in ipairs(JN.status.servers) do
        local latStr = s.latency and (s.latency < 0 and "DOWN" or (s.latency .. "ms")) or "?"
        NLog(string.format("  [%d] %-16s %-22s:%-5d %-8s prio=%d %s %s",
            i, s.name, s.host, s.port, s.region, s.priority, s.enabled and "on" or "off", latStr))
    end
    NLog("state: " .. JN.status.state .. " | ping: " .. JN.status.lastPing .. "ms")
    NLog("drops: " .. JN.status.drops .. " | rejoins: " .. JN.status.rejoins .. " | failovers: " .. JN.status.failovers)
    local samples = {}
    for _, p in ipairs(JN.status.pingSamples) do
        table.insert(samples, tostring(p))
    end
    NLog("ping window: [" .. table.concat(samples, ",") .. "]")
    NPanel("report printed to UE4SS log ([JinxingNetSuite] lines)", 5)
end

local function BindKeys()
    
    local ctrl = nil
    pcall(function() ctrl = { ModifierKey.CONTROL } end)
    if ctrl == nil or ctrl[1] == nil then
        pcall(function() ctrl = { Key.LEFT_CONTROL } end)
    end
    if ctrl == nil or ctrl[1] == nil then
        pcall(function() ctrl = { Key.CONTROL } end)
    end
    local okF5, kF5 = pcall(function() return Key.F5 end)
    if okF5 and kF5 then
        pcall(function() RegisterKeyBind(kF5, function() Report() end) end)
    end
    local okF6, kF6 = pcall(function() return Key.F6 end)
    if okF6 and kF6 and ctrl and ctrl[1] then
        pcall(function() RegisterKeyBind(kF6, ctrl, function() SwitchToBest("manual switch") end) end)
    else
        NLog("key note: Ctrl+F6 unavailable on this build; switching stays automatic (failover)")
    end
    local okF7, kF7 = pcall(function() return Key.F7 end)
    if okF7 and kF7 and ctrl and ctrl[1] then
        pcall(function() RegisterKeyBind(kF7, ctrl, function()
            JN.config.autoSwitch = not JN.config.autoSwitch
            NPanel("auto switch " .. (JN.config.autoSwitch and "ON" or "OFF"), 4)
        end) end)
    end
    NPanel("net keys: F5=report Ctrl+F6=switch Ctrl+F7=auto", 6)
end

local function ReloadServers()
    JN.status.servers = LoadServerConfig()
    NLog("server list loaded: " .. #JN.status.servers .. " from " .. JN.status.cfgSource)
end

local function Boot()
    NLog("boot v" .. JN.version)
    JN.config.pingWarn = ReadIniInt(JN.config.iniFile, "ping_warn", 120)
    JN.config.pingKick = ReadIniInt(JN.config.iniFile, "ping_kick", 180)
    JN.config.pingBadSamples = ReadIniInt(JN.config.iniFile, "ping_bad_samples", 4)
    JN.config.autoSwitch = ReadIniBool(JN.config.iniFile, "auto_switch", false)
    JN.config.rejoinOnDrop = ReadIniBool(JN.config.iniFile, "rejoin_on_drop", true)
    JN.config.failoverOnDrop = ReadIniBool(JN.config.iniFile, "failover_on_drop", true)
    JN.config.pollMs = ReadIniInt(JN.config.iniFile, "poll_ms", 5000)
    JN.config.travelDelayMs = ReadIniInt(JN.config.iniFile, "travel_delay_ms", 3000)
    JN.config.maxFailoverTries = ReadIniInt(JN.config.iniFile, "max_failover_tries", 3)
    ReloadServers()
    Exec("net.ServerMaxTickRate 60")
    Exec("net.UseAdaptiveNetUpdateFrequency 1")
    Exec("net.IPConnectionUseSendTasks 1")
    BindKeys()
    ExecuteWithDelay(3000, function()
        pcall(function()
            JN.world = GetWorld()
            JN.pc = GetPlayerController()
            JN.status.initDone = true
            NPanel("net guard ready: F5 report / Ctrl+F6 switch / Ctrl+F7 auto " .. (JN.config.autoSwitch and "ON" or "OFF"), 6)
        end)
        
        pcall(NetLoop)
        ExecuteWithDelay(30000, function()
            pcall(ReloadServers)
            ExecuteWithDelay(120000, function() pcall(ReloadServers) end)
        end)
    end)
end

Boot()
