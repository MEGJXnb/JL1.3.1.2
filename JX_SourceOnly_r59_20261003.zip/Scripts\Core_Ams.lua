-- Core_Ams.lua (r16 split from main.lua) - deps bridged via _G.JXEnv
local E = _G.JXEnv or {}
local Log = E.Log or function(s) print("[JX] " .. tostring(s) .. "'\n'") end
-- r25 dedup: two loader paths in main.lua; single-arm guard.
if _G.JX_CORE_AMS_LOADED then Log("Core_Ams: duplicate load skipped (r25 dedup)") return end
_G.JX_CORE_AMS_LOADED = true
local ModDir = E.ModDir
local JXAlive = E.JXAlive
local JXName = E.JXName
function JXAmsJson()
    local function Say(s) Log("[AMS] " .. tostring(s)) end

    local function Encode(t)
        
        local function esc(s)
            s = tostring(s or "")
            return s:gsub('[%c"\\]', function(c)
                return string.format("\\u%04x", string.byte(c))
            end)
        end
        local parts = {}
        for _, row in ipairs(t) do
            local kv = {}
            for k, v in pairs(row) do
                kv[#kv + 1] = string.format('"%s":"%s"', esc(k), esc(v))
            end
            parts[#parts + 1] = "{" .. table.concat(kv, ",") .. "}"
        end
        return "[" .. table.concat(parts, ",") .. "]"
    end

    local function Snapshot()
        local rows, n = {}, 0
        pcall(function()
            local all = FindAllOf("StaticMeshActor")
            if not all then return end
            for _, a in pairs(all) do
                if JXAlive(a) then
                    local cls, loc, name = "", "", ""
                    pcall(function() cls = JXName(a:GetClass()) or "" end)
                    pcall(function() name = JXName(a) or "" end)
                    local l = nil
                    pcall(function() l = a:K2_GetActorLocation() end)
                    if l and cls ~= "" then
                        n = n + 1
                        rows[#rows + 1] = {
                            cls = cls, name = name,
                            x = string.format("%.1f", l.X or 0),
                            y = string.format("%.1f", l.Y or 0),
                            z = string.format("%.1f", l.Z or 0),
                        }
                    end
                end
            end
        end)
        return rows, n
    end

    local function MarkerRow()
        local p = nil
        pcall(function() p = MarkPos() end)
        if not p then return nil end
        return { cls = "Marker", name = "jmark",
                 x = string.format("%.1f", p.X), y = string.format("%.1f", p.Y), z = string.format("%.1f", p.Z) }
    end

    JXRegCmd("jxsave", function(FullCommand, Parameters, Ar)
        ExecuteInGameThread(function()
            pcall(function()
                local rows, n = Snapshot()
                local mk = MarkerRow()
                if mk then rows[#rows + 1] = mk; n = n + 1 end
                local map = CurrentMapName and CurrentMapName() or "unknown"
                local path = ModDir .. "saves/AMS-" .. map .. ".json"
                local h = io.open(path, "w")
                if not h then Say("cannot write " .. path); return end
                h:write('{"map":"' .. map .. '","count":' .. n .. ',"objects":')
                h:write(Encode(rows))
                h:write('}')
                h:close()
                Say(string.format("snapshot saved: %d object(s) + marker -> %s", n, path))
            end)
        end)
    end)

    JXRegCmd("jxload", function(FullCommand, Parameters, Ar)
        ExecuteInGameThread(function()
            pcall(function()
                local map = CurrentMapName and CurrentMapName() or "unknown"
                local path = ModDir .. "saves/AMS-" .. map .. ".json"
                local h = io.open(path, "r")
                if not h then Say("no snapshot for this map (jxsave first) - " .. path); return end
                local txt = h:read("*a")
                h:close()
                local restored = 0
                for cls, x, y, z in txt:gmatch('"cls":"(%w+)"[^}]-"x":"([%-%d%.]+)","y":"([%-%d%.]+)","z":"([%-%d%.]+)"') do
                    local a = J3SpawnAt(cls, tonumber(x), tonumber(y), tonumber(z), 0, nil)
                    if JXAlive(a) then restored = restored + 1 end
                end
                
                local mx, my, mz = txt:match('"cls":"Marker"[^}]-"x":"([%-%d%.]+)","y":"([%-%d%.]+)","z":"([%-%d%.]+)"')
                if mx then
                    pcall(function()
                        local a = J3SpawnAt("StaticMeshActor", tonumber(mx), tonumber(my), tonumber(mz), 0,
                            "/Engine/BasicShapes/Cube.Cube")
                        if JXAlive(a) then
                            pcall(function() a:SetActorScale3D({ X = 0.8, Y = 0.8, Z = 0.8 }) end)
                            Mark.actor = a
                        end
                    end)
                end
                Say(string.format("restored %d object(s) from %s%s", restored, path,
                    mx and " + marker cube re-armed" or ""))
            end)
        end)
    end)

    Log("AMS json ready: jxsave (snapshot incl. marker) | jxload (restore + re-arm)")
end
JXAmsJson()
