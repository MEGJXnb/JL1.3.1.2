-- Core_Reliab.lua (r16 split from main.lua) - deps bridged via _G.JXEnv
local E = _G.JXEnv or {}
local Log = E.Log or function(s) print("[JX] " .. tostring(s) .. "'\n'") end
-- r25 dedup: two loader paths in main.lua; single-arm guard (duplicate would
-- register jtab12/jtab13 twice and run two AssertPage 3 s re-assert loops).
if _G.JX_CORE_RELIAB_LOADED then Log("Core_Reliab: duplicate load skipped (r25 dedup)") return end
_G.JX_CORE_RELIAB_LOADED = true
local JXAlive = E.JXAlive
function JXReliability()
    local function Say(s) Log("[REL] " .. tostring(s)) end

    -- r44: 12/13 were the OLD generation's Plus/Pro slots. The F5531FBD pak
    -- patch moved the pill handlers to 18/19; these commands + the re-assert
    -- guard follow the live slots.
    -- r56: main exports _G.JXTabGo (its local is JxTabGo, private) - the bare
    -- name here was a nil global and both commands silently no-op'd
    JXRegCmd("jtab12", function() ExecuteInGameThread(function() pcall(function() _G.JXTabGo(18, true) end) end) end)
    JXRegCmd("jtab13", function() ExecuteInGameThread(function() pcall(function() _G.JXTabGo(19, true) end) end) end)

    local function AssertPage()
        pcall(function()
            -- r56: resolve the bridge at call time. The bare names
            -- (PakPanelMouseOn/TabIndex/AcquireTabSwitcher) were nil globals
            -- in this sidecar, so the guard returned on the first line and
            -- the drift re-assert never ran.
            local Env = _G.JXEnv or {}
            if not (Env.IsPanelMouseOn and Env.IsPanelMouseOn()) then return end
            local want = (Env.GetTabIndex and Env.GetTabIndex()) or 0
            if want == 18 or want == 19 then
                local sw = (Env.AcquireTabSwitcher and Env.AcquireTabSwitcher()) or nil
                if sw and JXAlive(sw) then
                    local got = nil
                    pcall(function() got = sw:GetActiveWidgetIndex() end)
                    if type(got) == "number" and got ~= want then
                        pcall(function() sw:SetActiveWidgetIndex(want) end)
                        Say(string.format("page re-asserted: %d (widget had drifted to %s)", want, tostring(got)))
                    end
                end
            end
        end)
        ExecuteWithDelay(3000, function() ExecuteInGameThread(function() pcall(AssertPage) end) end)
    end
    ExecuteWithDelay(6000, function() ExecuteInGameThread(function() pcall(AssertPage) end) end)
    Log("re-click hardening ready: jtab12/jtab13 + page re-assert while the panel is open")
end
JXReliability()
