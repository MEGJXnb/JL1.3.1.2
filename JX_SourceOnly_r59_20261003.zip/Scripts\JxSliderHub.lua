
local H = { applied = 0 }

local okUH, UEHelpers = pcall(require, "UEHelpers")
if not okUH then UEHelpers = nil end

local function Say(s) print("[SLIDER] " .. tostring(s) .. "\n") end

local function GetPC()
    local pc = nil
    if UEHelpers then
        pcall(function() pc = UEHelpers.GetPlayerController() end)
    end
    if not (pc and pc:IsValid()) then
        pcall(function() pc = FindFirstOf("PlayerController") end)
    end
    if pc and pc:IsValid() then return pc end
    return nil
end

local ExecRaw = (type(_G) == "table" and _G.JXExecCmd) or nil

local function Exec(cmd)
    local pc = GetPC()
    if not pc then Say("no player controller yet"); return false end
    local ok = false
    pcall(function()
        if ExecRaw then
            ok = ExecRaw(pc, cmd)
        else
            ok = JXExecCmd(pc, cmd)   
        end
    end)
    return ok == true
end

local F = {}
local function def(name, mn, mx, dfmt, apply)
    F[name] = { mn = mn, mx = mx, fmt = dfmt, apply = apply }
end

local function numfmt(v, unit)
    if unit and unit ~= "" then return string.format("%g%s", v, unit) end
    return string.format("%g", v)
end

def("speed", 300, 2400, "u/s", function(v)
    local done = false
    pcall(function()
        local pc = GetPC()
        if pc and pc.Pawn and pc.Pawn:IsValid() then
            local m = pc.Pawn.CharacterMovement
            if m and m:IsValid() then m.MaxWalkSpeed = v; done = true end
        end
    end)
    return done
end)

local VISION = { "off", "night", "luma", "stealth" }
def("vision", 0, 3, "", function(v)
    local i = math.floor(v + 0.5)
    if i == 0 then
        Exec("r.EyeAdaptationQuality 1")
        Exec("r.TonemapperGamma 1.0")
        Exec("r.DefaultFeature.AutoExposure 1")
        return true
    end
    if i == 1 then
        Exec("r.EyeAdaptationQuality 2")
        Exec("r.TonemapperGamma 1.8")
        Exec("r.DefaultFeature.AutoExposure 0")
        return true
    end
    if i == 2 then
        Exec("r.Tonemapper.Sharpen 1.5")
        Exec("r.Tonemapper.Quality 5")
        Exec("r.Color.Mid 0.45")
        return true
    end
    if i == 3 then
        Exec("r.EyeAdaptationQuality 0")
        Exec("r.TonemapperGamma 0.85")
        return true
    end
    return false
end)
F.vision.unit = ""
F.vision.labels = VISION

def("jump", 400, 2000, "u", function(v)
    local done = false
    pcall(function()
        local pc = GetPC()
        if pc and pc.Pawn and pc.Pawn:IsValid() then
            local m = pc.Pawn.CharacterMovement
            if m and m:IsValid() then m.JumpZVelocity = v; done = true end
        end
    end)
    return done
end)

def("glide", 0, 4, "", function(v) return Exec("jplus glide") end)
F.glide.labels = { "off", "slow", "mid", "fast", "feather" }

def("brightness", 0.5, 2.0, "x", function(v) return Exec("r.TonemapperGamma " .. string.format("%g", v)) end)
def("gamma", 0.8, 2.2, "", function(v) return Exec("r.TonemapperGamma " .. string.format("%g", v)) end)
def("exposure", 0.5, 2.0, "x", function(v) return Exec("r.EyeAdaptation.ExposureCompensation " .. string.format("%g", (v - 1.0) * 3.0)) end)
def("sharpen", 0, 3, "", function(v) return Exec("r.Tonemapper.Sharpen " .. string.format("%g", v)) end)
def("fov", 80, 150, "deg", function(v)
    local done = false
    pcall(function()
        local pc = GetPC()
        if pc and pc:IsValid() and pc.SetFOV then pc:SetFOV(v); done = true end
    end)
    return done
end)
def("dof", 0, 4, "", function(v) return Exec("r.DepthOfFieldQuality " .. math.floor(v + 0.5)) end)
F.dof.labels = { "off", "low", "mid", "high", "cinematic" }

def("timescale", 0.25, 3.0, "x", function(v) return Exec("slomo " .. string.format("%g", v)) end)
def("gravity", 0.1, 2.0, "x", function(v)
    local done = false
    pcall(function()
        local pc = GetPC()
        if pc and pc.Pawn and pc.Pawn:IsValid() then
            local m = pc.Pawn.CharacterMovement
            if m and m:IsValid() then m.GravityScale = v; done = true end
        end
    end)
    return done
end)
def("pro_speed", 300, 3000, "u/s", function(v)
    local done = false
    pcall(function()
        local pc = GetPC()
        if pc and pc.Pawn and pc.Pawn:IsValid() then
            local m = pc.Pawn.CharacterMovement
            if m and m:IsValid() then m.MaxWalkSpeed = v; done = true end
        end
    end)
    return done
end)
def("pro_jump", 400, 3000, "u", function(v)
    local done = false
    pcall(function()
        local pc = GetPC()
        if pc and pc.Pawn and pc.Pawn:IsValid() then
            local m = pc.Pawn.CharacterMovement
            if m and m:IsValid() then m.JumpZVelocity = v; done = true end
        end
    end)
    return done
end)
def("scale", 0.5, 3.0, "x", function(v)
    local done = false
    pcall(function()
        local pc = GetPC()
        if pc and pc.Pawn and pc.Pawn:IsValid() then
            pc.Pawn:SetActorScale3D({ X = v, Y = v, Z = v })
            done = true
        end
    end)
    return done
end)
def("sprint", 500, 3000, "u", function(v)
    local done = false
    pcall(function()
        
        local pc = GetPC()
        if pc and pc:IsValid() and pc.Pawn and pc.Pawn:IsValid() then
            local p = pc.Pawn:K2_GetActorLocation()
            local r = pc.Pawn:K2_GetActorRotation()
            local yaw = math.rad(r.Yaw or 0)
            local nx = p.X + math.sin(yaw) * v
            local ny = p.Y + math.cos(yaw) * v
            pc.Pawn:K2_SetActorLocation({ X = nx, Y = ny, Z = p.Z }, false, true)
            done = true
        end
    end)
    return done
end)
def("climb", 500, 5000, "u", function(v)
    local done = false
    pcall(function()
        
        local pc = GetPC()
        if pc and pc:IsValid() and pc.Pawn and pc.Pawn:IsValid() then
            local p = pc.Pawn:K2_GetActorLocation()
            pc.Pawn:K2_SetActorLocation({ X = p.X, Y = p.Y, Z = p.Z + v }, false, true)
            done = true
        end
    end)
    return done
end)

def("shadow", 0, 4, "", function(v) return Exec("sg.ShadowQuality " .. math.floor(v + 0.5)) end)
F.shadow.labels = { "off", "low", "mid", "high", "cinematic" }
def("texture", 0, 3, "", function(v) return Exec("sg.TextureQuality " .. math.floor(v + 0.5)) end)
F.texture.labels = { "off", "low", "mid", "high" }
def("aa", 0, 4, "", function(v) return Exec("sg.AntiAliasingQuality " .. math.floor(v + 0.5)) end)
def("pp", 0, 4, "", function(v) return Exec("sg.PostProcessQuality " .. math.floor(v + 0.5)) end)
def("particles", 100, 2000, "k", function(v) return Exec("fx.MaxGPUSimulationParticles " .. math.floor(v * 1000)) end)
def("drawdist", 0.5, 2.0, "x", function(v) return Exec("r.ViewDistanceScale " .. string.format("%g", v)) end)
def("lod", 0.5, 2.0, "x", function(v) return Exec("r.StaticMeshLODDistanceScale " .. string.format("%g", v)) end)
def("aniso", 0, 16, "x", function(v) return Exec("r.MaxAnisotropy " .. math.floor(v + 0.5)) end)

local function Apply(feature, rawv)
    local f = F[feature]
    if not f then
        local names = {}
        for k in pairs(F) do names[#names + 1] = k end
        table.sort(names)
        Say("unknown feature '" .. tostring(feature) .. "'. features: " .. table.concat(names, " "))
        return false
    end
    local v = tonumber(rawv)
    if v == nil then
        Say("usage: jxslider " .. feature .. " <" .. f.mn .. ".." .. f.mx .. ">")
        return false
    end
    if v < f.mn then v = f.mn end
    if v > f.mx then v = f.mx end
    local ok = false
    pcall(function() ok = f.apply(v) == true end)
    local label = numfmt(v, f.unit)
    if f.labels and f.labels[math.floor(v + 0.5) + 1] then
        label = label .. " (" .. f.labels[math.floor(v + 0.5) + 1] .. ")"
    end
    if ok then
        H.applied = H.applied + 1
        Say(feature .. " = " .. label .. "  [applied #" .. H.applied .. "]")
    else
        Say(feature .. " = " .. label .. "  [apply FAILED - see log]")
    end
    return ok
end

local function List()
    local names = {}
    for k in pairs(F) do names[#names + 1] = k end
    table.sort(names)
    Say(#names .. " features: " .. table.concat(names, " "))
    Say("usage: jxslider <feature> <value>   e.g. jxslider timescale 1.5")
end

JXRegCmd("jxslider", function(FullCommand, Parameters)
    local f = Parameters and Parameters[1]
    if not f or f == "" or f == "list" then
        List()
        return true
    end
    local v = Parameters[2]
    if v == nil and F[f] then v = F[f].mn end   
    ExecuteInGameThread(function() pcall(Apply, f, v) end)
    return true
end)

function H.FeatureCount()
    local n = 0
    for _ in pairs(F) do n = n + 1 end
    return n
end

local Grid = { tiles = {}, cube = nil, visible = false }

local function GridClear()
    for _, t in ipairs(Grid.tiles) do
        if t and t:IsValid() then pcall(function() t:DestroyActor() end) end
    end
    Grid.tiles = {}
    Grid.visible = false
end

local function GridHalfHeight(pc)
    local h = 88
    pcall(function()
        local c = pc.Pawn.CapsuleComponent
        if c and c:IsValid() then
            local r = c:GetScaledCapsuleHalfHeight()
            if type(r) == "number" and r > 4 and r < 400 then h = r end
        end
    end)
    return h
end

local function SpawnTile(x, y, z, yaw, mesh_path, scale, r, g, b, a)
    local W = nil
    pcall(function() W = UEHelpers and UEHelpers.GetWorld() or FindFirstOf("World") end)
    if not (W and W:IsValid()) then return nil end

    local cls = nil
    pcall(function() cls = StaticFindObject("/Script/Engine.StaticMeshActor") end)
    if not (cls and cls:IsValid()) then return nil end

    local actor = nil
    pcall(function() actor = W:SpawnActor(cls, { X = x, Y = y, Z = z }, { Pitch = 0, Yaw = yaw or 0, Roll = 0 }) end)
    if not (actor and actor:IsValid()) then return nil end

    if scale then pcall(function() actor:SetActorScale3D({ X = scale, Y = scale, Z = scale }) end) end
    pcall(function() actor:SetActorEnableCollision(false) end)

    if r or g or b then
        pcall(function()
            local smc = actor.StaticMeshComponent
            if smc and smc:IsValid() then
                local mid = smc:CreateDynamicMaterialInstance(0)
                if mid then
                    local col = { R = r or 0, G = g or 1, B = b or 1, A = a or 0.45 }
                    local hit = false
                    pcall(function() mid:SetVectorParameterValue("Color", col); hit = true end)
                    if not hit then
                        pcall(function() mid:SetVectorParameterValue("BaseColor", col); hit = true end)
                    end
                    pcall(function() mid:SetScalarParameterValue("Opacity", a or 0.45) end)
                end
            end
        end)
    end

    if mesh_path then
        pcall(function()
            local mesh = nil
            pcall(function() mesh = StaticFindObject(mesh_path) end)
            if not (mesh and mesh:IsValid()) then
                pcall(function() mesh = LoadAsset(mesh_path) end)
            end
            if mesh and mesh:IsValid() then
                local smc = actor.StaticMeshComponent
                if smc and smc:IsValid() then smc:SetStaticMesh(mesh) end
            end
        end)
    end
    return actor
end

function H.GridBuild(n, gap, r, g, b)
    n = n or 5; gap = gap or 130
    r = r or 0; g = g or 1; b = b or 1
    GridClear()
    local pc = GetPC()
    if not (pc and pc.Pawn and pc.Pawn:IsValid()) then
        Say("grid: no player pawn yet")
        return false
    end
    local loc, rot = nil, nil
    pcall(function() loc = pc.Pawn:K2_GetActorLocation() end)
    pcall(function() rot = pc.Pawn:K2_GetActorRotation() end)
    if not loc then Say("grid: pawn has no location"); return false end
    local yaw = (rot and rot.Yaw) or 0
    local halfH = GridHalfHeight(pc)
    local z = loc.Z - halfH + 6
    local half = (n - 1) / 2
    local made = 0
    for i = 0, n - 1 do
        for j = 0, n - 1 do
            local tx = loc.X + (i - half) * gap
            local ty = loc.Y + (j - half) * gap
            local tile = SpawnTile(tx, ty, z, yaw, "/Engine/BasicShapes/Cube.Cube", 1.1, r, g, b, 0.4)
            if tile then
                pcall(function() tile:SetActorScale3D({ X = 1.1, Y = 1.1, Z = 0.06 }) end)
                Grid.tiles[#Grid.tiles + 1] = tile
                made = made + 1
            end
        end
    end
    
    local pillar = SpawnTile(loc.X, loc.Y, z + 300, yaw, "/Engine/BasicShapes/Cube.Cube", 0.35, 1, 1, 0, 1)
    if pillar then
        pcall(function() pillar:SetActorScale3D({ X = 0.35, Y = 0.35, Z = 6.0 }) end)
        Grid.tiles[#Grid.tiles + 1] = pillar
    end
    Grid.visible = true
    
    Say(string.format("grid: %dx%d (%d tiles + pillar) at (%.0f, %.0f, %.0f) floor z=%.0f",
        n, n, made, loc.X, loc.Y, z, z))
    return made > 0
end

function H.GridClear()
    GridClear()
    Say("grid: cleared")
end

function H.CubeSpawn(atAim)
    local pc = GetPC()
    if not (pc and pc.Pawn and pc.Pawn:IsValid()) then
        Say("cube: no player pawn yet")
        return false
    end
    
    if Grid.cube and Grid.cube:IsValid() then
        pcall(function() Grid.cube:DestroyActor() end)
        Grid.cube = nil
    end
    local loc, rot = nil, nil
    pcall(function() loc = pc.Pawn:K2_GetActorLocation() end)
    pcall(function() rot = pc.Pawn:K2_GetActorRotation() end)
    if not loc then Say("cube: no location"); return false end
    local x, y, z = loc.X, loc.Y, loc.Z
    local yaw = (rot and rot.Yaw) or 0
    if atAim then
        
        pcall(function()
            local cam = pc.PlayerCameraManager
            if cam and cam:IsValid() then
                local cl = cam:GetCameraLocation()
                local cr = cam:GetCameraRotation()
                if cl and cr then
                    local pitch = math.rad(cr.Pitch or 0)
                    local yw = math.rad(cr.Yaw or 0)
                    local cp = math.cos(pitch)
                    local dist = 180
                    x = cl.X + cp * math.cos(yw) * dist
                    y = cl.Y + cp * math.sin(yw) * dist
                    z = cl.Z + math.sin(pitch) * dist
                    yaw = cr.Yaw or 0
                end
            end
        end)
    else
        
        local halfH = GridHalfHeight(pc)
        z = loc.Z - halfH + 45
    end
    local cube = SpawnTile(x, y, z, yaw, "/Engine/BasicShapes/Cube.Cube", 0.8, 0, 1, 1, 0.45)
    if cube then
        Grid.cube = cube
        Say(string.format("cube: live at (%.0f, %.0f, %.0f) walk-through semi-transparent", x, y, z))
        return true
    end
    Say("cube: spawn failed")
    return false
end

function H.CubeRemove()
    if Grid.cube and Grid.cube:IsValid() then
        pcall(function() Grid.cube:DestroyActor() end)
        Grid.cube = nil
        Say("cube: removed")
        return true
    end
    Say("cube: none live")
    return false
end

function H.CubeMove()
    if Grid.cube and Grid.cube:IsValid() then
        pcall(function() Grid.cube:DestroyActor() end)
        Grid.cube = nil
    end
    return H.CubeSpawn(true)
end

JXRegCmd("jxgrid", function(FullCommand, Parameters)
    local sub = (Parameters and Parameters[1]) or "on"
    ExecuteInGameThread(function()
        pcall(function()
            if sub == "off" then H.GridClear()
            elseif sub == "status" then
                Say("grid: " .. (#Grid.tiles > 0 and (#Grid.tiles .. " tiles live") or "off"))
            else
                local n = tonumber(sub) or 5
                if n < 2 then n = 2 elseif n > 11 then n = 11 end
                local gap = tonumber(Parameters and Parameters[2]) or 130
                H.GridBuild(n, gap)
            end
        end)
    end)
    return true
end)

JXRegCmd("jxcube", function(FullCommand, Parameters)
    local sub = (Parameters and Parameters[1]) or "on"
    ExecuteInGameThread(function()
        pcall(function()
            if sub == "off" then H.CubeRemove()
            elseif sub == "here" or sub == "move" then H.CubeMove()
            elseif sub == "aim" then H.CubeSpawn(true)
            else H.CubeSpawn(false) end   
        end)
    end)
    return true
end)

print("[SLIDER] hub ready: " .. H.FeatureCount() .. " features + grid + cube via jxslider/jxgrid/jxcube\n")

return H
