-- Core_WL.lua (r16 split from main.lua) - deps bridged via _G.JXEnv
local E = _G.JXEnv or {}
local Log = E.Log or function(s) print("[JX] " .. tostring(s) .. "'\n'") end
-- r25 dedup: two loader paths in main.lua; single-arm guard. Second load would
-- double JXMemberPack (auto-boost/jboost2/pacing timers) and WL boot75 ticks.
if _G.JX_CORE_WL_LOADED then Log("Core_WL: duplicate load skipped (r25 dedup)") return end
_G.JX_CORE_WL_LOADED = true
local UEHelpers = E.UEHelpers
local ModDir = E.ModDir
local JXQueue = E.JXQueue
local JXRootOr = E.JXRootOr
function JXWhitelist()
    local Level, WLDefault = 0, 0
    local LastName = "?"

    local function Say(s) Log("[WL] " .. tostring(s)) end

    local function LoadList()
        local lv, names = {}, {}
        local base = ModDir or JXRootOr or "Mods/JinxingLoaderRT/"
        local h = io.open(base .. "config/whitelist.ini", "r")
        if not h then Log("WL| LoadList: cannot open whitelist.ini at " .. tostring(base)); return names, 0 end
        local section = ""
        for line in h:lines() do
            line = line:gsub("^\239\187\191", "")
            local s = line:match("^%s*%[([%w%._]+)%]")
            if s then section = s:lower()
            else
                local k, v = line:match("^%s*([^#%s][^=]-)%s*=%s*(.-)%s*$")
                if k then
                    if k:lower() == "default" then
                        lv = tonumber(v) or 0
                    elseif section == "levels" then
                        
                        local lvlStr, expiryStr = v:match("^(%d+%.?%d*):?(%d*)$")
                        local n = tonumber(lvlStr)
                        if n then
                            local expired = false
                            if expiryStr and expiryStr ~= "" then
                                local y, mo, d = tonumber(expiryStr:sub(1,4)), tonumber(expiryStr:sub(5,6)), tonumber(expiryStr:sub(7,8))
                                if y and mo and d then
                                    local now_t = os.time()
                                    local exp_t = nil
                                    pcall(function() exp_t = os.time({year=y, month=mo, day=d, hour=23, min=59, sec=59}) end)
                                    expired = (exp_t ~= nil and now_t > exp_t)
                                end
                            end
                            if not expired then
                                names[#names + 1] = { name = k, level = n }
                            else
                                Log("WL| '" .. k .. "' expired " .. expiryStr .. " -> level 0")
                            end
                        end
                    end
                end
            end
        end
        h:close()
        return names, lv
    end

    local function Names()
        local n, d = LoadList()
        WLDefault = d
        return n
    end

    local function Me()
        local me = ""
        pcall(function() if type(JXIdent) == "function" then me = (JXIdent()) or "" end end)
        if me ~= "" and me ~= "steam:unknown" then return me end -- r17.6: unknown falls through -- r17.6: unknown steam id falls through to the player-name channel
        pcall(function()
            local PC = UEHelpers.GetPlayerController()
            if PC and PC:IsValid() then
                me = PlayerName(PC.PlayerState) or ""
            end
        end)
        if me:find("TrivialObject", 1, true) then me = "" end
        return me
    end

    local function LevelOf(name)
        if type(name) ~= "string" or name == "" then return WLDefault end
        local list = Names()
        for _, e in ipairs(list) do
            if e.name == name then return e.level end
        end
        
        for _, e in ipairs(list) do
            if e.name:lower() == name:lower() then return e.level end
        end
        return WLDefault
    end

    local function Refresh(tag)
        Log("WL| R1 enter tag=" .. tostring(tag))
        local me = Me()
        Log("WL| R2 me=" .. tostring(me))
        local lvl = LevelOf(me)
        pcall(function() lvl = math.min(tonumber(lvl) or 0, 6) end)
        Log("WL| R3 lvl=" .. tostring(lvl) .. " (cap 6)")
        pcall(function()
            local info = JXTravelInfo and JXTravelInfo() or nil
            if info and info.authority == true and lvl < 6 then lvl = 6 end
        end)
        Level = lvl
        LastName = (me == "" and "(unknown)" or me)
        local tier = "none"
        
        if lvl >= 4 and lvl <= 5.5 then tier = "PRO+PLUS"
        elseif lvl >= 1 and lvl <= 3 then tier = "PLUS"
        elseif lvl == 0 then tier = "ordinary (level 0)" end
        local h = false
        pcall(function()
            local info = JXTravelInfo and JXTravelInfo() or nil
            h = (info ~= nil and info.authority == true)
        end)
        Log("WL| R4 host=" .. tostring(h))
        if h then tier = tier .. " +HOST" end
        Log(string.format("WL| %s: player=%s level=%s -> %s", tostring(tag), LastName, tostring(lvl), tier))
        if lvl >= 1 then
            
            local okf = pcall(function() JXQueue({ "t.MaxFPS 0", "r.MotionBlurQuality 0", "r.MotionBlur.Max 0", "r.MotionBlur.Amount 0" }) end)
            Log("WL| full crash guard unlocked for " .. LastName)
        end
        return lvl
    end

    local function IsHost()
        local auth = false
        pcall(function()
            local info = JXTravelInfo and JXTravelInfo() or nil
            auth = (info ~= nil and info.authority == true)
        end)
        return auth
    end
    local function Allow(need)
        if IsHost() then return true end
        
        local JW = _G.JxWhitelist
        if type(JW) == "table" and type(JW.AllowBySteam64) == "function" then
            local verdict = JW.AllowBySteam64(need)
            if verdict ~= nil then return verdict end
        end
        
        if need == "PLUS" then return Level >= 1 end
        if need == "PRO" then return Level >= 3.5 end
        return false
    end

    local function Refuse(need, cmd)
        local msg = string.format("%s needs %s - your whitelist level is %s (player %s)",
            cmd, need, tostring(Level), tostring(LastName))
        Log("WL| refused: " .. msg)
        pcall(function()
            local w = io.open(ModDir .. "config/whitelist_blocks.log", "a")
            if w then
                w:write(os.date("%Y-%m-%d %H:%M:%S") .. "  " .. tostring(LastName)
                    .. "  lvl=" .. tostring(Level) .. "  " .. tostring(cmd)
                    .. " needs " .. tostring(need) .. "\r\n")
                w:close()
            end
        end)
        return false
    end

    local prevPlus, prevPro = nil, nil
    pcall(function()
        local JXCmds = JX.cmds or nil
    end)
    local function Wrap(tag, need, fn)
        return function(FullCommand, Parameters, Ar)
            if not Allow(need) then Refuse(need, tag); return end
            return fn(FullCommand, Parameters, Ar)
        end
    end

    local plusFn, proFn = nil, nil
    pcall(function()
        
        plusFn = function(fc, p) if JXMemberRun then return JXMemberRun("jplus", p) end end
        proFn = function(fc, p) if JXMemberRun then return JXMemberRun("jpro", p) end end
    end)
    if type(JXMemberRun) == "function" then
        JXRegCmd("jplus", Wrap("jplus", "PLUS", plusFn))
        JXRegCmd("jpro", Wrap("jpro", "PRO", proFn))
        Log("WL| jplus/jpro are now behind the whitelist gate")
    else
        Log("WL| member runner not exposed; the gate is recorded but not wrapped")
    end

    JXRegCmd("jwl", function(FullCommand, Parameters, Ar)
        local sub = (Parameters and Parameters[1]) or "status"
        if sub == "me" or sub == "status" then
            Refresh("status")
            return
        end
        if sub == "list" then
            local list, d = LoadList()
            Log(string.format("WL| %d whitelisted name(s), default level %s:", #list, tostring(d)))
            for _, e in ipairs(list) do Log(string.format("WL|   %-24s %s", e.name, tostring(e.level))) end
            return
        end
        if sub == "reload" then Refresh("reload"); return end
        if sub == "set" then
            local who, lvl = Parameters and Parameters[2], tonumber(Parameters and Parameters[3])
            if not who or not lvl then Log("WL| usage: jwl set <name> <level>"); return end
            lvl = math.floor(lvl)
            if lvl > 6 then lvl = 6 end
            if lvl < 0 then lvl = 0 end
            Log("WL| level clamped to 0..6 (r14 hardening)")
            local lines = {}
            local h = io.open(ModDir .. "config/whitelist.ini", "r")
            if h then for line in h:lines() do lines[#lines + 1] = line end; h:close() end
            local found = false
            for i, l in ipairs(lines) do
                if l:match("^%s*" .. who:gsub("%W", "%%%1") .. "%s*=") then
                    lines[i] = string.format("%s = %s", who, tostring(lvl)); found = true
                end
            end
            if not found then lines[#lines + 1] = string.format("%s = %s", who, tostring(lvl)) end
            local w = io.open(ModDir .. "config/whitelist.ini", "w")
            if w then
                for _, l in ipairs(lines) do w:write(l .. "\r\n") end
                w:close()
            end
            Log(string.format("WL| %s -> level %s (saved)", who, tostring(lvl)))
            Refresh("after-set")
            return
        end
        Log("WL| usage: jwl status|list|reload|set <name> <level>")
    end)

    JXWL = {
        Level = function() return Level end,
        LevelOf = LevelOf,
        Allow = Allow,
        IsHost = IsHost,
        Refresh = Refresh,
    }
    
    ExecuteWithDelay(15000, function() ExecuteInGameThread(function()
        pcall(function()
            local PLUS_SLOTS = {
                speed=1, vision=1, jump=1, glide=1, brightness=1, gamma=1,
                exposure=1, sharpen=1, fov=1, sprint=1, climb=1, drawdist=1, aa=1,
            }
            JX.Gates = JX.Gates or {}
            JX.Gates["jxslider"] = {
                Allow = function(fc)
                    local slot = tostring(fc):match("^jxslider%s+(%S+)") or ""
                    return Allow(PLUS_SLOTS[slot] and "PLUS" or "PRO")
                end,
                Refuse = Refuse,
                need = "PRO",
            }
            JX.Gates["jxhide"] = {
                Allow = function(fc) return Allow("PLUS") end,
                Refuse = Refuse,
                need = "PLUS",
            }
            Log("WL| jxslider/jxhide gated via JXRegCmd gate table (r9)")
        end)
    end) end)
    
    ExecuteWithDelay(20000, function() ExecuteInGameThread(function()
        Log("WL| boot tick")
        pcall(function() Refresh("boot") end)
        Log("WL| boot done")
    end) end)
    ExecuteWithDelay(75000, function() ExecuteInGameThread(function()
        Log("WL| boot75 tick")
        pcall(function() Refresh("boot+75s") end)
        Log("WL| boot75 done")
    end) end)
    
    do
        local LastKey = "?"
        local function Periodic(n)
            ExecuteInGameThread(function()
                pcall(function()
                    local before = LastKey
                    pcall(Refresh, "periodic")
                    local key = tostring(LastName) .. "@" .. tostring(Level)
                    if key ~= before then Log("WL| periodic change -> " .. key) end
                    LastKey = key
                end)
                ExecuteWithDelay(60000, function() ExecuteInGameThread(function() pcall(Periodic, n + 1) end) end)
            end)
        end
        ExecuteWithDelay(40000, function() ExecuteInGameThread(function() pcall(Periodic, 0) end) end)
    end
    Log("whitelist ready: jwl status|list|set <name> <level>|reload; levels 1-3 = PLUS, 3.5-5.5 = PRO, 0 = ordinary")
end

local okMemberPack, errMemberPack = pcall(JXMemberPack)
if not okMemberPack then
    Log("JXMemberPack failed to arm: " .. tostring(errMemberPack))
end
JXWhitelist()
