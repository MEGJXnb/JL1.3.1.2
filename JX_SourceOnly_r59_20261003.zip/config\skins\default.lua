-- 皮肤示例（r5.0 新 UI 版）：config/skins/default.lua
-- r5.0 起面板是全新绘制的 9 页 UI（NX* 控件），页签文字由生成管线烤好、
-- 透明度强制 1.0，本皮肤默认留空 = 显示 pak 原样。想改任何文字再往下写。
--
-- 规则：tabs/headers/buttons = 控件名 -> 显示文字（存在才涂，写错只跳过不崩）
--       reveal = 强制显示的控件名列表
-- 改完进游戏：juiskin reload；换别的皮肤：juiskin <名字>
-- 控件名速查（r5.0 生成）：NXTab_0..8=页签，NXPage_<键>=页，NXB_<键>_<n>=按钮，
--   NXS_<键>_<n>=滑条。页序：play常用/gfx画质/world实体/mods模组/roster名单/
--   plus会员/pro尊享/ent娱乐/sys系统。

return {
    name = "default",
    tabs = {
        -- 例：["NXTab_0"] = "常用功能",
    },
    reveal = {},
    headers = {},
    buttons = {
        -- 例：["NXB_play_0"] = "飞行",
    },
}
