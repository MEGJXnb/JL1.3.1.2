
local JIF = {
    version = "1.0.0",
    store = {},
    securityLog = {},
    maxLog = 200,
}
local function Log(s) print("[JIF] " .. tostring(s) .. "\n") end
function JIF.Get(key) return JIF.store[key] end
function JIF.Set(key, value) JIF.store[key] = value end

function JIF.GetSteam64(pc)
    local result = { steam64 = "unknown", name = "unknown" }
    pcall(function()
        if not pc or not pc:IsValid() then return end
        if pc.PlayerState and pc.PlayerState:IsValid() then
            result.name = tostring(pc.PlayerState.PlayerName)
            local uid = pc.PlayerState.UniqueId
            if uid then
                pcall(function()
                    if uid.UniqueNetId and uid.UniqueNetId.ToString then
                        local s = uid.UniqueNetId:ToString()
                        local digits = s and s:match("(7656119%d+)")
                        if digits then result.steam64 = digits end
                    end
                end)
            end
        end
    end)
    return result
end

function JIF.LogSecurity(playerName, steam64, eventType, detail)
    local entry = {
        time = os.date("%Y-%m-%d %H:%M:%S"),
        name = tostring(playerName),
        steam64 = tostring(steam64),
        event = tostring(eventType),
        detail = tostring(detail or ""),
    }
    JIF.securityLog[#JIF.securityLog + 1] = entry
    if #JIF.securityLog > JIF.maxLog then table.remove(JIF.securityLog, 1) end
    Log("SECURITY: " .. entry.name .. " (" .. entry.steam64 .. ") " .. eventType
        .. (entry.detail ~= "" and (" - " .. entry.detail) or ""))
    pcall(function()
        
        local dir = (_G.JXSidecarDir or "")
        if dir ~= "" then
            dir = tostring(dir):gsub("\\", "/"):gsub("[^/]+/$", "")
        end
        local path = dir ~= "" and (dir .. "logs/security_events.log")
            or "Mods/JinxingLoaderRT/logs/security_events.log"
        local f = io.open(path, "a")
        if f then
            f:write(entry.time .. " | " .. entry.name .. " | " .. entry.steam64
                .. " | " .. entry.event .. " | " .. entry.detail .. "\n")
            f:close()
        else
            Log("security event log not writable at " .. path)
        end
    end)
    return entry
end

function JIF.GetSecurityLog() return JIF.securityLog end

function JIF.IsWhitelisted(name)
    local wl = nil
    pcall(function() wl = JX.WLRef end)
    if not wl or not wl.list then return nil end
    if not wl.on then return true end
    return wl.list[tostring(name):lower()] == true
end

_G.JIF = JIF
Log("interface ready (v" .. JIF.version .. ", security log + Steam64 + whitelist)")
return JIF
