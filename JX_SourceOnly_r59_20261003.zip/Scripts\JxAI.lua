-- JxAI.lua v1 - offline Chinese intent engine for JinxingLoaderRT
-- Pure resolver (M.Resolve) is UI/engine-free and offline-testable.
-- Install() wires: jai command (PRO gated), _G.JxAIAllowed, UE4SS log tail.
-- Footprint: pure Lua tables, well under 1 MB.

local M = { name = "JxAI", ver = 5, safemode = false }

local EXEC = nil
local UH = nil

local function log(s) print("[JxAI] " .. tostring(s) .. "\n") end

local function say(s)
    local jxsay = nil
    if type(_G.JX) == "table" and type(_G.JX.Say) == "function" then jxsay = _G.JX.Say end
    if jxsay then
        pcall(jxsay, tostring(s))
    else
        print("[JxAI] " .. tostring(s) .. "\n")
    end
end

local function send(cmd)
    if type(EXEC) ~= "function" then
        log("no executor, cannot send: " .. tostring(cmd))
        return false
    end
    local ok, r = pcall(EXEC, cmd)
    log("cmd -> " .. tostring(cmd) .. " (" .. tostring(ok and r or "err") .. ")")
    return ok
end

-- Level gates: 4 = PRO may use the AI, 5.5 = host/authority may toggle safemode
local function aiLevel()
    local lvl = 0
    pcall(function()
        if type(_G.JXWL) == "table" and type(_G.JXWL.Level) == "function" then
            lvl = tonumber(_G.JXWL.Level()) or 0
        end
        if lvl < 5.5 and type(_G.JXPanelGateAllowed) == "function" and _G.JXPanelGateAllowed() then
            lvl = 5.5
        end
    end)
    return lvl
end
local function aiAllowed()
    return aiLevel() >= 4
end
_G.JxAIAllowed = aiAllowed
_G.JxAILevel = aiLevel

-- 278-name official spawn catalog for real fuzzy entity matching
local CAT, CAT_AT = nil, 0
local function load_catalog()
    if CAT and (os.clock() - CAT_AT) < 30 then return CAT end
    local list = {}
    local sd = _G.JXSidecarDir or ""
    -- JXSidecarDir ends with ".../Scripts/" so config is a SIBLING, not a child
    for _, fn in ipairs({ sd .. "../config/spawn_catalog_working.txt", sd .. "../config/spawn_catalog.txt" }) do
        local f = io.open(fn, "r")
        if f then
            for ln in f:lines() do
                if ln:sub(1, 1) ~= "#" then
                    local name = ln:match("^%s*%[?%a*%]?%s*(.-)%s*=")
                    if name then
                        name = name:gsub("%s+$", ""):gsub("^%s+", "")
                        if #name > 0 then list[#list + 1] = name end
                    end
                end
            end
            f:close()
        end
        if #list > 0 then break end
    end
    CAT = list
    CAT_AT = os.clock()
    return CAT
end

-- utf8-safe shared-char score between keyword and catalog name
local function name_score(kw, name)
    if name:find(kw, 1, true) then return 100 + #kw end
    if kw:find(name, 1, true) then return 80 + #name end
    local ok, score = pcall(function()
        local set = {}
        for _, code in utf8.codes(name) do set[code] = true end
        local hit, total = 0, 0
        for _, code in utf8.codes(kw) do
            total = total + 1
            if set[code] then hit = hit + 1 end
        end
        if total == 0 then return 0 end
        return 60 * hit / total
    end)
    if ok and type(score) == "number" then return score end
    return 0
end

local function catalog_match(kw, want)
    local cat = load_catalog()
    local hits = {}
    for _, name in ipairs(cat) do
        local sc = name_score(kw, name)
        if sc >= 34 then hits[#hits + 1] = { name = name, sc = sc } end
    end
    table.sort(hits, function(a, b) return a.sc > b.sc end)
    local out = {}
    for i = 1, math.min(want or 3, #hits) do out[i] = hits[i].name end
    return out
end

-- runtime index of every Actor class alive in the level (jai index to refresh)
local AIDX, AIDX_AT = nil, 0
local function build_actor_index()
    if AIDX and (os.clock() - AIDX_AT) < 60 then return AIDX end
    local okr, names = pcall(function()
        local set, order = {}, {}
        local all = FindAllOf("Actor")
        for _, a in pairs(all or {}) do
            if #order >= 800 then break end
            pcall(function()
                if a and a.IsValid and a:IsValid() then
                    local cn = a:GetClass():GetName()
                    if cn and cn ~= "" and not set[cn] then
                        set[cn] = true
                        order[#order + 1] = cn
                    end
                end
            end)
        end
        return order
    end)
    AIDX = (okr and names) or {}
    AIDX_AT = os.clock()
    return AIDX
end

local function index_hit(kw)
    local names = build_actor_index()
    local kwl = kw:lower()
    for _, cn in ipairs(names) do
        local lc = cn:lower()
        if lc:find(kwl, 1, true) or kwl:find(lc, 1, true) then return cn end
    end
    return nil
end

local function save_actor_index(names)
    pcall(function()
        local sd = _G.JXSidecarDir or ""
        local f = io.open(sd .. "../config/ai_actor_index.txt", "w")
        if f then
            for _, cn in ipairs(names) do f:write(cn .. "\n") end
            f:close()
        end
    end)
end

local function catalog_entry(kw)
    local cat = load_catalog()
    local best, bestSc = nil, 0
    for _, name in ipairs(cat) do
        local sc = name_score(kw, name)
        if sc > bestSc then best, bestSc = name, sc end
    end
    if not best then return nil end
    -- recover the asset path of the matched name from the raw catalog lines
    local sd = _G.JXSidecarDir or ""
    for _, fn in ipairs({ sd .. "../config/spawn_catalog_working.txt", sd .. "../config/spawn_catalog.txt" }) do
        local f = io.open(fn, "r")
        if f then
            for ln in f:lines() do
                if ln:sub(1, 1) ~= "#" then
                    local name, path = ln:match("^%s*%[?%a*%]?%s*(.-)%s*=%s*(%S+)")
                    if name and path and name_score(kw, name) == bestSc and name == best then
                        f:close()
                        return { name = name, path = path }
                    end
                end
            end
            f:close()
        end
    end
    return { name = best, path = nil }
end

-- ---------------------------------------------------------------- distilled UE4.27 KB
-- Compact REAL reference data: native classes + their common parameters.
local KB = {
    classes = {
        { n = "PointLight",       p = "/Script/Engine.PointLight",       zh = "点光源",   props = { "Brightness", "LightColor", "AttenuationRadius", "bVisible" } },
        { n = "SpotLight",        p = "/Script/Engine.SpotLight",        zh = "射灯",     props = { "Brightness", "InnerConeAngle", "OuterConeAngle", "bVisible" } },
        { n = "DirectionalLight", p = "/Script/Engine.DirectionalLight", zh = "方向光",   props = { "Brightness", "Intensity", "bUsedAsAtmosphereSunLight" } },
        { n = "StaticMeshActor",  p = "/Script/Engine.StaticMeshActor",  zh = "静态网格体", props = { "bHidden", "Mobility" } },
        { n = "TriggerBox",       p = "/Script/Engine.TriggerBox",       zh = "触发盒",   props = { "bHidden", "Brush" } },
        { n = "CameraActor",      p = "/Script/Engine.CameraActor",      zh = "相机",     props = { "bConstrainAspectRatio" } },
        { n = "DecalActor",       p = "/Script/Engine.DecalActor",       zh = "贴花",     props = { "Decal" } },
        { n = "AmbientSound",     p = "/Script/Engine.AmbientSound",     zh = "环境音",   props = { "bAutoActivate" } },
        { n = "TextRenderActor",  p = "/Script/Engine.TextRenderActor",  zh = "文字渲染", props = { "Text", "WorldSize" } },
        { n = "PlayerStart",      p = "/Script/Engine.PlayerStart",      zh = "出生点",   props = { "PlayerStartTag" } },
        { n = "ExponentialHeightFog", p = "/Script/Engine.ExponentialHeightFog", zh = "雾", props = { "FogDensity", "FogHeightFalloff" } },
        { n = "SkeletalMeshActor", p = "/Script/Engine.SkeletalMeshActor", zh = "骨骼网格体", props = { "bHidden" } },
    },
    notes = {
        "UE4.27.2 + UE4SS 3.0.1 分支环境；所有引擎调用在游戏线程内 pcall 执行",
        "BP 类名 = 资产路径叶子名 + _C；/Game 路径经 J3LoadObject(StaticFindObject→LoadAsset) 加载",
        "生成走 World:SpawnActor（直接调用，非控制台）；属性读写走 UE4SS 反射绑定 obj.Prop = v",
    },
}

-- system prompt (the AI's constitution, quoted in identity/help, logged at install)
M.SYSTEM = {
    "你是 JX AI，运行在 UE 4.27.2 Escape The Backrooms 的 UE4SS Lua 环境内。",
    "原则一：能直接调用引擎 API 就绝不转发控制台命令——生成用 World:SpawnActor，属性用 obj.Prop 直接读写。",
    "原则二：绝不编造类名/路径——先查 278 名实体目录和内置 UE4.27 知识库，都查不到就承认不知道并给建议。",
    "原则三：所有引擎调用必须 pcall 包裹并回读确认，失败要说清楚失败在哪。",
    "原则四：回复用中文、不出现乱码；权限 PRO4 可用，5.5 级才能关安全权限。",
}

-- ---------------------------------------------------------------- normalize
-- Byte-classes are UNSAFE on UTF-8 (a class byte can sit inside a Han char,
-- e.g. 《 = E3 80 8A poisons any byte 8A). Filter by CODEPOINT instead.
local FW_PUNCT = {
    [0xFF0C]=true,[0x3002]=true,[0xFF01]=true,[0xFF1F]=true,[0x3001]=true,
    [0xFF1B]=true,[0xFF1A]=true,[0xFF08]=true,[0xFF09]=true,[0x3010]=true,
    [0x3011]=true,[0x300A]=true,[0x300B]=true,[0x2026]=true,[0x00B7]=true,
    [0xFF5E]=true,[0xFF5C]=true,[0x201C]=true,[0x201D]=true,[0x2018]=true,
    [0x2019]=true,[0x301C]=true,[0x3000]=true,
}
local function norm(s)
    s = tostring(s or ""):lower()
    local ok, out = pcall(function()
        local acc = {}
        for _, code in utf8.codes(s) do
            if not FW_PUNCT[code] and code ~= 0x3000 then
                if code < 128 then
                    local c = string.char(code)
                    if not c:find("%p") and not c:find("%s") then acc[#acc + 1] = c end
                else
                    acc[#acc + 1] = utf8.char(code)
                end
            end
        end
        return table.concat(acc)
    end)
    if ok and out then return out end
    return (s:gsub("%s+", ""))
end

-- extract a search/spawn keyword (Chinese or ascii) after trigger words
-- r33: Lua character classes match BYTES; a class over multi-byte UTF-8
-- quantifiers (一[个只名台]) eats only the FIRST byte and leaves orphan
-- continuation bytes glued to the keyword (the "half character" bug:
-- "帮我找一个气球" yielded a keyword starting with B8 AA). Rules now use
-- literal chains only, and clean() strips any leading continuation bytes
-- as a final guard at every extraction exit.
local function clean(s)
    return (tostring(s):gsub("^[\128-\191]+", ""))
end
local TRIGGERS = { "搜索", "查找", "找一下", "找找", "帮我找", "找", "生成一个", "生成个", "召唤一个",
                   "召唤个", "召唤", "生成", "放一个", "放个", "来一个", "来个", "给我一个", "给我个" }
local function extract_kw(text)
    for _, t in ipairs(TRIGGERS) do
        local s, e = text:find(t, 1, true)
        if s then
            local kw = text:sub(e + 1):gsub("^的", "")
            kw = kw:gsub("^一个", ""):gsub("^一只", ""):gsub("^一名", ""):gsub("^一台", "")
            kw = kw:gsub("^%d+个", "")
            kw = kw:gsub("^[一二两三四五六七八九十]+个", "")
            if #kw > 0 then return clean(kw) end
        end
    end
    return nil
end

local function extract_count(text)
    local n = text:match("(%d+)%s*个") or text:match("([一二两三四五六七八九十]+)个")
    if n == nil then return nil end
    local dig = tonumber(n)
    if dig then return dig end
    local cn = { ["一"]=1,["两"]=2,["二"]=2,["三"]=3,["四"]=4,["五"]=5,["六"]=6,["七"]=7,["八"]=8,["九"]=9,["十"]=10 }
    return cn[n] or nil
end

-- ---------------------------------------------------------------- rules
-- each rule: { tag, pats (normalized substrings), fn(text, ntext) -> {replies, sends} or nil }
local RULES = {}
local function rule(tag, pats, fn)
    RULES[#RULES + 1] = { tag = tag, pats = pats, fn = fn }
end

local function plain(tag, pats, replies, sends)
    rule(tag, pats, function()
        return { replies = replies, sends = sends or {} }
    end)
end

-- identity / help -------------------------------------------------------
plain("identity", { "你是谁", "你叫什么", "你是什么东西", "你是什么", "自我介绍" },
    { "我是 JX AI（离线中文意图引擎 v5，直接调用引擎 API + 全场 Actor 索引）。",
      M.SYSTEM[2], M.SYSTEM[3],
      "把想说的话发给我：『生成一个门』『查看狗哥的参数』『把点光源的亮度设成3』都行。" })

plain("help", { "帮助", "你能干什么", "你能做什么", "怎么用你", "你会什么", "help", "功能表", "指令" },
    { "JX AI 能听懂的话（说一句就行）：" },
    { "生成：『生成一个门』『召唤窃皮者』『生成点光源』（278 名目录+UE 内置类，直接 World:SpawnActor）" },
    { "参数：『查看狗哥的参数』『查看我的参数』『把点光源的亮度设成3』（直接反射读写，不走控制台）" },
    { "查找：『找 僵尸』『搜索 door』；普查：『全场普查』『列出Actor』『静态网格』" },
    { "画质：『帧率低』『优化』『高画质』；位置：『我在哪』『传送』；动作：『穿墙』『复活』『杀怪』『挂机检测』" },
    { "系统：『看日志』『崩溃修复』『体检』『白名单』『存档/读档』『在线玩家』『64人』" },
    { "权限：PRO 4 级可用本 AI；5.5 级（房主/授权）可说『关闭安全权限』解锁连生成+自由放置" },
    { "全场索引：『jai index』收录场上所有 Actor/BP 类，生成可直接用类名" },
    { "没听懂时会给你最接近的建议。本 AI 是 PRO 专属，聊天框直接说（B 键面板 + jai 命令）。" })

plain("gptq", { "gpt", "大模型", "chatgpt", "深度思考", "5.4", "5.6" },
    { "我不是云端大模型——我是装在你模组里的离线小引擎，专精本模组的命令。",
      "体积不到 1MB、零延迟、不联网。生成物件、普查、日志这些事直接说就行。" })

-- ---------------------------------------------------------------- direct API layer
-- True engine calls (no console strings): J3LoadObject -> class ->
-- JXSpawnClassOf -> World:SpawnActor; properties via UE4SS reflection binding.
local function game_ready()
    return type(_G.J3LoadObject) == "function" and type(_G.JXSpawnClassOf) == "function"
end

local function class_from_path(path)
    if type(_G.J3LoadObject) ~= "function" then return nil end
    local leaf = path:match("([^/]+)$")
    local cls = nil
    if leaf then
        pcall(function() cls = _G.J3LoadObject(path .. "." .. leaf .. "_C") end)
    end
    if not cls then
        local asset = nil
        pcall(function() asset = _G.J3LoadObject(path) end)
        pcall(function() cls = asset and asset.GeneratedClass or nil end)
    end
    return cls
end

local function kb_class(kw)
    kw = tostring(kw or ""):lower()
    for _, c in ipairs(KB.classes) do
        if c.n:lower():find(kw, 1, true) or kw:find(c.n:lower(), 1, true)
            or c.zh:find(kw, 1, true) or kw:find(c.zh, 1, true) then
            return c
        end
    end
    return nil
end

local function spawn_direct(kw)
    if not game_ready() then return nil, "游戏内才可执行" end
    local entry = catalog_entry(kw)
    if entry and entry.path then
        local cls = class_from_path(entry.path)
        if cls then
            local a = nil
            pcall(function() a = _G.JXSpawnClassOf(cls) end)
            if a then return a, "目录:" .. entry.name end
        end
    end
    -- runtime index: any live Actor class in the level
    local hitcn = index_hit(kw)
    if hitcn then
        local inst, cls = nil, nil
        pcall(function() inst = FindFirstOf(hitcn) end)
        pcall(function() if inst and inst.IsValid and inst:IsValid() then cls = inst:GetClass() end end)
        if cls then
            local a = nil
            pcall(function() a = _G.JXSpawnClassOf(cls) end)
            if a then return a, "索引:" .. hitcn end
        end
    end
    local c = kb_class(kw)
    if c then
        local cls = nil
        pcall(function() cls = _G.J3LoadObject(c.p) end)
        if cls then
            local a = nil
            pcall(function() a = _G.JXSpawnClassOf(cls) end)
            if a then return a, "KB:" .. c.n end
        end
    end
    return nil, nil
end

local function first_instance(classHint)
    if not game_ready() then return nil end
    local nm = classHint:match("([%w_]+)_C$") or classHint:match("([^/%.]*)$") or classHint
    local ok, inst = pcall(function() return FindFirstOf(nm) end)
    if ok and inst and inst.IsValid and inst:IsValid() then return inst end
    return nil
end

local function dump_props(obj, names)
    local out = {}
    for _, pn in ipairs(names) do
        local ok, v = pcall(function() return obj[pn] end)
        if ok then out[#out + 1] = pn .. " = " .. tostring(v) end
    end
    return out
end

local function live_prop_names(cls)
    local ok, list = pcall(function()
        local acc = {}
        for _, p in ipairs(cls:GetProperties()) do acc[#acc + 1] = p:GetFName():ToString() end
        return acc
    end)
    if ok and type(list) == "table" and #list > 0 then return list end
    return nil
end

local PROP_ALIAS = {
    ["血量"] = "Health", ["生命"] = "Health", ["隐身"] = "bHidden", ["可见"] = "bVisible",
    ["亮度"] = "Brightness", ["强度"] = "Intensity", ["雾密度"] = "FogDensity",
    ["文字"] = "Text", ["移动性"] = "Mobility", ["坐标"] = "K2_GetActorLocation",
}

local function parse_value(raw)
    -- r33: clean() first - audit report flagged this path writing dirty
    -- continuation bytes straight into UE properties if any future caller
    -- skips the extraction-level guard
    raw = clean(raw)
    raw = tostring(raw or ""):gsub("^%s+", ""):gsub("%s+$", "")
    local n = tonumber(raw)
    if n then return n end
    if raw == "true" or raw == "开启" or raw == "是" then return true end
    if raw == "false" or raw == "关闭" or raw == "否" then return false end
    return raw
end

-- ---------------------------------------------------------------- grid placement
-- Our own assets only: StaticMeshActor + engine basic Cube, placed on a grid
-- anchored once per map. Level objects are non-replicated: host sees the
-- grid, guests see the untouched original game.
M.Grid = { map = "", origin = nil, cell = 220, cols = 8, idx = 0 }

local function world_obj()
    if UH and UH.GetWorld then
        local ok, W = pcall(UH.GetWorld)
        if ok and W and W.IsValid and W:IsValid() then return W end
    end
    return nil
end

local function spawn_at(cls, x, y, z, yaw)
    local W = world_obj()
    if not (W and cls) then return nil end
    local a = nil
    pcall(function() a = W:SpawnActor(cls, { X = x, Y = y, Z = z },
        { Pitch = 0, Yaw = yaw or 0, Roll = 0 }) end)
    if not (a and a.IsValid and a:IsValid()) then
        pcall(function() a = W:SpawnActor(cls, { X = x, Y = y, Z = z }) end)
    end
    if not (a and a.IsValid and a:IsValid()) then
        pcall(function() a = W:SpawnActor(cls) end)
        if a then pcall(function() a:K2_SetActorLocation({ X = x, Y = y, Z = z }) end) end
    end
    if a and a.IsValid and a:IsValid() then
        pcall(function() a:K2_SetActorLocation({ X = x, Y = y, Z = z }) end)
    end
    return a
end

local function pawn_pos()
    local p = nil
    pcall(function()
        local pc = FindFirstOf("PlayerController")
        if pc and pc:IsValid() and pc.Pawn and pc.Pawn:IsValid() then
            p = pc.Pawn:K2_GetActorLocation()
        end
    end)
    return p
end

function M.GridNext()
    local W = world_obj()
    if not W then return nil end
    local nm = ""
    pcall(function() nm = W:GetName() end)
    if nm ~= M.Grid.map or not M.Grid.origin then
        local p = pawn_pos()
        if not p then return nil end
        M.Grid.map = nm
        M.Grid.origin = { X = p.X + 200, Y = p.Y - (M.Grid.cols - 1) * M.Grid.cell / 2, Z = p.Z + 40 }
        M.Grid.idx = 0
    end
    local r = math.floor(M.Grid.idx / M.Grid.cols)
    local c = M.Grid.idx % M.Grid.cols
    M.Grid.idx = M.Grid.idx + 1
    return M.Grid.origin.X + c * M.Grid.cell, M.Grid.origin.Y + r * M.Grid.cell, M.Grid.origin.Z
end

function M.GridReset()
    M.Grid.origin = nil
    M.Grid.idx = 0
end

-- spawn one of OUR cubes at x,y,z
local function spawn_own_cube(x, y, z, scale)
    if not game_ready() then return nil, "游戏内才可执行" end
    local cls = nil
    pcall(function() cls = _G.J3LoadObject("/Script/Engine.StaticMeshActor") end)
    if not cls then return nil, "StaticMeshActor 类没加载" end
    local a = spawn_at(cls, x, y, z, 0)
    if not (a and a.IsValid and a:IsValid()) then return nil, "生成被构建版拒绝" end
    pcall(function()
        local mesh = _G.J3LoadObject("/Engine/BasicShapes/Cube.Cube")
        if mesh then a.StaticMeshComponent:SetStaticMesh(mesh) end
    end)
    if scale then pcall(function() a:SetActorScale3D({ X = scale, Y = scale, Z = scale }) end) end
    return a
end

-- resolve kw to a class and spawn it at an exact position (direct API)
local function spawn_class_at(kw, x, y, z)
    local cls = nil
    local via = nil
    local entry = catalog_entry(kw)
    if entry and entry.path then
        cls = class_from_path(entry.path)
        if cls then via = "目录:" .. entry.name end
    end
    if not cls then
        local c = kb_class(kw)
        if c then
            pcall(function() cls = _G.J3LoadObject(c.p) end)
            if cls then via = "KB:" .. c.n end
        end
    end
    if not cls then return nil end
    local a = spawn_at(cls, x, y, z, 0)
    if a then return a, via end
    return nil
end

-- spawn -----------------------------------------------------------------
rule("spawn_kw", { "生成", "召唤", "放一个", "放个", "来一个", "来个", "给我一个", "给我个" }, function(text, ntext)
    local kw = extract_kw(text)
    if kw == nil or #kw == 0 then return nil end
    local replies, sends = {}, {}
    local cn = extract_count(text)
    if kw:find("方块") or kw:find("立方") or kw:find("box") or kw:find("cube") then
        replies[#replies + 1] = "好，在脚下生成定位方块。"
        sends[#sends + 1] = "jspat cube"
    elseif kw:find("标记") or kw:find("mark") then
        replies[#replies + 1] = "好，青色标记方块已放脚下。"
        sends[#sends + 1] = "jmark on"
    else
        -- DIRECT API first: catalog class -> World:SpawnActor (no console)
        local a, via = spawn_direct(kw)
        if a then
            local aname = "?"
            pcall(function() aname = a:GetClass():GetName() end)
            replies[#replies + 1] = "已直接生成『" .. kw .. "』（" .. tostring(via) .. " → " .. aname .. "）"
            if cn and cn > 1 then
                if M.safemode then
                    local n = math.min(cn, 10)
                    for _ = 2, n do
                        local more = select(1, spawn_direct(kw))
                        if not more then break end
                    end
                    replies[#replies + 1] = "安全权限已关：共直接生成 " .. n .. " 个。"
                else
                    replies[#replies + 1] = "（要连生成 " .. cn .. " 个，需 5.5 级先关安全权限：『关闭安全权限』。）"
                end
            end
            return { replies = replies, sends = sends }
        end
        replies[#replies + 1] = "直接调用没找到类，回退到实体目录命令……"
        sends[#sends + 1] = "jent " .. kw
        replies[#replies + 1] = "如果没生成，发『实体列表』看全部可生成名字。"
    end
    if cn and cn > 1 then
        if M.safemode then
            local n = math.min(cn, 10)
            local one = sends[#sends]
            for _ = 2, n do sends[#sends + 1] = one end
            replies[#replies + 1] = "安全权限已关：连生成 " .. n .. " 个。"
        else
            replies[#replies + 1] = "（要连生成 " .. cn .. " 个，需 5.5 级先关安全权限：『关闭安全权限』。）"
        end
    end
    return { replies = replies, sends = sends }
end)

-- object parameter inspection (direct reflection, game only) -------------
rule("mypara", { "我的参数", "我的属性", "我的状态" }, function()
    if not game_ready() then
        return { replies = { "参数直读需在游戏内执行（重启进图后可用）。" } }
    end
    local pawn = nil
    pcall(function()
        local pc = FindFirstOf("PlayerController")
        if pc and pc:IsValid() then pawn = pc.Pawn end
    end)
    if not pawn then return { replies = { "没找到你的 Pawn（还没进图？）。" } } end
    local replies = { "你的 Pawn 参数（直接反射读取）：" }
    local done = false
    for _, grp in ipairs({
        { "Location", function() local l = pawn:K2_GetActorLocation() return { ("坐标 = %.0f, %.0f, %.0f"):format(l.X, l.Y, l.Z) } end },
        { "common",   function() return dump_props(pawn, { "Health", "bHidden", "bActorEnableCollision", "AutoReceiveInput" }) end },
    }) do
        local ok, lines = pcall(grp[2])
        if ok and type(lines) == "table" then
            for _, ln in ipairs(lines) do replies[#replies + 1] = "  " .. ln end
            done = true
        end
    end
    if not done then return { replies = { "反射读取失败（该对象无可读属性）。" } } end
    return { replies = replies }
end)

rule("listprop", { "的参数", "的属性" }, function(text, ntext)
    if not game_ready() then
        return { replies = { "参数直读需在游戏内执行（重启进图后可用）。" } }
    end
    local ckw = text:match("查看(.+)的[参属]") or text:match("(.+)的[参属]")
    if not ckw or #ckw == 0 then ckw = extract_kw(text) end
    if not ckw or #ckw == 0 then
        return { replies = { "要看谁的参数？说『查看狗哥的参数』或『查看点光源的参数』。" } }
    end
    local inst, via = nil, nil
    local entry = catalog_entry(ckw)
    if entry and entry.path then
        local leaf = entry.path:match("([^/]+)$")
        inst = first_instance(leaf .. "_C")
        if inst then via = "目录:" .. entry.name end
    end
    if not inst then
        local c = kb_class(ckw)
        if c then
            inst = first_instance(c.n)
            if inst then via = "KB:" .. c.n end
        end
    end
    if not inst then
        inst = first_instance(ckw)
        if inst then via = ckw end
    end
    if not inst then
        return { replies = { "场上没找到『" .. ckw .. "』的实例（先『生成" .. ckw .. "』再看）。" } }
    end
    local c = kb_class(ckw)
    local names = nil
    if c then names = c.props end
    if not names and entry and entry.path then
        local leafCls = class_from_path(entry.path)
        if leafCls then names = live_prop_names(leafCls) end
    end
    if not names then
        names = { "Health", "bHidden", "bVisible", "Brightness", "Owner" }
    end
    local lines = dump_props(inst, names)
    local replies = { "『" .. (via or ckw) .. "』参数（直接反射读取" .. #lines .. "项）：" }
    for _, ln in ipairs(lines) do replies[#replies + 1] = "  " .. ln end
    return { replies = replies }
end)

-- direct property write: 把<类>的<属性>设成<值> ---------------------------
rule("setprop", { "设为", "设成", "改成", "设置" }, function(text, ntext)
    local clsKw, propZh, valRaw = text:match("把(.+)的(.+)设[为成定]"), nil, nil
    if clsKw then
        propZh = text:match("把.+" .. "的(.+)设[为成定]")
        -- r33: literal alternatives - the old 设[为成定](.+) class captured
        -- the value starting with 2 orphan bytes of 为/成/定 (half character)
        valRaw = text:match("设为%s*(.+)$") or text:match("设成%s*(.+)$") or text:match("设定%s*(.+)$")
        valRaw = valRaw and clean(valRaw) or nil
    else
        clsKw = text:match("把(.+)的(.+)改[为成]")
        if clsKw then
            propZh = text:match("把.+的(.+)改[为成]")
            valRaw = text:match("改为%s*(.+)$") or text:match("改成%s*(.+)$")
            valRaw = valRaw and clean(valRaw) or nil
        end
    end
    if not (clsKw and propZh) then
        return { replies = { "格式：『把<对象>的<属性>设成<值>』，例如『把点光源的亮度设成3』『把僵尸的血量设成1』。" } }
    end
    if not game_ready() then
        return { replies = { "属性直写需在游戏内执行（重启进图后可用）。" } }
    end
    local prop = PROP_ALIAS[propZh] or propZh
    local val = parse_value(valRaw)
    local inst = nil
    local entry = catalog_entry(clsKw)
    if entry and entry.path then
        local leaf = entry.path:match("([^/]+)$")
        inst = first_instance(leaf .. "_C")
    end
    if not inst then
        local c = kb_class(clsKw)
        if c then inst = first_instance(c.n) end
    end
    if not inst then inst = first_instance(clsKw) end
    if not inst then
        return { replies = { "场上没找到『" .. clsKw .. "』的实例，先生成再改。" } }
    end
    local before = nil
    pcall(function() before = inst[prop] end)
    local okW = pcall(function() inst[prop] = val end)
    local after = nil
    pcall(function() after = inst[prop] end)
    if okW and tostring(after) ~= "nil" then
        return { replies = { "已直接写入（" .. clsKw .. "." .. prop .. "）："
            .. tostring(before) .. " → " .. tostring(after) } }
    end
    return { replies = { "写入失败（属性不存在或只读）：" .. clsKw .. "." .. prop
        .. "，试试英文属性名如 Health / Brightness / bHidden。" } }
end)

rule("gridgen", { "方格里生成", "方格生成", "在方格", "格子生成", "方格" }, function(text, ntext)
    if not game_ready() then
        return { replies = { "方格生成需在游戏内执行（重启进图后可用）。" } }
    end
    local x, y, z = M.GridNext()
    if not x then return { replies = { "没拿到玩家位置（还没进图）。" } } end
    local kw = extract_kw(text)
    local cellName = "自有方块"
    if kw and #kw > 0 and not ntext:find("方块") then
        local a, via = spawn_class_at(kw, x, y, z)
        if a then
            cellName = (via or kw)
            local aname = "?"
            pcall(function() aname = a:GetClass():GetName() end)
            local replies = { "第 " .. M.Grid.idx .. " 格已直接生成『" .. cellName .. "』（" .. aname .. "）" }
            return { replies = replies }
        end
        cellName = kw .. "(类没找到,放自有方块)"
    end
    local a, why = spawn_own_cube(x, y, z, 0.5)
    if not a then
        return { replies = { "方格生成失败：" .. tostring(why) } }
    end
    return { replies = { "第 " .. M.Grid.idx .. " 格已放入自有方块（0.5 倍，格距 " .. M.Grid.cell .. "，每行 " .. M.Grid.cols .. " 格）。说『方格重置』重新锚定。" } }
end)

plain("gridreset", { "方格重置", "重置方格", "清空方格" },
    { "方格已重置：下个生成重新从你当前位置锚定起点。" })

-- native stats (C++ sampler -> NativeStats.json) ------------------------
local function read_native_stats()
    local sd = _G.JXSidecarDir or ""
    local f = io.open(sd .. "../logs/NativeStats.json", "r")
    if not f then return nil end
    local j = f:read("*a")
    f:close()
    return {
        ws = j:match('"workingSetMB"%s*:%s*([%d%.]+)'),
        pk = j:match('"peakMB"%s*:%s*([%d%.]+)'),
        th = j:match('"threads"%s*:%s*(%d+)'),
        cpu = j:match('"sysCPUPercent"%s*:%s*([%d%.]+)'),
        up = j:match('"watchUptimeSec"%s*:%s*(%d+)'),
    }
end

rule("native", { "内存", "原生", "native" }, function(text, ntext)
    local off = ntext:find("关闭") or ntext:find("停止")
    if off and (ntext:find("采样") or ntext:find("原生")) then
        local sd = _G.JXSidecarDir or ""
        local f = io.open(sd .. "../config/jxnative.stop", "w")
        if f then f:write("stop"); f:close() end
        return { replies = { "已写 jxnative.stop：原生采样器将在 0.25 秒内退出（删除该文件并在下局重启恢复）。" } }
    end
    local st = read_native_stats()
    if not st or not st.ws then
        return { replies = { "原生采样数据还没有（启动 30 秒后每 5 秒更新；确认 Scripts 里有 JxNative.exe）。" } }
    end
    return { replies = { "C++ 原生采样：游戏内存 " .. st.ws .. " MB（峰值 " .. (st.pk or "?")
        .. " MB），线程 " .. (st.th or "?") .. "，系统CPU " .. (st.cpu or "?")
        .. "%，采样器运行 " .. (st.up or "?") .. " 秒。" } }
end)

-- safety permission toggle: 5.5 (host/authority) only --------------------
rule("safety", { "关闭安全", "解除安全", "安全权限", "安全模式", "放开限制", "恢复安全", "安全" }, function(text, ntext)
    local off = ntext:find("关闭") or ntext:find("解除") or ntext:find("off")
        or ntext:find("放开") or ntext:find("开安全")
    local on = ntext:find("打开安全") or ntext:find("恢复安全") or ntext:find("开启安全") or ntext:find("安全on")
    if aiLevel() >= 5.5 then
        if off and not on then
            M.safemode = true
            return { replies = { "安全权限已关闭（5.5 级）：AI 可连生成、自由放置。重开游戏自动恢复安全。" } }
        elseif on then
            M.safemode = false
            return { replies = { "安全权限已恢复：单次生成、放置走默认路径。" } }
        end
        return { replies = { "安全权限当前：" .. (M.safemode and "已关闭" or "开启中") .. "（说『关闭安全权限』或『恢复安全』切换）" } }
    end
    return { replies = { "安全权限开关需要 5.5 级（房主/授权）。你当前等级不够，此请求已拒绝。" } }
end)

-- free placement: gated behind safemode ----------------------------------
rule("freep", { "自由放置", "任意位置放", "随便放一个", "随便放个", "随便放", "放到任意" }, function(text, ntext)
    if not M.safemode then
        if aiLevel() >= 5.5 then
            return { replies = { "先说『关闭安全权限』解锁自由放置（防误放保护当前开着）。" } }
        end
        return { replies = { "自由放置需要 5.5 级关安全权限后才能用，已拒绝。" } }
    end
    return { replies = { "自由放置：放下一个采到的静态网格（说『放网格』继续，注意别挡门）。" }, sends = { "jsmesh spawn" } }
end)

plain("ent_list", { "实体列表", "怪物列表", "能生成什么", "有哪些怪", "实体目录", "列表" },
    { "打开实体目录（278 个中文名实体）。" }, { "jent list" })

rule("find_kw", { "找", "搜索", "查找", "search" }, function(text, ntext)
    local kw = extract_kw(text)
    if kw == nil or #kw == 0 then return nil end
    return { replies = { "全场搜索『" .. kw .. "』……" }, sends = { "jfind " .. kw } }
end)

plain("census", { "全场普查", "普查", "列出actor", "列出actor", "actor普查", "有什么actor", "看看有什么" },
    { "全场 Actor 普查开始，结果在聊天栏和日志。" }, { "jall" })

plain("mesh", { "静态网格", "网格普查", "mesh" },
    { "静态网格普查开始（物件+落方块统计）。" }, { "jsmesh census" })

plain("mesh_spawn", { "放网格", "生成网格" },
    { "按顺序放下一个采到的静态网格。" }, { "jsmesh spawn" })

-- gfx / perf ------------------------------------------------------------
plain("fps", { "帧率", "fps", "卡顿", "掉帧", "优化", "流畅", "性能" },
    { "切到 ultra_fps 性能档（画质自动降一档换帧数）。" }, { "jboost2 ultra_fps" })

plain("pretty", { "高画质", "画质好", "好看点", "画质拉满" },
    { "切回 balanced 平衡档（画质优先）。" }, { "jboost2 balanced" })

plain("fps60", { "锁60", "锁六十" },
    { "锁 60 帧。" }, { "jfps60" })

-- position / movement ---------------------------------------------------
plain("whereami", { "我在哪", "我的位置", "哪里", "whereami", "坐标" },
    { "报坐标中（聊天栏显示）。" }, { "whereami" })

plain("tp", { "传送", "tp", "去标记", "回标记" },
    { "传送到标记点（先放标记：『生成标记』）。" }, { "markergo" })

plain("noclip", { "穿墙", "noclip", "飞行", "飞起来" },
    { "穿墙模式切换（再发一次关闭；飞行用穿墙代替）。" }, { "noclip" })

plain("revive", { "复活", "救我", "revive" },
    { "原地复活。" }, { "revive" })

plain("killai", { "杀怪", "清怪", "killai", "清场" },
    { "清除全场 AI。" }, { "killai" })

plain("antiafk", { "挂机", "防踢", "antiafk" },
    { "防挂机踢切换。" }, { "antiafk" })

plain("brightness", { "亮度", "太黑了", "亮一点" },
    { "提高亮度一档。" }, { "brightness" })

-- system ----------------------------------------------------------------
plain("wl", { "白名单", "名单", "黑名单", "权限", "等级" },
    { "白名单状态（列表+等级）。改等级：jwl set <名字> <等级>，PRO=4 以上。" }, { "jwl status" })

plain("players", { "在线", "多少人在", "玩家列表", "谁在线", "联机玩家" },
    { "列出在线玩家。" }, { "jnet" })

plain("maxplayer", { "64人", "人数上限", "多少人", "上限" },
    { "人数上限设置面板。" }, { "jmax" })

plain("save", { "存档", "保存", "保存一下" },
    { "保存当前布置（物件+定位方块）。" }, { "jxsave" })

plain("load", { "读档", "读取", "读档一下", "恢复" },
    { "读取上次保存的布置。" }, { "jxload" })

plain("slot", { "槽位", "slot" },
    { "存档槽位状态。" }, { "jxslot status" })

plain("ams", { "ams", "地图存档" },
    { "JXAMS 地图存档状态（每图独立）。" }, { "jams" })

plain("crashfix", { "崩溃", "修复", "自检", "崩了" },
    { "运行自动修复（崩溃日志分析+守护喂食）。" }, { "jxautofix" })

plain("errs", { "错误", "报错", "err" },
    { "最近记录的错误（屏显+缓冲）。" }, { "jerr" })

plain("diag", { "体检", "诊断", "诊断一下", "检查" },
    { "UI 链路体检（画布/钩子/门控全套）。" }, { "jxdiag" })

plain("panel_on", { "打开面板", "开面板", "显示面板" },
    { "打开画布面板。" }, { "jui show" })

plain("panel_off", { "关闭面板", "关面板", "隐藏面板" },
    { "关闭画布面板（B 键随时再开）。" }, { "jui hide" })

plain("settab", { "设置面板", "设置页" },
    { "切到设置页签。" }, { "jtab 6" })

plain("fun", { "娱乐", "整蛊", "搞笑", "整活" },
    { "切到娱乐页签。" }, { "jtab 15" })

plain("plus", { "plus功能", "特级功能", "plus页" },
    { "打开 PLUS 特级功能页签。" }, { "jtab 13" })

plain("pro", { "pro功能", "pro页" },
    { "打开 PRO 页签。" }, { "jtab 14" })

-- log tail (reads real file when installed; offline test stubs it) ------
local UE4SS_LOG = nil
local function set_log_path(p) UE4SS_LOG = p end

local function tail_lines(path, n, onlyErr)
    local f = io.open(path, "r")
    if not f then return nil, "打不开日志文件" end
    local lines = {}
    for ln in f:lines() do lines[#lines + 1] = ln end
    f:close()
    local out = {}
    for i = math.max(1, #lines - n + 1), #lines do
        local ln = lines[i]
        if (not onlyErr) or ln:find("Error", 1, true) then out[#out + 1] = ln end
    end
    return out, nil
end

rule("logs", { "日志", "log" }, function(text, ntext)
    local onlyErr = ntext:find("错误") or ntext:find("报错") or ntext:find("error")
    if not UE4SS_LOG then
        return { replies = { "日志路径未就绪（重启游戏后可用）。聊天命令 jerr 可看缓冲错误。" } }
    end
    local lines, err = tail_lines(UE4SS_LOG, 12, onlyErr)
    if not lines then return { replies = { "读日志失败：" .. err } } end
    local replies = { onlyErr and "最近日志里的 Error：" or "最近 12 行日志：" }
    for _, ln in ipairs(lines) do
        replies[#replies + 1] = "  " .. ln:sub(1, 110)
    end
    if #lines == 0 then replies[#replies + 1] = "（没有匹配行）" end
    return { replies = replies, sends = {} }
end)

-- panel toggle via globals ----------------------------------------------
rule("panel", { "面板" }, function(text, ntext)
    if ntext:find("开") then return { replies = { "打开画布面板。" }, sends = { "jui show" } } end
    if ntext:find("关") or ntext:find("隐藏") then return { replies = { "收起画布面板。" }, sends = { "jui hide" } } end
    return nil
end)

-- ---------------------------------------------------------------- resolve
local function best_rule(ntext)
    local best, bestScore = nil, 0
    for _, r in ipairs(RULES) do
        for _, p in ipairs(r.pats) do
            if #p > 0 and ntext:find(p, 1, true) then
                local bonus = (r.tag == "gridgen" or r.tag == "freep") and 3 or 0
                local score = #p + bonus
                if score > bestScore then best, bestScore = r, score end
            end
        end
    end
    return best, bestScore
end

local function suggestions(ntext)
    local out = {}
    for _, r in ipairs(RULES) do
        for _, p in ipairs(r.pats) do
            if #p >= 2 and ntext:find(p:sub(1, math.min(3, #p)), 1, true) then
                out[#out + 1] = p
                break
            end
        end
        if #out >= 5 then break end
    end
    if #out == 0 then
        out = { "帮助", "生成方块", "全场普查", "我在哪", "看日志" }
    end
    return out
end

-- Resolve: pure. returns { found, tag, replies, sends, alts }
function M.Resolve(text)
    local ntext = norm(text)
    if ntext == "" then
        return { found = false, tag = "empty", replies = { "说什么呀？试试『帮助』。" }, sends = {}, alts = {} }
    end
    local r = best_rule(ntext)
    if not r then
        local kw = extract_kw(text)
        local replies = { "这句我还不太懂（离线小引擎词汇有限）。" }
        local sends = {}
        if kw and #kw > 0 then
            replies[#replies + 1] = "先按关键字『" .. kw .. "』帮你全场搜一下。"
            sends[#sends + 1] = "jfind " .. kw
        end
        local alts = suggestions(ntext)
        replies[#replies + 1] = "你可以试试：" .. table.concat(alts, "、")
        return { found = false, tag = "fallback", replies = replies, sends = sends, alts = alts }
    end
    local out = r.fn(text, ntext)
    if not out then
        return { found = false, tag = r.tag, replies = { "没提取到关键词，试试『帮助』。" }, sends = {}, alts = {} }
    end
    return { found = true, tag = r.tag, replies = out.replies or {}, sends = out.sends or {}, alts = {} }
end

-- ---------------------------------------------------------------- test
local TESTS = {
    { "帮助", true, "help" },          { "你是谁呀", true, "identity" },
    { "生成方块", true, "spawn_kw" },   { "给我一个箱子", true, "spawn_kw" },
    { "召唤僵尸", true, "spawn_kw" },   { "生成3个方块", true, "spawn_kw" },
    { "实体列表", true, "ent_list" },   { "找 僵尸", true, "find_kw" },
    { "搜索door", true, "find_kw" },    { "全场普查", true, "census" },
    { "列出actor", true, "census" },    { "静态网格", true, "mesh" },
    { "帧率好低", true, "fps" },        { "我要高画质", true, "pretty" },
    { "我在哪", true, "whereami" },     { "传送过去", true, "tp" },
    { "穿墙", true, "noclip" },         { "复活我", true, "revive" },
    { "清怪", true, "killai" },         { "防挂机踢", true, "antiafk" },
    { "太黑了", true, "brightness" },   { "白名单状态", true, "wl" },
    { "谁在线", true, "players" },      { "64人上限", true, "maxplayer" },
    { "存档一下", true, "save" },       { "读档", true, "load" },
    { "崩溃修复", true, "crashfix" },   { "看日志", true, "logs" },
    { "体检一下", true, "diag" },       { "打开面板", true, "panel_on" },
    { "关闭面板", true, "panel_off" },  { "娱乐一下", true, "fun" },
    { "关闭安全权限", true, "safety" }, { "恢复安全", true, "safety" },
    { "安全权限", true, "safety" },     { "自由放置一个门", true, "freep" },
    { "生成狗哥", true, "spawn_kw" },   { "随便放一个", true, "freep" },
    { "生成点光源", true, "spawn_kw" }, { "查看我的参数", true, "mypara" },
    { "查看狗哥的参数", true, "listprop" }, { "把点光源的亮度设成3", true, "setprop" },
    { "把僵尸的血量设成1", true, "setprop" }, { "设置面板", true, "settab" },
    { "在方格里生成", true, "gridgen" }, { "方格里生成一个门", true, "gridgen" },
    { "方格重置", true, "gridreset" }, { "方格", true, "gridgen" },
    { "查看内存", true, "native" }, { "关闭原生采样", true, "native" },
    { "今天天气怎么样", false, "fallback" },
}

function M.SelfTest(stubLog)
    set_log_path(stubLog)
    local pass, fail = 0, 0
    for _, t in ipairs(TESTS) do
        local r = M.Resolve(t[1])
        local ok = (r.found == t[2])
        if t[2] then ok = ok and (r.tag == t[3]) else ok = ok and (r.tag == "fallback") end
        if ok then pass = pass + 1
        else
            fail = fail + 1
            log(string.format("FAIL [%s] tag=%s found=%s", t[1], tostring(r.tag), tostring(r.found)))
        end
    end
    set_log_path(nil)
    return pass, fail
end

-- ---------------------------------------------------------------- install
function M.Install(executor, deps)
    EXEC = executor
    UH = (deps and deps.UEHelpers) or nil
    if type(deps) == "table" and type(deps.logPath) == "string" then
        set_log_path(deps.logPath)
    else
        pcall(function()
            local sd = _G.JXSidecarDir or ""
            UE4SS_LOG = sd .. "../../UE4SS.log"
        end)
    end

    -- PRO gate on the jai command itself
    pcall(function()
        local JX = _G.JX
        if type(JX) == "table" then
            JX.Gates = JX.Gates or {}
            JX.Gates["jai"] = {
                Allow = function(fc) return aiAllowed() end,
                Refuse = function(need, name)
                    say("AI 是 PRO 专属：需要等级 4 以上（房主直接放行）。jwl set <名字> 4")
                end,
                need = "PRO",
            }
        end
    end)

    local function handle(FullCommand)
        local q = tostring(FullCommand or ""):match("^jai%s+(.+)$")
        if q == nil then
            say("用法：jai <随便说>，例如：jai 生成方块 / jai 帮助 / jai 看日志")
            return true
        end
        if q == "test" then
            local p, f = M.SelfTest(UE4SS_LOG)
            say("JX AI 自检：" .. p .. " 过 / " .. f .. " 挂")
            return true
        end
        if q == "index" then
            local names = build_actor_index()
            save_actor_index(names)
            local sample = {}
            for i = 1, math.min(6, #names) do sample[i] = names[i] end
            say("全场 Actor 类索引：" .. #names .. " 个（示例：" .. table.concat(sample, "、") .. "）已存 config/ai_actor_index.txt")
            return true
        end
        log("query: " .. q)
        local r = M.Resolve(q)
        for _, line in ipairs(r.replies) do say(line) end
        for _, cmd in ipairs(r.sends) do
            say("→ 执行：" .. cmd)
            send(cmd)
        end
        return true
    end

    if type(_G.JXRegCmd) == "function" then
        pcall(_G.JXRegCmd, "jai", handle)
        log("jai registered (PRO gated); system prompt: " .. #M.SYSTEM
            .. " directives; KB: " .. #KB.classes .. " native classes; catalog: "
            .. #(load_catalog()) .. " entries")
    else
        log("JXRegCmd missing - jai unavailable")
    end
    return M
end

return M
