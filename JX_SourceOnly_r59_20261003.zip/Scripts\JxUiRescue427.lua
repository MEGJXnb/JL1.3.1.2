
local UR = { version = "1.0", watching = false }

local function Say(s) print("[JxUiRescue] " .. tostring(s) .. "\n") end

local function okCall(fn)
    local ok, a, b, c = pcall(fn)
    if ok then return true, a, b, c end
    return false, a
end

local function alive(o)
    if o == nil then return false end
    local ok, v = pcall(function() return o:IsValid() end)
    return ok and v == true
end

local function PC()
    local pc = nil
    pcall(function()
        if UEHelpers and UEHelpers.GetPlayerController then
            pc = UEHelpers.GetPlayerController()
        end
    end)
    if not alive(pc) then pcall(function() pc = FindFirstOf("PlayerController") end) end
    return alive(pc) and pc or nil
end

local function WBL()
    local w = nil
    pcall(function() w = StaticFindObject("/Script/UMG.Default__WidgetBlueprintLibrary") end)
    return alive(w) and w or nil
end

local VIS = { [0] = "Visible", [1] = "Collapsed", [2] = "Hidden",
              [3] = "HitTestInvisible", [4] = "SelfHitTestInvisible" }

local function visOf(w)
    local v = -1
    pcall(function() v = tonumber(w:GetVisibility()) end)
    return v
end

local function visStr(v) return VIS[v] or ("?(" .. tostring(v) .. ")") end

local cacheW, cacheT = nil, 0
local function uiRoot()
    if cacheW and alive(cacheW) and (os.time() - cacheT) < 30 then return cacheW end
    local hit = nil
    pcall(function()
        local all = FindAllOf("UserWidget")
        if not all then return end
        for _, w in pairs(all) do
            if alive(w) then
                local s = ""
                pcall(function()
                    if w.GetFullName then s = w:GetFullName() or "" end
                end)
                for _, hint in ipairs({ "WBP_JinxingRoot", "JinxingRoot", "JinxingMain" }) do
                    if s ~= "" and s:find(hint, 1, true) then hit = w; break end
                end
                if hit then break end
            end
        end
    end)
    if hit then cacheW, cacheT = hit, os.time() end
    return hit
end

local function repairWidget(w)
    local rep = {}
    if not alive(w) then return rep end

    local v = visOf(w)
    if v == 1 or v == 2 then
        local ok = okCall(function() w:SetVisibility(0) end)
        rep[#rep + 1] = (ok and "vis " .. visStr(v) .. "->Visible") or "vis FAILED"
    end

    local invp = false
    pcall(function() invp = (w:IsInViewport() == true) end)
    if not invp then
        -- r58: z=100 sat below the rest of the tree's 10000, so a rescued shell
        -- could still be covered by the game HUD. One ZOrder for the panel.
        local ok = okCall(function() w:AddToViewport(10000) end)
        rep[#rep + 1] = (ok and "AddToViewport(z=10000)") or "viewport FAILED"
    end

    local okf, cur = okCall(function() return w.bIsFocusable end)
    if okf and cur == false then
        local ok = okCall(function() w.bIsFocusable = true end)
        rep[#rep + 1] = (ok and "focusable 0->1") or "focusable FAILED"
    end

    local oko, op = okCall(function() return w.RenderOpacity end)
    if oko and tonumber(op) == 0 then
        local ok = okCall(function() w.RenderOpacity = 1 end)
        rep[#rep + 1] = (ok and "opacity 0->1") or "opacity FAILED"
    end

    return rep
end

local function repairInput(show)
    local rep = {}
    local pc = PC()
    if not pc then return rep end
    
    local okc, cur = okCall(function() return pc.bShowMouseCursor end)
    if okc and cur ~= show then
        okCall(function() pc.bShowMouseCursor = show end)
        rep[#rep + 1] = "cursor " .. tostring(show)
    end
    
    local wbl = WBL()
    if wbl then
        if show then
            
            local ok = okCall(function() wbl:SetInputMode_GameAndUIEx(pc, nil, 0, false) end)
            rep[#rep + 1] = (ok and "mode GameAndUI") or "mode FAILED"
        else
            local ok = okCall(function() wbl:SetInputMode_GameOnly(pc) end)
            rep[#rep + 1] = (ok and "mode GameOnly") or "mode FAILED"
        end
    end
    return rep
end

local function report()
    Say("=== UI pipeline report (UE4.27) ===")
    
    local w = uiRoot()
    if alive(w) then
        local invp = "?"; pcall(function() invp = tostring(w:IsInViewport() == true) end)
        local v = visOf(w)
        local name = "?"; pcall(function() name = w:GetFullName() or "?" end)
        Say(string.format("pak root : ALIVE vis=%s inViewport=%s", visStr(v), invp))
        Say("  path: " .. name)
    else
        Say("pak root : absent (pak panel not created / pak dead)")
    end
    
    local pc = PC()
    if pc then
        local cur = "?"; pcall(function() cur = tostring(pc.bShowMouseCursor) end)
        Say("cursor   : " .. cur)
    else
        Say("cursor   : no PlayerController")
    end
    
    local jp = _G.JxPanels
    if type(jp) == "table" then
        local aliveStr = "?"
        pcall(function()
            aliveStr = (type(jp.HookAlive) == "function" and jp.HookAlive()) and "hook LIVE" or "hook dead"
        end)
        Say("canvas   : " .. aliveStr .. (jp.open and " panel OPEN" or ""))
    else
        Say("canvas   : JxPanels not loaded")
    end
    
    if type(_G.JxUiProbe) == "function" then
        local ok, r = pcall(_G.JxUiProbe)
        if ok and r then
            Say("probe    : core=" .. tostring(r.coreState) .. " pakui=" .. tostring(r.uirootState)
                .. " f6=" .. tostring(r.f6State) .. " pakClass=" .. tostring(r.pakClassLoadable))
        end
    end
    Say("fix      : 'juix fix' force-repairs widget+input; 'juix watch on' auto-holds")
end

local function treeDump()
    local w = uiRoot()
    if not alive(w) then
        Say("tree: no pak UI root to dump")
        return
    end
    local function walk(node, depth, seen)
        if not alive(node) or depth > 6 then return end
        if seen[node] then return end
        seen[node] = true
        local cls = "?"
        pcall(function() cls = node:GetClass():GetName() end)
        local v = visOf(node)
        Say(string.format("%s%s [%s]", string.rep("  ", depth), tostring(cls), visStr(v)))
        local kids = nil
        pcall(function() kids = node.WidgetTree end)
        
        local slots = { "JxSearchRow0", "JxSearchRow1", "JxSearchStatus", "WidgetTree" }
        for _, s in ipairs(slots) do
            local c = nil
            pcall(function() c = node[s] end)
            if alive(c) and not seen[c] then walk(c, depth + 1, seen) end
        end
    end
    Say("=== pak widget tree (named slots, depth<=6) ===")
    walk(w, 0, {})
end

local function watchTick()
    local anyOpen = false
    
    local w = uiRoot()
    if alive(w) then
        local v = visOf(w)
        local invp = false
        pcall(function() invp = (w:IsInViewport() == true) end)
        if v == 0 and invp then
            anyOpen = true
            
            repairInput(true)
        end
    end
    
    local jp = _G.JxPanels
    if not anyOpen and type(jp) == "table" and jp.open then
        anyOpen = true
        repairInput(true)
    end
    
    if not anyOpen and UR.holding then
        repairInput(false)
        UR.holding = false
    elseif anyOpen then
        UR.holding = true
    end
    return true
end

local function watchOn(on)
    UR.watching = on
    if on and type(LoopAsync) == "function" then
        Say("watch ON: cursor/input re-asserted every 5 s while a panel is open")
        LoopAsync(5000, function()
            if not UR.watching then return false end
            if type(ExecuteInGameThread) == "function" then
                pcall(ExecuteInGameThread, function() pcall(watchTick) end)
            else
                pcall(watchTick)
            end
            return UR.watching
        end)
    elseif on then
        Say("watch requested but LoopAsync unavailable")
        UR.watching = false
    else
        Say("watch OFF (loop stops on next tick)")
    end
end

if type(JXRegCmd) == "function" then
    JXRegCmd("juix", function(FullCommand, Parameters)
        local sub = ((Parameters and Parameters[1]) or "report"):lower()
        local wrap = function(fn)
            if type(ExecuteInGameThread) == "function" then
                pcall(ExecuteInGameThread, function() pcall(fn) end)
            else
                pcall(fn)
            end
            return true
        end
        if sub == "report" or sub == "status" then
            return wrap(report)
        elseif sub == "tree" then
            return wrap(treeDump)
        elseif sub == "fix" then
            return wrap(function()
                Say("=== juix fix ===")
                local w = uiRoot()
                if alive(w) then
                    local rep = repairWidget(w)
                    local irep = repairInput(visOf(w) == 0)
                    for _, r in ipairs(rep) do Say("widget: " .. r) end
                    for _, r in ipairs(irep) do Say("input : " .. r) end
                    if #rep == 0 and #irep == 0 then Say("nothing to repair (already sane)") end
                else
                    Say("no pak widget to fix; repairing input only")
                    local irep = repairInput(false)
                    for _, r in ipairs(irep) do Say("input : " .. r) end
                end
            end)
        elseif sub == "watch" then
            local onoff = ((Parameters and Parameters[2]) or "on"):lower()
            watchOn(onoff ~= "off" and onoff ~= "0" and onoff ~= "false")
            return true
        else
            Say("usage: juix report|tree|fix|watch on|off")
            return true
        end
    end)
elseif type(RegisterConsoleCommandHandler) == "function" then
    
    pcall(RegisterConsoleCommandHandler, "juix", function(FullCommand, Parameters)
        pcall(function()
            local sub = ((Parameters and Parameters[1]) or "report"):lower()
            local run = function(fn)
                if type(ExecuteInGameThread) == "function" then
                    pcall(ExecuteInGameThread, function() pcall(fn) end)
                else
                    pcall(fn)
                end
            end
            if sub == "report" or sub == "status" then
                run(report)
            elseif sub == "tree" then
                run(treeDump)
            elseif sub == "fix" then
                run(function()
                    Say("=== juix fix ===")
                    local w = uiRoot()
                    if alive(w) then
                        local rep = repairWidget(w)
                        local irep = repairInput(visOf(w) == 0)
                        for _, r in ipairs(rep) do Say("widget: " .. r) end
                        for _, r in ipairs(irep) do Say("input : " .. r) end
                        if #rep == 0 and #irep == 0 then Say("nothing to repair (already sane)") end
                    else
                        Say("no pak widget to fix; repairing input only")
                        for _, r in ipairs(repairInput(false)) do Say("input : " .. r) end
                    end
                end)
            elseif sub == "watch" then
                local onoff = ((Parameters and Parameters[2]) or "on"):lower()
                watchOn(onoff ~= "off" and onoff ~= "0" and onoff ~= "false")
            else
                Say("usage: juix report|tree|fix|watch on|off")
            end
        end)
        return true
    end)
end

if type(ExecuteWithDelay) == "function" and type(ExecuteInGameThread) == "function" then
    ExecuteWithDelay(10000, function()
        pcall(function()
            ExecuteInGameThread(function() pcall(report) end)
        end)
    end)
end

_G.JxUiRescue427 = UR
Say("v" .. UR.version .. " ready: juix report|tree|fix|watch (UE4.27)")
return UR
